<?php
require('init.php');

$input = json_decode(file_get_contents("php://input"), true);
$param = array_merge($_REQUEST, (array) $input);

TTransaction::open(MAIN_DATABASE);
    
$webhookLog = new WebhookLog();
$webhookLog->gateway_pagamento_id = SaasGatewayPagamento::MERCADO_PAGO;
$webhookLog->payload = json_encode($request);
$webhookLog->store();

TTransaction::close();

try
{
    TTransaction::open(MAIN_DATABASE);
    //https://www.mercadopago.com.br/developers/panel
    
    if(!empty($param['type']) && $param['type'] == 'subscription_authorized_payment' && !empty($param['data_id']))
    {
        
        $service = new GatewayPagamentoService(new SaasGatewayPagamento(SaasGatewayPagamento::MERCADO_PAGO));
        $payment = $service->getPayment($param['data_id']);
        
        if(!empty($payment['preapproval_id']))
        {
            SaasPagamentoService::verificaAssinatura($payment['preapproval_id']);
        }
    }
    elseif(!empty($param['type']) && $param['type'] == 'subscription_preapproval' && !empty($param['data_id']))
    {
        SaasPagamentoService::verificaAssinatura($param['data_id']);
    }
    elseif(!empty($param['preapproval_id'])) // primeira assinatura
    {
        SaasPagamentoService::verificaAssinatura($param['preapproval_id']);
    }
    elseif (!empty($param['external_reference']))
    {
        SaasPagamentoService::atualizar($param['external_reference'], $param['status'], $param['payment_type']);
    }
    
    if (TSession::getValue('logged'))
    {
        $user = SystemUsers::find(TSession::getValue('userid'));
        
        ApplicationAuthenticationService::loadSessionVars($user);
    }
    
    
    TTransaction::close();
    
    TScript::create("window.location.href = 'index.php?class=SaasMinhaContaDashboard&method=onShow'");
}
catch (Exception $e)
{
    TTransaction::rollback();
    die($e->getMessage());
}