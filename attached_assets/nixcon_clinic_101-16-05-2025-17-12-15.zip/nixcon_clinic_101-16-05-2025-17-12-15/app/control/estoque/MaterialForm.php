<?php

class MaterialForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Material';
    private static $primaryKey = 'id';
    private static $formName = 'form_Material';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de material");

        $criteria_clinica_id = new TCriteria();
        $criteria_unidade_medida_id = new TCriteria();

        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_clinica_id->add(new TFilter('id', 'in', $filterVar)); 

        $id = new TEntry('id');
        $clinica_id = new TDBCombo('clinica_id', 'clinica', 'Clinica', 'id', '{nome}','nome asc' , $criteria_clinica_id );
        $nome = new TEntry('nome');
        $lote = new TEntry('lote');
        $estoque_minimo = new TNumeric('estoque_minimo', '2', ',', '.' );
        $dt_vencimento = new TDate('dt_vencimento');
        $ativo = new TRadioGroup('ativo');
        $estoque_atualizado = new TNumeric('estoque_atualizado', '2', ',', '.' );
        $unidade_medida_id = new TDBCombo('unidade_medida_id', 'clinica', 'UnidadeMedida', 'id', '{nome}','nome asc' , $criteria_unidade_medida_id );

        $clinica_id->addValidation("Clínica", new TRequiredValidator()); 
        $nome->addValidation("Nome", new TRequiredValidator()); 
        $ativo->addValidation("Ativo", new TRequiredValidator()); 
        $unidade_medida_id->addValidation("Unidade de medida", new TRequiredValidator()); 

        $id->setEditable(false);
        $dt_vencimento->setMask('dd/mm/yyyy');
        $dt_vencimento->setDatabaseMask('yyyy-mm-dd');
        $ativo->addItems(["T"=>"Sim","F"=>"Não"]);
        $ativo->setLayout('horizontal');
        $ativo->setUseButton();
        $ativo->setValue('S');
        $clinica_id->setValue(PermissaoService::getUnidadeDefault());

        $clinica_id->enableSearch();
        $unidade_medida_id->enableSearch();

        $id->setSize(100);
        $ativo->setSize(80);
        $nome->setSize('100%');
        $lote->setSize('100%');
        $clinica_id->setSize('100%');
        $dt_vencimento->setSize(110);
        $estoque_minimo->setSize('100%');
        $unidade_medida_id->setSize('100%');
        $estoque_atualizado->setSize('100%');

        $row1 = $this->form->addFields([new TLabel("Código:", null, '14px', null, '100%'),$id],[new TLabel("Clínica:", '#FF0000', '14px', null, '100%'),$clinica_id]);
        $row1->layout = ['col-sm-6',' col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$nome],[new TLabel("Lote:", null, '14px', null, '100%'),$lote]);
        $row2->layout = [' col-sm-6','col-sm-6'];

        $row3 = $this->form->addFields([new TLabel("Estoque mínimo:", null, '14px', null, '100%'),$estoque_minimo],[new TLabel("Vencimento:", null, '14px', null, '100%'),$dt_vencimento],[new TLabel("Ativo:", '#FF0000', '14px', null, '100%'),$ativo]);
        $row3->layout = ['col-sm-3','col-sm-3','col-sm-2'];

        $row4 = $this->form->addFields([new TLabel("Estoque inicial:", null, '14px', null),$estoque_atualizado],[new TLabel("Unidade de medida:", '#FF0000', '14px', null),$unidade_medida_id]);
        $row4->layout = [' col-sm-4',' col-sm-5'];

        if (! empty($param['key']))
        {
            $row4->style =  'display: none';
        }

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['MaterialList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=MaterialForm]');
        $style->width = '50% !important';   
        $style->show(true);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Material(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('MaterialList', 'onShow', $loadPageParam); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Material($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

