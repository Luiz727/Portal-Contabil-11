<?php

class AtendimentoTimeLine extends TPage
{
    private static $database = 'clinica';
    private static $activeRecord = 'Atendimento';
    private static $primaryKey = 'id';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null )
    {
        try
        {
            parent::__construct();

            TTransaction::open(self::$database);

            if(!empty($param['target_container']))
            {
                $this->adianti_target_container = $param['target_container'];
            }

            $this->timeline = new TTimeline;
            $this->timeline->setItemDatabase(self::$database);
            $this->timelineCriteria = new TCriteria;

            if(!empty($param['paciente_id']??''))
        {
            TSession::setValue(__CLASS__.'load_filter_paciente_id', $param['paciente_id']??'');
        }
        $filterVar = TSession::getValue(__CLASS__.'load_filter_paciente_id');
            $this->timelineCriteria->add(new TFilter('paciente_id', '=', $filterVar));
            $filterVar = PermissaoService::getUnidadeIds();
            $this->timelineCriteria->add(new TFilter('clinica_id', 'in', $filterVar));

            $limit = 0;

            $this->timelineCriteria->setProperty('limit', $limit);
            $this->timelineCriteria->setProperty('order', 'id asc');

            $objects = Atendimento::getObjects($this->timelineCriteria);

            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {

                    $object->dt_inicio = call_user_func(function($value, $object, $row)
                    {
                        if(!empty(trim((string) $value)))
                        {
                            try
                            {
                                $date = new DateTime($value);
                                return $date->format('d/m/Y H:i');
                            }
                            catch (Exception $e)
                            {
                                return $value;
                            }
                        }
                    }, $object->dt_inicio, $object, null);

                    $id = $object->id;
                    $title = "Atendimento #{id}";
                    $htmlTemplate = "Agenda: <b>{agendamento->agenda->nome}</b><br/>
Convênio: <b>{agendamento->agendamento_procedimento_convenio_to_string} </b><br/>
Profissional: <b>{profissional->nome_formatado}</b><br/>
Clínica: <b>{agendamento->agenda->clinica->nome}</b>";
                    $date = $object->dt_inicio;
                    $icon = 'fa:arrow-left bg-green';
                    $position = 'left';

                    if(empty($positionValue[$object->dt_inicio]))
                    {
                        $lastPosition = (empty($lastPosition) || $lastPosition == 'right') ? 'left' : 'right';
                        $bg = ($lastPosition == 'left') ? 'bg-green' : 'bg-blue';

                        $positionValue[$object->dt_inicio]['position'] = $lastPosition;
                        $positionValue[$object->dt_inicio]['bg'] = $bg;
                        $position = $positionValue[$object->dt_inicio]['position'];
                        $icon = "fa:arrow-{$lastPosition} {$bg}";
                    }
                    else
                    {
                        $position = $positionValue[$object->dt_inicio]['position'];
                        $lastPosition = $position;
                        $icon = "fa:arrow-{$lastPosition} {$positionValue[$object->dt_inicio]['bg']}";
                    }

                    $this->timeline->addItem($id, $title, $htmlTemplate, $date, $icon, $position, $object);

                }
            }

            $this->timeline->setUseBothSides();
            $this->timeline->setTimeDisplayMask('dd/mm/yyyy');
            $this->timeline->setFinalIcon( 'fas:flag-checkered #ffffff #FF9800' );

            $action_AtendimentoTimeLine_onAbriAtendimento = new TAction(['AtendimentoTimeLine', 'onAbriAtendimento'], ['key'=> '{id}']);
            $action_AtendimentoTimeLine_onAbriAtendimento->setParameter('id', '{id}');
            $action_AtendimentoTimeLine_onAbriAtendimento->setProperty('btn-class', 'btn btn-default');
            $this->timeline->addAction($action_AtendimentoTimeLine_onAbriAtendimento, "Acessar atendimento", 'fas:dot-circle #FF9800','AtendimentoTimeLine::podeExibir'); 

            $container = new TVBox;

            $container->style = 'width: 100%';
            $container->class = 'form-container';

            parent::setTargetContainer('adianti_right_panel');
            $container->style .= '; padding: 0 15px';
            $div = new TElement('div');
            $div->style = 'margin-top: 20px; margin-right: 20px; float: right';

            $btnClose = new TButton('closeCurtain');
            $btnClose->class = 'btn btn-sm btn-default';

            $btnClose->onClick = "Template.closeRightPanel();";
            $btnClose->setLabel("Fechar");
            $btnClose->setImage('fas:times');

            $div->add($btnClose);
            $container->add($div);
            $container->add($this->timeline);

            $header = new TElement('div');
            $header->class = 'card-header panel-heading';
            $header->style = 'margin: 0px -15px;';
            $header->add(TElement::tag('div', 'Time line de atendimentos', ['class' => 'panel-title card-title']));
            $container->insert(0,$header);

            $div->style = 'position: absolute; right: 20px; top: 6px;';

            $style = new TStyle('right-panel > .container-part[page-name=AtendimentoTimeLine]');
            $style->width = '75% !important';   
            $style->show(true);

            TTransaction::close();

            parent::add($container);
        }
        catch(Exception $e)
        {
            new TMessage('error', $e->getMessage());
        }
    }

    public  static  function onAbriAtendimento($param = null) 
    {
        try 
        {
            TScript::create('Template.closeRightPanel();');

            $pageParam = [
                'id' => $param['id'],
                'key' => $param['key']
            ]; // ex.: = ['key' => 10]

            TApplication::loadPage('AtendimentoFormView', 'onShow', $pageParam);

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function podeExibir($object)
    {
        try 
        {
            return AtendimentoService::podeManipular($object, TSession::getValue('userid'));
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onShow($param = null)
    {

// 

    } 

}

