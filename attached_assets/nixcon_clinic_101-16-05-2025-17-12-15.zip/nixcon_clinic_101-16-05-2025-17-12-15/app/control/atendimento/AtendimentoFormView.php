<?php

class AtendimentoFormView extends TPage
{
    protected $form; // form
    private static $database = 'clinica';
    private static $activeRecord = 'Atendimento';
    private static $primaryKey = 'id';
    private static $formName = 'formView_Atendimento';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        TTransaction::open(self::$database);
        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        $this->form->setTagName('div');

        $atendimento = new Atendimento($param['key']);
        // define the form title
        $this->form->setFormTitle("Atendimento {$param['key']}");

        $transformed_atendimento_agendamento_observacao = call_user_func(function($value, $object, $row)
        {
            return $value ? $value : '-';

        }, $atendimento->agendamento->observacao, $atendimento, null);    

        $transformed_atendimento_agendamento_online = call_user_func(function($value, $object, $row)
        {
            if ($value == 'T' && empty($object->dt_final))
            {
                $button = new TElement('a');
                $button->class = 'btn btn-block btn-success';
                $button->target = '_blank';
                $button->href = 'https://meet.jit.si/' . $object->agendamento->link_atendimento_online . "#userInfo.displayName=\"{$object->profissional->nome}\"";
                $button->add(TElement::tag('i', '', ['class' => 'fas fa-video']));
                $button->add(TElement::tag('span', 'Entrar no atendimento'));
                return $button;
            }

            return '';

        }, $atendimento->agendamento->online, $atendimento, null);

        TTransaction::open(self::$database);
        $criteria = new TCriteria;
        $criteria->add(new TFilter('ativo', '=', 'S'));
        $criteria->add(new TFilter('clinica_id', 'in', PermissaoService::getUnidadeIds()));

        $tipos = Formulario::getIndexedArray('id', 'nome', $criteria);
        $tipos_formularios = '<span style="font-weight: normal">Formulários disponíveis:</span><br/>' . implode(', ', $tipos);
        TTransaction::close();

        $label2 = new TLabel("Paciente:", '', '14px', 'B', '100%');
        $text4 = new TTextDisplay($atendimento->paciente->nome_formatado, '', '16px', '');
        $label211 = new TLabel("Agenda:", '', '14px', 'B', '100%');
        $text32 = new TTextDisplay($atendimento->agendamento->agenda->nome, '', '16px', '');
        $label6 = new TLabel("Data início:", '', '14px', 'B', '100%');
        $text5 = new TTextDisplay(TDateTime::convertToMask($atendimento->dt_inicio, 'yyyy-mm-dd hh:ii', 'dd/mm/yyyy hh:ii'), '', '16px', '');
        $label4 = new TLabel("Observações do agendamento", '', '14px', 'B', '100%');
        $text544 = new TTextDisplay($transformed_atendimento_agendamento_observacao, '', '16px', '');
        $text3 = new TTextDisplay($transformed_atendimento_agendamento_online, '', '12px', '');
        $action2 = new TActionLink("Adicionar procedimento", new TAction(['AtendimentoProcedimentoForm', 'onShow'], ['atendimento_id'=> $atendimento->id]), '', '12px', '', 'fas:plus #4CAF50');
        $actionExame = new TActionLink("Adicionar exame", new TAction(['ExameAtendimentoForm', 'onShow'], ['atendimento_id'=> $atendimento->id]), '', '12px', '', 'fas:plus #4CAF50');
        $action22 = new TActionLink("Adicionar material", new TAction(['AtendimentoMaterialForm', 'onShow'], ['atendimento_id'=> $atendimento->id]), '', '12px', '', 'fas:plus #4CAF50');
        $action6 = new TActionLink("Adicionar materiais padrões de um procedimento", new TAction(['AdicionarMateriaisProcedimentoForm', 'onShow'], ['atendimento_id'=> $atendimento->id]), '', '12px', '', 'fas:cart-plus #CDDC39');
        $actionAnexo = new TActionLink("Adicionar anexo", new TAction(['AnexoForm', 'onShow'], ['atendimento_id'=> $atendimento->id]), '', '12px', '', 'fas:plus #4CAF50');
        $actionPreescrucao = new TActionLink("Adicionar prescrição", new TAction(['PrescricaoForm', 'onShow'], ['atendimento_id'=> $atendimento->id]), '', '12px', '', 'fas:plus #4CAF50');
        $action2Atestado = new TActionLink("Adicionar documento", new TAction(['DocumentoForm', 'onShow'], ['atendimento_id'=> $atendimento->id]), '', '12px', '', 'fas:plus #4CAF50');
        $labelFormulario = new TLabel("{$tipos_formularios}", '', '12px', '', '100%');
        $action2aaa = new TActionLink("Preencher novo formulário", new TAction(['RespostaFormularioForm', 'onShow'], ['atendimento_id'=> $atendimento->id]), '', '12px', '', 'fas:plus #4CAF50');

        $action2->class = 'btn btn-default';
        $action6->class = 'btn btn-default';
        $action22->class = 'btn btn-default';
        $action2aaa->class = 'btn btn-default';
        $actionExame->class = 'btn btn-default';
        $actionAnexo->class = 'btn btn-default';
        $action2Atestado->class = 'btn btn-default';
        $actionPreescrucao->class = 'btn btn-default';

        $row1 = $this->form->addFields([$label2,$text4],[$label211,$text32],[$label6,$text5]);
        $row1->layout = [' col-sm-6',' col-sm-3','col-sm-3'];

        $row2 = $this->form->addFields([$label4,$text544]);
        $row2->layout = [' col-sm-12'];

        $row3 = $this->form->addFields([$text3]);
        $row3->layout = [' col-sm-12'];

        $abas = new BootstrapFormBuilder('abas');
        $this->abas = $abas;
        $abas->setProperty('style', 'border:none; box-shadow:none;');

        $abas->appendPage("Procedimentos");

        $abas->addFields([new THidden('current_tab_abas')]);
        $abas->setTabFunction("$('[name=current_tab_abas]').val($(this).attr('data-current_page'));");

        $row4 = $abas->addFields([$action2]);
        $row4->layout = [' col-sm-12'];

        $this->atendimento_procedimento_atendimento_id_list = new TQuickGrid;
        $this->atendimento_procedimento_atendimento_id_list->style = 'width:100%';
        $this->atendimento_procedimento_atendimento_id_list->disableDefaultClick();

        $action_onEdit = new TDataGridAction(array('AtendimentoProcedimentoForm', 'onEdit'));
        $action_onEdit->setUseButton(false);
        $action_onEdit->setButtonClass('btn btn-default btn-sm');
        $action_onEdit->setLabel("");
        $action_onEdit->setImage('far:edit #2196F3');
        $action_onEdit->setField('id');

        $action_onEdit->setParameter('atendimento_id', '{atendimento_id}');
        $this->atendimento_procedimento_atendimento_id_list->addAction($action_onEdit);

        $action_onExcuirProcedimento = new TDataGridAction(array('AtendimentoFormView', 'onExcuirProcedimento'));
        $action_onExcuirProcedimento->setUseButton(false);
        $action_onExcuirProcedimento->setButtonClass('btn btn-default btn-sm');
        $action_onExcuirProcedimento->setLabel("");
        $action_onExcuirProcedimento->setImage('far:trash-alt #F44336');
        $action_onExcuirProcedimento->setField('id');

        $this->atendimento_procedimento_atendimento_id_list->addAction($action_onExcuirProcedimento);

        $column_procedimento_nome = $this->atendimento_procedimento_atendimento_id_list->addQuickColumn("Procedimento", 'procedimento->nome', 'left' , '60%');
        $column_valor_transformed = $this->atendimento_procedimento_atendimento_id_list->addQuickColumn("Valor", 'valor', 'left');
        $column_quantidade_transformed = $this->atendimento_procedimento_atendimento_id_list->addQuickColumn("Quantidade", 'quantidade', 'center' , '150px');
        $column_valor_total_transformed = $this->atendimento_procedimento_atendimento_id_list->addQuickColumn("Valor total", 'valor_total', 'right');

        $column_valor_total_transformed->setTotalFunction( function($values) { 
            return array_sum((array) $values); 
        }); 

        $column_valor_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });

        $column_quantidade_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            return number_format($value, 2, ',', '.');

        });

        $column_valor_total_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });

        $this->atendimento_procedimento_atendimento_id_list->createModel();

        $criteria_atendimento_procedimento_atendimento_id = new TCriteria();
        $criteria_atendimento_procedimento_atendimento_id->add(new TFilter('atendimento_id', '=', $atendimento->id));

        $criteria_atendimento_procedimento_atendimento_id->setProperty('order', 'id desc');

        $atendimento_procedimento_atendimento_id_items = AtendimentoProcedimento::getObjects($criteria_atendimento_procedimento_atendimento_id);

        $this->atendimento_procedimento_atendimento_id_list->addItems($atendimento_procedimento_atendimento_id_items);

        $panel = new TElement('div');
        $panel->class = 'formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->atendimento_procedimento_atendimento_id_list));

        $abas->addContent([$panel]);

        $abas->appendPage("Exames");
        $row5 = $abas->addFields([$actionExame]);
        $row5->layout = [' col-sm-12'];

        $this->exame_atendimento_atendimento_id_list = new TQuickGrid;
        $this->exame_atendimento_atendimento_id_list->style = 'width:100%';
        $this->exame_atendimento_atendimento_id_list->disableDefaultClick();

        $action_onEdit = new TDataGridAction(array('ExameAtendimentoForm', 'onEdit'));
        $action_onEdit->setUseButton(false);
        $action_onEdit->setButtonClass('btn btn-default btn-sm');
        $action_onEdit->setLabel("");
        $action_onEdit->setImage('far:edit #2196F3');
        $action_onEdit->setField('id');

        $this->exame_atendimento_atendimento_id_list->addAction($action_onEdit);

        $action_onDeleteExame = new TDataGridAction(array('AtendimentoFormView', 'onDeleteExame'));
        $action_onDeleteExame->setUseButton(false);
        $action_onDeleteExame->setButtonClass('btn btn-default btn-sm');
        $action_onDeleteExame->setLabel("");
        $action_onDeleteExame->setImage('far:trash-alt #F44336');
        $action_onDeleteExame->setField('id');

        $this->exame_atendimento_atendimento_id_list->addAction($action_onDeleteExame);

        $column_indicacao_clinica = $this->exame_atendimento_atendimento_id_list->addQuickColumn("Indicação clínica", 'indicacao_clinica', 'left');
        $column_exame_nome = $this->exame_atendimento_atendimento_id_list->addQuickColumn("Exame", 'exame->nome', 'left');
        $column_quantidade = $this->exame_atendimento_atendimento_id_list->addQuickColumn("Quantidade", 'quantidade', 'center' , '100px');
        $column_dt_exames_transformed = $this->exame_atendimento_atendimento_id_list->addQuickColumn("Data", 'dt_exames', 'center' , '100px');

        $column_dt_exames_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $this->exame_atendimento_atendimento_id_list->createModel();

        $criteria_exame_atendimento_atendimento_id = new TCriteria();
        $criteria_exame_atendimento_atendimento_id->add(new TFilter('atendimento_id', '=', $atendimento->id));

        $criteria_exame_atendimento_atendimento_id->setProperty('order', 'id desc');

        $exame_atendimento_atendimento_id_items = ExameAtendimento::getObjects($criteria_exame_atendimento_atendimento_id);

        $this->exame_atendimento_atendimento_id_list->addItems($exame_atendimento_atendimento_id_items);

        $panel = new TElement('div');
        $panel->class = 'formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->exame_atendimento_atendimento_id_list));

        $abas->addContent([$panel]);

        $abas->appendPage("Materiais");
        $row6 = $abas->addFields([$action22,$action6]);
        $row6->layout = [' col-sm-12'];

        $this->atendimento_material_atendimento_id_list = new TQuickGrid;
        $this->atendimento_material_atendimento_id_list->style = 'width:100%';
        $this->atendimento_material_atendimento_id_list->disableDefaultClick();

        $action_onEdit = new TDataGridAction(array('AtendimentoMaterialForm', 'onEdit'));
        $action_onEdit->setUseButton(false);
        $action_onEdit->setButtonClass('btn btn-default btn-sm');
        $action_onEdit->setLabel("");
        $action_onEdit->setImage('far:edit #2196F3');
        $action_onEdit->setField('id');

        $action_onEdit->setParameter('key', '{id}');
        $this->atendimento_material_atendimento_id_list->addAction($action_onEdit);

        $action_onExcluirMaterial = new TDataGridAction(array('AtendimentoFormView', 'onExcluirMaterial'));
        $action_onExcluirMaterial->setUseButton(false);
        $action_onExcluirMaterial->setButtonClass('btn btn-default btn-sm');
        $action_onExcluirMaterial->setLabel("");
        $action_onExcluirMaterial->setImage('far:trash-alt #F44336');
        $action_onExcluirMaterial->setField('id');

        $this->atendimento_material_atendimento_id_list->addAction($action_onExcluirMaterial);

        $column_material_nome = $this->atendimento_material_atendimento_id_list->addQuickColumn("Material", 'material->nome', 'left');
        $column_quantidade_transformed1 = $this->atendimento_material_atendimento_id_list->addQuickColumn("Quantidade", 'quantidade', 'right' , '150px');

        $column_quantidade_transformed1->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            return number_format($value, 2, ',', '.');

        });

        $this->atendimento_material_atendimento_id_list->createModel();

        $criteria_atendimento_material_atendimento_id = new TCriteria();
        $criteria_atendimento_material_atendimento_id->add(new TFilter('atendimento_id', '=', $atendimento->id));

        $criteria_atendimento_material_atendimento_id->setProperty('order', 'id desc');

        $atendimento_material_atendimento_id_items = AtendimentoMaterial::getObjects($criteria_atendimento_material_atendimento_id);

        $this->atendimento_material_atendimento_id_list->addItems($atendimento_material_atendimento_id_items);

        $panel = new TElement('div');
        $panel->class = 'formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->atendimento_material_atendimento_id_list));

        $abas->addContent([$panel]);

        $abas->appendPage("Anexos");
        $row7 = $abas->addFields([$actionAnexo]);
        $row7->layout = [' col-sm-12'];

        $this->anexo_atendimento_id_list = new TQuickGrid;
        $this->anexo_atendimento_id_list->style = 'width:100%';
        $this->anexo_atendimento_id_list->disableDefaultClick();

        $action_onEdit = new TDataGridAction(array('AnexoForm', 'onEdit'));
        $action_onEdit->setUseButton(false);
        $action_onEdit->setButtonClass('btn btn-default btn-sm');
        $action_onEdit->setLabel("");
        $action_onEdit->setImage('far:edit #2196F3');
        $action_onEdit->setField('id');

        $this->anexo_atendimento_id_list->addAction($action_onEdit);

        $action_onRemoveAnexo = new TDataGridAction(array('AtendimentoFormView', 'onRemoveAnexo'));
        $action_onRemoveAnexo->setUseButton(false);
        $action_onRemoveAnexo->setButtonClass('btn btn-default btn-sm');
        $action_onRemoveAnexo->setLabel("");
        $action_onRemoveAnexo->setImage('far:trash-alt #F44336');
        $action_onRemoveAnexo->setField('id');

        $this->anexo_atendimento_id_list->addAction($action_onRemoveAnexo);

        $column_arquivo_transformed = $this->anexo_atendimento_id_list->addQuickColumn("Arquivo", 'arquivo', 'center' , '150px');
        $column_observacao = $this->anexo_atendimento_id_list->addQuickColumn("Observação", 'observacao', 'left');

        $column_arquivo_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            if(!$value)
            {
                return '';
            }
            return "
                <a href='download.php?file={$value}' class='btn btn-sm btn-default' target='_blank'>
                    <i class = 'fas fa-file-download'></i> Download 
                </a>
            ";

        });

        $this->anexo_atendimento_id_list->createModel();

        $criteria_anexo_atendimento_id = new TCriteria();
        $criteria_anexo_atendimento_id->add(new TFilter('atendimento_id', '=', $atendimento->id));

        $criteria_anexo_atendimento_id->setProperty('order', 'arquivo desc');

        $anexo_atendimento_id_items = Anexo::getObjects($criteria_anexo_atendimento_id);

        $this->anexo_atendimento_id_list->addItems($anexo_atendimento_id_items);

        $panel = new TElement('div');
        $panel->class = 'formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->anexo_atendimento_id_list));

        $abas->addContent([$panel]);

        $abas->appendPage("Prescrição");
        $row8 = $abas->addFields([$actionPreescrucao]);
        $row8->layout = [' col-sm-12'];

        $this->prescricao_atendimento_id_list = new TQuickGrid;
        $this->prescricao_atendimento_id_list->style = 'width:100%';
        $this->prescricao_atendimento_id_list->disableDefaultClick();

        $action_onEdit = new TDataGridAction(array('PrescricaoForm', 'onEdit'));
        $action_onEdit->setUseButton(false);
        $action_onEdit->setButtonClass('btn btn-default btn-sm');
        $action_onEdit->setLabel("");
        $action_onEdit->setImage('far:edit #2196F3');
        $action_onEdit->setField('id');

        $this->prescricao_atendimento_id_list->addAction($action_onEdit);

        $action_onExcluirPrescricao = new TDataGridAction(array('AtendimentoFormView', 'onExcluirPrescricao'));
        $action_onExcluirPrescricao->setUseButton(false);
        $action_onExcluirPrescricao->setButtonClass('btn btn-default btn-sm');
        $action_onExcluirPrescricao->setLabel("");
        $action_onExcluirPrescricao->setImage('far:trash-alt #F44336');
        $action_onExcluirPrescricao->setField('id');

        $this->prescricao_atendimento_id_list->addAction($action_onExcluirPrescricao);

        $action_onGenerate = new TDataGridAction(array('PrescricaoDocument', 'onGenerate'));
        $action_onGenerate->setUseButton(false);
        $action_onGenerate->setButtonClass('btn btn-default btn-sm');
        $action_onGenerate->setLabel("Imprimir");
        $action_onGenerate->setImage('far:file-pdf #673AB7');
        $action_onGenerate->setField('id');

        $action_onGenerate->setParameter('key', '{id}');
        $this->prescricao_atendimento_id_list->addAction($action_onGenerate);

        $column_id_transformed = $this->prescricao_atendimento_id_list->addQuickColumn("Medicamentos", 'id', 'left');
        $column_dt_prescricao_transformed = $this->prescricao_atendimento_id_list->addQuickColumn("Data", 'dt_prescricao', 'center' , '150px');
        $column_controle_especial_transformed = $this->prescricao_atendimento_id_list->addQuickColumn("Controle especial", 'controle_especial', 'center' , '200px');

        $column_id_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            $medicamentos = $object->getMedicamentos();

            $table = "<table class='table table-sm' style='width: 100%'>";

            if ($medicamentos)
            {
                $table .= "<thead><tr><th>Medicamento</th> <th>Posologia</th> <th>Qtde.</th></tr></thead>";

                foreach ($medicamentos as $medicamento)
                {
                    $table .= "<tr><td>{$medicamento->medicamento}</td> <td>{$medicamento->posologia}</td> <td>{$medicamento->quantidade}</td></tr>";
                }
            }

            $table .= "</table>";
            return $table;

        });

        $column_dt_prescricao_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_controle_especial_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            $label = new TElement('span');
            $label->{'class'} = 'label label-';

            if ($value == 'S' || $value == 'T') {
                $label->{'class'} .= 'success';
                $label->add('Sim');    

                return $label;
            }

            $label->{'class'} .= 'danger';
            $label->add('Não');

            return $label;
        });

        $this->prescricao_atendimento_id_list->createModel();

        $criteria_prescricao_atendimento_id = new TCriteria();
        $criteria_prescricao_atendimento_id->add(new TFilter('atendimento_id', '=', $atendimento->id));

        $criteria_prescricao_atendimento_id->setProperty('order', 'id desc');

        $prescricao_atendimento_id_items = Prescricao::getObjects($criteria_prescricao_atendimento_id);

        $this->prescricao_atendimento_id_list->addItems($prescricao_atendimento_id_items);

        $panel = new TElement('div');
        $panel->class = 'formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->prescricao_atendimento_id_list));

        $abas->addContent([$panel]);

        $abas->appendPage("Documentos/Laudos");
        $row9 = $abas->addFields([$action2Atestado]);
        $row9->layout = [' col-sm-12'];

        $this->documento_atendimento_id_list = new TQuickGrid;
        $this->documento_atendimento_id_list->style = 'width:100%';
        $this->documento_atendimento_id_list->disableDefaultClick();

        $action_onInvalidarDocumento = new TDataGridAction(array('AtendimentoFormView', 'onInvalidarDocumento'));
        $action_onInvalidarDocumento->setUseButton(false);
        $action_onInvalidarDocumento->setButtonClass('btn btn-default btn-sm');
        $action_onInvalidarDocumento->setLabel("Invalidar");
        $action_onInvalidarDocumento->setImage('fas:ban #F44336');
        $action_onInvalidarDocumento->setField('id');
        $action_onInvalidarDocumento->setDisplayCondition('AtendimentoFormView::canInvalidar');

        $this->documento_atendimento_id_list->addAction($action_onInvalidarDocumento);

        $action_onGenerate = new TDataGridAction(array('DocumentoDocument', 'onGenerate'));
        $action_onGenerate->setUseButton(false);
        $action_onGenerate->setButtonClass('btn btn-default btn-sm');
        $action_onGenerate->setLabel("Imprimir");
        $action_onGenerate->setImage('far:file-pdf #9C27B0');
        $action_onGenerate->setField('id');

        $action_onGenerate->setParameter('key', '{id}');
        $this->documento_atendimento_id_list->addAction($action_onGenerate);

        $action_onEdit = new TDataGridAction(array('DocumentoForm', 'onEdit'));
        $action_onEdit->setUseButton(false);
        $action_onEdit->setButtonClass('btn btn-default btn-sm');
        $action_onEdit->setLabel("");
        $action_onEdit->setImage('fas:edit #2196F3');
        $action_onEdit->setField('id');

        $this->documento_atendimento_id_list->addAction($action_onEdit);

        $column_tipo_documento_nome = $this->documento_atendimento_id_list->addQuickColumn("Tipo", 'tipo_documento->nome', 'left');
        $column_dt_preenchimento_transformed = $this->documento_atendimento_id_list->addQuickColumn("Emissão", 'dt_preenchimento', 'center' , '100px');
        $column_autenticador = $this->documento_atendimento_id_list->addQuickColumn("Autenticador", 'autenticador', 'center' , '200px');

        $column_dt_preenchimento_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y H:i');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $this->documento_atendimento_id_list->createModel();

        $criteria_documento_atendimento_id = new TCriteria();
        $criteria_documento_atendimento_id->add(new TFilter('atendimento_id', '=', $atendimento->id));

        $criteria_documento_atendimento_id->setProperty('order', 'id desc');

        $documento_atendimento_id_items = Documento::getObjects($criteria_documento_atendimento_id);

        $this->documento_atendimento_id_list->addItems($documento_atendimento_id_items);

        $panel = new TElement('div');
        $panel->class = 'formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->documento_atendimento_id_list));

        $abas->addContent([$panel]);

        $abas->appendPage("Formulários");
        $row10 = $abas->addFields([$labelFormulario,$action2aaa]);
        $row10->layout = [' col-sm-12'];

        $this->resposta_formulario_atendimento_id_list = new TQuickGrid;
        $this->resposta_formulario_atendimento_id_list->style = 'width:100%';
        $this->resposta_formulario_atendimento_id_list->disableDefaultClick();

        $action_onEdit = new TDataGridAction(array('RespostaFormularioForm', 'onEdit'));
        $action_onEdit->setUseButton(false);
        $action_onEdit->setButtonClass('btn btn-default btn-sm');
        $action_onEdit->setLabel("Editar");
        $action_onEdit->setImage('far:edit #2196F3');
        $action_onEdit->setField('id');

        $action_onEdit->setParameter('id', '{id}');
        $this->resposta_formulario_atendimento_id_list->addAction($action_onEdit);

        $action_onRemoverFormulario = new TDataGridAction(array('AtendimentoFormView', 'onRemoverFormulario'));
        $action_onRemoverFormulario->setUseButton(false);
        $action_onRemoverFormulario->setButtonClass('btn btn-default btn-sm');
        $action_onRemoverFormulario->setLabel("Apagar");
        $action_onRemoverFormulario->setImage('far:trash-alt #F44336');
        $action_onRemoverFormulario->setField('id');

        $this->resposta_formulario_atendimento_id_list->addAction($action_onRemoverFormulario);

        $column_formulario_nome = $this->resposta_formulario_atendimento_id_list->addQuickColumn("Formulário", 'formulario->nome', 'left');
        $column_dt_resposta_transformed = $this->resposta_formulario_atendimento_id_list->addQuickColumn("Data ", 'dt_resposta', 'center' , '100px');

        $column_dt_resposta_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $this->resposta_formulario_atendimento_id_list->createModel();

        $criteria_resposta_formulario_atendimento_id = new TCriteria();
        $criteria_resposta_formulario_atendimento_id->add(new TFilter('atendimento_id', '=', $atendimento->id));

        $criteria_resposta_formulario_atendimento_id->setProperty('order', 'id desc');

        $resposta_formulario_atendimento_id_items = RespostaFormulario::getObjects($criteria_resposta_formulario_atendimento_id);

        $this->resposta_formulario_atendimento_id_list->addItems($resposta_formulario_atendimento_id_items);

        $panel = new TElement('div');
        $panel->class = 'formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->resposta_formulario_atendimento_id_list));

        $abas->addContent([$panel]);
        $row11 = $this->form->addFields([$abas]);
        $row11->layout = [' col-sm-12'];

        if(!empty($param['current_tab']))
        {
            $this->form->setCurrentPage($param['current_tab']);
        }

        if(!empty($param['current_tab_abas']))
        {
            $this->abas->setCurrentPage($param['current_tab_abas']);
        }

        $this->abas->class = 'no-padding';
        $row5->layout = [' col-sm-12 d-flex column-space-between'];

        if (empty($atendimento->dt_final))
        {
            $btnFinalizarAction = new TAction([$this, 'onFinalizar'],['static' => 1, 'key'=>$atendimento->id]);
            $btnFinalizarLabel = new TLabel("Finalizar atendimento");
            $btnFinalizarLabel->setFontSize('12px'); 
            $btnFinalizarLabel->setFontColor('#333'); 

            $this->form->addHeaderAction($btnFinalizarLabel, $btnFinalizarAction, 'fas:check #4CAF50'); 
        }

        if (! AtendimentoService::podeManipular($atendimento, TSession::getValue('userid')))
        {
            $container = new TElement('div');
            $action = new TAction(['AgendamentoList', 'onShow']);
            new TMessage('error', 'Você não tem acesso a esse atendimento', $action);

            return false;
        }

        $btnAtendimentoTimeLineOnShowAction = new TAction(['AtendimentoTimeLine', 'onShow'],['paciente_id'=>$atendimento->paciente_id]);
        $btnAtendimentoTimeLineOnShowLabel = new TLabel("Ver histórico");

        $btnAtendimentoTimeLineOnShow = $this->form->addHeaderAction($btnAtendimentoTimeLineOnShowLabel, $btnAtendimentoTimeLineOnShowAction, 'fas:dot-circle #FF9800'); 
        $btnAtendimentoTimeLineOnShowLabel->setFontSize('12px'); 
        $btnAtendimentoTimeLineOnShowLabel->setFontColor('#333'); 

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        TTransaction::close();
        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=AtendimentoFormView]');
        $style->width = '85% !important';   
        $style->show(true);

    }

    public static function onExcuirProcedimento($param = null) 
    {
        try 
        {
            new TQuestion("Deseja confirmar a exclusão desse procedimento?", new TAction([__CLASS__, 'excluirProcedimento'], $param), new TAction([__CLASS__, 'cancelarExclusaoProcedimento'], $param));
            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onDeleteExame($param = null) 
    {
        try 
        {
            new TQuestion("Deseja confrimar a exclusão desse exame?", new TAction([__CLASS__, 'deletarExame'], $param), new TAction([__CLASS__, 'cancelarDeleteExame'], $param));

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onExcluirMaterial($param = null) 
    {
        try 
        {
            new TQuestion("Deseja confirmar a exclusão desse material?", new TAction([__CLASS__, 'excluirMaterial'], $param), new TAction([__CLASS__, 'cancelarExclusaoMaterial'], $param));

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onRemoveAnexo($param = null) 
    {
        try 
        {
            new TQuestion("Deseja confirmar a exclusão desse anexo?", new TAction([__CLASS__, 'onDeleteAnexo'], $param), new TAction([__CLASS__, 'onCancelDeleteAnexo'], $param));
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onExcluirPrescricao($param = null) 
    {
        try 
        {
            new TQuestion("Deseja confirmar a exclusão dessa prescrição?", new TAction([__CLASS__, 'excluirPrescricao'], $param), new TAction([__CLASS__, 'cancelarExclusaoPrescricao'], $param));
            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onInvalidarDocumento($param = null) 
    {
        try 
        {
            new TQuestion("Deseja confirmar a invalidação do documento?", new TAction([__CLASS__, 'invalidarDocumento'], $param), new TAction([__CLASS__, 'cancelarInvalidacao'], $param));

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function canInvalidar($object)
    {
        try 
        {
            if($object->autenticador)
            {
                return true;
            }

            return false;
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onRemoverFormulario($param = null) 
    {

        new TQuestion("Deseja confirmar a remoção desse formulário?", new TAction([__CLASS__, 'removerFormulario'], $param), new TAction([__CLASS__, 'cancelarRemocaoFormulario'], $param));
            //</autoCode>

    }

    public function onShow($param = null)
    {     

    }

    public static function excluirProcedimento($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $atendimento = AtendimentoProcedimento::find($param['id']);

            $id = $atendimento->atendimento_id;

            if ($atendimento)
            {
                $atendimento->delete();
            }

            TTransaction::close();

            TApplication::loadPage(__CLASS__, 'onShow', ['key' => $id, 'id' => $id]);
        }
        catch (Exception $e) 
        {
            TTransaction::rollback();

            new TMessage('error', $e->getMessage());    
        }
    }

    public static function cancelarExclusaoProcedimento($param = null) 
    {

    }

    public static function excluirMaterial($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $material = AtendimentoMaterial::find($param['id']);

            $id = $material->atendimento_id;

            if ($material)
            {
                AtendimentoService::adicionarEstoque($material, TSession::getValue('userid'));

                $material->delete();
            }

            TTransaction::close();

            TApplication::loadPage(__CLASS__, 'onShow', ['key' => $id, 'id' => $id, 'current_tab_abas' => 2]);
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function cancelarExclusaoMaterial($param = null) 
    {

    }

    public static function onDeleteAnexo($param = null) 
    {
         try 
        {
            TTransaction::open(self::$database);

            $anexo = Anexo::find($param['id']);

            $id = $anexo->atendimento_id;

            if ($anexo)
            {
                $anexo->delete();
            }

            TTransaction::close();

            TApplication::loadPage(__CLASS__, 'onShow', ['key' => $id, 'id' => $id, 'current_tab_abas' => 3]);
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onCancelDeleteAnexo($param = null) 
    {

    }

    public static function deletarExame($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $exameAtendimento = ExameAtendimento::find($param['id']);

            $id = $exameAtendimento->atendimento_id;

            if ($exameAtendimento)
            {
                $exameAtendimento->delete();
            }

            TTransaction::close();

            TApplication::loadPage(__CLASS__, 'onShow', ['key' => $id, 'id' => $id, 'current_tab_abas' => 1]);
        }
        catch (Exception $e) 
        {
            TTransaction::rollback();

            new TMessage('error', $e->getMessage());    
        }
    }

    public static function cancelarDeleteExame($param = null) 
    {
    }

    public static function excluirPrescricao($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $prescricao = Prescricao::find($param['id']);

            $id = $prescricao->atendimento_id;

            if ($prescricao)
            {
                $prescricao->deleteComposite('Medicamento', 'prescricao_id', $prescricao->id);
                $prescricao->delete();
            }

            TTransaction::close();

            TApplication::loadPage(__CLASS__, 'onShow', ['key' => $id, 'id' => $id, 'current_tab_abas' => 4]);
        }
        catch (Exception $e) 
        {
            TTransaction::rollback();

            new TMessage('error', $e->getMessage());    
        }
    }

    public static function cancelarExclusaoPrescricao($param = null) 
    {

    }

    public static function invalidarDocumento($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $documento = Documento::find($param['id']);

            $id = $documento->atendimento_id;

            if ($documento)
            {
                $documento->autenticador = '';
                $documento->store();
            }

            TTransaction::close();

            TApplication::loadPage(__CLASS__, 'onShow', ['key' => $id, 'id' => $id, 'current_tab_abas' => 5]);
        }
        catch (Exception $e) 
        {
            TTransaction::rollback();

            new TMessage('error', $e->getMessage());    
        }
    }

    public static function cancelarInvalidacao($param = null) 
    {

    }

    public static function removerFormulario($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $respostaFormulario = RespostaFormulario::find($param['id']);

            $id = $respostaFormulario->atendimento_id;

            if ($respostaFormulario)
            {
                $respostaFormulario->deleteComposite('Resposta', 'resposta_formulario_id', $respostaFormulario->id);
                $respostaFormulario->delete();
            }

            TTransaction::close();

            TApplication::loadPage(__CLASS__, 'onShow', ['key' => $id, 'id' => $id, 'current_tab_abas' => 5]);
        }
        catch (Exception $e) 
        {
            TTransaction::rollback();

            new TMessage('error', $e->getMessage());    
        }
    }

    public static function cancelarRemocaoFormulario($param = null) 
    {

    }

    public static function onYesDeleteCodigoEstudo($param = null) 
    {
        try 
        {
            // Código gerado pelo snippet: "Conexão com banco de dados"
            TTransaction::open('clinica');

            $objeto = ImagemEstudo::find( $param['key'] );
            $atendimento_id = $objeto->atendimento_id;
            if($objeto)
            {
                $objeto->delete();    
            }

            TTransaction::close();

            // Código gerado pelo snippet: "Mensagem Toast"
            TToast::show("success", "Registro deletado", "topRight", "fas fa-hand-point-right");
            // -----

            $pageParam = [
                'key' => $atendimento_id,
                'id' => $atendimento_id,
                'current_tab_abas' => 6
            ]; 

            TApplication::loadPage('AtendimentoFormView', 'onShow', $pageParam);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onNoDeleteCodigoEstudo($param = null) 
    {
        try 
        {
            //code here
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onFinalizar($param)
    {
        try 
        {
            TTransaction::open(self::$database);

            $atendimento = Atendimento::find($param['key']);
            $atendimento->dt_final = date('Y-m-d H:i:s');
            $atendimento->store();

            $agendamento = $atendimento->agendamento;

            if ($agendamento->estado_agenda->estado_final == 'T')
            {
                throw new Exception('Esse agendamento já está finalizado!');
            }

            $agendamento->estado_agenda_id = EstadoAgenda::ATENDIDO;
            $agendamento->store();

            $historico = new EstadoAgendamento();
            $historico->agendamento_id = $agendamento->id;
            $historico->estado_agenda_id = $agendamento->estado_agenda_id;
            $historico->system_users_id = TSession::getValue('userid');
            $historico->atribuido_em = date('Y-m-d H:i:s');
            $historico->store();

            TToast::show('success', 'Atendimento finalizado com sucesso');

            TTransaction::close();

            TApplication::loadPage(__CLASS__, 'onShow', ['key' => $atendimento->id, 'id' => $atendimento->id]);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
}

