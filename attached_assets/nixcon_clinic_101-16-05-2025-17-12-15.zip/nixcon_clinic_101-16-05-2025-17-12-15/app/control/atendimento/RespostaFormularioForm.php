<?php

class RespostaFormularioForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_RespostaFormularioForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Resposta Formulário");


        $formulario_id = new TCombo('formulario_id');
        $atendimento_id = new THidden('atendimento_id');
        $id = new THidden('id');

        $formulario_id->setChangeAction(new TAction([$this,'onChangeFormulario']));

        $id->setSize(200);
        $atendimento_id->setSize(200);
        $formulario_id->setSize('100%');

        $id->setValue($param['id']??'');
        $formulario_id->setValue($param['formulario_id']??'');
        $atendimento_id->setValue($param['atendimento_id']??'');


        $row1 = $this->form->addFields([new TFormSeparator("Formulário", '#333', '18', '#eee')]);
        $row1->layout = [' col-sm-12'];

        $row2 = $this->form->addFields([$formulario_id,new TLabel("*Escolha o formulário para responder as perguntas", '#607D8B', '14px', null),$atendimento_id,$id]);
        $row2->layout = [' col-sm-12'];

        $row3 = $this->form->addFields([new TFormSeparator("Perguntas", '#333', '18', '#eee')]);
        $row3->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsalvarrespostas = $this->form->addAction("Salvar respostas", new TAction([$this, 'onSalvarRespostas']), 'fas:save #ffffff');
        $this->btn_onsalvarrespostas = $btn_onsalvarrespostas;
        $btn_onsalvarrespostas->addStyleClass('btn-primary'); 

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=RespostaFormularioForm]');
        $style->width = '70% !important';   
        $style->show(true);

    }

    public static function onChangeFormulario($param = null) 
    {
        try 
        {
            if (! empty($param['atendimento_id']) && ! empty($param['formulario_id']))
            {
                TApplication::loadPage('RespostaFormularioForm', 'onShow', ['formulario_id' => $param['formulario_id'], 'atendimento_id' => $param['atendimento_id']]);
            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onSalvarRespostas($param = null) 
    {
        try
        {
            TTransaction::open('clinica');

            self::validate($param);

            $respostaFormulario = empty($param['id']) ? new  RespostaFormulario : RespostaFormulario::find($param['id']);

            $respostaFormulario->dt_resposta = date('Y-m-d');
            $respostaFormulario->formulario_id = $param['formulario_id'];
            $respostaFormulario->atendimento_id = $param['atendimento_id'];

            $respostaFormulario->store();

            $questoes = Questao::where('formulario_id', '=', $param['formulario_id'])->getIndexedArray('id', 'id');

            foreach($questoes as $questao_id)
            {
                $value = $param['questao_'. $questao_id]??null;

                $questao = Questao::find($questao_id);

                if ($questao->fl_obrigatorio == 'T' && ! $value)
                {
                    throw new Exception("A questão \"{$questao->nome}\", é obrigatória");
                }

                $resposta = Resposta::where(
                    'questao_id', '=', $questao_id
                )->where(
                    'resposta_formulario_id', '=', $respostaFormulario->id
                )->first();

                $resposta = $resposta ?? new Resposta;

                $resposta->questao_id = $questao_id;
                $resposta->resposta_formulario_id = $respostaFormulario->id;
                $resposta->resposta = $questao->tipo_campo === 'TCheckGroup' ? implode(',', $value) : $value;

                $resposta->store();
            }

            TTransaction::close();

            $loadPageParam = [
                'id' => $respostaFormulario->atendimento_id,
                'key' => $respostaFormulario->atendimento_id,
                'current_tab_abas' => 6
            ];

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('AtendimentoFormView', 'onShow', $loadPageParam);
        }
        catch (Exception $e)
        {
            TTransaction::rollback();

            new TMessage('error', $e->getMessage());
        }
    }

    public function onShow($param = null)
    {               

        try
        {
            TTransaction::open('clinica');

            if (! empty($param['formulario_id']))
            {
                $formulario = Formulario::find($param['formulario_id']);

                $questoes = $formulario->getQuestaos();

                $data = new stdClass;
                $data->atendimento_id = $param['atendimento_id'];
                $data->formulario_id = $param['formulario_id'];

                $this->form->setData($data);

                if ($questoes)
                {
                    foreach ($questoes as $questao)
                    {
                        if ($questao->ativo == 'F')
                        {
                            continue;
                        }

                        $fieldQuestao = FormularioService::getField($questao);
                        $labelQuestao = FormularioService::getLabel($questao);

                        $rowCustom = $this->form->addFields([$labelQuestao, $fieldQuestao]);
                        $rowCustom->layout = ['col-sm-12'];
                    }
                }
            }

            if (!empty($param['atendimento_id']))
            {
                $atendimento = new Atendimento($param['atendimento_id']);

                $criteria = new TCriteria();
                $criteria->add(new TFilter('clinica_id', '=', $atendimento->clinica_id));

                $items = Formulario::getIndexedArray('id', 'nome', $criteria);

                $this->form->getField('formulario_id')->addItems($items);
            }

            TTransaction::close();
        }
        catch(Exception $e)
        {
            TTransaction::rollback();
        }

    } 

    public static function onClose($param)
    {
        TScript::create("Template.closeRightPanel();");
    }

    public function onView($param)
    {
        $param['readonly'] = true;
        $this->onEdit($param);

        $this->form->getField('formulario_id')->setEditable(false);
        $this->btn_onsalvarrespostas->setAction(new TAction([$this, 'onClose']), 'Fechar');
        $this->btn_onsalvarrespostas->setImage('fas:times');
        $this->btn_onsalvarrespostas->class = 'btn btn-sm btn-default';

    }

    public static function validate($param)
    {
        if (empty($param['atendimento_id']))
        {
            throw new Exception('Atendimento é obrigatório');
        }

        if (empty($param['formulario_id']))
        {
            throw new Exception('Formulário é obrigatório');
        }
    }

    public function onEdit($param = null)
    {
        try
        {
            TTransaction::open('clinica');

            if ($param['id'])
            {
                $respostaFormulario = RespostaFormulario::find($param['id']);

                $criteria = new TCriteria();
                $criteria->add(new TFilter('clinica_id', '=', $respostaFormulario->atendimento->clinica_id));

                $items = Formulario::getIndexedArray('id', 'nome', $criteria);

                $this->form->getField('formulario_id')->addItems($items);

                $formulario = $respostaFormulario->formulario;

                $questoes = $formulario->getQuestaos();

                $data = new stdClass;
                $data->id = $respostaFormulario->id;
                $data->atendimento_id = $respostaFormulario->atendimento_id;
                $data->formulario_id = $respostaFormulario->formulario_id;

                $this->form->setData($data);

                if ($questoes)
                {
                    foreach ($questoes as $questao)
                    {
                        $resposta = Resposta::where('resposta_formulario_id', '=', $respostaFormulario->id)->where('questao_id', '=', $questao->id)->first();

                        if (! $resposta && $questao->ativo == 'F')
                        {
                            continue;
                        }

                        $fieldQuestao = FormularioService::getField($questao, $resposta);
                        $labelQuestao = FormularioService::getLabel($questao);

                        if(!empty($param['readonly']))
                        {
                            $fieldQuestao->setEditable(false);
                        }

                        $rowCustom = $this->form->addFields([$labelQuestao, $fieldQuestao]);
                        $rowCustom->layout = ['col-sm-12'];
                    }   
                }
            }

            TTransaction::close();
        }
        catch(Exception $e)
        {
            TTransaction::rollback();
        }
    }

}

