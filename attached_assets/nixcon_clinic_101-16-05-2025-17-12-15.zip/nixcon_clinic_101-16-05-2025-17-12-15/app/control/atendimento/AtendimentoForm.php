<?php

class AtendimentoForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Atendimento';
    private static $primaryKey = 'id';
    private static $formName = 'form_Atendimento';

    use BuilderMasterDetailFieldListTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Atendimento #{$param['key']}");

        $criteria_atendimento_procedimento_atendimento_procedimento_id = new TCriteria();
        $criteria_exame_atendimento_atendimento_exame_id = new TCriteria();
        $criteria_atendimento_material_atendimento_material_id = new TCriteria();

        $filterVar = "S";
        $criteria_atendimento_procedimento_atendimento_procedimento_id->add(new TFilter('ativo', '=', $filterVar)); 
        $filterVar = "S";
        $criteria_exame_atendimento_atendimento_exame_id->add(new TFilter('codigo_referencia', '=', $filterVar)); 
        $filterVar = "S";
        $criteria_atendimento_material_atendimento_material_id->add(new TFilter('ativo', '=', $filterVar)); 

        $id = new TEntry('id');
        $atendimento_procedimento_atendimento_id = new THidden('atendimento_procedimento_atendimento_id[]');
        $atendimento_procedimento_atendimento___row__id = new THidden('atendimento_procedimento_atendimento___row__id[]');
        $atendimento_procedimento_atendimento___row__data = new THidden('atendimento_procedimento_atendimento___row__data[]');
        $atendimento_procedimento_atendimento_procedimento_id = new TDBCombo('atendimento_procedimento_atendimento_procedimento_id[]', 'clinica', 'Procedimento', 'id', '{nome}','nome asc' , $criteria_atendimento_procedimento_atendimento_procedimento_id );
        $atendimento_procedimento_atendimento_quantidade = new TNumeric('atendimento_procedimento_atendimento_quantidade[]', '2', ',', '.' );
        $atendimento_procedimento_atendimento_valor = new TNumeric('atendimento_procedimento_atendimento_valor[]', '2', ',', '.' );
        $atendimento_procedimento_atendimento_valor_total = new TNumeric('atendimento_procedimento_atendimento_valor_total[]', '2', ',', '.' );
        $this->procedimentos = new TFieldList();
        $exame_atendimento_atendimento_id = new THidden('exame_atendimento_atendimento_id[]');
        $exame_atendimento_atendimento___row__id = new THidden('exame_atendimento_atendimento___row__id[]');
        $exame_atendimento_atendimento___row__data = new THidden('exame_atendimento_atendimento___row__data[]');
        $exame_atendimento_atendimento_indicacao_clinica = new TEntry('exame_atendimento_atendimento_indicacao_clinica[]');
        $exame_atendimento_atendimento_exame_id = new TDBCombo('exame_atendimento_atendimento_exame_id[]', 'clinica', 'Exame', 'id', '{nome}','nome asc' , $criteria_exame_atendimento_atendimento_exame_id );
        $exame_atendimento_atendimento_quantidade = new TEntry('exame_atendimento_atendimento_quantidade[]');
        $exame_atendimento_atendimento_dt_exames = new TDate('exame_atendimento_atendimento_dt_exames[]');
        $this->exames = new TFieldList();
        $atendimento_material_atendimento_id = new THidden('atendimento_material_atendimento_id[]');
        $atendimento_material_atendimento___row__id = new THidden('atendimento_material_atendimento___row__id[]');
        $atendimento_material_atendimento___row__data = new THidden('atendimento_material_atendimento___row__data[]');
        $atendimento_material_atendimento_material_id = new TDBCombo('atendimento_material_atendimento_material_id[]', 'clinica', 'Material', 'id', '{nome} - ({unidade_medida->sigla})','nome asc' , $criteria_atendimento_material_atendimento_material_id );
        $atendimento_material_atendimento_quantidade = new TNumeric('atendimento_material_atendimento_quantidade[]', '2', ',', '.' );
        $this->fieldList_60fb02dae1078 = new TFieldList();

        $this->procedimentos->addField(null, $atendimento_procedimento_atendimento_id, []);
        $this->procedimentos->addField(null, $atendimento_procedimento_atendimento___row__id, ['uniqid' => true]);
        $this->procedimentos->addField(null, $atendimento_procedimento_atendimento___row__data, []);
        $this->procedimentos->addField(new TLabel("Procedimento", null, '14px', null), $atendimento_procedimento_atendimento_procedimento_id, ['width' => '40%']);
        $this->procedimentos->addField(new TLabel("Quantidade", null, '14px', null), $atendimento_procedimento_atendimento_quantidade, ['width' => '20%','sum' => true]);
        $this->procedimentos->addField(new TLabel("Valor", null, '14px', null), $atendimento_procedimento_atendimento_valor, ['width' => '20%']);
        $this->procedimentos->addField(new TLabel("Total", null, '14px', null), $atendimento_procedimento_atendimento_valor_total, ['width' => '100%']);

        $this->procedimentos->width = '100%';
        $this->procedimentos->setFieldPrefix('atendimento_procedimento_atendimento');
        $this->procedimentos->name = 'procedimentos';

        $this->criteria_procedimentos = new TCriteria();
        $this->default_item_procedimentos = new stdClass();

        $this->form->addField($atendimento_procedimento_atendimento_id);
        $this->form->addField($atendimento_procedimento_atendimento___row__id);
        $this->form->addField($atendimento_procedimento_atendimento___row__data);
        $this->form->addField($atendimento_procedimento_atendimento_procedimento_id);
        $this->form->addField($atendimento_procedimento_atendimento_quantidade);
        $this->form->addField($atendimento_procedimento_atendimento_valor);
        $this->form->addField($atendimento_procedimento_atendimento_valor_total);

        $this->procedimentos->setRemoveAction(null, 'fas:times #dd5a43', "Excluír");

        $this->exames->addField(null, $exame_atendimento_atendimento_id, []);
        $this->exames->addField(null, $exame_atendimento_atendimento___row__id, ['uniqid' => true]);
        $this->exames->addField(null, $exame_atendimento_atendimento___row__data, []);
        $this->exames->addField(new TLabel("Indicação clínica", null, '14px', null), $exame_atendimento_atendimento_indicacao_clinica, ['width' => '30%']);
        $this->exames->addField(new TLabel("Exame", null, '14px', null), $exame_atendimento_atendimento_exame_id, ['width' => '30%']);
        $this->exames->addField(new TLabel("Quantidade", null, '14px', null), $exame_atendimento_atendimento_quantidade, ['width' => '25px']);
        $this->exames->addField(new TLabel("Data", null, '14px', null), $exame_atendimento_atendimento_dt_exames, ['width' => '150px']);

        $this->exames->width = '100%';
        $this->exames->setFieldPrefix('exame_atendimento_atendimento');
        $this->exames->name = 'exames';

        $this->criteria_exames = new TCriteria();
        $this->default_item_exames = new stdClass();

        $this->form->addField($exame_atendimento_atendimento_id);
        $this->form->addField($exame_atendimento_atendimento___row__id);
        $this->form->addField($exame_atendimento_atendimento___row__data);
        $this->form->addField($exame_atendimento_atendimento_indicacao_clinica);
        $this->form->addField($exame_atendimento_atendimento_exame_id);
        $this->form->addField($exame_atendimento_atendimento_quantidade);
        $this->form->addField($exame_atendimento_atendimento_dt_exames);

        $this->exames->setRemoveAction(null, 'fas:times #dd5a43', "Excluír");

        $this->fieldList_60fb02dae1078->addField(null, $atendimento_material_atendimento_id, []);
        $this->fieldList_60fb02dae1078->addField(null, $atendimento_material_atendimento___row__id, ['uniqid' => true]);
        $this->fieldList_60fb02dae1078->addField(null, $atendimento_material_atendimento___row__data, []);
        $this->fieldList_60fb02dae1078->addField(new TLabel("Material", null, '14px', null), $atendimento_material_atendimento_material_id, ['width' => '50%']);
        $this->fieldList_60fb02dae1078->addField(new TLabel("Quantidade", null, '14px', null), $atendimento_material_atendimento_quantidade, ['width' => '20%']);

        $this->fieldList_60fb02dae1078->width = '100%';
        $this->fieldList_60fb02dae1078->setFieldPrefix('atendimento_material_atendimento');
        $this->fieldList_60fb02dae1078->name = 'fieldList_60fb02dae1078';

        $this->criteria_fieldList_60fb02dae1078 = new TCriteria();
        $this->default_item_fieldList_60fb02dae1078 = new stdClass();

        $this->form->addField($atendimento_material_atendimento_id);
        $this->form->addField($atendimento_material_atendimento___row__id);
        $this->form->addField($atendimento_material_atendimento___row__data);
        $this->form->addField($atendimento_material_atendimento_material_id);
        $this->form->addField($atendimento_material_atendimento_quantidade);

        $this->fieldList_60fb02dae1078->setRemoveAction(null, 'fas:times #dd5a43', "Excluír");

        $atendimento_procedimento_atendimento_procedimento_id->setChangeAction(new TAction([$this,'onChangeProcedimento']));

        $atendimento_procedimento_atendimento_quantidade->setExitAction(new TAction([$this,'onExitQuantidade']));
        $atendimento_procedimento_atendimento_valor->setExitAction(new TAction([$this,'onExitValor']));

        $atendimento_procedimento_atendimento_procedimento_id->addValidation("Procedimento", new TRequiredListValidator()); 
        $atendimento_procedimento_atendimento_quantidade->addValidation("Quantidade", new TRequiredListValidator()); 
        $atendimento_procedimento_atendimento_valor->addValidation("Valor", new TRequiredListValidator()); 
        $exame_atendimento_atendimento_indicacao_clinica->addValidation("Indicação clínica", new TRequiredListValidator()); 
        $exame_atendimento_atendimento_exame_id->addValidation("Exame id", new TRequiredListValidator()); 
        $exame_atendimento_atendimento_quantidade->addValidation("Quantidade", new TRequiredListValidator()); 
        $exame_atendimento_atendimento_dt_exames->addValidation("Data", new TRequiredListValidator()); 
        $atendimento_material_atendimento_material_id->addValidation("Material", new TRequiredListValidator()); 
        $atendimento_material_atendimento_quantidade->addValidation("Quantidade", new TRequiredListValidator()); 

        $id->setEditable(false);
        $exame_atendimento_atendimento_dt_exames->setMask('dd/mm/yyyy');
        $exame_atendimento_atendimento_dt_exames->setDatabaseMask('yyyy-mm-dd');
        $exame_atendimento_atendimento_exame_id->enableSearch();
        $atendimento_procedimento_atendimento_procedimento_id->enableSearch();

        $id->setSize(100);
        $exame_atendimento_atendimento_dt_exames->setSize(110);
        $exame_atendimento_atendimento_exame_id->setSize('100%');
        $exame_atendimento_atendimento_quantidade->setSize('100%');
        $atendimento_procedimento_atendimento_valor->setSize('100%');
        $atendimento_material_atendimento_quantidade->setSize('100%');
        $atendimento_material_atendimento_material_id->setSize('100%');
        $atendimento_procedimento_atendimento_quantidade->setSize('100%');
        $exame_atendimento_atendimento_indicacao_clinica->setSize('100%');
        $atendimento_procedimento_atendimento_valor_total->setSize('100%');
        $atendimento_procedimento_atendimento_procedimento_id->setSize('100%');


        $this->form->appendPage("Procedimentos");

        $this->form->addFields([new THidden('current_tab')]);
        $this->form->setTabFunction("$('[name=current_tab]').val($(this).attr('data-current_page'));");

        $row1 = $this->form->addFields([new TLabel("Código:", null, '14px', null, '100%'),$id],[]);
        $row1->layout = ['col-sm-6',' col-sm-4'];

        $row2 = $this->form->addFields([$this->procedimentos]);
        $row2->layout = ['col-sm-12'];

        $this->form->appendPage("Exames");
        $row3 = $this->form->addFields([$this->exames]);
        $row3->layout = [' col-sm-12'];

        $this->form->appendPage("Materiais");
        $row4 = $this->form->addFields([$this->fieldList_60fb02dae1078]);
        $row4->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave'],['static' => 1]), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Atendimento","Cadastro de Atendimento"]));
        }
        $container->add($this->form);

        parent::add($container);

    }

    public static function onExitQuantidade($param = null) 
    {
        try 
        {

            // Código gerado pelo snippet: "Cálculos com campos"
            $field_id = explode('_', $param['_field_id']);
            $field_id = end($field_id);
            $field_data = json_decode($param['_field_data_json']);

            $atendimento_procedimento_atendimento_quantidade = (double) str_replace(',', '.', str_replace('.', '', $param['atendimento_procedimento_atendimento_quantidade'][$field_data->row]));
            $atendimento_procedimento_atendimento_valor = (double) str_replace(',', '.', str_replace('.', '', $param['atendimento_procedimento_atendimento_valor'][$field_data->row]));

            $atendimento_procedimento_atendimento_valor_total = $atendimento_procedimento_atendimento_quantidade * $atendimento_procedimento_atendimento_valor ;
            $object = new stdClass();
            $object->{"atendimento_procedimento_atendimento_valor_total_{$field_id}"} = number_format($atendimento_procedimento_atendimento_valor_total, 2, ',', '.');
            TForm::sendData(self::$formName, $object);
            // -----

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onExitValor($param = null) 
    {
        try 
        {

            self::onExitQuantidade($param);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onChangeProcedimento($param = null) 
    {
        try 
        {
            if(!empty($param['key']))
            {
                TTransaction::open(self::$database);

                $procedimento = new Procedimento($param['key']);

                TTransaction::close();

                // Código gerado pelo snippet: "Enviar dados para campo"

                $field_id = explode('_', $param['_field_id']);
                $field_id = end($field_id);

                $object = new stdClass();
                $object->{"atendimento_procedimento_atendimento_valor_{$field_id}"} = TextService::toBRL($procedimento->valor);
                $object->{"atendimento_procedimento_atendimento_quantidade_{$field_id}"} = 1;
                $object->{"atendimento_procedimento_atendimento_valor_total_{$field_id}"} = TextService::toBRL($procedimento->valor);
                //$object->fieldName = 'insira o novo valor aqui'; //sample

                TForm::sendData(self::$formName, $object);
                // -----

            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Atendimento(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $atendimento_material_atendimento_items = $this->storeItems('AtendimentoMaterial', 'atendimento_id', $object, $this->fieldList_60fb02dae1078, function($masterObject, $detailObject){ 

                //code here

            }, $this->criteria_fieldList_60fb02dae1078); 

            $exame_atendimento_atendimento_items = $this->storeItems('ExameAtendimento', 'atendimento_id', $object, $this->exames, function($masterObject, $detailObject){ 

                //code here

            }, $this->criteria_exames); 

            $atendimento_procedimento_atendimento_items = $this->storeItems('AtendimentoProcedimento', 'atendimento_id', $object, $this->procedimentos, function($masterObject, $detailObject){ 

                //code here

            }, $this->criteria_procedimentos); 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            new TMessage('info', "Registro salvo", $messageAction); 

            TForm::sendData(self::$formName, (object)['id' => $object->id]);

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Atendimento($key); // instantiates the Active Record 

                $this->fieldList_60fb02dae1078_items = $this->loadItems('AtendimentoMaterial', 'atendimento_id', $object, $this->fieldList_60fb02dae1078, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }, $this->criteria_fieldList_60fb02dae1078); 

                $this->exames_items = $this->loadItems('ExameAtendimento', 'atendimento_id', $object, $this->exames, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }, $this->criteria_exames); 

                $this->procedimentos_items = $this->loadItems('AtendimentoProcedimento', 'atendimento_id', $object, $this->procedimentos, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }, $this->criteria_procedimentos); 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        $this->procedimentos->addHeader();
        $this->procedimentos->addDetail($this->default_item_procedimentos);

        $this->procedimentos->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        $this->exames->addHeader();
        $this->exames->addDetail($this->default_item_exames);

        $this->exames->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        $this->fieldList_60fb02dae1078->addHeader();
        $this->fieldList_60fb02dae1078->addDetail($this->default_item_fieldList_60fb02dae1078);

        $this->fieldList_60fb02dae1078->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

    }

    public function onShow($param = null)
    {
        $this->procedimentos->addHeader();
        $this->procedimentos->addDetail($this->default_item_procedimentos);

        $this->procedimentos->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        $this->exames->addHeader();
        $this->exames->addDetail($this->default_item_exames);

        $this->exames->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        $this->fieldList_60fb02dae1078->addHeader();
        $this->fieldList_60fb02dae1078->addDetail($this->default_item_fieldList_60fb02dae1078);

        $this->fieldList_60fb02dae1078->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

