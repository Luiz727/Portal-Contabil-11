<?php

class DashboardAtendimentoGeral extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_DashboardAtendimentoGeral';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Dashboard de ATENDIMENTOS");

        $criteria_clinica_id = new TCriteria();
        $criteria_qtd_atendimentos = new TCriteria();
        $criteria_total_bruto = new TCriteria();
        $criteria_total_por_agenda = new TCriteria();
        $criteria_total_por_procedimento = new TCriteria();
        $criteria_atendimento_mes = new TCriteria();
        $criteria_total_convenio = new TCriteria();

        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_clinica_id->add(new TFilter('system_unit_id', 'in', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_qtd_atendimentos->add(new TFilter('atendimento.clinica_id', 'in', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_total_bruto->add(new TFilter('atendimento.clinica_id', 'in', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_total_por_agenda->add(new TFilter('atendimento.clinica_id', 'in', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $filterVar = (is_array($filterVar) && $filterVar) ? "'".implode("','", $filterVar)."'" : $filterVar;
        $criteria_total_por_procedimento->add(new TFilter('atendimento_procedimento.atendimento_id', 'in', "(SELECT id FROM atendimento WHERE clinica_id in ({$filterVar}))")); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_atendimento_mes->add(new TFilter('atendimento.clinica_id', 'in', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $filterVar = (is_array($filterVar) && $filterVar) ? "'".implode("','", $filterVar)."'" : $filterVar;
        $criteria_total_convenio->add(new TFilter('atendimento_procedimento.atendimento_id', 'in', "(SELECT id FROM atendimento WHERE clinica_id in ({$filterVar}))")); 

        $mes = new TCombo('mes');
        $ano = new TCombo('ano');
        $clinica_id = new TDBCombo('clinica_id', 'clinica', 'Clinica', 'id', '{nome}','nome asc' , $criteria_clinica_id );
        $agenda_id = new TCombo('agenda_id');
        $button_buscar = new TButton('button_buscar');
        $qtd_atendimentos = new BIndicator('qtd_atendimentos');
        $total_bruto = new BIndicator('total_bruto');
        $total_por_agenda = new BBarChart('total_por_agenda');
        $total_por_procedimento = new BPieChart('total_por_procedimento');
        $atendimento_mes = new BLineChart('atendimento_mes');
        $total_convenio = new BDonutChart('total_convenio');

        $clinica_id->setChangeAction(new TAction([$this,'onChangeClinica']));

        $clinica_id->enableSearch();
        $button_buscar->setAction(new TAction(['DashboardAtendimentoGeral', 'onShow']), "Buscar");
        $button_buscar->addStyleClass('btn-default');
        $button_buscar->setImage('fas:search #00BCD4');
        $ano->addItems(TempoService::getAnos());
        $mes->addItems(TempoService::getMeses());

        $mes->setSize('100%');
        $ano->setSize('100%');
        $agenda_id->setSize('100%');
        $clinica_id->setSize('100%');

        $qtd_atendimentos->setDatabase('clinica');
        $qtd_atendimentos->setFieldValue("atendimento.id");
        $qtd_atendimentos->setModel('Atendimento');
        $qtd_atendimentos->setTotal('count');
        $qtd_atendimentos->setColors('#00CEC9', '#ffffff', '#81ECEC', '#ffffff');
        $qtd_atendimentos->setTitle("atendimentos", '#ffffff', '20', '');
        $qtd_atendimentos->setCriteria($criteria_qtd_atendimentos);
        $qtd_atendimentos->setIcon(new TImage('fas:calendar-alt #ffffff'));
        $qtd_atendimentos->setValueSize("30");
        $qtd_atendimentos->setValueColor("#ffffff", 'B');
        $qtd_atendimentos->setSize('100%', 95);
        $qtd_atendimentos->setLayout('horizontal', 'left');

        $total_bruto->setDatabase('clinica');
        $total_bruto->setFieldValue("atendimento.valor_total");
        $total_bruto->setModel('Atendimento');
        $total_bruto->setTransformerValue(function($value)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $total_bruto->setTotal('sum');
        $total_bruto->setColors('#27AE60', '#FFFFFF', '#2ECC71', '#FFFFFF');
        $total_bruto->setTitle("total bruto", '#FFFFFF', '20', '');
        $total_bruto->setCriteria($criteria_total_bruto);
        $total_bruto->setIcon(new TImage('far:money-bill-alt #FFFFFF'));
        $total_bruto->setValueSize("28");
        $total_bruto->setValueColor("#FFFFFF", 'B');
        $total_bruto->setSize('100%', 95);
        $total_bruto->setLayout('horizontal', 'left');

        $total_por_agenda->setDatabase('clinica');
        $total_por_agenda->setFieldValue("atendimento.valor_total");
        $total_por_agenda->setFieldGroup(["agenda.nome"]);
        $total_por_agenda->setModel('Atendimento');
        $total_por_agenda->setTitle("Total por agenda");
        $total_por_agenda->setTransformerValue(function($value, $row, $data)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $total_por_agenda->setLayout('horizontal');
        $total_por_agenda->setJoins([
             'agendamento' => ['atendimento.agendamento_id', 'agendamento.id'],
             'agenda' => ['agendamento.agenda_id', 'agenda.id']
        ]);
        $total_por_agenda->setTotal('sum');
        $total_por_agenda->showLegend(false);
        $total_por_agenda->enableOrderByValue('asc');
        $total_por_agenda->setCriteria($criteria_total_por_agenda);
        $total_por_agenda->setLabelValue("Valor Total");
        $total_por_agenda->setSize('100%', 280);
        $total_por_agenda->disableZoom();

        $total_por_procedimento->setDatabase('clinica');
        $total_por_procedimento->setFieldValue("atendimento_procedimento.valor_total");
        $total_por_procedimento->setFieldGroup("procedimento.nome");
        $total_por_procedimento->setModel('AtendimentoProcedimento');
        $total_por_procedimento->setTitle("Total por pocedimento");
        $total_por_procedimento->setTransformerValue(function($value, $row, $data)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $total_por_procedimento->setJoins([
             'procedimento' => ['atendimento_procedimento.procedimento_id', 'procedimento.id']
        ]);
        $total_por_procedimento->setTotal('sum');
        $total_por_procedimento->showLegend(true);
        $total_por_procedimento->enableOrderByValue('asc');
        $total_por_procedimento->setCriteria($criteria_total_por_procedimento);
        $total_por_procedimento->setSize('100%', 280);
        $total_por_procedimento->disableZoom();

        $atendimento_mes->setDatabase('clinica');
        $atendimento_mes->setFieldValue("atendimento.id");
        $atendimento_mes->setFieldGroup(["atendimento.ano_mes_inicial"]);
        $atendimento_mes->setModel('Atendimento');
        $atendimento_mes->setTitle("Atendimento mês");
        $atendimento_mes->setTransformerLegend(function($value, $row, $data)
            {
                return TempoService::getMesAno($value);

            });
        $atendimento_mes->setTotal('count');
        $atendimento_mes->showLegend(true);
        $atendimento_mes->setCriteria($criteria_atendimento_mes);
        $atendimento_mes->setLabelValue("Quantidade");
        $atendimento_mes->setSize('100%', 280);
        $atendimento_mes->showArea(true);
        $atendimento_mes->disableZoom();

        $total_convenio->setDatabase('clinica');
        $total_convenio->setFieldValue("atendimento_procedimento.valor_total");
        $total_convenio->setFieldGroup("convenio.nome");
        $total_convenio->setModel('AtendimentoProcedimento');
        $total_convenio->setTitle("Total por convênio");
        $total_convenio->setTransformerValue(function($value, $row, $data)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $total_convenio->setJoins([
             'convenio' => ['atendimento_procedimento.convenio_id', 'convenio.id']
        ]);
        $total_convenio->setTotal('sum');
        $total_convenio->showLegend(true);
        $total_convenio->enableOrderByValue('asc');
        $total_convenio->setCriteria($criteria_total_convenio);
        $total_convenio->setSize('100%', 280);
        $total_convenio->disableZoom();

        $row1 = $this->form->addFields([new TLabel("Mês:", null, '14px', null, '100%'),$mes],[new TLabel("Ano:", null, '14px', null, '100%'),$ano],[new TLabel("Clinica:", null, '14px', null),$clinica_id],[new TLabel("Agenda:", null, '14px', null, '100%'),$agenda_id],[new TLabel(" ", null, '14px', null, '100%'),$button_buscar]);
        $row1->layout = ['col-sm-2','col-sm-2',' col-sm-3','col-sm-3','col-sm-2'];

        $row2 = $this->form->addFields([$qtd_atendimentos],[$total_bruto]);
        $row2->layout = [' col-sm-6',' col-sm-6'];

        $row3 = $this->form->addFields([$total_por_agenda],[$total_por_procedimento]);
        $row3->layout = [' col-sm-7',' col-sm-5'];

        $row4 = $this->form->addFields([$atendimento_mes],[$total_convenio]);
        $row4->layout = [' col-sm-7',' col-sm-5'];

        $searchData = $this->form->getData();
        $this->form->setData($searchData);

        $filterVar = $searchData->mes;
        if($filterVar)
        {
            $criteria_qtd_atendimentos->add(new TFilter('atendimento.mes_inicial', '=', $filterVar)); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_qtd_atendimentos->add(new TFilter('atendimento.ano_inicial', '=', $filterVar)); 
        }
        $filterVar = $searchData->agenda_id;
        if($filterVar)
        {
            $criteria_qtd_atendimentos->add(new TFilter('atendimento.agendamento_id', 'in', "(SELECT id FROM agendamento WHERE agenda_id = '$filterVar')")); 
        }
        $filterVar = $searchData->clinica_id;
        if($filterVar)
        {
            $criteria_qtd_atendimentos->add(new TFilter('atendimento.clinica_id', '=', $filterVar)); 
        }
        $filterVar = $searchData->mes;
        if($filterVar)
        {
            $criteria_total_bruto->add(new TFilter('atendimento.mes_inicial', '=', $filterVar)); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_total_bruto->add(new TFilter('atendimento.ano_inicial', '=', $filterVar)); 
        }
        $filterVar = $searchData->agenda_id;
        if($filterVar)
        {
            $criteria_total_bruto->add(new TFilter('atendimento.agendamento_id', 'in', "(SELECT id FROM agendamento WHERE agenda_id = '$filterVar')")); 
        }
        $filterVar = $searchData->clinica_id;
        if($filterVar)
        {
            $criteria_total_bruto->add(new TFilter('atendimento.clinica_id', '=', $filterVar)); 
        }
        $filterVar = $searchData->mes;
        if($filterVar)
        {
            $criteria_total_por_agenda->add(new TFilter('atendimento.mes_inicial', '=', $filterVar)); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_total_por_agenda->add(new TFilter('atendimento.ano_inicial', '=', $filterVar)); 
        }
        $filterVar = $searchData->clinica_id;
        if($filterVar)
        {
            $criteria_total_por_agenda->add(new TFilter('atendimento.clinica_id', '=', $filterVar)); 
        }
        $filterVar = $searchData->mes;
        if($filterVar)
        {
            $criteria_total_por_procedimento->add(new TFilter('atendimento_procedimento.atendimento_id', 'in', "(SELECT id FROM atendimento WHERE mes_inicial = '$filterVar')")); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_total_por_procedimento->add(new TFilter('atendimento_procedimento.atendimento_id', 'in', "(SELECT id FROM atendimento WHERE ano_inicial = '$filterVar')")); 
        }
        $filterVar = $searchData->clinica_id;
        if($filterVar)
        {
            $criteria_total_por_procedimento->add(new TFilter('atendimento_procedimento.atendimento_id', 'in', "(SELECT id FROM atendimento WHERE clinica_id = '$filterVar')")); 
        }
        $filterVar = $searchData->agenda_id;
        if($filterVar)
        {
            $criteria_total_por_procedimento->add(new TFilter('atendimento_procedimento.atendimento_id', 'in', "(SELECT id FROM atendimento WHERE agendamento_id in (SELECT id FROM agendamento WHERE agenda_id = '$filterVar'))")); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_atendimento_mes->add(new TFilter('atendimento.ano_inicial', '=', $filterVar)); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_atendimento_mes->add(new TFilter('atendimento.mes_inicial', '=', $filterVar)); 
        }
        $filterVar = $searchData->agenda_id;
        if($filterVar)
        {
            $criteria_atendimento_mes->add(new TFilter('atendimento.agendamento_id', 'in', "(SELECT id FROM agendamento WHERE agenda_id = '$filterVar')")); 
        }
        $filterVar = $searchData->clinica_id;
        if($filterVar)
        {
            $criteria_atendimento_mes->add(new TFilter('atendimento.clinica_id', '=', $filterVar)); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_total_convenio->add(new TFilter('atendimento_procedimento.atendimento_id', 'in', "(SELECT id FROM atendimento WHERE ano_inicial = '$filterVar')")); 
        }
        $filterVar = $searchData->mes;
        if($filterVar)
        {
            $criteria_total_convenio->add(new TFilter('atendimento_procedimento.atendimento_id', 'in', "(SELECT id FROM atendimento WHERE mes_inicial = '$filterVar')")); 
        }
        $filterVar = $searchData->agenda_id;
        if($filterVar)
        {
            $criteria_total_convenio->add(new TFilter('atendimento_procedimento.atendimento_id', 'in', "(SELECT id FROM atendimento WHERE agendamento_id in ((SELECT id FROM agendamento WHERE agenda_id in (SELECT id FROM agenda WHERE id = '$filterVar'))))")); 
        }
        $filterVar = $searchData->clinica_id;
        if($filterVar)
        {
            $criteria_total_convenio->add(new TFilter('atendimento_procedimento.atendimento_id', 'in', "(SELECT id FROM atendimento WHERE clinica_id = '$filterVar')")); 
        }

        BChart::generate($qtd_atendimentos, $total_bruto, $total_por_agenda, $total_por_procedimento, $atendimento_mes, $total_convenio);

        // create the form actions

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Atendimento","Dashboard"]));
        }
        $container->add($this->form);

        parent::add($container);

    }

    public static function onChangeClinica($param = null) 
    {
        try 
        {
            if(!empty($param['key']))
            {
                TSession::setValue('clinica_id_dashboard_atedimento_geral', $param['key']);
            }
            else
            {
                TSession::setValue('clinica_id_dashboard_atedimento_geral', PermissaoService::getUnidadeDefault());
            }
            TMultiSearch::clearField(self::$formName, 'agenda_id');

            if (isset($param['clinica_id']) && $param['clinica_id'])
            { 
                $criteria = TCriteria::create(['clinica_id' => $param['clinica_id']]);
                $filterVar = PermissaoService::getUnidadeIds();
                $criteria->add(new TFilter('clinica_id', 'in', $filterVar)); 
                $filterVar = "{session.clinica_id_dashboard_atedimento_geral}";
                $criteria->add(new TFilter('clinica_id', '=', $filterVar)); 
                TDBCombo::reloadFromModel(self::$formName, 'agenda_id', 'clinica', 'Agenda', 'id', '{nome}', 'nome asc', $criteria, TRUE); 
            } 
            else 
            { 
                TCombo::clearField(self::$formName, 'agenda_id'); 
            }  

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onShow($param = null)
    {               

        TSession::setValue('clinica_id_dashboard_atedimento_geral', PermissaoService::getUnidadeDefault());
    } 

    public function fireEvents( $object )
    {
        $obj = new stdClass;
        if(is_object($object) && get_class($object) == 'stdClass')
        {
            if(isset($object->clinica_id))
            {
                $value = $object->clinica_id;

                $obj->clinica_id = $value;
            }
            if(isset($object->agenda_id))
            {
                $value = $object->agenda_id;

                $obj->agenda_id = $value;
            }
        }
        elseif(is_object($object))
        {
            if(isset($object->clinica_id))
            {
                $value = $object->clinica_id;

                $obj->clinica_id = $value;
            }
            if(isset($object->agenda_id))
            {
                $value = $object->agenda_id;

                $obj->agenda_id = $value;
            }
        }
        TForm::sendData(self::$formName, $obj);
    }  

}

