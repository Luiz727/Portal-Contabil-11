<?php

class PrescricaoForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Prescricao';
    private static $primaryKey = 'id';
    private static $formName = 'form_PrescricaoForm';

    use BuilderMasterDetailTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Prescrição");


        $id = new TEntry('id');
        $atendimento_id = new THidden('atendimento_id');
        $controle_especial = new TRadioGroup('controle_especial');
        $dt_prescricao = new TDate('dt_prescricao');
        $medicamento_prescricao_medicamento = new TEntry('medicamento_prescricao_medicamento');
        $medicamento_prescricao_id = new THidden('medicamento_prescricao_id');
        $medicamento_prescricao_posologia = new TEntry('medicamento_prescricao_posologia');
        $medicamento_prescricao_quantidade = new TNumeric('medicamento_prescricao_quantidade', '2', ',', '.' );
        $button_adicionar_medicamento_prescricao = new TButton('button_adicionar_medicamento_prescricao');

        $controle_especial->addValidation("Receituário controle especial", new TRequiredValidator()); 
        $dt_prescricao->addValidation("Data", new TRequiredValidator()); 

        $id->setEditable(false);
        $controle_especial->addItems(["T"=>"Sim","F"=>"Não"]);
        $controle_especial->setLayout('horizontal');
        $controle_especial->setUseButton();
        $dt_prescricao->setMask('dd/mm/yyyy');
        $dt_prescricao->setDatabaseMask('yyyy-mm-dd');
        $button_adicionar_medicamento_prescricao->setAction(new TAction([$this, 'onAddDetailMedicamentoPrescricao'],['static' => 1]), "Adicionar");
        $button_adicionar_medicamento_prescricao->addStyleClass('btn-default');
        $button_adicionar_medicamento_prescricao->setImage('fas:plus #2ecc71');
        $controle_especial->setValue('N');
        $dt_prescricao->setValue(date('Y-m-d'));
        $medicamento_prescricao_quantidade->setValue('1,00');
        $atendimento_id->setValue($param['atendimento_id']??'');

        $id->setSize(100);
        $dt_prescricao->setSize(110);
        $atendimento_id->setSize(200);
        $controle_especial->setSize('100%');
        $medicamento_prescricao_id->setSize(200);
        $medicamento_prescricao_posologia->setSize('100%');
        $medicamento_prescricao_quantidade->setSize('100%');
        $medicamento_prescricao_medicamento->setSize('100%');

        $button_adicionar_medicamento_prescricao->id = '611a7d9ee39ab';

        $row1 = $this->form->addFields([new TLabel("Código:", null, '14px', null, '100%'),$id,$atendimento_id]);
        $row1->layout = ['col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Receituário controle especial:", '#ff0000', '14px', null, '100%'),$controle_especial],[new TLabel("Data:", '#FF0000', '14px', null, '100%'),$dt_prescricao]);
        $row2->layout = ['col-sm-4','col-sm-4'];

        $this->detailFormMedicamentoPrescricao = new BootstrapFormBuilder('detailFormMedicamentoPrescricao');
        $this->detailFormMedicamentoPrescricao->setProperty('style', 'border:none; box-shadow:none; width:100%;');

        $this->detailFormMedicamentoPrescricao->setProperty('class', 'form-horizontal builder-detail-form');

        $row3 = $this->detailFormMedicamentoPrescricao->addFields([new TFormSeparator("Medicamentos", '#333', '18', '#eee')]);
        $row3->layout = [' col-sm-12'];

        $row4 = $this->detailFormMedicamentoPrescricao->addFields([new TLabel("Medicamento:", '#ff0000', '14px', null, '100%'),$medicamento_prescricao_medicamento,$medicamento_prescricao_id],[new TLabel("Posologia:", null, '14px', null, '100%'),$medicamento_prescricao_posologia],[new TLabel("Quantidade:", '#ff0000', '14px', null, '100%'),$medicamento_prescricao_quantidade]);
        $row4->layout = [' col-sm-7',' col-sm-3',' col-sm-2'];

        $row5 = $this->detailFormMedicamentoPrescricao->addFields([$button_adicionar_medicamento_prescricao]);
        $row5->layout = [' col-sm-12'];

        $row6 = $this->detailFormMedicamentoPrescricao->addFields([new THidden('medicamento_prescricao__row__id')]);
        $this->medicamento_prescricao_criteria = new TCriteria();

        $this->medicamento_prescricao_list = new BootstrapDatagridWrapper(new TDataGrid);
        $this->medicamento_prescricao_list->generateHiddenFields();
        $this->medicamento_prescricao_list->setId('medicamento_prescricao_list');

        $this->medicamento_prescricao_list->style = 'width:100%';
        $this->medicamento_prescricao_list->class .= ' table-bordered';

        $column_medicamento_prescricao_medicamento = new TDataGridColumn('medicamento', "Medicamento", 'left');
        $column_medicamento_prescricao_posologia = new TDataGridColumn('posologia', "Posologia", 'left');
        $column_medicamento_prescricao_quantidade = new TDataGridColumn('quantidade', "Quantidade", 'center' , '100px');

        $column_medicamento_prescricao__row__data = new TDataGridColumn('__row__data', '', 'center');
        $column_medicamento_prescricao__row__data->setVisibility(false);

        $action_onEditDetailMedicamento = new TDataGridAction(array('PrescricaoForm', 'onEditDetailMedicamento'));
        $action_onEditDetailMedicamento->setUseButton(false);
        $action_onEditDetailMedicamento->setButtonClass('btn btn-default btn-sm');
        $action_onEditDetailMedicamento->setLabel("Editar");
        $action_onEditDetailMedicamento->setImage('far:edit #478fca');
        $action_onEditDetailMedicamento->setFields(['__row__id', '__row__data']);

        $this->medicamento_prescricao_list->addAction($action_onEditDetailMedicamento);
        $action_onDeleteDetailMedicamento = new TDataGridAction(array('PrescricaoForm', 'onDeleteDetailMedicamento'));
        $action_onDeleteDetailMedicamento->setUseButton(false);
        $action_onDeleteDetailMedicamento->setButtonClass('btn btn-default btn-sm');
        $action_onDeleteDetailMedicamento->setLabel("Excluir");
        $action_onDeleteDetailMedicamento->setImage('fas:trash-alt #dd5a43');
        $action_onDeleteDetailMedicamento->setFields(['__row__id', '__row__data']);

        $this->medicamento_prescricao_list->addAction($action_onDeleteDetailMedicamento);

        $this->medicamento_prescricao_list->addColumn($column_medicamento_prescricao_medicamento);
        $this->medicamento_prescricao_list->addColumn($column_medicamento_prescricao_posologia);
        $this->medicamento_prescricao_list->addColumn($column_medicamento_prescricao_quantidade);

        $this->medicamento_prescricao_list->addColumn($column_medicamento_prescricao__row__data);

        $this->medicamento_prescricao_list->createModel();
        $this->detailFormMedicamentoPrescricao->addContent([$this->medicamento_prescricao_list]);
        $row7 = $this->form->addFields([$this->detailFormMedicamentoPrescricao]);
        $row7->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave'],['static' => 1]), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=PrescricaoForm]');
        $style->width = '70% !important';   
        $style->show(true);

    }

    public  function onAddDetailMedicamentoPrescricao($param = null) 
    {
        try
        {
            $data = $this->form->getData();

            $errors = [];
            $requiredFields = [];
            $requiredFields[] = ['label'=>"Medicamento", 'name'=>"medicamento_prescricao_medicamento", 'class'=>'TRequiredValidator', 'value'=>[]];
            $requiredFields[] = ['label'=>"Quantidade", 'name'=>"medicamento_prescricao_quantidade", 'class'=>'TRequiredValidator', 'value'=>[]];
            foreach($requiredFields as $requiredField)
            {
                try
                {
                    (new $requiredField['class'])->validate($requiredField['label'], $data->{$requiredField['name']}, $requiredField['value']);
                }
                catch(Exception $e)
                {
                    $errors[] = $e->getMessage() . '.';
                }
             }
             if(count($errors) > 0)
             {
                 throw new Exception(implode('<br>', $errors));
             }

            $__row__id = !empty($data->medicamento_prescricao__row__id) ? $data->medicamento_prescricao__row__id : 'b'.uniqid();

            TTransaction::open(self::$database);

            $grid_data = new Medicamento();
            $grid_data->__row__id = $__row__id;
            $grid_data->medicamento = $data->medicamento_prescricao_medicamento;
            $grid_data->id = $data->medicamento_prescricao_id;
            $grid_data->posologia = $data->medicamento_prescricao_posologia;
            $grid_data->quantidade = $data->medicamento_prescricao_quantidade;

            $__row__data = array_merge($grid_data->toArray(), (array)$grid_data->getVirtualData());
            $__row__data['__row__id'] = $__row__id;
            $__row__data['__display__']['medicamento'] =  $param['medicamento_prescricao_medicamento'] ?? null;
            $__row__data['__display__']['id'] =  $param['medicamento_prescricao_id'] ?? null;
            $__row__data['__display__']['posologia'] =  $param['medicamento_prescricao_posologia'] ?? null;
            $__row__data['__display__']['quantidade'] =  $param['medicamento_prescricao_quantidade'] ?? null;

            $grid_data->__row__data = base64_encode(serialize((object)$__row__data));
            $row = $this->medicamento_prescricao_list->addItem($grid_data);
            $row->id = $grid_data->__row__id;

            TDataGrid::replaceRowById('medicamento_prescricao_list', $grid_data->__row__id, $row);

            TTransaction::close();

            $data = new stdClass;
            $data->medicamento_prescricao_medicamento = '';
            $data->medicamento_prescricao_id = '';
            $data->medicamento_prescricao_posologia = '';
            $data->medicamento_prescricao_quantidade = '1,00';
            $data->medicamento_prescricao__row__id = '';

            TForm::sendData(self::$formName, $data);
            TScript::create("
               var element = $('#611a7d9ee39ab');
               if(typeof element.attr('add') != 'undefined')
               {
                   element.html(base64_decode(element.attr('add')));
               }
            ");

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }

    public static function onEditDetailMedicamento($param = null) 
    {
        try
        {

            $__row__data = unserialize(base64_decode($param['__row__data']));
            $__row__data->__display__ = is_array($__row__data->__display__) ? (object) $__row__data->__display__ : $__row__data->__display__;
            $fireEvents = true;
            $aggregate = false;

            $data = new stdClass;
            $data->medicamento_prescricao_medicamento = $__row__data->__display__->medicamento ?? null;
            $data->medicamento_prescricao_id = $__row__data->__display__->id ?? null;
            $data->medicamento_prescricao_posologia = $__row__data->__display__->posologia ?? null;
            $data->medicamento_prescricao_quantidade = $__row__data->__display__->quantidade ?? null;
            $data->medicamento_prescricao__row__id = $__row__data->__row__id;

            TForm::sendData(self::$formName, $data, $aggregate, $fireEvents);
            TScript::create("
               var element = $('#611a7d9ee39ab');
               if(!element.attr('add')){
                   element.attr('add', base64_encode(element.html()));
               }
               element.html(\"<span><i class='far fa-edit' style='color:#478fca;padding-right:4px;'></i>Editar</span>\");
               if(!element.attr('edit')){
                   element.attr('edit', base64_encode(element.html()));
               }
            ");

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }
    public static function onDeleteDetailMedicamento($param = null) 
    {
        try
        {

            $__row__data = unserialize(base64_decode($param['__row__data']));

            $data = new stdClass;
            $data->medicamento_prescricao_medicamento = '';
            $data->medicamento_prescricao_id = '';
            $data->medicamento_prescricao_posologia = '';
            $data->medicamento_prescricao_quantidade = '';
            $data->medicamento_prescricao__row__id = '';

            TForm::sendData(self::$formName, $data);

            TDataGrid::removeRowById('medicamento_prescricao_list', $__row__data->__row__id);
            TScript::create("
               var element = $('#611a7d9ee39ab');
               if(typeof element.attr('add') != 'undefined')
               {
                   element.html(base64_decode(element.attr('add')));
               }
            ");

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }
    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Prescricao(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->clinica_id = 1;

            $object->store(); // save the object 

            $messageAction = new TAction(['AtendimentoFormView', 'onShow']);   

            if(!empty($param['target_container']))
            {
                $messageAction->setParameter('target_container', $param['target_container']);
            }

            if(!empty($object->atendimento_id))
            {
                $messageAction->setParameter("id", $object->atendimento_id);
            }

            if(!empty($object->atendimento_id))
            {
                $messageAction->setParameter("key", $object->atendimento_id);
            }

            $messageAction->setParameter("current_tab_abas", "4");
            TForm::sendData(self::$formName, (object)['id' => $object->id]);

            $medicamento_prescricao_items = $this->storeMasterDetailItems('Medicamento', 'prescricao_id', 'medicamento_prescricao', $object, $param['medicamento_prescricao_list___row__data'] ?? [], $this->form, $this->medicamento_prescricao_list, function($masterObject, $detailObject){ 

                $detailObject->clinica_id = 1;

            }, $this->medicamento_prescricao_criteria); 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            new TMessage('info', "Registro salvo", $messageAction); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Prescricao($key); // instantiates the Active Record 

                $medicamento_prescricao_items = $this->loadMasterDetailItems('Medicamento', 'prescricao_id', 'medicamento_prescricao', $object, $this->form, $this->medicamento_prescricao_list, $this->medicamento_prescricao_criteria, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }); 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

