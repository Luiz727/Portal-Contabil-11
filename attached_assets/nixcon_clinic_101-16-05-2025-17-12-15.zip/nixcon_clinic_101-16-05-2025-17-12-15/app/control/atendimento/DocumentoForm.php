<?php

class DocumentoForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Documento';
    private static $primaryKey = 'id';
    private static $formName = 'form_DocumentoForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Documento");

        $variaveis = implode(' | ', array_keys(TipoDocumento::VARIAVEIS));

        $id = new TEntry('id');
        $atendimento_id = new THidden('atendimento_id');
        $tipo_documento_id = new TCombo('tipo_documento_id');
        $dt_validade = new TDate('dt_validade');
        $texto = new THtmlEditor('texto');

        $tipo_documento_id->setChangeAction(new TAction([$this,'changeTipoDocumento']));

        $tipo_documento_id->addValidation("Tipo documento", new TRequiredValidator()); 
        $dt_validade->addValidation("Validade", new TRequiredValidator()); 
        $texto->addValidation("Texto", new TRequiredValidator()); 

        $id->setEditable(false);
        $tipo_documento_id->enableSearch();
        $dt_validade->setMask('dd/mm/yyyy');
        $dt_validade->setDatabaseMask('yyyy-mm-dd');
        $dt_validade->setValue(date('d/m/Y'));
        $atendimento_id->setValue($param['atendimento_id']??'');

        $id->setSize(100);
        $texto->setSize('100%', 350);
        $atendimento_id->setSize(200);
        $dt_validade->setSize('100%');
        $tipo_documento_id->setSize('100%');

        $row1 = $this->form->addFields([new TLabel("Código:", null, '14px', null, '100%'),$id,$atendimento_id]);
        $row1->layout = ['col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Tipo documento:", '#ff0000', '14px', null, '100%'),$tipo_documento_id],[new TLabel("Validade:", '#ff0000', '14px', null, '100%'),$dt_validade]);
        $row2->layout = [' col-sm-10',' col-sm-2'];

        $row3 = $this->form->addFields([new TLabel("Variavéis", '#000000', '14px', 'B', '100%'),new TLabel("use as variáveis abaixo para preencher o texto automáticamente:", '#607D8B', '10px', null, '100%'),new TLabel("{$variaveis}", null, '10px', 'B')]);
        $row3->layout = [' col-sm-6 col-xl-12'];

        $row4 = $this->form->addFields([new TLabel("Texto:", '#ff0000', '14px', null, '100%'),$texto]);
        $row4->layout = [' col-sm-12'];

        $row1->style = 'display: none';
        $tipo_documento_id->setDefaultOption('Manual');

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=DocumentoForm]');
        $style->width = '70% !important';   
        $style->show(true);

    }

    public static function changeTipoDocumento($param = null) 
    {
        try 
        {

            $data = new stdClass;

            if (empty($param['key']))
            {
                $data->texto = '';
            }
            else
            {
                TTransaction::open(self::$database);

                $tipo_documento = TipoDocumento::find($param['key']);
                $data->texto = $tipo_documento->texto_padrao;

                TTransaction::close();
            }

            TForm::sendData(self::$formName, $data);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Documento(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            if (empty($object->id))
            {
                $object->dt_preenchimento = date('Y-m-d H:i:s');
                $object->autenticador = strtoupper(TextService::uuid());
            }

            if (!$data->id)
            {
                $object->clinica_id = PermissaoService::getUnidadeDefault();
            }

            $object->store(); // save the object 

            $messageAction = new TAction(['AtendimentoFormView', 'onShow']);   

            if(!empty($param['target_container']))
            {
                $messageAction->setParameter('target_container', $param['target_container']);
            }

            if(!empty($object->atendimento_id))
            {
                $messageAction->setParameter("key", $object->atendimento_id);
            }

            if(!empty($object->atendimento_id))
            {
                $messageAction->setParameter("id", $object->atendimento_id);
            }

            $messageAction->setParameter("current_tab_abas", "5"); 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            new TMessage('info', "Registro salvo", $messageAction); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Documento($key); // instantiates the Active Record 

                $criteria = new TCriteria();
                $criteria->add(new TFilter('clinica_id', '=', $object->atendimento->clinica_id));

                $items = TipoDocumento::getIndexedArray('id', 'nome', $criteria);

                $this->form->getField('tipo_documento_id')->addItems($items);

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

        if (!empty($param['atendimento_id']))
        {
            TTransaction::open(self::$database);

            $atendimento = new Atendimento($param['atendimento_id']);

            $criteria = new TCriteria();
            $criteria->add(new TFilter('clinica_id', '=', $atendimento->clinica_id));

            $items = TipoDocumento::getIndexedArray('id', 'nome', $criteria);

            $this->form->getField('tipo_documento_id')->addItems($items);

            TTransaction::close();
        }
    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

