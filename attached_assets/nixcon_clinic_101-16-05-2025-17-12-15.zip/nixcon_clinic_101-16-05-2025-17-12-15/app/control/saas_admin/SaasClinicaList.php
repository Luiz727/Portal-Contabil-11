<?php

class SaasClinicaList extends TPage
{
    private $form; // form
    private $datagrid; // listing
    private $pageNavigation;
    private $loaded;
    private $filter_criteria;
    private static $database = 'clinica';
    private static $activeRecord = 'Clinica';
    private static $primaryKey = 'id';
    private static $formName = 'formList_Clinica';
    private $showMethods = ['onReload', 'onSearch', 'onRefresh', 'onClearFilters'];
    private $limit = 20;

    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct($param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        // define the form title
        $this->form->setFormTitle("Listagem de clínicas");
        $this->limit = 20;

        $nome = new TEntry('nome');
        $cnpj = new TEntry('cnpj');
        $email = new TEntry('email');


        $cnpj->setMask('99.999.999/9999-99');
        $nome->setSize('100%');
        $cnpj->setSize('100%');
        $email->setSize('100%');

        $row1 = $this->form->addFields([new TLabel("Nome:", null, '14px', null, '100%'),$nome]);
        $row1->layout = ['col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("CNPJ:", null, '14px', null, '100%'),$cnpj],[new TLabel("E-mail:", null, '14px', null, '100%'),$email]);
        $row2->layout = ['col-sm-6','col-sm-6'];

        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );

        $btn_onsearch = $this->form->addAction("Buscar", new TAction([$this, 'onSearch']), 'fas:search #ffffff');
        $this->btn_onsearch = $btn_onsearch;
        $btn_onsearch->addStyleClass('btn-primary'); 

        // creates a Datagrid
        $this->datagrid = new TDataGrid;
        $this->datagrid->setId(__CLASS__.'_datagrid');

        $this->datagrid_form = new TForm('datagrid_'.self::$formName);
        $this->datagrid_form->onsubmit = 'return false';

        $this->datagrid = new BootstrapDatagridWrapper($this->datagrid);
        $this->filter_criteria = new TCriteria;

        $this->datagrid->disableDefaultClick();
        $this->datagrid->style = 'width: 100%';
        $this->datagrid->setHeight(250);

        $column_id = new TDataGridColumn('id', "Código", 'center' , '70px');
        $column_cidade_nome = new TDataGridColumn('cidade->nome', "Cidade", 'left');
        $column_nome = new TDataGridColumn('nome', "Nome", 'left');
        $column_cnpj = new TDataGridColumn('cnpj', "CNPJ", 'left');
        $column_telefone = new TDataGridColumn('telefone', "Telefone", 'left');
        $column_email = new TDataGridColumn('email', "E-mail", 'left');
        $column_system_unit_id_transformed = new TDataGridColumn('system_unit_id', "Link Agendamento Online", 'center');

        $column_system_unit_id_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if ($value) 
            {
                if (isset($value))
                {

                    $clinica = $object->token;

                    $referer = $_SERVER['HTTP_REFERER'];
                    $link = substr($referer, 0, strpos($referer, 'index.php'));
                    $link .= "home-{$clinica}";

                    $botao = new HClipboardButton('botao');
                    $id = 'tbutton_' . mt_rand(1000000000, 1999999999);
                    $botao->setId($id);
                    $botao->setData($link);
                    $botao->setLabel('️Copiar');
                    $botao->setImage('fa:copy');
                    $botao->addFunction(
                        "setTimeout( function() {
                            let text = btoa('Link copiado para area de transferencia'); 
                            __adianti_show_toast64('success', text, 'bottom left', 'fa fa-thumbs-up green');
                        }, 1 );
                    "
                    );

                    $botao->setClass('btn_clipboard');
                    return "{$link} <br> ".$botao;
                }
            }
            return '';

        });        

        $order_id = new TAction(array($this, 'onReload'));
        $order_id->setParameter('order', 'id');
        $column_id->setAction($order_id);

        $this->datagrid->addColumn($column_id);
        $this->datagrid->addColumn($column_cidade_nome);
        $this->datagrid->addColumn($column_nome);
        $this->datagrid->addColumn($column_cnpj);
        $this->datagrid->addColumn($column_telefone);
        $this->datagrid->addColumn($column_email);
        $this->datagrid->addColumn($column_system_unit_id_transformed);

        $action_onEdit = new TDataGridAction(array('SaasClinicaForm', 'onEdit'));
        $action_onEdit->setUseButton(false);
        $action_onEdit->setButtonClass('btn btn-default btn-sm');
        $action_onEdit->setLabel("Editar");
        $action_onEdit->setImage('far:edit #478fca');
        $action_onEdit->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onEdit);

        $action_onDelete = new TDataGridAction(array('SaasClinicaList', 'onDelete'));
        $action_onDelete->setUseButton(false);
        $action_onDelete->setButtonClass('btn btn-default btn-sm');
        $action_onDelete->setLabel("Excluir");
        $action_onDelete->setImage('fas:trash-alt #dd5a43');
        $action_onDelete->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onDelete);

        $action_onCriarEmitente = new TDataGridAction(array('SaasClinicaList', 'onCriarEmitente'));
        $action_onCriarEmitente->setUseButton(true);
        $action_onCriarEmitente->setButtonClass('btn btn-default btn-sm');
        $action_onCriarEmitente->setLabel("Criar Emitente");
        $action_onCriarEmitente->setImage('fas:user-plus #03A9F4');
        $action_onCriarEmitente->setField(self::$primaryKey);
        $action_onCriarEmitente->setDisplayCondition('SaasClinicaList::onExibirCriarEmitente');

        $this->datagrid->addAction($action_onCriarEmitente);

        $action_onAtualizarEmitente = new TDataGridAction(array('SaasClinicaList', 'onAtualizarEmitente'));
        $action_onAtualizarEmitente->setUseButton(false);
        $action_onAtualizarEmitente->setButtonClass('btn btn-default btn-sm');
        $action_onAtualizarEmitente->setLabel("Atualizar Emitente");
        $action_onAtualizarEmitente->setImage('fas:user-cog #000000');
        $action_onAtualizarEmitente->setField(self::$primaryKey);
        $action_onAtualizarEmitente->setDisplayCondition('SaasClinicaList::onExibirAtualizarEmitente');

        $this->datagrid->addAction($action_onAtualizarEmitente);

        $action_onAtualizarParametrosFiscais = new TDataGridAction(array('SaasClinicaList', 'onAtualizarParametrosFiscais'));
        $action_onAtualizarParametrosFiscais->setUseButton(false);
        $action_onAtualizarParametrosFiscais->setButtonClass('btn btn-default btn-sm');
        $action_onAtualizarParametrosFiscais->setLabel("Atualizar Parametros Fiscais");
        $action_onAtualizarParametrosFiscais->setImage('fas:file-invoice-dollar #673AB7');
        $action_onAtualizarParametrosFiscais->setField(self::$primaryKey);
        $action_onAtualizarParametrosFiscais->setDisplayCondition('SaasClinicaList::onExibirParametrosFiscais');

        $this->datagrid->addAction($action_onAtualizarParametrosFiscais);

        // create the datagrid model
        $this->datagrid->createModel();

        // creates the page navigation
        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
        $this->pageNavigation->setWidth($this->datagrid->getWidth());

        $panel = new TPanelGroup("Listagem de clínicas");
        $panel->datagrid = 'datagrid-container';
        $this->datagridPanel = $panel;
        $this->datagrid_form->add($this->datagrid);
        $panel->add($this->datagrid_form);

        $panel->addFooter($this->pageNavigation);

        $headerActions = new TElement('div');
        $headerActions->class = ' datagrid-header-actions ';
        $headerActions->style = 'justify-content: space-between;';

        $head_left_actions = new TElement('div');
        $head_left_actions->class = ' datagrid-header-actions-left-actions ';

        $head_right_actions = new TElement('div');
        $head_right_actions->class = ' datagrid-header-actions-left-actions ';

        $headerActions->add($head_left_actions);
        $headerActions->add($head_right_actions);

        $panel->getBody()->insert(0, $headerActions);

        $button_atualizar = new TButton('button_button_atualizar');
        $button_atualizar->setAction(new TAction(['SaasClinicaList', 'onRefresh']), "Atualizar");
        $button_atualizar->addStyleClass('btn-default');
        $button_atualizar->setImage('fas:sync-alt #03a9f4');

        $this->datagrid_form->addField($button_atualizar);

        $button_filtros = new TButton('button_button_filtros');
        $button_filtros->setAction(new TAction(['SaasClinicaList', 'onShowCurtainFilters']), "Filtros");
        $button_filtros->addStyleClass('btn-default');
        $button_filtros->setImage('fas:filter #000000');

        $this->datagrid_form->addField($button_filtros);

        $button_limpar_filtros = new TButton('button_button_limpar_filtros');
        $button_limpar_filtros->setAction(new TAction(['SaasClinicaList', 'onClearFilters']), "Limpar filtros");
        $button_limpar_filtros->addStyleClass('btn-default');
        $button_limpar_filtros->setImage('fas:eraser #f44336');

        $this->datagrid_form->addField($button_limpar_filtros);

        $dropdown_button_exportar = new TDropDown("Exportar", 'fas:file-export #2d3436');
        $dropdown_button_exportar->setPullSide('right');
        $dropdown_button_exportar->setButtonClass('btn btn-default waves-effect dropdown-toggle');
        $dropdown_button_exportar->addPostAction( "CSV", new TAction(['SaasClinicaList', 'onExportCsv'],['static' => 1]), 'datagrid_'.self::$formName, 'fas:table #00b894' );
        $dropdown_button_exportar->addPostAction( "PDF", new TAction(['SaasClinicaList', 'onExportPdf'],['static' => 1]), 'datagrid_'.self::$formName, 'far:file-pdf #e74c3c' );

        $head_left_actions->add($button_atualizar);
        $head_left_actions->add($button_filtros);
        $head_left_actions->add($button_limpar_filtros);

        $head_right_actions->add($dropdown_button_exportar);

        $this->divLimites = new TElement('div');
        $panel->getBody()->insert(0, $this->divLimites);

        $this->button_filtros = $button_filtros;

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["SaaS Admin","Admin Clínicas"]));
        }

        $container->add($panel);

        parent::add($container);

    }

    public function onDelete($param = null) 
    { 
        if(isset($param['delete']) && $param['delete'] == 1)
        {
            try
            {
                // get the paramseter $key
                $key = $param['key'];
                // open a transaction with database
                TTransaction::open(self::$database);

                // instantiates object
                $object = new Clinica($key, FALSE); 

                // deletes the object from the database
                $object->delete();

                // close the transaction
                TTransaction::close();

                // reload the listing
                $this->onReload( $param );
                // shows the success message
                new TMessage('info', AdiantiCoreTranslator::translate('Record deleted'));
            }
            catch (Exception $e) // in case of exception
            {
                // shows the exception error message
                new TMessage('error', $e->getMessage());
                // undo all pending operations
                TTransaction::rollback();
            }
        }
        else
        {
            // define the delete action
            $action = new TAction(array($this, 'onDelete'));
            $action->setParameters($param); // pass the key paramseter ahead
            $action->setParameter('delete', 1);
            // shows a dialog to the user
            new TQuestion(AdiantiCoreTranslator::translate('Do you really want to delete ?'), $action);   
        }
    }
    public static function onCriarEmitente($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $configs = SaasConfiguracaoService::getConfiguracoes();

            $gateway = SaasConfiguracaoService::getGatewayNFSESoftwareHouse($configs);

            $clinica = new Clinica($param['key']);

            $emitentes = $gateway->getEmitentes();

            if($emitentes)
            {
                foreach($emitentes as $emitente)
                {
                    if($emitente->status == 'ATIVO' && $emitente->cnpj == TextService::removeMask($clinica->cnpj))
                    {
                        $clinica->token_integra_notas = $emitente->token;
                        $clinica->emitente_configurado = 'T';
                        $clinica->store();

                        TTransaction::close();

                        new TMessage('info', "Emite já havia sido configurado para a Clínica:<br> {$clinica->nome} - {$clinica->id}");

                        self::manageRow($clinica->id);

                        return true;
                    }
                }
            }

            $dados = new stdClass();
            $dados->nome = $clinica->nome;
            $dados->razao = $clinica->razao_social;
            $dados->telefone = $clinica->telefone;
            $dados->email = $clinica->email;
            $dados->rua = $clinica->rua;
            $dados->numero = $clinica->numero;
            $dados->complemento = $clinica->complemento;
            $dados->bairro = $clinica->bairro;
            $dados->cnum = $clinica->cidade->codigo_ibge;
            $dados->municipio = $clinica->cidade->nome;
            $dados->uf = $clinica->cidade->estado->sigla;
            $dados->cep = $clinica->cep;
            $dados->documentos = ['nfse' => true];

            $result = $gateway->criaEmitente($dados);

            $clinica->token_integra_notas = $result->token;
            $clinica->emitente_configurado = 'T';
            $clinica->store();

            TTransaction::close();

            if($clinica->certificado_a1_conteudo && $clinica->senha_certificado_a1)
            {
                $clinicaConfig = clone $clinica;
                $clinicaConfig->nfse_emissao_producao = 'T';

                $gateway = ClinicaConfiguracaoService::getGatewayNFSE($clinicaConfig);
                $gateway->atualizaCertificadoEmitente([
                    'certificado' => $clinica->certificado_a1_conteudo,
                    'senha' => $clinica->senha_certificado_a1
                ]);
            }

            self::manageRow($clinica->id);

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onExibirCriarEmitente($object)
    {
        try 
        {
            if($object->emitente_configurado == 'F')
            {
                return true;
            }

            return false;
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onAtualizarEmitente($param = null) 
    {
        try 
        {

            TTransaction::open(self::$database);

            $clinica = new Clinica($param['key']);

            $clinicaConfig = clone $clinica;
            $clinicaConfig->nfse_emissao_producao = 'T';

            $gateway = ClinicaConfiguracaoService::getGatewayNFSE($clinicaConfig);

            $dados = new stdClass();
            $dados->nome = $clinica->nome;
            $dados->razao = $clinica->razao_social;
            $dados->telefone = TextService::removeMask($clinica->telefone);
            $dados->email = $clinica->email;
            $dados->rua = $clinica->rua;
            $dados->numero = $clinica->numero;
            $dados->complemento = $clinica->complemento;
            $dados->bairro = $clinica->bairro;
            $dados->cnum = $clinica->cidade->codigo_ibge;
            $dados->municipio = $clinica->cidade->nome;
            $dados->uf = $clinica->cidade->estado->sigla;
            $dados->cep = TextService::removeMask($clinica->cep);
            $dados->documentos = ['nfse' => true];

            $result = $gateway->atualizaEmitente($dados);

            TTransaction::close();

            if($clinica->certificado_a1_conteudo && $clinica->senha_certificado_a1)
            {
                $clinicaConfig = clone $clinica;
                $clinicaConfig->nfse_emissao_producao = 'T';

                $gateway = ClinicaConfiguracaoService::getGatewayNFSE($clinicaConfig);
                $gateway->atualizaCertificadoEmitente([
                    'certificado' => $clinica->certificado_a1_conteudo,
                    'senha' => $clinica->senha_certificado_a1
                ]);
            }

            self::manageRow($clinica->id);

            new TMessage('info', 'Emitente atualizado!');

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onExibirAtualizarEmitente($object)
    {
        try 
        {
            if($object->emitente_configurado == 'T')
            {
                return true;
            }

            return false;
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onAtualizarParametrosFiscais($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $clinica = new Clinica($param['key']);

            if(!$clinica->token_integra_notas)
            {
                throw new Exception('O token de produção do integra notas não está cadastrado!');
            }

            if(!$clinica->cidade->codigo_ibge)
            {
                throw new Exception("Códgigo do IBGE da cidade {$clinica->cidade->nome} da clínica não foi cadastrado!");
            }

            $gateway = ClinicaConfiguracaoService::getGatewayNFSE($clinica);

            $info = $gateway->getNfseInfo($clinica->cidade->codigo_ibge);

            $clinica->nfse_info = json_encode($info);

            $clinica->store();

            TTransaction::close();

            new TMessage('info', 'Parâmetros importados');

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onExibirParametrosFiscais($object)
    {
        try 
        {
            if($object->emitente_configurado == 'T')
            {
                return true;
            }

            return false;
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onExportCsv($param = null) 
    {
        try
        {
            $output = 'app/output/'.uniqid().'.csv';

            if ( (!file_exists($output) && is_writable(dirname($output))) OR is_writable($output))
            {
                $this->limit = 0;
                $objects = $this->onReload();

                if ($objects)
                {
                    $handler = fopen($output, 'w');
                    TTransaction::open(self::$database);

                    foreach ($objects as $object)
                    {
                        $row = [];
                        foreach ($this->datagrid->getColumns() as $column)
                        {
                            $column_name = $column->getName();

                            if (isset($object->$column_name))
                            {
                                $row[] = is_scalar($object->$column_name) ? $object->$column_name : '';
                            }
                            else if (method_exists($object, 'render'))
                            {
                                $column_name = (strpos($column_name, '{') === FALSE) ? ( '{' . $column_name . '}') : $column_name;
                                $row[] = $object->render($column_name);
                            }
                        }

                        fputcsv($handler, $row);
                    }

                    fclose($handler);
                    TTransaction::close();
                }
                else
                {
                    throw new Exception(_t('No records found'));
                }

                TPage::openFile($output);
            }
            else
            {
                throw new Exception(_t('Permission denied') . ': ' . $output);
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }
    public function onExportPdf($param = null) 
    {
        try
        {
            $output = 'app/output/'.uniqid().'.pdf';

            if ( (!file_exists($output) && is_writable(dirname($output))) OR is_writable($output))
            {
                $this->limit = 0;
                $this->datagrid->prepareForPrinting();
                $this->onReload();

                $html = clone $this->datagrid;
                $contents = file_get_contents('app/resources/styles-print.html') . $html->getContents();

                $dompdf = new \Dompdf\Dompdf;
                $dompdf->loadHtml($contents);
                $dompdf->setPaper('A4', 'portrait');
                $dompdf->render();

                file_put_contents($output, $dompdf->output());

                $window = TWindow::create('PDF', 0.8, 0.8);
                $object = new TElement('object');
                $object->data  = $output;
                $object->type  = 'application/pdf';
                $object->style = "width: 100%; height:calc(100% - 10px)";

                $window->add($object);
                $window->show();
            }
            else
            {
                throw new Exception(_t('Permission denied') . ': ' . $output);
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }
    public function onRefresh($param = null) 
    {
        $this->onReload([]);
    }
    public static function onShowCurtainFilters($param = null) 
    {
        try 
        {
            //code here

                        $filter = new self([]);

            $btnClose = new TButton('closeCurtain');
            $btnClose->class = 'btn btn-sm btn-default';
            $btnClose->style = 'margin-right:10px;';
            $btnClose->onClick = "Template.closeRightPanel();";
            $btnClose->setLabel("Fechar");
            $btnClose->setImage('fas:times');

            $filter->form->addHeaderWidget($btnClose);

            $page = new TPage();
            $page->setTargetContainer('adianti_right_panel');
            $page->setProperty('page-name', 'SaasClinicaListSearch');
            $page->setProperty('page_name', 'SaasClinicaListSearch');
            $page->adianti_target_container = 'adianti_right_panel';
            $page->target_container = 'adianti_right_panel';
            $page->add($filter->form);
            $page->setIsWrapped(true);
            $page->show();

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onClearFilters($param = null) 
    {
        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }

    /**
     * Register the filter in the session
     */
    public function onSearch($param = null)
    {
        $data = $this->form->getData();
        $filters = [];

        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        if (isset($data->nome) AND ( (is_scalar($data->nome) AND $data->nome !== '') OR (is_array($data->nome) AND (!empty($data->nome)) )) )
        {

            $filters[] = new TFilter('nome', 'like', "%{$data->nome}%");// create the filter 
        }

        if (isset($data->cnpj) AND ( (is_scalar($data->cnpj) AND $data->cnpj !== '') OR (is_array($data->cnpj) AND (!empty($data->cnpj)) )) )
        {

            $filters[] = new TFilter('cnpj', 'like', "%{$data->cnpj}%");// create the filter 
        }

        if (isset($data->email) AND ( (is_scalar($data->email) AND $data->email !== '') OR (is_array($data->email) AND (!empty($data->email)) )) )
        {

            $filters[] = new TFilter('email', 'like', "%{$data->email}%");// create the filter 
        }

        $this->button_filtros->style = 'position: relative';
        $countFiltros = count($filters);

        if ($countFiltros)
        {
            $this->button_filtros->setLabel('Filtros'. "<span class='badge badge-success' style='position: absolute'>{$countFiltros}<span>");
        }

        // fill the form with data again
        $this->form->setData($data);

        // keep the search data in the session
        TSession::setValue(__CLASS__.'_filter_data', $data);
        TSession::setValue(__CLASS__.'_filters', $filters);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }

    /**
     * Load the datagrid with data
     */
    public function onReload($param = NULL)
    {
        try
        {
            // open a transaction with database 'clinica'
            TTransaction::open(self::$database);

            // creates a repository for Clinica
            $repository = new TRepository(self::$activeRecord);

            $criteria = clone $this->filter_criteria;

            if (empty($param['order']))
            {
                $param['order'] = 'id';    
            }

            if (empty($param['direction']))
            {
                $param['direction'] = 'desc';
            }

            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $this->limit);

            if($filters = TSession::getValue(__CLASS__.'_filters'))
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            $this->datagrid->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {

                    $row = $this->datagrid->addItem($object);
                    $row->id = "row_{$object->id}";

                }
            }

            // reset the criteria for record count
            $criteria->resetProperties();
            $count= $repository->count($criteria);

            $this->pageNavigation->setCount($count); // count of records
            $this->pageNavigation->setProperties($param); // order, page
            $this->pageNavigation->setLimit($this->limit); // limit

            $plano_limite_unidades = PermissaoService::getLimiteUnidades();

            $info = new BHelper(new TImage('far:question-circle #FF9800'));
            $info->enableHover();
            $info->setContent("O seu plano permite criar até {$plano_limite_unidades} unidades.");

            $this->divLimites->add("

                Utilizado {$count} de {$plano_limite_unidades} {$info}

            ");

            // close the transaction
            TTransaction::close();
            $this->loaded = true;

            return $objects;
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

    /**
     * method show()
     * Shows the page
     */
    public function show()
    {
        // check if the datagrid is already loaded
        if (!$this->loaded AND (!isset($_GET['method']) OR !(in_array($_GET['method'],  $this->showMethods))) )
        {
            if (func_num_args() > 0)
            {
                $this->onReload( func_get_arg(0) );
            }
            else
            {
                $this->onReload();
            }
        }
        parent::show();
    }

    public static function manageRow($id, $param = [])
    {
        $list = new self($param);

        $openTransaction = TTransaction::getDatabase() != self::$database ? true : false;

        if($openTransaction)
        {
            TTransaction::open(self::$database);    
        }

        $object = new Clinica($id);

        $row = $list->datagrid->addItem($object);
        $row->id = "row_{$object->id}";

        if($openTransaction)
        {
            TTransaction::close();    
        }

        TDataGrid::replaceRowById(__CLASS__.'_datagrid', $row->id, $row);
    }

}

