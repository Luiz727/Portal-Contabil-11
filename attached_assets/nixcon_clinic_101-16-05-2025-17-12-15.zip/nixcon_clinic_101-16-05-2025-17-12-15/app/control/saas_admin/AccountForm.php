<?php

class AccountForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Account';
    private static $primaryKey = 'id';
    private static $formName = 'form_AccountForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cliente");

        $criteria_cidade_id = new TCriteria();

        $id = new TEntry('id');
        $tipo_pessoa = new TCombo('tipo_pessoa');
        $razao_social = new TEntry('razao_social');
        $documento = new TEntry('documento');
        $nome_responsavel = new TEntry('nome_responsavel');
        $telefone = new TEntry('telefone');
        $email = new TEntry('email');
        $cep = new TEntry('cep');
        $buscar_cep = new TButton('buscar_cep');
        $rua = new TEntry('rua');
        $bairro = new TEntry('bairro');
        $cidade_id = new TDBUniqueSearch('cidade_id', 'clinica', 'Cidade', 'id', 'nome','nome asc' , $criteria_cidade_id );
        $numero = new TEntry('numero');
        $complemento = new TEntry('complemento');

        $tipo_pessoa->setChangeAction(new TAction([$this,'onChangeTipo']));

        $razao_social->addValidation("Nome", new TRequiredValidator()); 
        $nome_responsavel->addValidation("Nome responsavel", new TRequiredValidator()); 

        $id->setEditable(false);
        $tipo_pessoa->addItems(["J"=>"Jurídica","F"=>"Física"]);
        $tipo_pessoa->setValue('J');
        $tipo_pessoa->setDefaultOption(false);
        $buscar_cep->setAction(new TAction([$this, 'onSearchCEP']), "Buscar");
        $buscar_cep->addStyleClass('btn-default');
        $buscar_cep->setImage('fas:search #000000');
        $cidade_id->setMinLength(2);
        $cep->setMask('99.999-999');
        $telefone->setMask('(99) 9 9999-9999');
        $cidade_id->setMask('{nome} - {estado->sigla}');

        $id->setSize('100%');
        $rua->setSize('100%');
        $email->setSize('100%');
        $bairro->setSize('100%');
        $numero->setSize('100%');
        $telefone->setSize('100%');
        $documento->setSize('100%');
        $cidade_id->setSize('100%');
        $tipo_pessoa->setSize('100%');
        $complemento->setSize('100%');
        $razao_social->setSize('100%');
        $nome_responsavel->setSize('100%');
        $cep->setSize('calc(100% - 100px)');

        $this->form->appendPage("Dados");

        $this->form->addFields([new THidden('current_tab')]);
        $this->form->setTabFunction("$('[name=current_tab]').val($(this).attr('data-current_page'));");

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null, '100%'),$id]);
        $row1->layout = [' col-sm-4'];

        $row2 = $this->form->addFields([new TLabel("Tipo:", '#FF0000', '14px', null, '100%'),$tipo_pessoa],[new TLabel("Nome:", '#FF0000', '14px', null, '100%'),$razao_social]);
        $row2->layout = [' col-sm-4',' col-sm-8'];

        $row3 = $this->form->addFields([new TLabel("Documento:", '#FF0000', '14px', null, '100%'),$documento],[new TLabel("Nome responsavel:", '#ff0000', '14px', null, '100%'),$nome_responsavel],[new TLabel("Telefone:", null, '14px', null, '100%'),$telefone],[new TLabel("Email:", null, '14px', null, '100%'),$email]);
        $row3->layout = [' col-sm-4',' col-sm-8',' col-sm-4',' col-sm-8'];

        $this->form->appendPage("Endereço");
        $row4 = $this->form->addFields([new TLabel("CEP:", null, '14px', null, '100%'),$cep,$buscar_cep],[new TLabel("Rua:", null, '14px', null, '100%'),$rua]);
        $row4->layout = [' col-sm-4',' col-sm-8'];

        $row5 = $this->form->addFields([new TLabel("Bairro:", null, '14px', null, '100%'),$bairro],[new TLabel("Cidade:", null, '14px', null, '100%'),$cidade_id],[new TLabel("Numero:", null, '14px', null, '100%'),$numero]);
        $row5->layout = [' col-sm-4',' col-sm-5',' col-sm-3'];

        $row6 = $this->form->addFields([new TLabel("Complemento:", null, '14px', null, '100%'),$complemento]);
        $row6->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['AccountList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

    }

    public static function onChangeTipo($param = null) 
    {
        try 
        {
            if (! empty($param['tipo_pessoa']) && $param['tipo_pessoa'] == 'F')
            {
                TEntry::changeMask(self::$formName, 'documento', '999.999.999-99');
            }
            else
            {
                TEntry::changeMask(self::$formName, 'documento', '99.999.999/9999-99');
            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onSearchCEP($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database); // open a transaction

            if (! empty($param['cep']))
            {
                $cep = CEPService::get($param['cep']);

                $data = new stdClass;
                $data->cidade_id = $cep->cidade_id;
                $data->cidade = $cep->cidade;
                $data->bairro = $cep->bairro;
                $data->rua = $cep->rua;

                TForm::sendData(self::$formName, $data);
            }
            TTransaction::close(); 

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Account(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('AccountList', 'onShow', $loadPageParam); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Account($key); // instantiates the Active Record 
                self::onChangeTipo($object->toArray());

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

