<?php

class SaasServicoForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'SaasServico';
    private static $primaryKey = 'id';
    private static $formName = 'form_ServicoForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de serviço");

        $criteria_servico_grupo_imposto_id = new TCriteria();

        $id = new THidden('id');
        $nome = new TEntry('nome');
        $preco = new TNumeric('preco', '2', ',', '.' );
        $ativo = new TRadioGroup('ativo');
        $servico_grupo_imposto_id = new TDBCombo('servico_grupo_imposto_id', 'clinica', 'SaasServicoGrupoImposto', 'id', '{nome}','nome asc' , $criteria_servico_grupo_imposto_id );
        $descricao = new TText('descricao');

        $nome->addValidation("Nome", new TRequiredValidator()); 
        $preco->addValidation("Preço", new TRequiredValidator()); 
        $ativo->addValidation("Ativo", new TRequiredValidator()); 
        $descricao->addValidation("Descrição do serviço", new TRequiredValidator()); 

        $ativo->addItems(["T"=>"Sim","F"=>"Não"]);
        $ativo->setLayout('horizontal');
        $ativo->setValue('T');
        $ativo->setUseButton();
        $servico_grupo_imposto_id->enableSearch();
        $id->setSize(200);
        $nome->setSize('100%');
        $preco->setSize('100%');
        $ativo->setSize('100%');
        $descricao->setSize('99%', 150);
        $servico_grupo_imposto_id->setSize('100%');

        $row1 = $this->form->addFields([$id,new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$nome],[new TLabel("Preço:", '#ff0000', '14px', null, '100%'),$preco],[new TLabel("Ativo:", '#ff0000', '14px', null, '100%'),$ativo]);
        $row1->layout = ['col-sm-6',' col-sm-3',' col-sm-3'];

        $row2 = $this->form->addFields([new TLabel("Grupo de imposto:", '#FF0000', '14px', null, '100%'),$servico_grupo_imposto_id]);
        $row2->layout = [' col-sm-6'];

        $row3 = $this->form->addFields([new TLabel("Descrição do serviço:", '#ff0000', '14px', null, '100%'),$descricao]);
        $row3->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['SaasServicoList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new SaasServico(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            if (!$data->id)
            {
                $object->clinica_id = PermissaoService::getUnidadeDefault();
            }

            $object->store(); // save the object 

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('SaasServicoList', 'onShow', $loadPageParam); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new SaasServico($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

