<?php

class SaasContratoList extends TPage
{
    private $form; // form
    private $datagrid; // listing
    private $pageNavigation;
    private $loaded;
    private $filter_criteria;
    private static $database = 'clinica';
    private static $activeRecord = 'SaasContrato';
    private static $primaryKey = 'id';
    private static $formName = 'form_SaasContratoList';
    private $showMethods = ['onReload', 'onSearch', 'onRefresh', 'onClearFilters'];
    private $limit = 20;

    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct($param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        // define the form title
        $this->form->setFormTitle("Listagem de contratos");
        $this->limit = 20;

        $criteria_account_id = new TCriteria();
        $criteria_saas_contrato_status_id = new TCriteria();

        $id = new TEntry('id');
        $account_id = new TDBUniqueSearch('account_id', 'clinica', 'Account', 'id', 'razao_social','id asc' , $criteria_account_id );
        $saas_contrato_status_id = new TDBCombo('saas_contrato_status_id', 'clinica', 'SaasContratoStatus', 'id', '{nome}','nome asc' , $criteria_saas_contrato_status_id );
        $data_inicial = new TDate('data_inicial');
        $data_inicial_fim = new TDate('data_inicial_fim');
        $data_final = new TDate('data_final');
        $data_final_fim = new TDate('data_final_fim');
        $valor_total = new TNumeric('valor_total', '2', ',', '.' );
        $valor_total_fim = new TNumeric('valor_total_fim', '2', ',', '.' );


        $account_id->setMinLength(0);
        $account_id->setFilterColumns(["documento","email","razao_social","telefone"]);
        $saas_contrato_status_id->enableSearch();
        $data_final->setDatabaseMask('yyyy-mm-dd');
        $data_inicial->setDatabaseMask('yyyy-mm-dd');
        $data_final_fim->setDatabaseMask('yyyy-mm-dd');
        $data_inicial_fim->setDatabaseMask('yyyy-mm-dd');

        $data_final->setMask('dd/mm/yyyy');
        $data_inicial->setMask('dd/mm/yyyy');
        $data_final_fim->setMask('dd/mm/yyyy');
        $data_inicial_fim->setMask('dd/mm/yyyy');
        $account_id->setMask('{razao_social} ( {email} - {documento} - {telefone} )');

        $id->setSize('100%');
        $data_final->setSize(110);
        $data_inicial->setSize(110);
        $account_id->setSize('100%');
        $data_final_fim->setSize(110);
        $data_inicial_fim->setSize(110);
        $saas_contrato_status_id->setSize('100%');
        $valor_total->setSize('calc(50% - 50px)');
        $valor_total_fim->setSize('calc(50% - 50px)');

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null, '100%'),$id],[new TLabel("Cliente:", null, '14px', null, '100%'),$account_id],[new TLabel("Status:", null, '14px', null, '100%'),$saas_contrato_status_id]);
        $row1->layout = [' col-sm-2',' col-sm-7',' col-sm-3'];

        $row2 = $this->form->addFields([new TLabel("Data inicial:", null, '14px', null, '100%'),$data_inicial,new TLabel("até", null, '14px', null),$data_inicial_fim],[new TLabel("Data final:", null, '14px', null, '100%'),$data_final,new TLabel("até", null, '14px', null),$data_final_fim],[new TLabel("Valor total:", null, '14px', null, '100%'),$valor_total,new TLabel("até", null, '14px', null),$valor_total_fim]);
        $row2->layout = ['col-sm-4','col-sm-4','col-sm-4'];

        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );

        $btn_onsearch = $this->form->addAction("Buscar", new TAction([$this, 'onSearch']), 'fas:search #ffffff');
        $this->btn_onsearch = $btn_onsearch;
        $btn_onsearch->addStyleClass('btn-primary'); 

        // creates a Datagrid
        $this->datagrid = new TDataGrid;
        $this->datagrid->setId(__CLASS__.'_datagrid');

        $this->datagrid_form = new TForm('datagrid_'.self::$formName);
        $this->datagrid_form->onsubmit = 'return false';

        $this->datagrid = new BootstrapDatagridWrapper($this->datagrid);
        $this->filter_criteria = new TCriteria;

        $this->datagrid->style = 'width: 100%';
        $this->datagrid->setHeight(250);

        $column_id = new TDataGridColumn('id', "Id", 'center' , '70px');
        $column_account_razao_socialbraccount_email = new TDataGridColumn('{account->razao_social}<br>{account->email}', "Cliente", 'left');
        $column_data_inicial_transformed = new TDataGridColumn('data_inicial', "Data inicial", 'center');
        $column_data_final_transformed = new TDataGridColumn('data_final', "Data final", 'center');
        $column_criado_em_transformed = new TDataGridColumn('criado_em', "Criado em", 'center');
        $column_valor_total_transformed = new TDataGridColumn('valor_total', "Valor total", 'center');
        $column_saas_contrato_status_nome_transformed = new TDataGridColumn('saas_contrato_status->nome', "Status", 'center');
        $column_saas_plano_valor_saas_plano_nome = new TDataGridColumn('saas_plano_valor->saas_plano->nome', "Plano", 'left');
        $column_saas_plano_valor_recorrencia_transformed = new TDataGridColumn('saas_plano_valor->recorrencia', "Recorrência", 'center');

        $column_data_inicial_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_data_final_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_criado_em_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y H:i');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_valor_total_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });

        $column_saas_contrato_status_nome_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            return "<span class = 'label label-default' style='color:#fff; background-color: {$object->saas_contrato_status->cor}'> {$object->saas_contrato_status->nome} </span> ";

        });

        $column_saas_plano_valor_recorrencia_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            $label = new TElement('span');
            $label->{'class'} = 'label label-';

            if ($value == 'S' || $value == 'T') {
                $label->{'class'} .= 'success';
                $label->add('Sim');    

                return $label;
            }

            $label->{'class'} .= 'danger';
            $label->add('Não');

            return $label;
        });        

        $order_id = new TAction(array($this, 'onReload'));
        $order_id->setParameter('order', 'id');
        $column_id->setAction($order_id);

        $this->datagrid->addColumn($column_id);
        $this->datagrid->addColumn($column_account_razao_socialbraccount_email);
        $this->datagrid->addColumn($column_data_inicial_transformed);
        $this->datagrid->addColumn($column_data_final_transformed);
        $this->datagrid->addColumn($column_criado_em_transformed);
        $this->datagrid->addColumn($column_valor_total_transformed);
        $this->datagrid->addColumn($column_saas_contrato_status_nome_transformed);
        $this->datagrid->addColumn($column_saas_plano_valor_saas_plano_nome);
        $this->datagrid->addColumn($column_saas_plano_valor_recorrencia_transformed);

        $action_onEdit = new TDataGridAction(array('SaasContratoForm', 'onEdit'));
        $action_onEdit->setUseButton(false);
        $action_onEdit->setButtonClass('btn btn-default btn-sm');
        $action_onEdit->setLabel("Editar");
        $action_onEdit->setImage('far:edit #478fca');
        $action_onEdit->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onEdit);

        $action_onDelete = new TDataGridAction(array('SaasContratoList', 'onDelete'));
        $action_onDelete->setUseButton(false);
        $action_onDelete->setButtonClass('btn btn-default btn-sm');
        $action_onDelete->setLabel("Excluir");
        $action_onDelete->setImage('fas:trash-alt #dd5a43');
        $action_onDelete->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onDelete);

        $action_onEviarAvisoVencimento = new TDataGridAction(array('SaasContratoList', 'onEviarAvisoVencimento'));
        $action_onEviarAvisoVencimento->setUseButton(false);
        $action_onEviarAvisoVencimento->setButtonClass('btn btn-default btn-sm');
        $action_onEviarAvisoVencimento->setLabel("Aviso de vencimento");
        $action_onEviarAvisoVencimento->setImage('far:envelope #FF5722');
        $action_onEviarAvisoVencimento->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onEviarAvisoVencimento);

        $action_onGerarPagamento = new TDataGridAction(array('SaasContratoList', 'onGerarPagamento'));
        $action_onGerarPagamento->setUseButton(false);
        $action_onGerarPagamento->setButtonClass('btn btn-default btn-sm');
        $action_onGerarPagamento->setLabel("Gerar pagamento");
        $action_onGerarPagamento->setImage('fas:dollar-sign #8BC34A');
        $action_onGerarPagamento->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onGerarPagamento);

        $action_onEnviarEmailPlanoAtivado = new TDataGridAction(array('SaasContratoList', 'onEnviarEmailPlanoAtivado'));
        $action_onEnviarEmailPlanoAtivado->setUseButton(false);
        $action_onEnviarEmailPlanoAtivado->setButtonClass('btn btn-default btn-sm');
        $action_onEnviarEmailPlanoAtivado->setLabel("Enviar email de plano ativado");
        $action_onEnviarEmailPlanoAtivado->setImage('fas:paper-plane #FF9800');
        $action_onEnviarEmailPlanoAtivado->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onEnviarEmailPlanoAtivado);

        // create the datagrid model
        $this->datagrid->createModel();

        // creates the page navigation
        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
        $this->pageNavigation->setWidth($this->datagrid->getWidth());

        $panel = new TPanelGroup("Listagem de contratos");
        $panel->datagrid = 'datagrid-container';
        $this->datagridPanel = $panel;
        $this->datagrid_form->add($this->datagrid);
        $panel->add($this->datagrid_form);

        $panel->getBody()->class .= ' table-responsive';

        $panel->addFooter($this->pageNavigation);

        $headerActions = new TElement('div');
        $headerActions->class = ' datagrid-header-actions ';
        $headerActions->style = 'justify-content: space-between;';

        $head_left_actions = new TElement('div');
        $head_left_actions->class = ' datagrid-header-actions-left-actions ';

        $head_right_actions = new TElement('div');
        $head_right_actions->class = ' datagrid-header-actions-left-actions ';

        $headerActions->add($head_left_actions);
        $headerActions->add($head_right_actions);

        $panel->getBody()->insert(0, $headerActions);

        $button_cadastrar = new TButton('button_button_cadastrar');
        $button_cadastrar->setAction(new TAction(['SaasContratoForm', 'onShow']), "Cadastrar");
        $button_cadastrar->addStyleClass('btn-default');
        $button_cadastrar->setImage('fas:plus #69aa46');

        $this->datagrid_form->addField($button_cadastrar);

        $btnShowCurtainFilters = new TButton('button_btnShowCurtainFilters');
        $btnShowCurtainFilters->setAction(new TAction(['SaasContratoList', 'onShowCurtainFilters']), "Filtros");
        $btnShowCurtainFilters->addStyleClass('btn-default');
        $btnShowCurtainFilters->setImage('fas:filter #000000');

        $this->datagrid_form->addField($btnShowCurtainFilters);

        $button_limpar_filtros = new TButton('button_button_limpar_filtros');
        $button_limpar_filtros->setAction(new TAction(['SaasContratoList', 'onClearFilters']), "Limpar filtros");
        $button_limpar_filtros->addStyleClass('btn-default');
        $button_limpar_filtros->setImage('fas:eraser #f44336');

        $this->datagrid_form->addField($button_limpar_filtros);

        $button_atualizar = new TButton('button_button_atualizar');
        $button_atualizar->setAction(new TAction(['SaasContratoList', 'onRefresh']), "Atualizar");
        $button_atualizar->addStyleClass('btn-default');
        $button_atualizar->setImage('fas:sync-alt #03a9f4');

        $this->datagrid_form->addField($button_atualizar);

        $head_left_actions->add($button_cadastrar);
        $head_left_actions->add($btnShowCurtainFilters);
        $head_left_actions->add($button_limpar_filtros);
        $head_left_actions->add($button_atualizar);

        $this->btnShowCurtainFilters = $btnShowCurtainFilters;

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["SaaS Admin","Contratos"]));
        }

        $container->add($panel);

        parent::add($container);

    }

    public function onDelete($param = null) 
    { 
        if(isset($param['delete']) && $param['delete'] == 1)
        {
            try
            {
                // get the paramseter $key
                $key = $param['key'];
                // open a transaction with database
                TTransaction::open(self::$database);

                // instantiates object
                $object = new SaasContrato($key, FALSE); 

                // deletes the object from the database
                $object->delete();

                // close the transaction
                TTransaction::close();

                // reload the listing
                $this->onReload( $param );
                // shows the success message
                new TMessage('info', AdiantiCoreTranslator::translate('Record deleted'));
            }
            catch (Exception $e) // in case of exception
            {
                // shows the exception error message
                new TMessage('error', $e->getMessage());
                // undo all pending operations
                TTransaction::rollback();
            }
        }
        else
        {
            // define the delete action
            $action = new TAction(array($this, 'onDelete'));
            $action->setParameters($param); // pass the key paramseter ahead
            $action->setParameter('delete', 1);
            // shows a dialog to the user
            new TQuestion(AdiantiCoreTranslator::translate('Do you really want to delete ?'), $action);   
        }
    }
    public static function onEviarAvisoVencimento($param = null) 
    {
        try 
        {
            if(isset($param['enviar']) && $param['enviar'] == 1)
            {
                TTransaction::open(self::$database);

                $contrato = new SaasContrato($param['key']);

                $data_vencimento = TDate::date2br($contrato->data_final);
                $email = $contrato->account->email;
                $nome = $contrato->account->nome_responsavel;

                TTransaction::close();

                if(SaasEmailTemplateService::enviarAvisoVencimento($email, $nome, $data_vencimento))
                {
                    new TMessage('info', 'Email enviado');
                }
                else
                {
                    new TMEssage('error', 'Ocorreu um erro ao enviar, verifique os logs de erro.');
                }
            }
            else
            {
                $action = new TAction(['SaasContratoList', 'onEviarAvisoVencimento']);
                $action->setParameters($param); 
                $action->setParameter('enviar', 1);

                new TQuestion('Deseja enviar o aviso de vencimento?', $action);
            }

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onGerarPagamento($param = null) 
    {
        try 
        {
            if(isset($param['gerar']) && $param['gerar'] == 1)
            {
                try
                {
                    if (empty($param['saas_gateway_pagamento_id']))
                    {
                        throw new Exception("Informe o gateway");
                    }

                    $key = $param['key'];

                    TTransaction::open(self::$database);

                    $contrato = SaasContrato::find($key);
                    $gateway = SaasGatewayPagamento::find($param['saas_gateway_pagamento_id']);

                    if (empty($contrato))
                    {
                        throw new Exception("Contrato não encontrado");
                    }

                    if (empty($gateway))
                    {
                        throw new Exception("Gateway não encontrado");
                    }

                    $pagamento = SaasPagamentoService::createByContrato($contrato, $gateway);

                    TTransaction::close();

                    self::manageRow($key);

                    new TMessage('info', 'Link para pagamento: <br>' . $pagamento->link_gateway, null, 'Pagamento criado');
                }
                catch (Exception $e)
                {
                    new TMessage('error', $e->getMessage());
                    TTransaction::rollback();
                }
            }
            else
            {
                $criteria = new TCriteria();
                $criteria->add(new TFilter('ativo', '=', 'T'));

                $saas_gateway_pagamento_id = new TDBCombo('saas_gateway_pagamento_id', self::$database, 'SaasGatewayPagamento', 'id', 'nome', 'nome', $criteria);
                $saas_gateway_pagamento_id->setSize('100%');

                $form = new BootstrapFormBuilder;
                $form->addFields([new TLabel("Informe o gateway para gerar?"), $saas_gateway_pagamento_id]);

                $action = new TAction(array(__CLASS__, 'onGerarPagamento'));
                $action->setParameters($param);
                $action->setParameter('gerar', 1);

                $form->addAction("Gerar", $action);

                new TInputDialog('Deseja gerar um pagamento?', $form);   
            }
            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onEnviarEmailPlanoAtivado($param = null) 
    {
        try 
        {
            if(isset($param['enviar']) && $param['enviar'] == 1)
            {
                try
                {
                    $key = $param['key'];

                    TTransaction::open(self::$database);

                    $contrato = SaasContrato::find($key);

                    if (empty($contrato))
                    {
                        throw new Exception("Contrato não encontrado");
                    }

                    SaasEmailTemplateService::enviarPlanoAtivado($contrato);

                    TTransaction::close();

                    self::manageRow($key);

                    new TMessage('info', 'Email enviado!');
                }
                catch (Exception $e)
                {
                    new TMessage('error', $e->getMessage());
                }
            }
            else
            {
                $action = new TAction(['SaasContratoList', 'onEnviarEmailPlanoAtivado']);
                $action->setParameters($param); 
                $action->setParameter('enviar', 1);

                new TQuestion('Deseja enviar o email de plano ativado?', $action);
            }

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onShowCurtainFilters($param = null) 
    {
        try 
        {
            //code here

                        $filter = new self([]);

            $btnClose = new TButton('closeCurtain');
            $btnClose->class = 'btn btn-sm btn-default';
            $btnClose->style = 'margin-right:10px;';
            $btnClose->onClick = "Template.closeRightPanel();";
            $btnClose->setLabel("Fechar");
            $btnClose->setImage('fas:times');

            $filter->form->addHeaderWidget($btnClose);

            $page = new TPage();
            $page->setTargetContainer('adianti_right_panel');
            $page->setProperty('page-name', 'SaasContratoListSearch');
            $page->setProperty('page_name', 'SaasContratoListSearch');
            $page->adianti_target_container = 'adianti_right_panel';
            $page->target_container = 'adianti_right_panel';
            $page->add($filter->form);
            $page->setIsWrapped(true);
            $page->show();

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onClearFilters($param = null) 
    {
        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }
    public function onRefresh($param = null) 
    {
        $this->onReload([]);
    }

    /**
     * Register the filter in the session
     */
    public function onSearch($param = null)
    {
        $data = $this->form->getData();
        $filters = [];

        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        if (isset($data->id) AND ( (is_scalar($data->id) AND $data->id !== '') OR (is_array($data->id) AND (!empty($data->id)) )) )
        {

            $filters[] = new TFilter('id', '=', $data->id);// create the filter 
        }

        if (isset($data->account_id) AND ( (is_scalar($data->account_id) AND $data->account_id !== '') OR (is_array($data->account_id) AND (!empty($data->account_id)) )) )
        {

            $filters[] = new TFilter('account_id', '=', $data->account_id);// create the filter 
        }

        if (isset($data->saas_contrato_status_id) AND ( (is_scalar($data->saas_contrato_status_id) AND $data->saas_contrato_status_id !== '') OR (is_array($data->saas_contrato_status_id) AND (!empty($data->saas_contrato_status_id)) )) )
        {

            $filters[] = new TFilter('saas_contrato_status_id', '=', $data->saas_contrato_status_id);// create the filter 
        }

        if (isset($data->data_inicial) AND ( (is_scalar($data->data_inicial) AND $data->data_inicial !== '') OR (is_array($data->data_inicial) AND (!empty($data->data_inicial)) )) )
        {

            $filters[] = new TFilter('data_inicial', '=', $data->data_inicial);// create the filter 
        }

        if (isset($data->data_inicial_fim) AND ( (is_scalar($data->data_inicial_fim) AND $data->data_inicial_fim !== '') OR (is_array($data->data_inicial_fim) AND (!empty($data->data_inicial_fim)) )) )
        {

            $filters[] = new TFilter('data_inicial', '<=', $data->data_inicial_fim);// create the filter 
        }

        if (isset($data->data_final) AND ( (is_scalar($data->data_final) AND $data->data_final !== '') OR (is_array($data->data_final) AND (!empty($data->data_final)) )) )
        {

            $filters[] = new TFilter('data_final', '=', $data->data_final);// create the filter 
        }

        if (isset($data->data_final_fim) AND ( (is_scalar($data->data_final_fim) AND $data->data_final_fim !== '') OR (is_array($data->data_final_fim) AND (!empty($data->data_final_fim)) )) )
        {

            $filters[] = new TFilter('data_final', '<=', $data->data_final_fim);// create the filter 
        }

        if (isset($data->valor_total) AND ( (is_scalar($data->valor_total) AND $data->valor_total !== '') OR (is_array($data->valor_total) AND (!empty($data->valor_total)) )) )
        {

            $filters[] = new TFilter('valor_total', '>=', $data->valor_total);// create the filter 
        }

        if (isset($data->valor_total_fim) AND ( (is_scalar($data->valor_total_fim) AND $data->valor_total_fim !== '') OR (is_array($data->valor_total_fim) AND (!empty($data->valor_total_fim)) )) )
        {

            $filters[] = new TFilter('valor_total', '<=', $data->valor_total_fim);// create the filter 
        }

        // fill the form with data again
        $this->form->setData($data);

        // keep the search data in the session
        TSession::setValue(__CLASS__.'_filter_data', $data);
        TSession::setValue(__CLASS__.'_filters', $filters);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }

    /**
     * Load the datagrid with data
     */
    public function onReload($param = NULL)
    {
        try
        {
            // open a transaction with database 'clinica'
            TTransaction::open(self::$database);

            // creates a repository for SaasContrato
            $repository = new TRepository(self::$activeRecord);

            $criteria = clone $this->filter_criteria;

            if (empty($param['order']))
            {
                $param['order'] = 'id';    
            }

            if (empty($param['direction']))
            {
                $param['direction'] = 'desc';
            }

            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $this->limit);

            if($filters = TSession::getValue(__CLASS__.'_filters'))
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            //</blockLine><btnShowCurtainFiltersAutoCode>
            if(!empty($this->btnShowCurtainFilters) && empty($this->btnShowCurtainFiltersAdjusted))
            {
                $this->btnShowCurtainFiltersAdjusted = true;
                $this->btnShowCurtainFilters->style = 'position: relative';
                $countFilters = count($filters ?? []);
                $this->btnShowCurtainFilters->setLabel($this->btnShowCurtainFilters->getLabel(). "<span class='badge badge-success' style='position: absolute'>{$countFilters}<span>");
            }
            //</blockLine></btnShowCurtainFiltersAutoCode>

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            $this->datagrid->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {

                    $row = $this->datagrid->addItem($object);
                    $row->id = "row_{$object->id}";

                }
            }

            // reset the criteria for record count
            $criteria->resetProperties();
            $count= $repository->count($criteria);

            $this->pageNavigation->setCount($count); // count of records
            $this->pageNavigation->setProperties($param); // order, page
            $this->pageNavigation->setLimit($this->limit); // limit

            // close the transaction
            TTransaction::close();
            $this->loaded = true;

            return $objects;
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

    /**
     * method show()
     * Shows the page
     */
    public function show()
    {
        // check if the datagrid is already loaded
        if (!$this->loaded AND (!isset($_GET['method']) OR !(in_array($_GET['method'],  $this->showMethods))) )
        {
            if (func_num_args() > 0)
            {
                $this->onReload( func_get_arg(0) );
            }
            else
            {
                $this->onReload();
            }
        }
        parent::show();
    }

    public static function manageRow($id, $param = [])
    {
        $list = new self($param);

        $openTransaction = TTransaction::getDatabase() != self::$database ? true : false;

        if($openTransaction)
        {
            TTransaction::open(self::$database);    
        }

        $object = new SaasContrato($id);

        $row = $list->datagrid->addItem($object);
        $row->id = "row_{$object->id}";

        if($openTransaction)
        {
            TTransaction::close();    
        }

        TDataGrid::replaceRowById(__CLASS__.'_datagrid', $row->id, $row);
    }

}

