<?php

class SaasNFSeEmailForm extends TWindow
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_SaasNFSeEmailForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();
        parent::setSize(0.80, null);
        parent::setTitle("Enviar email com a NFS-e");
        parent::setProperty('class', 'window_modal');

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Enviar email com a NFS-e");


        $id = new TEntry('id');
        $email = new TEntry('email');
        $email_container = new BElement('div');


        $id->setValue($param["key"] ?? "");
        $id->setEditable(false);
        $email->setEditable(false);

        $id->setSize('100%');
        $email->setSize('100%');
        $email_container->setSize('100%', 80);

        $this->email_container = $email_container;

        TTransaction::open(MAIN_DATABASE);

        $notaFiscal = SaasNotaFiscalServico::find($param['key']);

        $email->setValue($notaFiscal->email_tomador);

        $template = SaasTemplateEmail::find(SaasTemplateEmail::NOTA_FISCAL_ENVIADA);

        $titulo = str_replace('{$nome}', $notaFiscal->nome_tomador, $template->titulo);
        $conteudo = str_replace('{$titulo}', $template->titulo, $template->conteudo);
        $conteudo = str_replace('{$nome}', $notaFiscal->nome_tomador, $conteudo);

        TTransaction::close();

        $this->email_container->style = 'max-height:400px; overflow:auto;';
        $this->email_container->add($conteudo);

        $row1 = $this->form->addFields([new TLabel("ID da NFS-e:", null, '14px', null),$id]);
        $row1->layout = [' col-sm-12'];

        $row2 = $this->form->addFields([new TLabel("Email:", null, '14px', null, '100%'),$email]);
        $row2->layout = [' col-sm-12'];

        $row3 = $this->form->addFields([new TLabel("Pré-visualização do email", null, '14px', null)]);
        $row3->layout = [' col-sm-12'];

        $row4 = $this->form->addFields([$email_container]);
        $row4->layout = [' col-sm-12'];

        // create the form actions
        $btn_onenviar = $this->form->addAction("Enviar", new TAction([$this, 'onEnviar']), 'fas:rocket #ffffff');
        $this->btn_onenviar = $btn_onenviar;
        $btn_onenviar->addStyleClass('btn-primary'); 

        parent::add($this->form);

    }

    public static function onEnviar($param = null) 
    {
        try
        {
            TTransaction::open(MAIN_DATABASE);

            $nfse = new SaasNotaFiscalServico($param['id']);

            TTransaction::close();

            $dados = json_decode($nfse->dados_gateway_externo ?? '');

            if (!empty($dados->documento))
            {

                if(SaasEmailTemplateService::enviarNotaFiscal($nfse->email_tomador, $nfse->nome_tomador, $dados->documento))
                {
                    TTransaction::open(MAIN_DATABASE);

                    $nfse = new SaasNotaFiscalServico($param['id']);
                    $nfse->email_enviado = 'T';
                    $nfse->store();

                    TTransaction::close();

                    new TMessage('info', 'Email enviado');

                    TWindow::closeWindow();

                    SaasNotaFiscalServicoList::manageRow($nfse->id);

                }
                else
                {
                    new TMessage('error', 'Ocorreu um erro ao enviar o email.');
                }

            }
            else
            {
                throw new Exception('PDF da nota fiscal não encontrado');
            }
        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
        }
    }

    public function onShow($param = null)
    {               

    } 

}

