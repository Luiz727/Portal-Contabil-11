<?php

class SaasGatewayPagamentoWebhookForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'SaasGatewayPagamento';
    private static $primaryKey = 'id';
    private static $formName = 'form_GatewayPagamentoForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Configuração do Webhook de pagamento");


        $id = new TEntry('id');
        $nome = new TEntry('nome');
        $webhook_url = new TEntry('webhook_url');
        $button_buscar_informacoes_webhook = new TButton('button_buscar_informacoes_webhook');
        $button_consulta_ultimos_callbacks_enviados = new TButton('button_consulta_ultimos_callbacks_enviados');
        $info_webhook = new TText('info_webhook');

        $nome->addValidation("Nome", new TRequiredValidator()); 

        $id->setEditable(false);
        $nome->setEditable(false);

        $button_buscar_informacoes_webhook->setAction(new TAction([$this, 'onBuscarInfosWebhook']), "Buscar Informações webhook");
        $button_consulta_ultimos_callbacks_enviados->setAction(new TAction([$this, 'onBuscaCallbacks']), "Consulta ultimos callbacks enviados");

        $button_buscar_informacoes_webhook->addStyleClass('btn-default');
        $button_consulta_ultimos_callbacks_enviados->addStyleClass('btn-default');

        $button_buscar_informacoes_webhook->setImage('fas:cloud-download-alt #F44336');
        $button_consulta_ultimos_callbacks_enviados->setImage('fas:file-code #FF9800');

        $id->setSize(100);
        $nome->setSize('100%');
        $webhook_url->setSize('100%');
        $info_webhook->setSize('100%', 200);

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null, '100%'),$id],[new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$nome]);
        $row1->layout = ['col-sm-6','col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("URL:", null, '14px', null, '100%'),$webhook_url]);
        $row2->layout = [' col-sm-12'];

        $row3 = $this->form->addFields([$button_buscar_informacoes_webhook,$button_consulta_ultimos_callbacks_enviados]);
        $row3->layout = [' col-sm-12'];

        $row4 = $this->form->addFields([$info_webhook]);
        $row4->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

    }

    public static function onBuscarInfosWebhook($param = null) 
    {
        try 
        {

            TTransaction::open(self::$database);

            $gatewayPagamento = new SaasGatewayPagamento($param['id']);
            if(!$gatewayPagamento->webhook_url)
            {
                throw new Exception('Primeiro configure a URL, salve e depois verifique o Webhook por aqui..');
            }

            $service = new GatewayPagamentoService($gatewayPagamento);

            $dados = $service->getWebhookCadastrado();

            $object = new stdClass();
            $object->info_webhook = print_r($dados, true);

            TForm::sendData(self::$formName, $object);

            TTransaction::close();

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onBuscaCallbacks($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $gatewayPagamento = new SaasGatewayPagamento($param['id']);
            if(!$gatewayPagamento->webhook_url)
            {
                throw new Exception('Primeiro configure a URL, salve e depois verifique o Webhook por aqui..');
            }

            $service = new GatewayPagamentoService($gatewayPagamento);

            $filter = [
                'dataHoraInicio' => date('Y-m-d\TH:i\Z', strtotime('-7 days')),
                'dataHoraFim' => date('Y-m-d\TH:i\Z', strtotime('+7 days'))
            ];

            $dados = $service->getWebhookCallbacksEnviados($filter);

            $object = new stdClass();
            $object->info_webhook = print_r($dados, true);

            TForm::sendData(self::$formName, $object);

            TTransaction::close();

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new SaasGatewayPagamento(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TTransaction::open(self::$database);

            //precisa carregar de novo para buscar todos os dados do banco de dados
            $gatewayPagamento = new SaasGatewayPagamento($object->id);

            $service = new GatewayPagamentoService($gatewayPagamento);
            $service->criarWebhook();

            TTransaction::close();

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle'); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new SaasGatewayPagamento($key); // instantiates the Active Record 

                if(!$object->webhook_url && !empty($_SERVER['HTTP_REFERER']))
                {

                    if(preg_match('/index\.php/', $_SERVER['HTTP_REFERER']))
                    {
                        $object->webhook_url = substr($_SERVER['HTTP_REFERER'], 0, strpos($_SERVER['HTTP_REFERER'], 'index.php')).'hook_inter.php';    
                    }
                    else
                    {
                        $object->webhook_url = substr($_SERVER['HTTP_REFERER'], 0, strpos($_SERVER['HTTP_REFERER'], 'engine.php')).'hook_inter.php';
                    }

                    $object->store();
                }

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

