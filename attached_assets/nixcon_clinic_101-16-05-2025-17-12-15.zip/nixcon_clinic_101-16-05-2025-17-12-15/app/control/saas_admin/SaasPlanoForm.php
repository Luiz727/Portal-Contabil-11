<?php

class SaasPlanoForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'SaasPlano';
    private static $primaryKey = 'id';
    private static $formName = 'form_SaasPlanoForm';

    use BuilderMasterDetailFieldListTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de planos");

        $criteria_saas_servico_id = new TCriteria();
        $criteria_plano_grupo = new TCriteria();

        $filterVar = [1];
        $criteria_plano_grupo->add(new TFilter('id', 'not in', $filterVar)); 

        $nome = new TEntry('nome');
        $id = new THidden('id');
        $ativo = new TCheckButton('ativo');
        $descricao = new THtmlEditor('descricao');
        $saas_servico_id = new TDBCombo('saas_servico_id', 'clinica', 'SaasServico', 'id', '{nome}','nome asc' , $criteria_saas_servico_id );
        $discriminacao = new TText('discriminacao');
        $saas_plano_valor_saas_plano_id = new THidden('saas_plano_valor_saas_plano_id[]');
        $saas_plano_valor_saas_plano___row__id = new THidden('saas_plano_valor_saas_plano___row__id[]');
        $saas_plano_valor_saas_plano___row__data = new THidden('saas_plano_valor_saas_plano___row__data[]');
        $saas_plano_valor_saas_plano_nome = new TEntry('saas_plano_valor_saas_plano_nome[]');
        $saas_plano_valor_saas_plano_duracao = new TEntry('saas_plano_valor_saas_plano_duracao[]');
        $saas_plano_valor_saas_plano_valor = new TNumeric('saas_plano_valor_saas_plano_valor[]', '2', ',', '.' );
        $saas_plano_valor_saas_plano_ativo = new TCombo('saas_plano_valor_saas_plano_ativo[]');
        $saas_plano_valor_saas_plano_recorrencia = new TCombo('saas_plano_valor_saas_plano_recorrencia[]');
        $this->fieldList_valores = new TFieldList();
        $plano_grupo = new TCheckList('plano_grupo');
        $limite_usuarios = new TSpinner('limite_usuarios');
        $limite_unidades = new TSpinner('limite_unidades');

        $this->fieldList_valores->addField(null, $saas_plano_valor_saas_plano_id, []);
        $this->fieldList_valores->addField(null, $saas_plano_valor_saas_plano___row__id, ['uniqid' => true]);
        $this->fieldList_valores->addField(null, $saas_plano_valor_saas_plano___row__data, []);
        $this->fieldList_valores->addField(new TLabel("Nome", null, '14px', null), $saas_plano_valor_saas_plano_nome, ['width' => '40%']);
        $this->fieldList_valores->addField(new TLabel("Duração (meses)", null, '14px', null), $saas_plano_valor_saas_plano_duracao, ['width' => '150px']);
        $this->fieldList_valores->addField(new TLabel("Valor", null, '14px', null), $saas_plano_valor_saas_plano_valor, ['width' => '130px']);
        $this->fieldList_valores->addField(new TLabel("Ativo", null, '14px', null), $saas_plano_valor_saas_plano_ativo, ['width' => '140px']);
        $this->fieldList_valores->addField(new TLabel("Recorrência(cartão mp)", null, '14px', null), $saas_plano_valor_saas_plano_recorrencia, ['width' => '170px']);

        $this->fieldList_valores->width = '100%';
        $this->fieldList_valores->setFieldPrefix('saas_plano_valor_saas_plano');
        $this->fieldList_valores->name = 'fieldList_valores';

        $this->criteria_fieldList_valores = new TCriteria();
        $this->default_item_fieldList_valores = new stdClass();

        $this->form->addField($saas_plano_valor_saas_plano_id);
        $this->form->addField($saas_plano_valor_saas_plano___row__id);
        $this->form->addField($saas_plano_valor_saas_plano___row__data);
        $this->form->addField($saas_plano_valor_saas_plano_nome);
        $this->form->addField($saas_plano_valor_saas_plano_duracao);
        $this->form->addField($saas_plano_valor_saas_plano_valor);
        $this->form->addField($saas_plano_valor_saas_plano_ativo);
        $this->form->addField($saas_plano_valor_saas_plano_recorrencia);

        $this->fieldList_valores->disableRemoveButton();

        $nome->addValidation("Nome", new TRequiredValidator()); 
        $saas_plano_valor_saas_plano_nome->addValidation("Nome", new TRequiredListValidator()); 
        $saas_plano_valor_saas_plano_valor->addValidation("Valor", new TRequiredListValidator()); 

        $ativo->setValue('T');
        $ativo->setUseSwitch(true, 'blue');
        $ativo->setIndexValue("T");
        $ativo->setInactiveIndexValue("F");
        $saas_plano_valor_saas_plano_duracao->setMask('999999');
        $saas_plano_valor_saas_plano_ativo->addItems(["T"=>"Sim","F"=>"Não"]);
        $saas_plano_valor_saas_plano_recorrencia->addItems(["T"=>"Sim","F"=>"Não"]);

        $limite_usuarios->setRange(0, 2000, 1);
        $limite_unidades->setRange(0, 2000, 1);

        $saas_servico_id->enableSearch();
        $saas_plano_valor_saas_plano_ativo->enableSearch();
        $saas_plano_valor_saas_plano_recorrencia->enableSearch();

        $id->setSize(200);
        $nome->setSize('100%');
        $limite_usuarios->setSize(110);
        $limite_unidades->setSize(110);
        $descricao->setSize('100%', 250);
        $saas_servico_id->setSize('100%');
        $discriminacao->setSize('100%', 70);
        $saas_plano_valor_saas_plano_nome->setSize('100%');
        $saas_plano_valor_saas_plano_valor->setSize('100%');
        $saas_plano_valor_saas_plano_ativo->setSize('100%');
        $saas_plano_valor_saas_plano_duracao->setSize('100%');
        $saas_plano_valor_saas_plano_recorrencia->setSize('100%');

        $plano_grupo->setIdColumn('id');

        $column_plano_grupo_name = $plano_grupo->addColumn('name', "Grupo", 'left' , '100%');

        $column_plano_grupo_name->enableSearch();

        $plano_grupo->setHeight(400);
        $plano_grupo->makeScrollable();

        $plano_grupo->fillWith('clinica', 'SystemGroup', 'id', 'name asc' , $criteria_plano_grupo);

        $this->form->appendPage("Geral");

        $this->form->addFields([new THidden('current_tab')]);
        $this->form->setTabFunction("$('[name=current_tab]').val($(this).attr('data-current_page'));");

        $row1 = $this->form->addFields([new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$nome,$id],[new TLabel("Ativo:", null, '14px', null, '100%'),$ativo]);
        $row1->layout = [' col-sm-9',' col-sm-3'];

        $row2 = $this->form->addFields([new TLabel("Descrição:", null, '14px', null, '100%'),$descricao]);
        $row2->layout = [' col-sm-12'];

        $row3 = $this->form->addContent([new TFormSeparator("", '#333', '18', '#eee')]);
        $row4 = $this->form->addFields([new TLabel("Serviço:", null, '14px', null, '100%'),$saas_servico_id,new TLabel("Será utilizado na geração da nota fiscal de serviço", null, '11px', null, '100%')]);
        $row4->layout = [' col-sm-12'];

        $row5 = $this->form->addFields([new TLabel("Discriminação do serviço:", null, '14px', null, '100%'),$discriminacao,new TLabel("Será utilizado na geração da nota fiscal de serviço", null, '11px', null, '100%')]);
        $row5->layout = [' col-sm-12'];

        $this->form->appendPage("Valores");
        $row6 = $this->form->addFields([$this->fieldList_valores]);
        $row6->layout = [' col-sm-12'];

        $this->form->appendPage("Grupos");
        $row7 = $this->form->addFields([$plano_grupo]);
        $row7->layout = [' col-sm-12'];

        $this->form->appendPage("Limites");
        $row8 = $this->form->addFields([new TLabel("Limite máximo de usuários:", null, '14px', null, '100%'),$limite_usuarios],[new TLabel("Limite máximo de unidades:", null, '14px', null, '100%'),$limite_unidades]);
        $row8->layout = ['col-sm-6','col-sm-6'];

        $row9 = $this->form->addFields([new TLabel("Observação: se os limites forem definidos como zero, isso significa que erá ilimitado a quantidade de usuários ou unidades que podem ser criadas pelo usuário final do sistema.", null, '11px', null)]);
        $row9->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave'],['static' => 1]), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['SaasPlanoHeaderList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=SaasPlanoForm]');
        $style->width = '70% !important';   
        $style->show(true);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new SaasPlano(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $repository = SaasPlanoGrupo::where('saas_plano_id', '=', $object->id);
            $repository->delete(); 

            if ($data->plano_grupo) 
            {
                foreach ($data->plano_grupo as $plano_grupo_value) 
                {
                    $saas_plano_grupo = new SaasPlanoGrupo;

                    $saas_plano_grupo->system_group_id = $plano_grupo_value;
                    $saas_plano_grupo->saas_plano_id = $object->id;
                    $saas_plano_grupo->store();
                }
            }

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            $saas_plano_valor_saas_plano_items = $this->storeItems('SaasPlanoValor', 'saas_plano_id', $object, $this->fieldList_valores, function($masterObject, $detailObject){ 

                //code here

            }, $this->criteria_fieldList_valores); 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('SaasPlanoHeaderList', 'onShow', $loadPageParam); 

                        TScript::create("Template.closeRightPanel();");
            TForm::sendData(self::$formName, (object)['id' => $object->id]);

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new SaasPlano($key); // instantiates the Active Record 

                $object->plano_grupo = SaasPlanoGrupo::where('saas_plano_id', '=', $object->id)->getIndexedArray('system_group_id', 'system_group_id');

                $this->fieldList_valores_items = $this->loadItems('SaasPlanoValor', 'saas_plano_id', $object, $this->fieldList_valores, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }, $this->criteria_fieldList_valores); 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        $this->fieldList_valores->addHeader();
        $this->fieldList_valores->addDetail($this->default_item_fieldList_valores);

        $this->fieldList_valores->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

    }

    public function onShow($param = null)
    {
        $this->fieldList_valores->addHeader();
        $this->fieldList_valores->addDetail($this->default_item_fieldList_valores);

        $this->fieldList_valores->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

