<?php

class SaasConfiguracaoForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'SaasConfiguracao';
    private static $primaryKey = 'id';
    private static $formName = 'form_SaasConfiguracaoForm';

    use Adianti\Base\AdiantiFileSaveTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Parâmetros");

        $criteria_cidade_id = new TCriteria();
        $criteria_saas_plano_valor_trial_id = new TCriteria();
        $criteria_contrato_inativo_system_group_id = new TCriteria();

        $id = new THidden('id');
        $cnpj = new TEntry('cnpj');
        $buscar_cnpj = new TButton('buscar_cnpj');
        $inscricao_estadual = new TEntry('inscricao_estadual');
        $inscricao_municipal = new TEntry('inscricao_municipal');
        $razao_social = new TEntry('razao_social');
        $nome_fantasia = new TEntry('nome_fantasia');
        $cep = new TEntry('cep');
        $buscar_cep = new TButton('buscar_cep');
        $rua = new TEntry('rua');
        $bairro = new TEntry('bairro');
        $cidade_id = new TDBCombo('cidade_id', 'clinica', 'Cidade', 'id', '{nome} - {estado->sigla}','nome asc' , $criteria_cidade_id );
        $numero = new TEntry('numero');
        $complemento = new TEntry('complemento');
        $nfse_emissao_producao = new TCombo('nfse_emissao_producao');
        $button_importar_parametros = new TButton('button_importar_parametros');
        $token_integra_notas = new TEntry('token_integra_notas');
        $token_integra_notas_homologacao = new TEntry('token_integra_notas_homologacao');
        $token_integra_notas_software_house = new TEntry('token_integra_notas_software_house');
        $nfse_numero = new TEntry('nfse_numero');
        $nfse_serie = new TEntry('nfse_serie');
        $label_regime_tributacao = new TLabel("Regime de Tributação municipal:", null, '14px', null, '100%');
        $regime_tributacao = new TCombo('regime_tributacao');
        $contrato = new TFile('contrato');
        $termo_uso = new TFile('termo_uso');
        $saas_plano_valor_trial_id = new TDBCombo('saas_plano_valor_trial_id', 'clinica', 'SaasPlanoValor', 'id', '{saas_plano->nome} - {nome}','id asc' , $criteria_saas_plano_valor_trial_id );
        $dias_trial = new TEntry('dias_trial');
        $dias_renovacao_contrato = new TEntry('dias_renovacao_contrato');
        $contrato_inativo_system_group_id = new TDBCombo('contrato_inativo_system_group_id', 'clinica', 'SystemGroup', 'id', '{name}','name asc' , $criteria_contrato_inativo_system_group_id );
        $email_host = new TEntry('email_host');
        $email_port = new TEntry('email_port');
        $email_smtp_auth = new TCheckButton('email_smtp_auth');
        $email_username = new TEntry('email_username');
        $email_password = new TPassword('email_password');
        $email_from = new TEntry('email_from');
        $email_from_name = new TEntry('email_from_name');
        $email_teste = new TEntry('email_teste');
        $button_testar_envio_de_email = new TButton('button_testar_envio_de_email');
        $dias_vencimento_pagamento = new TEntry('dias_vencimento_pagamento');
        $url_sistema = new TEntry('url_sistema');

        $nfse_emissao_producao->addValidation("Nfse emissao producao", new TRequiredValidator()); 

        $nfse_emissao_producao->addItems(["T"=>"Sim","F"=>"Não"]);
        $contrato->setAllowedExtensions(["pdf"]);
        $email_smtp_auth->setUseSwitch(true, 'blue');
        $email_smtp_auth->setIndexValue("T");
        $email_smtp_auth->setInactiveIndexValue("F");
        $email_smtp_auth->setValue('T');
        $nfse_emissao_producao->setValue('F');

        $contrato->enableFileHandling();
        $termo_uso->enableFileHandling();

        $buscar_cnpj->setAction(new TAction([$this, 'onBuscar']), "Buscar");
        $buscar_cep->setAction(new TAction([$this, 'onSearchCEP']), "Buscar");
        $button_importar_parametros->setAction(new TAction([$this, 'onImportarParametros']), "Importar Parâmetros");
        $button_testar_envio_de_email->setAction(new TAction([$this, 'onTestarEnvioEmail'],['static' => 1]), "Testar Envio de Email");

        $buscar_cep->addStyleClass('btn-default');
        $buscar_cnpj->addStyleClass('btn-default');
        $button_importar_parametros->addStyleClass('btn-default');
        $button_testar_envio_de_email->addStyleClass('btn-default');

        $buscar_cep->setImage('fas:search #000000');
        $buscar_cnpj->setImage('fas:search #000000');
        $button_importar_parametros->setImage('fas:cogs #4CAF50');
        $button_testar_envio_de_email->setImage('fas:mail-bulk #F44336');

        $cidade_id->enableSearch();
        $regime_tributacao->enableSearch();
        $saas_plano_valor_trial_id->enableSearch();
        $contrato_inativo_system_group_id->enableSearch();

        $cep->setMask('99.999-999');
        $dias_trial->setMask('999');
        $cnpj->setMask('99.999.999/9999-99');
        $dias_renovacao_contrato->setMask('999');
        $dias_vencimento_pagamento->setMask('99');

        $id->setSize(200);
        $rua->setSize('100%');
        $bairro->setSize('100%');
        $numero->setSize('100%');
        $contrato->setSize('100%');
        $cidade_id->setSize('100%');
        $termo_uso->setSize('100%');
        $nfse_serie->setSize('100%');
        $dias_trial->setSize('100%');
        $email_host->setSize('100%');
        $email_port->setSize('100%');
        $email_from->setSize('100%');
        $complemento->setSize('100%');
        $nfse_numero->setSize('100%');
        $email_teste->setSize('100%');
        $url_sistema->setSize('100%');
        $razao_social->setSize('100%');
        $nome_fantasia->setSize('100%');
        $email_username->setSize('100%');
        $email_password->setSize('100%');
        $email_from_name->setSize('100%');
        $cep->setSize('calc(100% - 100px)');
        $regime_tributacao->setSize('100%');
        $cnpj->setSize('calc(100% - 100px)');
        $inscricao_estadual->setSize('100%');
        $inscricao_municipal->setSize('100%');
        $token_integra_notas->setSize('100%');
        $nfse_emissao_producao->setSize('100%');
        $dias_renovacao_contrato->setSize('100%');
        $saas_plano_valor_trial_id->setSize('100%');
        $dias_vencimento_pagamento->setSize('100%');
        $token_integra_notas_homologacao->setSize('100%');
        $contrato_inativo_system_group_id->setSize('100%');
        $token_integra_notas_software_house->setSize('100%');


        $this->form->appendPage("Empresa");

        $this->form->addFields([new THidden('current_tab')]);
        $this->form->setTabFunction("$('[name=current_tab]').val($(this).attr('data-current_page'));");

        $row1 = $this->form->addContent([new TFormSeparator("Informações básicas", '#333', '18', '#eee')]);
        $row2 = $this->form->addFields([new TLabel("CNPJ:", null, '14px', null, '100%'),$id,$cnpj,$buscar_cnpj],[new TLabel("Inscrição estadual:", null, '14px', null, '100%'),$inscricao_estadual],[new TLabel("Inscrição municipal:", null, '14px', null, '100%'),$inscricao_municipal]);
        $row2->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row3 = $this->form->addFields([new TLabel("Razão social:", null, '14px', null, '100%'),$razao_social],[new TLabel("Nome fantasia:", null, '14px', null, '100%'),$nome_fantasia]);
        $row3->layout = ['col-sm-6','col-sm-6'];

        $row4 = $this->form->addFields([new TFormSeparator("Endereço", '#333', '18', '#eee')]);
        $row4->layout = [' col-sm-12'];

        $row5 = $this->form->addFields([new TLabel("CEP:", null, '14px', null, '100%'),$cep,$buscar_cep],[new TLabel("Rua:", null, '14px', null, '100%'),$rua]);
        $row5->layout = [' col-sm-4',' col-sm-8'];

        $row6 = $this->form->addFields([new TLabel("Bairro:", null, '14px', null, '100%'),$bairro],[new TLabel("Cidade:", null, '14px', null, '100%'),$cidade_id],[new TLabel("Número:", null, '14px', null, '100%'),$numero]);
        $row6->layout = [' col-sm-4',' col-sm-5',' col-sm-3'];

        $row7 = $this->form->addFields([new TLabel("Complemento:", null, '14px', null, '100%'),$complemento]);
        $row7->layout = [' col-sm-12'];

        $this->form->appendPage("NFS-e");
        $row8 = $this->form->addFields([new TLabel("Produção:", null, '14px', null, '100%'),$nfse_emissao_producao],[$button_importar_parametros]);
        $row8->layout = ['col-sm-6',' col-sm-6'];

        $row9 = $this->form->addFields([new TLabel("Token Integra Notas envio NFS-e:", null, '14px', null, '100%'),$token_integra_notas],[new TLabel("Token Integra Notas envio NFS-e <small>(homologação)</small>:", null, '14px', null, '100%'),$token_integra_notas_homologacao]);
        $row9->layout = [' col-sm-6',' col-sm-6'];

        $row10 = $this->form->addFields([new TLabel("Token Integra Notas da sua Software House:", null, '14px', null, '100%'),$token_integra_notas_software_house],[]);
        $row10->layout = ['col-sm-6',' col-sm-6'];

        $row11 = $this->form->addFields([new TLabel("NFS-e número:", null, '14px', null, '100%'),$nfse_numero],[new TLabel("NFS-e série:", null, '14px', null, '100%'),$nfse_serie]);
        $row11->layout = [' col-sm-6','col-sm-6'];

        $row12 = $this->form->addFields([$label_regime_tributacao,$regime_tributacao],[]);
        $row12->layout = [' col-sm-6','col-sm-6'];

        $this->form->appendPage("Contrato / Termos");
        $row13 = $this->form->addFields([new TLabel("PDF do contrato:", null, '14px', null),$contrato]);
        $row13->layout = [' col-sm-12'];

        $row14 = $this->form->addFields([new TLabel("Termos de uso:", null, '14px', null, '100%'),$termo_uso]);
        $row14->layout = [' col-sm-12'];

        $row15 = $this->form->addFields([new TLabel("Plano trial:", null, '14px', null),$saas_plano_valor_trial_id],[new TLabel("Dias de trial:", null, '14px', null),$dias_trial],[new TLabel("Dias renovação automática:", null, '14px', null),$dias_renovacao_contrato,new TLabel("Dias antes que o contrato será renovado automaticamente, caso esteja em dia", null, '9px', null)]);
        $row15->layout = ['col-sm-6',' col-sm-3',' col-sm-3'];

        $row16 = $this->form->addFields([new TLabel("Grupo de permissão quando contrato inativo:", null, '14px', null, '100%'),$contrato_inativo_system_group_id],[],[]);
        $row16->layout = ['col-sm-6',' col-sm-3',' col-sm-3'];

        $this->form->appendPage("Email");
        $row17 = $this->form->addFields([new TLabel("Host:", null, '14px', null, '100%'),$email_host],[new TLabel("Porta:", null, '14px', null, '100%'),$email_port],[new TLabel("Autentica SMTP:", null, '14px', null, '100%'),$email_smtp_auth]);
        $row17->layout = [' col-sm-3',' col-sm-3',' col-sm-3'];

        $row18 = $this->form->addFields([new TLabel("Usuário:", null, '14px', null, '100%'),$email_username],[new TLabel("Senha:", null, '14px', null, '100%'),$email_password],[new TLabel("Email de origem:", null, '14px', null, '100%'),$email_from],[new TLabel("Nome da origem:", null, '14px', null, '100%'),$email_from_name]);
        $row18->layout = ['col-sm-3','col-sm-3',' col-sm-3',' col-sm-3'];

        $row19 = $this->form->addContent([new TFormSeparator("", '#333', '18', '#eee')]);
        $row20 = $this->form->addFields([new TLabel("Email de teste:", null, '14px', null, '100%'),$email_teste],[new TLabel(" ", null, '14px', null, '100%'),$button_testar_envio_de_email]);
        $row20->layout = ['col-sm-3',' col-sm-3'];

        $this->form->appendPage("Financeiro");
        $row21 = $this->form->addFields([new TLabel("Dias para vencimento do pagamento:", null, '14px', null),$dias_vencimento_pagamento]);
        $row21->layout = ['col-sm-6'];

        $this->form->appendPage("Sistema");
        $row22 = $this->form->addFields([new TLabel("URL Geral do Sistema:", null, '14px', null, '100%'),$url_sistema]);
        $row22->layout = [' col-sm-12'];

        TTransaction::open(self::$database);
        SaasConfiguracaoService::ajustaCampos($this->form, $this);
        TTransaction::close();

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave'],['static' => 1]), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["SaaS Admin","SaaS Parâmetros"]));
        }
        $container->add($this->form);

        parent::add($container);

    }

    public static function onBuscar($param = null) 
    {
        try 
        {
            if (! empty($param['cnpj']))
            {
                $cnpj = BuilderCNPJService::get($param['cnpj']);

                $data = new stdClass;
                $data->razao_social = $cnpj->razao_social;
                $data->nome_fantasia = $cnpj->nome_fantasia;
                $data->cep = ToolService::formatMask($cnpj->cep, '99.999-999');
                $data->bairro = $cnpj->bairro;
                $data->numero = $cnpj->numero;
                $data->complemento = $cnpj->complemento;
                $data->rua = $cnpj->logradouro;

                TForm::sendData(self::$formName, $data);
            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onSearchCEP($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database); // open a transaction
            if (! empty($param['cep']))
            {
                $cep = CEPService::get($param['cep']);

                $data = new stdClass;
                $data->cidade_id = $cep->cidade_id;
                $data->cidade = $cep->cidade;
                $data->bairro = $cep->bairro;
                $data->rua = $cep->rua;

                TForm::sendData(self::$formName, $data);
            }
            TTransaction::close(); 

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
            TTransaction::rollback(); 
        }
    }

    public static function onImportarParametros($param = null) 
    {
        try 
        {

            if(empty($param['token_integra_notas_homologacao']))
            {
                throw new Exception('Informe o token de homologação');
            }

            if(empty($param['token_integra_notas']))
            {
                throw new Exception('Informe o token de produção');
            }

            TTransaction::open(self::$database);

            $saasConfig = new SaasConfiguracao($param['id']);

            $saasConfig->token_integra_notas_homologacao = $param['token_integra_notas_homologacao'];
            $saasConfig->token_integra_notas = $param['token_integra_notas'];

            if(!$saasConfig->cidade->codigo_ibge)
            {
                throw new Exception('Códgigo do IBGE da cidade da empresa não foi definido ');
            }

            $form = new self([]);
            // var_dump($form);die;
            SaasConfiguracaoService::ajustaCampos($form->form, __CLASS__);

            $gateway = SaasConfiguracaoService::getGatewayNFSE($saasConfig);

            $info = $gateway->getNfseInfo($saasConfig->cidade->codigo_ibge);

            $saasConfig->nfse_info = json_encode($info);

            $saasConfig->store();

            TTransaction::close();

            //TForm::sendData(self::$formName, $data);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public  function onTestarEnvioEmail($param = null) 
    {
        try 
        {
            if(empty($param['email_teste']))
            {
                throw new Exception('Informe o email de teste');
            }

            $this->onSave($param);

            TTransaction::open(self::$database);

            $mail = SaasConfiguracaoService::getGatewayEmail();

            TTransaction::close();
            if($mail)
            {
                $mail->send([$param['email_teste']], 'teste', 'teste');

                new TMessage('info', 'Email enviado');
            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new SaasConfiguracao(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $contrato_dir = 'saas_arquivos/contrato';
            $termo_uso_dir = 'saas_arquivos/termo';  

            $object->store(); // save the object 

            $this->saveFile($object, $data, 'contrato', $contrato_dir);
            $this->saveFile($object, $data, 'termo_uso', $termo_uso_dir); 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            if($_REQUEST['method'] == 'onSave')
            {
                new TMessage('info', "Registro salvo");
            }

        }
        catch (Exception $e) // in case of exception
        {

            if($_REQUEST['method'] == 'onSave')
            {
                new TMessage('error', $e->getMessage()); // shows the exception error message
                $this->form->setData( $this->form->getData() ); // keep form data
                TTransaction::rollback(); // undo all pending operations    
            }
            else
            {
                throw $e;
            }

        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new SaasConfiguracao($key); // instantiates the Active Record 

                if(!$object->url_sistema && !empty($_SERVER['HTTP_REFERER']))
                {
                    $object->url_sistema = substr($referer, 0, strpos($_SERVER['HTTP_REFERER'], 'index.php'));
                    $object->store();
                }

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

        try
        {

            TTransaction::open(self::$database); // open a transaction

            $object = SaasConfiguracao::first(); // instantiates the Active Record

            if(!$object->url_sistema && !empty($_SERVER['HTTP_REFERER']))
            {

                if(preg_match('/index\.php/', $_SERVER['HTTP_REFERER']))
                {
                    $object->url_sistema = substr($_SERVER['HTTP_REFERER'], 0, strpos($_SERVER['HTTP_REFERER'], 'index.php'));    
                }
                else
                {
                    $object->url_sistema = substr($_SERVER['HTTP_REFERER'], 0, strpos($_SERVER['HTTP_REFERER'], 'engine.php'));
                }

                $object->store();
            }

            TTransaction::close(); // close the transaction 

            if ($object)
            {

                $this->form->setData($object); // fill the form
            }
            else
            {
                $this->form->clear();
            }
        }
        catch(Exception $e)
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

