<?php

class SaasNotaFiscalServicoList extends TPage
{
    private $form; // form
    private $datagrid; // listing
    private $pageNavigation;
    private $loaded;
    private $filter_criteria;
    private static $database = 'clinica';
    private static $activeRecord = 'SaasNotaFiscalServico';
    private static $primaryKey = 'id';
    private static $formName = 'form_NotaFiscalServicoList';
    private $showMethods = ['onReload', 'onSearch', 'onRefresh', 'onClearFilters'];
    private $limit = 20;

    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct($param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        // define the form title
        $this->form->setFormTitle("Notas fiscais");
        $this->limit = 20;

        $criteria_account_id = new TCriteria();

        $account_id = new TDBUniqueSearch('account_id', 'clinica', 'Account', 'id', 'razao_social','razao_social asc' , $criteria_account_id );
        $numero = new TEntry('numero');
        $data_hora_emissao = new TDateTime('data_hora_emissao');
        $data_hora_emissao_fim = new TDateTime('data_hora_emissao_fim');
        $discriminacao = new TEntry('discriminacao');
        $nfse_status = new TMultiSearch('nfse_status');


        $account_id->setMinLength(2);
        $account_id->setFilterColumns(["email","telefone","razao_social"]);
        $nfse_status->addItems(["CADASTRADA"=>"Cadastrada","ENVIADA"=>"Enviada","ERRO"=>"Erro","CANCELADA"=>"Cancelada","CANCELAMENTO_SOLICITADO"=>"Cancelamento solicitado","EMITIDA"=>"Emitida"]);
        $data_hora_emissao->setDatabaseMask('yyyy-mm-dd hh:ii');
        $data_hora_emissao_fim->setDatabaseMask('yyyy-mm-dd hh:ii');

        $data_hora_emissao->setMask('dd/mm/yyyy hh:ii');
        $data_hora_emissao_fim->setMask('dd/mm/yyyy hh:ii');
        $account_id->setMask('{razao_social} ( {email} {telefone})');

        $numero->setSize('100%');
        $account_id->setSize('100%');
        $discriminacao->setSize('100%');
        $data_hora_emissao->setSize(150);
        $nfse_status->setSize('100%', 70);
        $data_hora_emissao_fim->setSize(160);

        $row1 = $this->form->addFields([new TLabel("Cliente:", null, '14px', null, '100%'),$account_id]);
        $row1->layout = ['col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Número:", null, '14px', null, '100%'),$numero],[new TLabel("Data hora da emissão:", null, '14px', null, '100%'),$data_hora_emissao,new TLabel("até", null, '14px', null),$data_hora_emissao_fim]);
        $row2->layout = ['col-sm-6','col-sm-6'];

        $row3 = $this->form->addFields([new TLabel("Descrição:", null, '14px', null, '100%'),$discriminacao]);
        $row3->layout = [' col-sm-12'];

        $row4 = $this->form->addFields([new TLabel("Status:", null, '14px', null),$nfse_status]);
        $row4->layout = [' col-sm-12'];

        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );

        $btn_onsearch = $this->form->addAction("Buscar", new TAction([$this, 'onSearch']), 'fas:search #ffffff');
        $this->btn_onsearch = $btn_onsearch;
        $btn_onsearch->addStyleClass('btn-primary'); 

        // creates a Datagrid
        $this->datagrid = new TDataGrid;
        $this->datagrid->setId(__CLASS__.'_datagrid');

        $this->datagrid_form = new TForm('datagrid_'.self::$formName);
        $this->datagrid_form->onsubmit = 'return false';

        $this->datagrid = new BootstrapDatagridWrapper($this->datagrid);
        $this->filter_criteria = new TCriteria;

        $this->datagrid->disableDefaultClick();
        $this->datagrid->style = 'width: 100%';
        $this->datagrid->setHeight(250);

        $column_numero = new TDataGridColumn('numero', "Número", 'left');
        $column_numero_rps = new TDataGridColumn('numero_rps', "Número rps", 'left');
        $column_id_gateway_externo = new TDataGridColumn('id_gateway_externo', "Id gateway externo", 'left');
        $column_nome_tomador = new TDataGridColumn('nome_tomador', "Cliente", 'left');
        $column_valor_servicos_transformed = new TDataGridColumn('valor_servicos', "Valor total", 'center');
        $column_data_hora_emissao_transformed = new TDataGridColumn('data_hora_emissao', "Data/Hora", 'left' , '150px');
        $column_nota_fiscal_status_id_transformed = new TDataGridColumn('nota_fiscal_status_id', "Status", 'center' , '100px');

        $column_valor_servicos_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });

        $column_data_hora_emissao_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y H:i');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_nota_fiscal_status_id_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            $div = new TElement('span');
            $div->class = 'label label-default';
            $div->add($object->nota_fiscal_status->nome);
            $div->style = "background-color: {$object->nota_fiscal_status->cor} ; color: #fff";

            return $div;

        });        

        $this->builder_datagrid_check_all = new TCheckButton('builder_datagrid_check_all');
        $this->builder_datagrid_check_all->setIndexValue('on');
        $this->builder_datagrid_check_all->onclick = "Builder.checkAll(this)";
        $this->builder_datagrid_check_all->style = 'cursor:pointer';
        $this->builder_datagrid_check_all->setProperty('class', 'filled-in');
        $this->builder_datagrid_check_all->id = 'builder_datagrid_check_all';

        $label = new TLabel('');
        $label->style = 'margin:0';
        $label->class = 'checklist-label';
        $this->builder_datagrid_check_all->after($label);
        $label->for = 'builder_datagrid_check_all';

        $this->builder_datagrid_check = $this->datagrid->addColumn( new TDataGridColumn('builder_datagrid_check', $this->builder_datagrid_check_all, 'center',  '1%') );

        $this->datagrid->addColumn($column_numero);
        $this->datagrid->addColumn($column_numero_rps);
        $this->datagrid->addColumn($column_id_gateway_externo);
        $this->datagrid->addColumn($column_nome_tomador);
        $this->datagrid->addColumn($column_valor_servicos_transformed);
        $this->datagrid->addColumn($column_data_hora_emissao_transformed);
        $this->datagrid->addColumn($column_nota_fiscal_status_id_transformed);

        $action_group = new TDataGridActionGroup("Ações", 'fas:cog');
        $action_group->addHeader('');

        $action_onEdit = new TDataGridAction(array('SaasNotaFiscalServicoForm', 'onEdit'));
        $action_onEdit->setUseButton(TRUE);
        $action_onEdit->setButtonClass('btn btn-default');
        $action_onEdit->setLabel("Editar");
        $action_onEdit->setImage('far:edit #478fca');
        $action_onEdit->setField(self::$primaryKey);
        $action_onEdit->setDisplayCondition('SaasNotaFiscalServicoList::canEdit');

        $action_group->addAction($action_onEdit);

        $action_onTransmitir = new TDataGridAction(array('SaasNotaFiscalServicoList', 'onTransmitir'));
        $action_onTransmitir->setUseButton(TRUE);
        $action_onTransmitir->setButtonClass('btn btn-default');
        $action_onTransmitir->setLabel("Transmitir");
        $action_onTransmitir->setImage('fas:paper-plane #4CAF50');
        $action_onTransmitir->setField(self::$primaryKey);
        $action_onTransmitir->setDisplayCondition('SaasNotaFiscalServicoList::canTransmitir');

        $action_group->addAction($action_onTransmitir);

        $action_onAtualizar = new TDataGridAction(array('SaasNotaFiscalServicoList', 'onAtualizar'));
        $action_onAtualizar->setUseButton(TRUE);
        $action_onAtualizar->setButtonClass('btn btn-default');
        $action_onAtualizar->setLabel("Atualizar");
        $action_onAtualizar->setImage('fas:sync-alt #2196F3');
        $action_onAtualizar->setField(self::$primaryKey);
        $action_onAtualizar->setDisplayCondition('SaasNotaFiscalServicoList::canAtualizar');

        $action_group->addAction($action_onAtualizar);

        $action_onDocumento = new TDataGridAction(array('SaasNotaFiscalServicoList', 'onDocumento'));
        $action_onDocumento->setUseButton(TRUE);
        $action_onDocumento->setButtonClass('btn btn-default');
        $action_onDocumento->setLabel("Visualizar documento");
        $action_onDocumento->setImage('fas:file-pdf #F44336');
        $action_onDocumento->setField(self::$primaryKey);
        $action_onDocumento->setDisplayCondition('SaasNotaFiscalServicoList::canDocumento');

        $action_group->addAction($action_onDocumento);

        $action_onXml = new TDataGridAction(array('SaasNotaFiscalServicoList', 'onXml'));
        $action_onXml->setUseButton(TRUE);
        $action_onXml->setButtonClass('btn btn-default');
        $action_onXml->setLabel("Visualizar XML");
        $action_onXml->setImage('fas:file-code #FFC107');
        $action_onXml->setField(self::$primaryKey);
        $action_onXml->setDisplayCondition('SaasNotaFiscalServicoList::canXml');

        $action_group->addAction($action_onXml);

        $action_onShow = new TDataGridAction(array('SaasNFSeEmailForm', 'onShow'));
        $action_onShow->setUseButton(TRUE);
        $action_onShow->setButtonClass('btn btn-default');
        $action_onShow->setLabel("Enviar NFS-e por email");
        $action_onShow->setImage('far:envelope #F44336');
        $action_onShow->setField(self::$primaryKey);
        $action_onShow->setDisplayCondition('SaasNotaFiscalServicoList::onExibirEnviarEmail');
        $action_onShow->setParameter('key', '{id}');

        $action_group->addAction($action_onShow);

        $action_onDelete = new TDataGridAction(array('SaasNotaFiscalServicoList', 'onDelete'));
        $action_onDelete->setUseButton(TRUE);
        $action_onDelete->setButtonClass('btn btn-default');
        $action_onDelete->setLabel("Excluir");
        $action_onDelete->setImage('fas:trash-alt #dd5a43');
        $action_onDelete->setField(self::$primaryKey);
        $action_onDelete->setDisplayCondition('SaasNotaFiscalServicoList::canDelete');

        $action_group->addAction($action_onDelete);

        $action_onCancelar = new TDataGridAction(array('SaasNotaFiscalServicoList', 'onCancelar'));
        $action_onCancelar->setUseButton(TRUE);
        $action_onCancelar->setButtonClass('btn btn-default');
        $action_onCancelar->setLabel("Cancelar");
        $action_onCancelar->setImage('fas:times #F44336');
        $action_onCancelar->setField(self::$primaryKey);
        $action_onCancelar->setDisplayCondition('SaasNotaFiscalServicoList::canCancelar');

        $action_group->addAction($action_onCancelar);

        $this->datagrid->addActionGroup($action_group);    

        // create the datagrid model
        $this->datagrid->createModel();

        // creates the page navigation
        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
        $this->pageNavigation->setWidth($this->datagrid->getWidth());

        $panel = new TPanelGroup("Notas fiscais");
        $panel->datagrid = 'datagrid-container';
        $this->datagridPanel = $panel;
        $this->datagrid_form->add($this->datagrid);
        $panel->add($this->datagrid_form);

        $panel->getBody()->class .= ' table-responsive';

        $panel->addFooter($this->pageNavigation);

        $headerActions = new TElement('div');
        $headerActions->class = ' datagrid-header-actions ';
        $headerActions->style = 'justify-content: space-between;';

        $head_left_actions = new TElement('div');
        $head_left_actions->class = ' datagrid-header-actions-left-actions ';

        $head_right_actions = new TElement('div');
        $head_right_actions->class = ' datagrid-header-actions-left-actions ';

        $headerActions->add($head_left_actions);
        $headerActions->add($head_right_actions);

        $panel->getBody()->insert(0, $headerActions);

        $button_cadastrar = new TButton('button_button_cadastrar');
        $button_cadastrar->setAction(new TAction(['SaasNotaFiscalServicoForm', 'onShow']), "Cadastrar");
        $button_cadastrar->addStyleClass('btn-default');
        $button_cadastrar->setImage('fas:plus #69aa46');

        $this->datagrid_form->addField($button_cadastrar);

        $btnShowCurtainFilters = new TButton('button_btnShowCurtainFilters');
        $btnShowCurtainFilters->setAction(new TAction(['SaasNotaFiscalServicoList', 'onShowCurtainFilters']), "Filtros");
        $btnShowCurtainFilters->addStyleClass('btn-default');
        $btnShowCurtainFilters->setImage('fas:filter #000000');

        $this->datagrid_form->addField($btnShowCurtainFilters);

        $button_limpar_filtros = new TButton('button_button_limpar_filtros');
        $button_limpar_filtros->setAction(new TAction(['SaasNotaFiscalServicoList', 'onClearFilters']), "Limpar filtros");
        $button_limpar_filtros->addStyleClass('btn-default');
        $button_limpar_filtros->setImage('fas:eraser #f44336');

        $this->datagrid_form->addField($button_limpar_filtros);

        $button_atualizar_listagem = new TButton('button_button_atualizar_listagem');
        $button_atualizar_listagem->setAction(new TAction(['SaasNotaFiscalServicoList', 'onRefresh']), "Atualizar listagem");
        $button_atualizar_listagem->addStyleClass('btn-default');
        $button_atualizar_listagem->setImage('fas:sync-alt #3F51B5');

        $this->datagrid_form->addField($button_atualizar_listagem);

        $atualizarEmLote = new TButton('button_atualizarEmLote');
        $atualizarEmLote->setAction(new TAction(['SaasNotaFiscalServicoList', 'onAtualizarEmLote']), "Atualizar notas fiscais");
        $atualizarEmLote->addStyleClass('btn-default');
        $atualizarEmLote->setImage('fas:sync #2196F3');

        $this->datagrid_form->addField($atualizarEmLote);

        $head_left_actions->add($button_cadastrar);
        $head_left_actions->add($btnShowCurtainFilters);
        $head_left_actions->add($button_limpar_filtros);
        $head_left_actions->add($button_atualizar_listagem);
        $head_left_actions->add($atualizarEmLote);

        $this->btnShowCurtainFilters = $btnShowCurtainFilters;

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["SaaS Admin","NFS-e"]));
        }

        $container->add($panel);

        parent::add($container);

    }

    public static function canEdit($object)
    {
        try 
        {
            if($object->nota_fiscal_status_id == NotaFiscalStatus::PENDENTE || $object->nota_fiscal_status_id == NotaFiscalStatus::REJEITADA)
            {
                return true;    
            }

            return false;
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onTransmitir($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);
            $nota = SaasNotaFiscalServico::find($param['key']);
            SaasNotaFiscalServicoService::transmitir($nota);
            TTransaction::close();

            self::manageRow($param['key']);

            TToast::show('success', 'Nota fiscal <b>transmitida</b> com sucesso!');
            //</autoCode>
        }
        catch (Exception $e) 
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());    
        }

    }
    public static function canTransmitir($object)
    {
        try 
        {

            return (in_array($object->nota_fiscal_status_id, [NotaFiscalStatus::ENVIADA, NotaFiscalStatus::EM_PROCESSAMENTO,NotaFiscalStatus::REJEITADA]));
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onAtualizar($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);
            $nota = SaasNotaFiscalServico::find($param['key']);
            SaasNotaFiscalServicoService::atualizar($nota);

            TTransaction::close();

            self::manageRow($nota->id);

            TToast::show('success', 'Nota fiscal <b>atualizada</b> com sucesso!');
            //</autoCode>
        }
        catch (Exception $e) 
        {
            if($e->getCode() != NotaFiscalStatus::REJEITADA)
            {
                TTransaction::rollback();

                TTransaction::open(self::$database);
                $nota = SaasNotaFiscalServico::find($param['key']);
                $nota->nota_fiscal_status_id = NotaFiscalStatus::REJEITADA;
                //$nota->mesamge_erro = $e->getMessage();
                $nota->store();

                TTransaction::close();
            }

            self::manageRow($param['key']);

            new TMessage('error', $e->getMessage());    
        }
    }
    public static function canAtualizar($object)
    {
        try 
        {

            return in_array($object->nota_fiscal_status_id, [NotaFiscalStatus::ENVIADA, NotaFiscalStatus::PENDENTE, NotaFiscalStatus::EM_PROCESSAMENTO, NotaFiscalStatus::REJEITADA]);
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onDocumento($param = null) 
    {
        try 
        {

            TTransaction::open(self::$database);

            $nota_fiscal_servico = SaasNotaFiscalServico::find($param['key']);
            $dados = json_decode($nota_fiscal_servico->dados_gateway_externo ?? '');

            if ($dados->documento)
            {

                // $window = TWindow::create('PDF', 0.8, 0.8);

                // $object = new TElement('iframe');
                // $object->src  = 'data:application/pdf;base64,'. base64_encode(file_get_contents($dados->documento));
                // $object->type  = 'application/pdf';
                // $object->style = "width: 100%; height:calc(100% - 10px)";

                // $window->add($object);
                // $window->show();

                TScript::create("window.open('$dados->documento');");
            }

            TTransaction::close();
            //</autoCode>
        }
        catch (Exception $e) 
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function canDocumento($object)
    {
        try 
        {
            $dados = json_decode($object->dados_gateway_externo ?? '');
            return ! empty($dados->documento);
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onXml($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $nota_fiscal_servico = SaasNotaFiscalServico::find($param['key']);
            $dados = json_decode($nota_fiscal_servico->dados_gateway_externo ?? '');

            if ($dados->xml)
            {
                TScript::create("window.open('$dados->xml');");
            }

            TTransaction::close();
            //</autoCode>
        }
        catch (Exception $e) 
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function canXml($object)
    {
        try 
        {
            $dados = json_decode($object->dados_gateway_externo ?? '');
            return  ! empty($dados->xml);
        }
        catch (Exception $e) 
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onExibirEnviarEmail($object)
    {
        try 
        {
            if($object->nota_fiscal_status_id == NotaFiscalStatus::AUTORIZADA && $object->email_enviado == 'F')
            {
                return true;
            }

            return false;
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onDelete($param = null) 
    { 
        if(isset($param['delete']) && $param['delete'] == 1)
        {
            try
            {
                // get the paramseter $key
                $key = $param['key'];
                // open a transaction with database
                TTransaction::open(self::$database);

                // instantiates object
                $object = new SaasNotaFiscalServico($key, FALSE); 

                // deletes the object from the database

                $saasPagamento = SaasPagamento::where('saas_nota_fiscal_servico_id', '=', $object->id)->first();
                $saasPagamento->saas_nota_fiscal_servico_id = null;
                $saasPagamento->store();

                $object->delete();

                // close the transaction
                TTransaction::close();

                // reload the listing
                $this->onReload( $param );
                // shows the success message
                new TMessage('info', AdiantiCoreTranslator::translate('Record deleted'));
            }
            catch (Exception $e) // in case of exception
            {
                // shows the exception error message
                new TMessage('error', $e->getMessage());
                // undo all pending operations
                TTransaction::rollback();
            }
        }
        else
        {
            // define the delete action
            $action = new TAction(array($this, 'onDelete'));
            $action->setParameters($param); // pass the key paramseter ahead
            $action->setParameter('delete', 1);
            // shows a dialog to the user
            new TQuestion(AdiantiCoreTranslator::translate('Do you really want to delete ?'), $action);   
        }
    }
    public static function canDelete($object)
    {
        try 
        {
            return in_array($object->nota_fiscal_status_id, [NotaFiscalStatus::PENDENTE, NotaFiscalStatus::REJEITADA]);
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onCancelar($param = null) 
    {
        try 
        {

            if (! empty($param['cancelar']) && $param['cancelar'] == 'T' && ! empty($param['justificativa']))
            {
                TTransaction::open(self::$database);

                $nota = SaasNotaFiscalServico::find($param['key']);
                SaasNotaFiscalServicoService::cancelar($nota, $param['justificativa']??'');

                TTransaction::close();

                self::manageRow($param['key']);

                TToast::show('success', 'Nota fiscal <b>cancelada</b> com sucesso!');
            }
            else
            {
                $form = new BootstrapFormBuilder('cancel_form');
                $text = new TText('justificativa');
                $text->setSize('100%');
                $row = $form->addFields( [new TLabel('Justificativa'), $text]);
                $row->layout = ['col-sm-12'];

                $param['cancelar'] = 'T';
                $form->addAction('Cancelar', new TAction([__CLASS__, 'onCancelar'], $param), 'fa:times');

                new TInputDialog('Cancelamento de nota', $form);
            }

            //</autoCode>
        }
        catch (Exception $e) 
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function canCancelar($object)
    {
        try 
        {
            return $object->nota_fiscal_status_id == NotaFiscalStatus::AUTORIZADA;
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onShowCurtainFilters($param = null) 
    {
        try 
        {
            //code here

                        $filter = new self([]);

            $btnClose = new TButton('closeCurtain');
            $btnClose->class = 'btn btn-sm btn-default';
            $btnClose->style = 'margin-right:10px;';
            $btnClose->onClick = "Template.closeRightPanel();";
            $btnClose->setLabel("Fechar");
            $btnClose->setImage('fas:times');

            $filter->form->addHeaderWidget($btnClose);

            $page = new TPage();
            $page->setTargetContainer('adianti_right_panel');
            $page->setProperty('page-name', 'SaasNotaFiscalServicoListSearch');
            $page->setProperty('page_name', 'SaasNotaFiscalServicoListSearch');
            $page->adianti_target_container = 'adianti_right_panel';
            $page->target_container = 'adianti_right_panel';
            $page->add($filter->form);
            $page->setIsWrapped(true);
            $page->show();

            $style = new TStyle('right-panel > .container-part[page-name=SaasNotaFiscalServicoListSearch]');
            $style->width = '50% !important';
            $style->show(true);

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onClearFilters($param = null) 
    {
        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }
    public function onRefresh($param = null) 
    {
        $this->onReload([]);
    }
    public static function onAtualizarEmLote($param = null) 
    {
        if(isset($param['confirmAction']) && $param['confirmAction'] == 1)
        {
            try
            {
                $session_checks = TSession::getValue(__CLASS__.'builder_datagrid_check');

                if($session_checks)
                {
                    foreach($session_checks as $check_id)
                    {
                        TTransaction::open(self::$database);

                        $object = new SaasNotaFiscalServico($check_id);

                        if (! empty($object->id_gateway_externo))
                        {
                            SaasNotaFiscalServicoService::atualizar($object);
                        }

                        TTransaction::close();
                    }

                    TToast::show("success", "Notas fiscais atualizadas", "topRight", "fas fa-info-circle");                

                    TApplication::loadPage(__CLASS__, 'onShow', []);
                }

                TSession::setValue(__CLASS__.'builder_datagrid_check', []);
            }
            catch (Exception $e)
            {
                new TMessage('error', $e->getMessage());
                TTransaction::rollback();
            }
        }
        else
        {
            $action = new TAction(array(__CLASS__, 'onAtualizarEmLote'));
            $action->setParameters($param);
            $action->setParameter('confirmAction', 1);

            new TQuestion('Atualizar notas fiscais em lote?', $action);   
        }
    }

    /**
     * Register the filter in the session
     */
    public function onSearch($param = null)
    {
        $data = $this->form->getData();
        $filters = [];

        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        if (isset($data->account_id) AND ( (is_scalar($data->account_id) AND $data->account_id !== '') OR (is_array($data->account_id) AND (!empty($data->account_id)) )) )
        {

            $filters[] = new TFilter('account_id', '=', $data->account_id);// create the filter 
        }

        if (isset($data->numero) AND ( (is_scalar($data->numero) AND $data->numero !== '') OR (is_array($data->numero) AND (!empty($data->numero)) )) )
        {

            $filters[] = new TFilter('numero', 'like', "%{$data->numero}%");// create the filter 
        }

        if (isset($data->data_hora_emissao) AND ( (is_scalar($data->data_hora_emissao) AND $data->data_hora_emissao !== '') OR (is_array($data->data_hora_emissao) AND (!empty($data->data_hora_emissao)) )) )
        {

            $filters[] = new TFilter('data_hora_emissao', '>=', $data->data_hora_emissao);// create the filter 
        }

        if (isset($data->data_hora_emissao_fim) AND ( (is_scalar($data->data_hora_emissao_fim) AND $data->data_hora_emissao_fim !== '') OR (is_array($data->data_hora_emissao_fim) AND (!empty($data->data_hora_emissao_fim)) )) )
        {

            $filters[] = new TFilter('data_hora_emissao', '<=', $data->data_hora_emissao_fim);// create the filter 
        }

        if (isset($data->discriminacao) AND ( (is_scalar($data->discriminacao) AND $data->discriminacao !== '') OR (is_array($data->discriminacao) AND (!empty($data->discriminacao)) )) )
        {

            $filters[] = new TFilter('discriminacao', 'like', "%{$data->discriminacao}%");// create the filter 
        }

        if (isset($data->nfse_status) AND ( (is_scalar($data->nfse_status) AND $data->nfse_status !== '') OR (is_array($data->nfse_status) AND (!empty($data->nfse_status)) )) )
        {

            $filters[] = new TFilter('nfse_status', 'in', $data->nfse_status);// create the filter 
        }

        //UnidadeService::addFilterUnidade($data, $filters);

        // fill the form with data again
        $this->form->setData($data);

        // keep the search data in the session
        TSession::setValue(__CLASS__.'_filter_data', $data);
        TSession::setValue(__CLASS__.'_filters', $filters);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }

    /**
     * Load the datagrid with data
     */
    public function onReload($param = NULL)
    {
        try
        {
            // open a transaction with database 'clinica'
            TTransaction::open(self::$database);

            // creates a repository for SaasNotaFiscalServico
            $repository = new TRepository(self::$activeRecord);

            $criteria = clone $this->filter_criteria;

            if (empty($param['order']))
            {
                $param['order'] = 'id';    
            }

            if (empty($param['direction']))
            {
                $param['direction'] = 'desc';
            }

            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $this->limit);

            if($filters = TSession::getValue(__CLASS__.'_filters'))
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            $session_checks = TSession::getValue(__CLASS__.'builder_datagrid_check');

            //</blockLine><btnShowCurtainFiltersAutoCode>
            if(!empty($this->btnShowCurtainFilters) && empty($this->btnShowCurtainFiltersAdjusted))
            {
                $this->btnShowCurtainFiltersAdjusted = true;
                $this->btnShowCurtainFilters->style = 'position: relative';
                $countFilters = count($filters ?? []);
                $this->btnShowCurtainFilters->setLabel($this->btnShowCurtainFilters->getLabel(). "<span class='badge badge-success' style='position: absolute'>{$countFilters}<span>");
            }
            //</blockLine></btnShowCurtainFiltersAutoCode>

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            $this->datagrid->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {
                    $check = new TCheckGroup('builder_datagrid_check');
                    $check->addItems([$object->id => '']);
                    $check->getButtons()[$object->id]->onclick = 'event.stopPropagation()';

                    if(!$this->datagrid_form->getField('builder_datagrid_check[]'))
                    {
                        $this->datagrid_form->setFields([$check]);
                    }

                    $check->setChangeAction(new TAction([$this, 'builderSelectCheck']));
                    $object->builder_datagrid_check = $check;

                    if(!empty($session_checks[$object->id]))
                    {
                        $object->builder_datagrid_check->setValue([$object->id=>$object->id]);
                    }

                    $row = $this->datagrid->addItem($object);
                    $row->id = "row_{$object->id}";

                }
            }

            // reset the criteria for record count
            $criteria->resetProperties();
            $count= $repository->count($criteria);

            $this->pageNavigation->setCount($count); // count of records
            $this->pageNavigation->setProperties($param); // order, page
            $this->pageNavigation->setLimit($this->limit); // limit

            // close the transaction
            TTransaction::close();
            $this->loaded = true;

            return $objects;
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

    /**
     * method show()
     * Shows the page
     */
    public function show()
    {
        // check if the datagrid is already loaded
        if (!$this->loaded AND (!isset($_GET['method']) OR !(in_array($_GET['method'],  $this->showMethods))) )
        {
            if (func_num_args() > 0)
            {
                $this->onReload( func_get_arg(0) );
            }
            else
            {
                $this->onReload();
            }
        }
        parent::show();
    }

    public static function builderSelectCheck($param)
    {
        $session_checks = TSession::getValue(__CLASS__.'builder_datagrid_check');

        $valueOn = null;
        if(!empty($param['_field_data_json']))
        {
            $obj = json_decode($param['_field_data_json']);
            if($obj)
            {
                $valueOn = $obj->valueOn;
            }
        }

        $key = empty($param['key']) ? $valueOn : $param['key'];

        if(empty($param['builder_datagrid_check']) && !empty($session_checks[$key]))
        {
            unset($session_checks[$key]);
        }
        elseif(!empty($param['builder_datagrid_check']) && !in_array($key, $param['builder_datagrid_check']) && !empty($session_checks[$key]))
        {
            unset($session_checks[$key]);
        }
        elseif(!empty($param['builder_datagrid_check']) && in_array($key, $param['builder_datagrid_check']))
        {
            $session_checks[$key] = $key;
        }

        TSession::setValue(__CLASS__.'builder_datagrid_check', $session_checks);
    }

    public static function manageRow($id, $param = [])
    {
        $list = new self($param);

        $openTransaction = TTransaction::getDatabase() != self::$database ? true : false;

        if($openTransaction)
        {
            TTransaction::open(self::$database);    
        }

        $object = new SaasNotaFiscalServico($id);

        $session_checks = TSession::getValue(__CLASS__.'builder_datagrid_check');

        $check = new TCheckGroup('builder_datagrid_check');
        $check->addItems([$object->id => '']);
        $check->getButtons()[$object->id]->onclick = 'event.stopPropagation()';

        if(!$list->datagrid_form->getField('builder_datagrid_check[]'))
        {
            $list->datagrid_form->setFields([$check]);
        }

        $check->setChangeAction(new TAction([$list, 'builderSelectCheck']));
        $object->builder_datagrid_check = $check;

        if(!empty($session_checks[$object->id]))
        {
            $object->builder_datagrid_check->setValue([$object->id=>$object->id]);
        }

        $row = $list->datagrid->addItem($object);
        $row->id = "row_{$object->id}";

        if($openTransaction)
        {
            TTransaction::close();    
        }

        TDataGrid::replaceRowById(__CLASS__.'_datagrid', $row->id, $row);
    }

}

