<?php

class SaasPlanoValorSimpleList extends TPage
{

    private $datagrid; // listing
    private $pageNavigation;
    private $loaded;
    private static $database = 'clinica';
    private static $activeRecord = 'SaasPlanoValor';
    private static $primaryKey = 'id';
    private static $formName = 'formList_SaasPlanoValor';
    private $limit = 20;

    public function __construct($param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        $this->limit = 0;

        // creates a Datagrid
        $this->datagrid = new TDataGrid;
        $this->datagrid->setId(__CLASS__.'_datagrid');

        $this->datagrid_form = new TForm('datagrid_'.self::$formName);
        $this->datagrid_form->onsubmit = 'return false';

        $this->datagrid = new BootstrapDatagridWrapper($this->datagrid);

        $this->datagrid->style = 'width: 100%';
        $this->datagrid->setHeight(320);

        $column_nome = new TDataGridColumn('nome', "Nome", 'left');
        $column_valor = new TDataGridColumn('valor', "Valor", 'left');
        $column_duracao = new TDataGridColumn('duracao', "Duração em meses", 'center');
        $column_desativado_em_transformed = new TDataGridColumn('desativado_em', "Desativado em", 'center');
        $column_ativo_transformed = new TDataGridColumn('ativo', "Ativo", 'right');

        $column_desativado_em_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y H:i');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_ativo_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            if($value === 'T' || $value === true || $value === 't' || $value === 'S' || $value === 'Y'  || $value === 'y'  )
            {
                return '<span class="label label-success">Sim</span>';
            }
            elseif($value === 'F' || $value === false || $value === 'f' || $value === 'N' || $value === 'n'  )
            {
                return '<span class="label label-danger">Não</span>';
            }

            return '';

        });        

        $this->datagrid->addColumn($column_nome);
        $this->datagrid->addColumn($column_valor);
        $this->datagrid->addColumn($column_duracao);
        $this->datagrid->addColumn($column_desativado_em_transformed);
        $this->datagrid->addColumn($column_ativo_transformed);

        // create the datagrid model
        $this->datagrid->createModel();

        $panel = new TPanelGroup();
        $panel->datagrid = 'datagrid-container';
        $this->datagridPanel = $panel;
        $this->datagrid_form->add($this->datagrid);
        $panel->add($this->datagrid_form);

        $panel->getBody()->class .= ' table-responsive';

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["SaaS Admin","Valor dos planos"]));
        }
        $container->add($panel);

        parent::add($container);

    }

    /**
     * Load the datagrid with data
     */
    public function onReload($param = NULL)
    {
        try
        {
            // open a transaction with database 'clinica'
            TTransaction::open(self::$database);

            // creates a repository for SaasPlanoValor
            $repository = new TRepository(self::$activeRecord);
            // creates a criteria
            $criteria = new TCriteria;

            if(!empty($param["saas_plano_id"] ?? -99))
        {
            TSession::setValue(__CLASS__.'load_filter_saas_plano_id', $param["saas_plano_id"] ?? -99);
        }
        $filterVar = TSession::getValue(__CLASS__.'load_filter_saas_plano_id');
            $criteria->add(new TFilter('saas_plano_id', '=', $filterVar));

            if (empty($param['order']))
            {
                $param['order'] = 'id';    
            }
            if (empty($param['direction']))
            {
                $param['direction'] = 'desc';
            }

            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $this->limit);

            if($filters = TSession::getValue(__CLASS__.'_filters'))
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            $this->datagrid->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {

                    $row = $this->datagrid->addItem($object);
                    $row->id = "row_{$object->id}";

                }
            }

            // reset the criteria for record count
            $criteria->resetProperties();
            $count= $repository->count($criteria);

            // close the transaction
            TTransaction::close();
            $this->loaded = true;

            return $objects;
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

    /**
     * method show()
     * Shows the page
     */
    public function show()
    {
        // check if the datagrid is already loaded
        if (!$this->loaded AND (!isset($_GET['method']) OR !(in_array($_GET['method'],  array('onReload', 'onSearch')))) )
        {
            if (func_num_args() > 0)
            {
                $this->onReload( func_get_arg(0) );
            }
            else
            {
                $this->onReload();
            }
        }
        parent::show();
    }

    public static function onYesCriarPlanoMP($param = null) 
    {
        try 
        {
            if(!empty($param['key']))
            {
                TTransaction::open(self::$database);

                $saasPlanoValor = new SaasPlanoValor($param['key']);

                $service = new MercadoPagoService(new SaasGatewayPagamento(SaasGatewayPagamento::MERCADO_PAGO));

                $ret = $service->createPlan($saasPlanoValor);

                $saasPlanoValor->mercado_pago_plano_id = $ret['plan_id'];
                $saasPlanoValor->store();

                TTransaction::close();

                self::manageRow($saasPlanoValor->id);

                new TMessage('info', 'Plano criado no Mercado Pago');
            }
            else
            {
                throw new Exception('Valor do plano não encontrado');
            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onNoCriarPlanoMP($param = null) 
    {
        try 
        {
            //code here
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function manageRow($id, $param = [])
    {
        $list = new self($param);

        $openTransaction = TTransaction::getDatabase() != self::$database ? true : false;

        if($openTransaction)
        {
            TTransaction::open(self::$database);    
        }

        $object = new SaasPlanoValor($id);

        $row = $list->datagrid->addItem($object);
        $row->id = "row_{$object->id}";

        if($openTransaction)
        {
            TTransaction::close();    
        }

        TDataGrid::replaceRowById(__CLASS__.'_datagrid', $row->id, $row);
    }

}

