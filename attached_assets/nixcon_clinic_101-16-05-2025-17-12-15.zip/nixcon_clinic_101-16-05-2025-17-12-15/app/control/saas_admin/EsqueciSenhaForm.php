<?php

use \Firebase\JWT\JWT;
use \Firebase\JWT\Key;

class EsqueciSenhaForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_EsqueciSenhaForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Esqueci a senha");


        $email = new TEntry('email');


        $email->setSize('100%');


        $row1 = $this->form->addFields([new TLabel("Informe o email da sua conta:", null, '14px', null, '100%'),$email,new TLabel("Você receberá um email com um link para criar uma nova senha para a sua conta.", null, '11px', null)]);
        $row1->layout = [' col-sm-12'];

        // create the form actions
        $btn_onaction = $this->form->addAction("RESETAR A SENHA", new TAction([$this, 'onAction']), 'fas:user-lock #ffffff');
        $this->btn_onaction = $btn_onaction;
        $btn_onaction->addStyleClass('btnnovacontalogin'); 

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        }
        $container->add($this->form);

        $container->add('<div style="text-align:center;"> <a href="login" class="btn btn-link btnJaTemConta"><i class="fas fa-sign-in-alt"></i> Já tem conta? Faça login</a> </div>');

        parent::add($container);

    }

    public static function onAction($param = null) 
    {
        try
        {

            if(empty($param['email']))
            {
                throw new Exception('Informe o email');
            }

            $ini = AdiantiApplicationConfig::get();

            if (empty($ini['general']['seed']) OR $ini['general']['seed'] == 's8dkld83kf73kf094')
            {
                throw new Exception(_t('A new seed is required in the application.ini for security reasons'));
            }

            TTransaction::open('permission');

            $login = $param['email'];
            $user  = SystemUsers::newFromLogin($login);

            TTransaction::close();

            if ($user instanceof SystemUsers)
            {
                if ($user->active == 'N')
                {
                    throw new Exception('Permissão negada');
                }
                else
                {
                    $seed = APPLICATION_NAME . $ini['general']['seed'];

                    $token = array(
                        "user" => $user->login,
                        "expires" => strtotime("+ 3 hours")
                    );

                    $jwt = JWT::encode($token, $seed, 'HS256');

                    $referer = $_SERVER['HTTP_REFERER'];
                    $url = substr($referer, 0, strpos($referer, 'index.php'));
                    $url .= 'index.php?class=ResetSenhaForm&method=onLoad&token='.$jwt;

                    SaasEmailTemplateService::enviarResetarSenha($param['email'], $user->name, $url);

                    new TMessage('info', "Acesse o seu email que nele terá um link para trocar a sua senha.");

                    TScript::create("setTimeout(function(){location.href='index.php';}, 1500)");
                }
            }
            else
            {
                throw new Exception('Permissão negada!');
            }
        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
        }
    }

    public function onShow($param = null)
    {               

    } 

}

