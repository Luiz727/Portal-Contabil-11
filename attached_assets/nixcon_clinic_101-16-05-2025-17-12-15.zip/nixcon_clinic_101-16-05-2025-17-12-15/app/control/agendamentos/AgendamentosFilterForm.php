<?php

class AgendamentosFilterForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_AgendamentosFilterForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Agenda");

        $criteria_clinica_id = new TCriteria();
        $criteria_paciente_id = new TCriteria();
        $criteria_profissional_id = new TCriteria();

        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_clinica_id->add(new TFilter('system_unit_id', 'in', $filterVar)); 
        $filterVar = Grupo::PACIENTE;
        $criteria_paciente_id->add(new TFilter('id', 'in', "(SELECT pessoa_id FROM pessoa_grupo WHERE grupo_id = '{$filterVar}')")); 
        $filterVar = "{session.clinica_id_agendamentos_filter_form}";
        $criteria_paciente_id->add(new TFilter('clinica_id', '=', $filterVar)); 
        $filterVar = Grupo::PROFISSIONAL;
        $criteria_profissional_id->add(new TFilter('id', 'in', "(SELECT pessoa_id FROM pessoa_grupo WHERE grupo_id = '{$filterVar}')")); 
        $filterVar = "{session.clinica_id_agendamentos_filter_form}";
        $criteria_profissional_id->add(new TFilter('clinica_id', '=', $filterVar)); 

        $clinica_id = new TDBCombo('clinica_id', 'clinica', 'Clinica', 'id', '{nome}','nome asc' , $criteria_clinica_id );
        $agenda_id = new TCombo('agenda_id');
        $paciente_id = new TDBUniqueSearch('paciente_id', 'clinica', 'Pessoa', 'id', 'nome','nome asc' , $criteria_paciente_id );
        $profissional_id = new TDBUniqueSearch('profissional_id', 'clinica', 'Pessoa', 'id', 'nome','nome asc' , $criteria_profissional_id );
        $dt_busca = new TDate('dt_busca');
        $button_filtrar = new TButton('button_filtrar');
        $calendario = new BPageContainer();

        $clinica_id->setChangeAction(new TAction([$this,'onChangeClinica']));

        $clinica_id->enableSearch();
        $dt_busca->setDatabaseMask('yyyy-mm-dd');
        $button_filtrar->addStyleClass('btn-primary');
        $button_filtrar->setImage('fas:search #FFFFFF');
        $calendario->setId('calendar_agendamentos_container');
        $paciente_id->setMinLength(0);
        $profissional_id->setMinLength(0);

        $button_filtrar->setAction(new TAction([$this, 'onFilter']), "Filtrar");
        $calendario->setAction(new TAction(['AgendamentoCalendarFormView', 'onShow'], $param));

        $dt_busca->setMask('dd/mm/yyyy');
        $paciente_id->setMask('{nome_formatado}');
        $profissional_id->setMask('{nome_formatado}');

        $dt_busca->setSize(120);
        $agenda_id->setSize('100%');
        $clinica_id->setSize('100%');
        $calendario->setSize('100%');
        $paciente_id->setSize('100%');
        $profissional_id->setSize('100%');

        $loadingContainer = new TElement('div');
        $loadingContainer->style = 'text-align:center; padding:50px';

        $icon = new TElement('i');
        $icon->class = 'fas fa-spinner fa-spin fa-3x';

        $loadingContainer->add($icon);
        $loadingContainer->add('<br>Carregando');

        $calendario->add($loadingContainer);

        $this->calendario = $calendario;

        $row1 = $this->form->addFields([new TLabel("Clínica:", null, '14px', null, '100%'),$clinica_id],[new TLabel("Agenda:", null, '14px', null),$agenda_id],[new TLabel("Paciente:", null, '14px', null),$paciente_id],[new TLabel("Profissional:", null, '14px', null),$profissional_id],[new TLabel("Data:", null, '14px', null, '100%'),$dt_busca,$button_filtrar]);
        $row1->layout = ['col-sm-2','col-sm-2','col-sm-3',' col-sm-2',' col-sm-3'];

        $row2 = $this->form->addFields([$calendario]);
        $row2->layout = [' col-sm-12'];

        // create the form actions

        $btn_onshow = $this->form->addHeaderAction("Visualizar como listagem", new TAction(['AgendaAgendamentoList', 'onShow']), 'fas:list-ul #009688');
        $this->btn_onshow = $btn_onshow;

        $btn_onshow = $this->form->addHeaderAction("Adicionar bloqueio", new TAction(['BloqueioForm', 'onShow']), 'fas:ban #607D8B');
        $this->btn_onshow = $btn_onshow;

        $btnPaciente = $this->form->addHeaderAction("Paciente", new TAction(['PacienteForm', 'onShow']), 'fas:user-plus #4CAF50');
        $this->btnPaciente = $btnPaciente;

        $btn_onstartedit = $this->form->addHeaderAction("Novo Agendamento", new TAction(['AgendamentoCalendarForm', 'onStartEdit']), 'fas:calendar-plus #9C27B0');
        $this->btn_onstartedit = $btn_onstartedit;

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Agendamentos","Agendamentos"]));
        }
        $container->add($this->form);

        $btnPaciente->getAction()->setParameter('origin', 'calendar');

        $data = TSession::getValue('agendamentos_filter_data');

        TForm::sendData(self::$formName, $data);
        $this->form->setData($data);

        parent::add($container);

    }

    public static function onChangeClinica($param = null) 
    {
        try 
        {

            if(!empty($param['key']))
            {
                TSession::setValue('clinica_id_agendamentos_filter_form', $param['key']);

                TTransaction::open(MAIN_DATABASE);
                $agendas = ClinicaService::getAgendas($param['key']);

                TCombo::reload(self::$formName, 'agenda_id', $agendas, true);

                TTransaction::close();
            }
            else
            {
                TSession::setValue('clinica_id_agendamentos_filter_form', PermissaoService::getUnidadeDefault());
                TCombo::clearField(self::$formName, 'agenda_id');
            } 

            TMultiSearch::clearField(self::$formName, 'paciente_id');
            TMultiSearch::clearField(self::$formName, 'profissional_id');

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public  function onFilter($param = null) 
    {
        try 
        {
            $data = $this->form->getData();
            $this->form->setData($data);
            TForm::sendData(self::$formName, $data);

            TSession::setValue('agendamentos_filter_agenda_id', $data->agenda_id ?? null);
            TSession::setValue('agendamentos_filter_clinica_id', $data->clinica_id ?? null);
            TSession::setValue('agendamentos_filter_data', $data ?? null);

            TSession::setValue('clinica_id_agendamentos_filter_form', PermissaoService::getUnidadeDefault());

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onShow($param = null)
    {               

        // TForm::sendData(self::$formName, (object)[
        //     'clinica_id' => PermissaoService::getUnidadeDefault()
        // ]);

        TSession::setValue('clinica_id_agendamentos_filter_form', PermissaoService::getUnidadeDefault());

    } 

}

