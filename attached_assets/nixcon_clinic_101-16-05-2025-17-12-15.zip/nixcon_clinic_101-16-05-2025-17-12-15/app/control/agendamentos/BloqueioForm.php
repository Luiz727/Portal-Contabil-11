<?php

class BloqueioForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Bloqueio';
    private static $primaryKey = 'id';
    private static $formName = 'form_Bloqueio';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Bloqueio");

        $criteria_clinica_id = new TCriteria();

        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_clinica_id->add(new TFilter('id', 'in', $filterVar)); 

        $id = new TEntry('id');
        $clinica_id = new TDBCombo('clinica_id', 'clinica', 'Clinica', 'id', '{nome}','nome asc' , $criteria_clinica_id );
        $agenda_id = new TCombo('agenda_id');
        $dt_inicio = new TDateTime('dt_inicio');
        $dt_final = new TDateTime('dt_final');
        $observacao = new TText('observacao');

        $clinica_id->setChangeAction(new TAction([$this,'onChangeClinica']));

        $agenda_id->addValidation("Agenda", new TRequiredValidator()); 
        $dt_inicio->addValidation("Início", new TRequiredValidator()); 
        $dt_final->addValidation("Fim", new TRequiredValidator()); 
        $observacao->addValidation("Observação", new TRequiredValidator()); 

        $id->setEditable(false);
        $clinica_id->enableSearch();
        $dt_final->setMask('dd/mm/yyyy hh:ii');
        $dt_inicio->setMask('dd/mm/yyyy hh:ii');

        $dt_final->setDatabaseMask('yyyy-mm-dd hh:ii');
        $dt_inicio->setDatabaseMask('yyyy-mm-dd hh:ii');

        $id->setSize(100);
        $dt_final->setSize(150);
        $dt_inicio->setSize(150);
        $agenda_id->setSize('100%');
        $clinica_id->setSize('100%');
        $observacao->setSize('100%', 70);

        $row1 = $this->form->addFields([new TLabel("Código:", null, '14px', null, '100%'),$id]);
        $row1->layout = ['col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Clínica:", '#FF0000', '14px', null, '100%'),$clinica_id],[new TLabel("Agenda:", '#ff0000', '14px', null, '100%'),$agenda_id]);
        $row2->layout = ['col-sm-6','col-sm-6'];

        $row3 = $this->form->addFields([new TLabel("Início:", '#ff0000', '14px', null, '100%'),$dt_inicio],[new TLabel("Fim:", '#ff0000', '14px', null, '100%'),$dt_final]);
        $row3->layout = ['col-sm-3','col-sm-3'];

        $row4 = $this->form->addFields([new TLabel("Observação:", '#FF0000', '14px', null, '100%'),$observacao]);
        $row4->layout = [' col-sm-12'];

        // create the form actions
        $btnSalvar = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btnSalvar = $btnSalvar;
        $btnSalvar->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btnRemoverBloqueio = $this->form->addAction("Remover Bloqueio", new TAction([$this, 'onDeleteBloqueio']), 'fas:trash-alt #FF5722');
        $this->btnRemoverBloqueio = $btnRemoverBloqueio;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=BloqueioForm]');
        $style->width = '70% !important';   
        $style->show(true);

    }

    public static function onChangeClinica($param = null) 
    {
        try 
        {

            if(!empty($param['key']))
            {
                TTransaction::open(MAIN_DATABASE);
                $agendas = ClinicaService::getAgendas($param['key']);

                TCombo::reload(self::$formName, 'agenda_id', $agendas, true);

                TTransaction::close();
            }
            else
            {
                TCombo::clearField(self::$formName, 'agenda_id');
            } 

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Bloqueio(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $this->fireEvents($object);

            $messageAction = new TAction(['AgendamentosFilterForm', 'onShow']);   

            if(!empty($param['target_container']))
            {
                $messageAction->setParameter('target_container', $param['target_container']);
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            new TMessage('info', "Registro salvo", $messageAction); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {

            $this->fireEvents($this->form->getData());  

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }
    public static function onDeleteBloqueio($param = null) 
    {
        try 
        {
            // Código gerado pelo snippet: "Questionamento"
            new TQuestion("Você tem certeza que deseja remover esse bloqueio?", new TAction([__CLASS__, 'onYesRemoverBloqueio'], $param), new TAction([__CLASS__, 'onNoRemoverBloqueio'], $param));
            // -----

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Bloqueio($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                $this->fireEvents($object);

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        $this->btnRemoverBloqueio->disabled = 'disabled';

    }

    public function onShow($param = null)
    {

        $this->btnRemoverBloqueio->disabled = 'disabled';

    } 

    public function fireEvents( $object )
    {
        $obj = new stdClass;
        if(is_object($object) && get_class($object) == 'stdClass')
        {
            if(isset($object->clinica_id))
            {
                $value = $object->clinica_id;

                $obj->clinica_id = $value;
            }
            if(isset($object->agenda_id))
            {
                $value = $object->agenda_id;

                $obj->agenda_id = $value;
            }
        }
        elseif(is_object($object))
        {
            if(isset($object->clinica_id))
            {
                $value = $object->clinica_id;

                $obj->clinica_id = $value;
            }
            if(isset($object->agenda_id))
            {
                $value = $object->agenda_id;

                $obj->agenda_id = $value;
            }
        }
        TForm::sendData(self::$formName, $obj);
    }  

    public static function getFormName()
    {
        return self::$formName;
    }

    public static function onYesRemoverBloqueio($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $bloqueio = new Bloqueio($param['id']);
            $bloqueio->delete();

            TTransaction::close();

            new TMessage('info', 'Bloqueio removido', new TAction(['AgendamentosFilterForm', 'onShow']));

            TScript::create("Template.closeRightPanel();");
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onNoRemoverBloqueio($param = null) 
    {
        try 
        {
            //code here
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

}

