<?php
/**
 * AgendamentoCalendarForm Form
 * @author  <your name here>
 */
class AgendamentoCalendarFormView extends TPage
{
    private $fc;

    /**
     * Page constructor
     */
    public function __construct($param = null)
    {
        parent::__construct();

        TSession::setValue(__CLASS__.'load_filter_agenda_id', null);
        TSession::setValue(__CLASS__.'load_filter_agenda_id_1', null);
        TSession::setValue(__CLASS__.'load_filter_paciente_id', null);
        TSession::setValue(__CLASS__.'load_filter_clinica_id', null);

        $this->fc = new TFullCalendar(date('Y-m-d'), 'month');
        $this->fc->enableDays([0,1,2,3,4,5,6]);
        $this->fc->setReloadAction(new TAction(array($this, 'getEvents'), $param));
        $this->fc->setDayClickAction(new TAction(array('AgendamentoCalendarForm', 'onStartEdit')));
        $this->fc->setEventClickAction(new TAction(array('AgendamentoCalendarForm', 'onEdit')));
        $this->fc->setCurrentView('agendaWeek');
        $this->fc->setTimeRange('07:00', '19:00');
        $this->fc->enablePopover('', "{detalhe_html}
");
        $this->fc->setOption('slotTime', "00:15:00");
        $this->fc->setOption('slotDuration', "00:15:00");
        $this->fc->setOption('slotLabelInterval', 15);

        $this->fc->enableFullHeight();
        $this->fc->setEventClickAction(new TAction(array($this, 'onClick')));
        $this->fc->setDayClickAction(new TAction(array('AgendamentoCalendarForm', 'onStartEdit'), $param));
        $this->fc->id = 'agendamentos';

        $agenda_id = TSession::getValue('agendamentos_filter_agenda_id');

        if ($agenda_id)
        {
            TTransaction::open('clinica');
            $agenda = Agenda::find($agenda_id);

            $this->fc->setCurrentView($agenda->visualizacao_inicial);
            $this->fc->setTimeRange($agenda->horario_inicial, $agenda->horario_final);

            $time = date('H:i:s', strtotime("2000-01-01 +{$agenda->duracao} minutes"));

            $this->fc->setOption('slotTime', $time);
            $this->fc->setOption('slotDuration', $time);
            $this->fc->setOption('slotLabelInterval', (int) $agenda->duracao);

            TTransaction::close();
        }

        parent::add( $this->fc );
    }

    /**
     * Output events as an json
     */
    public static function getEvents($param=NULL)
    {
        $return = array();
        try
        {
            TTransaction::open('clinica');

            $criteria = new TCriteria(); 

            $criteria->add(new TFilter('dt_inicial', '<=', substr($param['end'], 0, 10).' 23:59:59'));
            $criteria->add(new TFilter('dt_final', '>=', substr($param['start'], 0, 10).' 00:00:00'));

            if(!empty($param['clear_session_filters']))
            {
                TSession::setValue(__CLASS__.'load_filter_agenda_id', null);
                TSession::setValue(__CLASS__.'load_filter_agenda_id_1', null);
                TSession::setValue(__CLASS__.'load_filter_paciente_id', null);
                TSession::setValue(__CLASS__.'load_filter_clinica_id', null);
            }

            $filterVar = "T";
            $criteria->add(new TFilter('ativo', '=', $filterVar)); 
            $filterVar = PermissaoService::getUnidadeIds();
            $criteria->add(new TFilter('clinica_id', 'in', $filterVar)); 
            if(!empty($param['agenda_id']))
        {
            TSession::setValue(__CLASS__.'load_filter_agenda_id', $param['agenda_id']);
        }
        $filterVar = TSession::getValue(__CLASS__.'load_filter_agenda_id');
            if (isset($filterVar) AND ( (is_scalar($filterVar) AND $filterVar !== '') OR (is_array($filterVar) AND (!empty($filterVar)))))
            {
                $criteria->add(new TFilter('agenda_id', '=', $filterVar)); 
            }
            if(!empty($param['profissional_id']))
        {
            TSession::setValue(__CLASS__.'load_filter_agenda_id_1', $param['profissional_id']);
        }
        $filterVar = TSession::getValue(__CLASS__.'load_filter_agenda_id_1');

            if (isset($filterVar) AND ( (is_scalar($filterVar) AND $filterVar !== '') OR (is_array($filterVar) AND (!empty($filterVar)))))
            {
                $criteria->add(new TFilter('agenda_id', 'in', "(SELECT id FROM agenda WHERE profissional_id = '{$filterVar}')")); 
            }
            if(!empty($param['paciente_id']))
        {
            TSession::setValue(__CLASS__.'load_filter_paciente_id', $param['paciente_id']);
        }
        $filterVar = TSession::getValue(__CLASS__.'load_filter_paciente_id');
            if (isset($filterVar) AND ( (is_scalar($filterVar) AND $filterVar !== '') OR (is_array($filterVar) AND (!empty($filterVar)))))
            {
                $criteria->add(new TFilter('paciente_id', '=', $filterVar)); 
            }
            if(!empty($param["clinica_id"] ?? ""))
        {
            TSession::setValue(__CLASS__.'load_filter_clinica_id', $param["clinica_id"] ?? "");
        }
        $filterVar = TSession::getValue(__CLASS__.'load_filter_clinica_id');
            if (isset($filterVar) AND ( (is_scalar($filterVar) AND $filterVar !== '') OR (is_array($filterVar) AND (!empty($filterVar)))))
            {
                $criteria->add(new TFilter('clinica_id', '=', $filterVar)); 
            }

            $filterVar = TSession::getValue("userid");

            $criteriaAcesso = new TCriteria;
            // está como um profissional relacionado com a agenda
            $criteriaAcesso->add(new TFilter('agenda_id', 'in', "(SELECT agenda.id FROM agenda, agenda_profissional, pessoa WHERE pessoa.id = agenda_profissional.profissional_id AND agenda.id = agenda_profissional.agenda_id AND system_users_id = '{$filterVar}')"));
            // oyu é o profissional responsável da agenda
            $criteriaAcesso->add(new TFilter('agenda_id', 'in', "(SELECT agenda.id FROM agenda, pessoa WHERE pessoa.id = agenda.profissional_id AND system_users_id = '{$filterVar}')"), TExpression::OR_OPERATOR); 

            $criteria->add($criteriaAcesso);

            $agenda_id = TSession::getValue('agendamentos_filter_agenda_id');

            if ($agenda_id)
            {
                $agenda = Agenda::find($agenda_id);

                // get dias off
                if ($agenda->dias)
                {

                    $end = new DateTime($param['end']);

                    $semanaTrabalho = [1=>1,2=>2,3=>3,4=>4,5=>5,6=>6,0=>0];

                    $dias = explode(',',$agenda->dias);

                    foreach($dias as $dia)
                    {
                        $start = new DateTime($param['start']);

                        if($dia > 0)
                        {
                            $d = $dia - 1;
                            $start = $start->modify("+{$d} day");    
                        }
                        else
                        {
                            $d = 6;
                            $start = $start->modify("+{$d} day");  
                        }

                        if(isset($semanaTrabalho[$dia]))
                        {
                            unset($semanaTrabalho[$dia]);
                        }

                        $return[] = [
                            'type' => 'disponivel',
                            'title' =>'Disponível',
                            'overlap' => false,
                            'rendering' => "background",
                            'display' => 'background',
                            'color' => '#00cec9',
                            'start' => $start->format('Y-m-d') .'T'. $agenda->horario_inicial,
                             'end' =>  $start->format('Y-m-d') .'T'. $agenda->horario_final
                        ];

                    }

                    foreach($semanaTrabalho as $naoTrabalho)
                    {
                        $start = new DateTime($param['start']);

                        if($naoTrabalho > 0)
                        {
                            $d = $naoTrabalho - 1;
                            $start = $start->modify("+{$d} day");    
                        }
                        else
                        {
                            $d = 6;
                            $start = $start->modify("+{$d} day");  
                        }

                        $event_array = [];
                        $event_array['start'] = $start->format('Y-m-d') .'T'. $agenda->horario_inicial;
                        $event_array['end'] =  $start->format('Y-m-d') .'T'. $agenda->horario_final;
                        $event_array['title'] = 'Não atende';
                        $event_array['id'] = 'nao-trabalha-'.uniqid();
                        $event_array['color'] = '#0000004a';
                        $event_array['overlap'] = true;
                        $event_array['rendering'] = 'block';
                        $event_array['display'] = 'block';

                        $return[] = $event_array;
                    }
                }

                // get Intervalo
                if ($agenda->horario_fim_intervalo AND $agenda->horario_inicio_intervalo)
                {
                    $start = new DateTime($param['start']);
                    $end = new DateTime($param['end']);

                    while($start->format('Y-m-d') <= $end->format('Y-m-d'))
                    {
                        if (! empty($semanaTrabalho[$start->format('w')]))
                        {
                            $start = $start->modify('+1 day');
                            continue;
                        }

                        $return[] = [
                            'type' => 'feriado',
                            'title' =>'Intervalo',
                            'overlap' => true,
                            'rendering' => "block",
                            'display' => 'block',
                            'color' => 'black',
                            'start' => $start->format('Y-m-d') .'T'. $agenda->horario_inicio_intervalo,
                            'end' =>  $start->format('Y-m-d') .'T'. $agenda->horario_fim_intervalo
                        ];

                        $start = $start->modify('+1 day');
                    }
                }
            }

            $criteriaBloqueio = new TCriteria;
            $criteriaBloqueio->add(new TFilter('dt_inicio', '<=', substr($param['end'], 0, 10).' 23:59:59'));
            $criteriaBloqueio->add(new TFilter('dt_final', '>=', substr($param['start'], 0, 10).' 00:00:00'));
            $criteriaBloqueio->add(new TFilter('clinica_id', 'in', PermissaoService::getUnidadeIds()));

            if (! empty($param['agenda_id']))
            {
                $criteriaBloqueio->add(new TFilter('agenda_id', '=', $param['agenda_id']));
            }

            // Get bloqueios
            $bloqueios = Bloqueio::getObjects($criteriaBloqueio);

            if ($bloqueios)
            {
                foreach($bloqueios as $bloqueio)
                {
                    if (! empty($semanaTrabalho[date('w', strtotime($bloqueio->dt_inicio))]))
                    {
                        continue;
                    }

                    $event_array = [];
                    $event_array['start'] = str_replace( ' ', 'T', $bloqueio->dt_inicio);
                    $event_array['end'] = str_replace( ' ', 'T', $bloqueio->dt_final);
                    $event_array['title'] = "<b>Horário bloqueado</b><br>" .nl2br($bloqueio->observacao);
                    $event_array['id'] = 'bloqueio-'.$bloqueio->id;
                    $event_array['color'] = '#555';

                    $return[] = $event_array;
                }
            }

            $events = Agendamento::getObjects($criteria);

            if ($events)
            {
                foreach ($events as $event)
                {
                    $event_array = $event->toArray();
                    $event_array['start'] = str_replace( ' ', 'T', $event_array['dt_inicial']);
                    $event_array['end'] = str_replace( ' ', 'T', $event_array['dt_final']);
                    $event_array['id'] = $event->id;

                    $event_array['title'] = TFullCalendar::renderPopover($event->render("<div style='display: flex; flex-direction: revert; justify-content: flex-start; align-items: center; gap: 5px;'>
<span title='{estado_agenda->nome}' class='estado_agendamento' style='background-color: {estado_agenda->cor}' ></span>  
{paciente->nome_formatado}
</div>"), $event->render(""), $event->render("{detalhe_html}
"));

                    $event_array['color'] = $event->render("{agenda->cor_agenda}");

                    $return[] = $event_array;
                }
            }
            TTransaction::close();
            echo json_encode($return);
        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
        }
    }

    /**
     * Reconfigure the callendar
     */
    public function onReload($param = null)
    {
        if (isset($param['view']))
        {
            $this->fc->setCurrentView($param['view']);
        }

        if (isset($param['date']))
        {
            $this->fc->setCurrentDate($param['date']);
        }
    }

    public static function onClick($param)
    {
        if (!empty($param['key']) && strpos($param['key'], 'bloqueio') !== false)
        {
            AdiantiCoreApplication::loadPage('BloqueioForm', 'onEdit', ['key' => str_replace('bloqueio-', '', $param['key'])]);
        }
        elseif (!empty($param['key']) && strpos($param['key'], 'trabalha') !== false)
        {
            // new TMessage('info', 'Não é posível agendar neste horário!');
        }
        elseif (!empty($param['key']) && strpos($param['key'], 'intervalo') !== false)
        {
            new TMessage('info', 'Não é posível agendar neste horário!');
        }
        elseif(!empty($param['key']))
        {
            unset($param['static']);
            AdiantiCoreApplication::loadPage('AgendamentoFormView', 'onShow', $param);
        }
    }

    public function onShow($param){}

}

