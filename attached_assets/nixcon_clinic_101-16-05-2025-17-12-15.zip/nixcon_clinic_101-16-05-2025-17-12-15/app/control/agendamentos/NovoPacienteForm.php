<?php

class NovoPacienteForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Pessoa';
    private static $primaryKey = 'id';
    private static $formName = 'form_NovoPacienteForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Paciente");

        if(!TSession::getValue('clinica_id'))
        {
            new TMessage('info', 'Sem permissão');
            return false;
        }

        $nome = new TEntry('nome');
        $email = new TEntry('email');
        $documento = new TEntry('documento');
        $telefone = new TEntry('telefone');
        $dt_nascimento = new TDate('dt_nascimento');
        $aceita_receber_mensagen_whatsapp = new TCheckButton('aceita_receber_mensagen_whatsapp');

        $nome->addValidation("Nome", new TRequiredValidator()); 
        $email->addValidation("E-mail", new TRequiredValidator()); 
        $documento->addValidation("CPF", new TRequiredValidator()); 
        $telefone->addValidation("Telefone", new TRequiredValidator()); 
        $dt_nascimento->addValidation("Data de nascimento", new TRequiredValidator()); 
        $email->addValidation("E-mail", new TEmailValidator(), []); 
        $documento->addValidation("CPF", new TCPFValidator(), []); 

        $dt_nascimento->setDatabaseMask('yyyy-mm-dd');
        $aceita_receber_mensagen_whatsapp->setUseSwitch(true, 'green');
        $aceita_receber_mensagen_whatsapp->setIndexValue("T");
        $documento->setMask('999.999.999-99');
        $telefone->setMask('(99) 99999-9999');
        $dt_nascimento->setMask('dd/mm/yyyy');

        $nome->setMaxLength(255);
        $email->setMaxLength(255);
        $telefone->setMaxLength(20);
        $documento->setMaxLength(255);

        $nome->setSize('100%');
        $email->setSize('100%');
        $telefone->setSize('100%');
        $documento->setSize('100%');
        $dt_nascimento->setSize('100%');

        $row1 = $this->form->addFields([new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$nome],[new TLabel("E-mail:", '#FF0000', '14px', null, '100%'),$email]);
        $row1->layout = ['col-sm-6','col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("CPF:", '#FF0000', '14px', null, '100%'),$documento],[new TLabel("Telefone:", '#FF0000', '14px', null, '100%'),$telefone],[new TLabel("Data nascimento:", '#FF0000', '14px', null, '100%'),$dt_nascimento]);
        $row2->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row3 = $this->form->addFields([new TLabel("Aceita receber informações sobre atualizações do seus agendamentos por whatsapp", null, '14px', null, '100%'),$aceita_receber_mensagen_whatsapp,new TLabel(new TImage('fas:info-circle #03A9F4')."Alguns exemplos de interação são lembrete de consulta, confirmação de agendamento", '#607D8B', '9px', 'I', '100%')]);
        $row3->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Cadastrar e continuar agendamento", new TAction([$this, 'onSave']), 'fas:arrow-right #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=NovoPacienteForm]');
        $style->width = '50% !important';   
        $style->show(true);

    }

    public function onSave($param = null) 
    {
        try
        {

            if(TSession::getValue('portal_paciente_id'))
            {
                new TMessage('info', 'Sem permissão');
                return false;
            }

            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Pessoa(); // create an empty object 

            $data = $this->form->getData(); // get form data as array

            if(empty($data->aceita_receber_mensagen_whatsapp))
            {
                $data->aceita_receber_mensagen_whatsapp = 'F';
            }

            $object->fromArray( (array) $data); // load the object with data

            if(!empty($data->id))
            {
                new TMessage('info', 'Sem permissão');
                unset($data->id);
                return false;
            }

            $username = strtoupper(uniqid());

            $object->usuario = $username;

            $consulta = Pessoa::where('usuario', '=', $username)->first();
            $count = 1;

            // gerando um nome de usuario unico
            while($consulta)
            {
                $object->usuario = $username.$count;
                $consulta = Pessoa::where('usuario', '=', $object->usuario)->first();
                $count++;
            }

            $bytes = openssl_random_pseudo_bytes(3);
            $pwd = bin2hex($bytes);

            $object->senha = $pwd;

            $object->clinica_id = TSession::getValue('clinica_id');

            $object->store(); // save the object 

            if (Pessoa::where('documento', '=', $data->documento)->where('clinica_id', '=', TSession::getValue('clinica_id'))->count() > 1)
            {
                throw new Exception('CPF já utilizado');
            }

            $pessoaGrupo = new PessoaGrupo();
            $pessoaGrupo->pessoa_id = $object->id;
            $pessoaGrupo->grupo_id = Grupo::PACIENTE;
            $pessoaGrupo->store();

            $agenda = Agenda::find(TSession::getValue('agenda_id'));

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data

            MensagemService::enviarEmailCredenciais($object, $agenda->clinica);

            TTransaction::close(); // close the transaction

            new TMessage('info', "Sucesso! você recebera um e-mail com o seu usuário e sua senha para acessar seus agendamentos e documentos.", $messageAction); 

            TSession::setValue('portal_paciente_id', $object->id);

            $param = ['date' => TSession::getValue('portal_date'), 'agenda_id' => TSession::getValue('agenda_id')];

            TScript::create('Template.closeRightPanel();');

            TApplication::loadPage('AgendamentoPacienteCalendarForm', 'onStartEdit', $param);
        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Pessoa($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

        $data = new stdClass;
        $data->aceita_receber_mensagen_whatsapp = 'T';
        $this->form->setData($data);

        TSession::setValue('portal_date', $param['date']);

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

