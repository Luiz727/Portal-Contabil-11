<?php

class AgendaForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Agenda';
    private static $primaryKey = 'id';
    private static $formName = 'form_Agenda';

    use BuilderMasterDetailTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de agenda");

        $criteria_clinica_id = new TCriteria();
        $criteria_agenda_profissional_agenda_profissional_id = new TCriteria();

        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_clinica_id->add(new TFilter('system_unit_id', 'in', $filterVar)); 
        $filterVar = Grupo::PROFISSIONAL;
        $criteria_agenda_profissional_agenda_profissional_id->add(new TFilter('id', 'in', "(SELECT pessoa_id FROM pessoa_grupo WHERE grupo_id = '{$filterVar}')")); 
        $filterVar = "{session.clinica_id_agenda_form}";
        $criteria_agenda_profissional_agenda_profissional_id->add(new TFilter('clinica_id', '=', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_agenda_profissional_agenda_profissional_id->add(new TFilter('clinica_id', 'in', $filterVar)); 

        $id = new TEntry('id');
        $clinica_id = new TDBCombo('clinica_id', 'clinica', 'Clinica', 'id', '{nome}','nome asc' , $criteria_clinica_id );
        $nome = new TEntry('nome');
        $profissional_id = new TCombo('profissional_id');
        $dias = new TCheckGroup('dias');
        $horario_inicial = new TTime('horario_inicial');
        $horario_final = new TTime('horario_final');
        $horario_inicio_intervalo = new TTime('horario_inicio_intervalo');
        $horario_fim_intervalo = new TTime('horario_fim_intervalo');
        $duracao = new TSpinner('duracao');
        $visualizacao_inicial = new TCombo('visualizacao_inicial');
        $cor = new TColor('cor');
        $procedimento_id = new TCombo('procedimento_id');
        $publica = new TRadioGroup('publica');
        $aceita_agendamento_online = new TRadioGroup('aceita_agendamento_online');
        $fl_permite_choque_horario = new TRadioGroup('fl_permite_choque_horario');
        $agenda_profissional_agenda_profissional_id = new TDBUniqueSearch('agenda_profissional_agenda_profissional_id', 'clinica', 'Pessoa', 'id', 'nome','nome asc' , $criteria_agenda_profissional_agenda_profissional_id );
        $agenda_profissional_agenda_id = new THidden('agenda_profissional_agenda_id');
        $agenda_profissional_agenda_fl_manipula_atendimento = new TRadioGroup('agenda_profissional_agenda_fl_manipula_atendimento');
        $button_adicionar_agenda_profissional_agenda = new TButton('button_adicionar_agenda_profissional_agenda');

        $clinica_id->setChangeAction(new TAction([$this,'onChangeClinica']));

        $clinica_id->addValidation("Clínica", new TRequiredValidator()); 
        $nome->addValidation("Nome", new TRequiredValidator()); 
        $profissional_id->addValidation("Profissional", new TRequiredValidator()); 
        $dias->addValidation("Atendimento em", new TRequiredValidator()); 
        $horario_inicial->addValidation("Horário inicial", new TRequiredValidator()); 
        $horario_final->addValidation("Horário final", new TRequiredValidator()); 
        $duracao->addValidation("Duração", new TRequiredValidator()); 
        $visualizacao_inicial->addValidation("Visualização inicial", new TRequiredValidator()); 
        $procedimento_id->addValidation("Procedimento padrão", new TRequiredValidator()); 
        $fl_permite_choque_horario->addValidation("Permite choque de horário", new TRequiredValidator()); 

        $id->setEditable(false);
        $profissional_id->enableSearch();
        $dias->setValueSeparator(',');
        $duracao->setRange(1, 2000, 1);
        $visualizacao_inicial->setDefaultOption(false);
        $agenda_profissional_agenda_profissional_id->setMinLength(0);
        $agenda_profissional_agenda_profissional_id->setMask('{nome_formatado}');
        $agenda_profissional_agenda_fl_manipula_atendimento->setBreakItems(2);
        $button_adicionar_agenda_profissional_agenda->setAction(new TAction([$this, 'onAddDetailAgendaProfissionalAgenda'],['static' => 1]), "Adicionar");
        $button_adicionar_agenda_profissional_agenda->addStyleClass('btn-default');
        $button_adicionar_agenda_profissional_agenda->setImage('fas:plus #2ecc71');
        $dias->setLayout('horizontal');
        $publica->setLayout('horizontal');
        $aceita_agendamento_online->setLayout('horizontal');
        $fl_permite_choque_horario->setLayout('horizontal');
        $agenda_profissional_agenda_fl_manipula_atendimento->setLayout('horizontal');

        $dias->setUseButton();
        $publica->setUseButton();
        $aceita_agendamento_online->setUseButton();
        $fl_permite_choque_horario->setUseButton();
        $agenda_profissional_agenda_fl_manipula_atendimento->setUseButton();

        $publica->addItems(["T"=>"Sim","F"=>"Não"]);
        $aceita_agendamento_online->addItems(["T"=>"Sim","F"=>"Não"]);
        $fl_permite_choque_horario->addItems(["T"=>"Sim","F"=>"Não"]);
        $agenda_profissional_agenda_fl_manipula_atendimento->addItems(["T"=>"Sim","F"=>"Não"]);
        $dias->addItems(["1"=>"Segunda","2"=>"Terça","3"=>"Quarta","4"=>"Quinta","5"=>"Sexta","6"=>"Sábado","0"=>"Domingo"]);
        $visualizacao_inicial->addItems(["month"=>"Mês","agendaWeek"=>"Semana","agendaDay"=>"Dia","listWeeky"=>"Agendamentos"]);

        $publica->setValue('F');
        $duracao->setValue('30');
        $horario_final->setValue('18:00');
        $horario_inicial->setValue('08:00');
        $aceita_agendamento_online->setValue('F');
        $visualizacao_inicial->setValue('agendaWeek');
        $clinica_id->setValue(PermissaoService::getUnidadeDefault());
        $agenda_profissional_agenda_fl_manipula_atendimento->setValue('N');

        $id->setSize(100);
        $dias->setSize(150);
        $cor->setSize('100%');
        $nome->setSize('100%');
        $duracao->setSize('100%');
        $publica->setSize('100%');
        $clinica_id->setSize('100%');
        $horario_final->setSize(110);
        $horario_inicial->setSize(110);
        $profissional_id->setSize('100%');
        $procedimento_id->setSize('100%');
        $horario_fim_intervalo->setSize(110);
        $visualizacao_inicial->setSize('100%');
        $horario_inicio_intervalo->setSize(110);
        $aceita_agendamento_online->setSize('100%');
        $fl_permite_choque_horario->setSize('100%');
        $agenda_profissional_agenda_id->setSize(200);
        $agenda_profissional_agenda_profissional_id->setSize('100%');
        $agenda_profissional_agenda_fl_manipula_atendimento->setSize('100%');

        $button_adicionar_agenda_profissional_agenda->id = '611d6c5e6b603';

        $row1 = $this->form->addFields([new TLabel("Código:", null, '14px', null, '100%'),$id],[new TLabel("Clínica:", '#ff0000', '14px', null, '100%'),$clinica_id]);
        $row1->layout = ['col-sm-6','col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$nome],[new TLabel("Profissional:", '#ff0000', '14px', null, '100%'),$profissional_id]);
        $row2->layout = ['col-sm-6',' col-sm-6'];

        $row3 = $this->form->addContent([new TFormSeparator("", '#333', '18', '#eee')]);
        $row4 = $this->form->addFields([new TLabel("Atendimento em:", '#ff0000', '14px', null, '100%'),$dias]);
        $row4->layout = [' col-sm-12'];

        $row5 = $this->form->addFields([new TLabel("Horário de atendimento:", '#ff0000', '14px', null, '100%'),$horario_inicial,new TLabel("até", null, '14px', null),$horario_final],[new TLabel("Intervalo:", null, '14px', null, '100%'),$horario_inicio_intervalo,new TLabel("até", null, '14px', null),$horario_fim_intervalo]);
        $row5->layout = [' col-sm-6',' col-sm-6'];

        $row6 = $this->form->addFields([new TLabel("Duração <small>(minutos)</small>:", '#ff0000', '14px', null, '100%'),$duracao],[new TLabel("Visualização inicial:", '#ff0000', '14px', null, '100%'),$visualizacao_inicial],[new TLabel("Cor:", null, '14px', null, '100%'),$cor]);
        $row6->layout = ['col-sm-4','col-sm-4',' col-sm-4'];

        $row7 = $this->form->addContent([new TFormSeparator("", '#333', '18', '#eee')]);
        $row8 = $this->form->addFields([new TLabel("Procedimento padrão:", null, '14px', null, '100%'),$procedimento_id],[new TLabel("Pública?", null, '14px', null, '100%'),$publica],[new TLabel("Permite agendamento online:", null, '14px', null, '100%'),$aceita_agendamento_online],[new TLabel("Permite choque de horário:", null, '14px', null),$fl_permite_choque_horario,new TLabel("<span style='color: #607D8B;font-size: 11px;font-weight: normal; width:100%;'>Ao marcar que sim, os agendamentos podem ser sobrepostos</span>", null, '14px', null)]);
        $row8->layout = [' col-sm-3','col-sm-3','col-sm-3',' col-sm-3'];

        $this->detailFormAgendaProfissionalAgenda = new BootstrapFormBuilder('detailFormAgendaProfissionalAgenda');
        $this->detailFormAgendaProfissionalAgenda->setProperty('style', 'border:none; box-shadow:none; width:100%;');

        $this->detailFormAgendaProfissionalAgenda->setProperty('class', 'form-horizontal builder-detail-form');

        $row9 = $this->detailFormAgendaProfissionalAgenda->addFields([new TFormSeparator("Profissionais que podem interagir com a agenda", '#333', '18', '#eee')]);
        $row9->layout = [' col-sm-12'];

        $row10 = $this->detailFormAgendaProfissionalAgenda->addFields([new TLabel("Profissional:", '#ff0000', '14px', null, '100%'),$agenda_profissional_agenda_profissional_id,$agenda_profissional_agenda_id],[new TLabel("Pode manipular atendimentos:<br/>", '#FF0000', '14px', null, '100%'),$agenda_profissional_agenda_fl_manipula_atendimento,new TLabel("<span style='color: #607D8B;font-size: 11px;font-weight: normal; width:100%;'>Ao marcar que sim, o profissional poderá inicialiar, acessar e finalizar atendimentos</span>", null, '14px', null)]);
        $row10->layout = [' col-sm-8',' col-sm-4'];

        $row11 = $this->detailFormAgendaProfissionalAgenda->addFields([$button_adicionar_agenda_profissional_agenda]);
        $row11->layout = [' col-sm-12'];

        $row12 = $this->detailFormAgendaProfissionalAgenda->addFields([new THidden('agenda_profissional_agenda__row__id')]);
        $this->agenda_profissional_agenda_criteria = new TCriteria();

        $this->agenda_profissional_agenda_list = new BootstrapDatagridWrapper(new TDataGrid);
        $this->agenda_profissional_agenda_list->generateHiddenFields();
        $this->agenda_profissional_agenda_list->setId('agenda_profissional_agenda_list');

        $this->agenda_profissional_agenda_list->style = 'width:100%';
        $this->agenda_profissional_agenda_list->class .= ' table-bordered';

        $column_agenda_profissional_agenda_profissional_nome = new TDataGridColumn('profissional->nome', "Profissional", 'left');
        $column_agenda_profissional_agenda_fl_manipula_atendimento_transformed = new TDataGridColumn('fl_manipula_atendimento', "Pode manipular atendimentos", 'center');

        $column_agenda_profissional_agenda__row__data = new TDataGridColumn('__row__data', '', 'center');
        $column_agenda_profissional_agenda__row__data->setVisibility(false);

        $action_onEditDetailAgendaProfissional = new TDataGridAction(array('AgendaForm', 'onEditDetailAgendaProfissional'));
        $action_onEditDetailAgendaProfissional->setUseButton(false);
        $action_onEditDetailAgendaProfissional->setButtonClass('btn btn-default btn-sm');
        $action_onEditDetailAgendaProfissional->setLabel("Editar");
        $action_onEditDetailAgendaProfissional->setImage('far:edit #478fca');
        $action_onEditDetailAgendaProfissional->setFields(['__row__id', '__row__data']);

        $this->agenda_profissional_agenda_list->addAction($action_onEditDetailAgendaProfissional);
        $action_onDeleteDetailAgendaProfissional = new TDataGridAction(array('AgendaForm', 'onDeleteDetailAgendaProfissional'));
        $action_onDeleteDetailAgendaProfissional->setUseButton(false);
        $action_onDeleteDetailAgendaProfissional->setButtonClass('btn btn-default btn-sm');
        $action_onDeleteDetailAgendaProfissional->setLabel("Excluir");
        $action_onDeleteDetailAgendaProfissional->setImage('fas:trash-alt #dd5a43');
        $action_onDeleteDetailAgendaProfissional->setFields(['__row__id', '__row__data']);

        $this->agenda_profissional_agenda_list->addAction($action_onDeleteDetailAgendaProfissional);

        $this->agenda_profissional_agenda_list->addColumn($column_agenda_profissional_agenda_profissional_nome);
        $this->agenda_profissional_agenda_list->addColumn($column_agenda_profissional_agenda_fl_manipula_atendimento_transformed);

        $this->agenda_profissional_agenda_list->addColumn($column_agenda_profissional_agenda__row__data);

        $this->agenda_profissional_agenda_list->createModel();
        $this->detailFormAgendaProfissionalAgenda->addContent([$this->agenda_profissional_agenda_list]);

        $column_agenda_profissional_agenda_fl_manipula_atendimento_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            $label = new TElement('span');
            $label->{'class'} = 'label label-';

            if ($value == 'S' || $value == 'T') {
                $label->{'class'} .= 'success';
                $label->add('Sim');    

                return $label;
            }

            $label->{'class'} .= 'danger';
            $label->add('Não');

            return $label;
        });        $row13 = $this->form->addFields([$this->detailFormAgendaProfissionalAgenda]);
        $row13->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave'],['static' => 1]), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['AgendaList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=AgendaForm]');
        $style->width = '70% !important';   
        $style->show(true);

    }

    public static function onChangeClinica($param = null) 
    {
        try 
        {
            if(!empty($param['key']))
            {
                TSession::setValue('clinica_id_agenda_form', $param['key']);
            }
            else
            {
                TSession::setValue('clinica_id_agenda_form', PermissaoService::getUnidadeDefault());
            }

            TMultiSearch::clearField(self::$formName, 'profissional_id');

            if (isset($param['clinica_id']) && $param['clinica_id'])
            { 
                $criteria = TCriteria::create(['clinica_id' => $param['clinica_id']]);
                $filterVar = Grupo::PROFISSIONAL;
                $criteria->add(new TFilter('id', 'in', "(SELECT pessoa_id FROM pessoa_grupo WHERE grupo_id = '{$filterVar}')")); 
                $filterVar = PermissaoService::getUnidadeIds();
                $criteria->add(new TFilter('clinica_id', 'in', $filterVar)); 
                TDBCombo::reloadFromModel(self::$formName, 'profissional_id', 'clinica', 'Pessoa', 'id', '{nome_formatado}', 'nome asc', $criteria, TRUE); 
            } 
            else 
            { 
                TCombo::clearField(self::$formName, 'profissional_id'); 
            }  

            if (isset($param['clinica_id']) && $param['clinica_id'])
            { 
                $criteria = TCriteria::create(['clinica_id' => $param['clinica_id']]);
                $filterVar = "T";
                $criteria->add(new TFilter('ativo', '=', $filterVar)); 
                TDBCombo::reloadFromModel(self::$formName, 'procedimento_id', 'clinica', 'Procedimento', 'id', '{nome}', 'nome asc', $criteria, TRUE); 
            } 
            else 
            { 
                TCombo::clearField(self::$formName, 'procedimento_id'); 
            }  

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public  function onAddDetailAgendaProfissionalAgenda($param = null) 
    {
        try
        {
            $data = $this->form->getData();

            $errors = [];
            $requiredFields = [];
            $requiredFields[] = ['label'=>"Profissional", 'name'=>"agenda_profissional_agenda_profissional_id", 'class'=>'TRequiredValidator', 'value'=>[]];
            $requiredFields[] = ['label'=>"Pode manipular atendimentos", 'name'=>"agenda_profissional_agenda_fl_manipula_atendimento", 'class'=>'TRequiredValidator', 'value'=>[]];
            foreach($requiredFields as $requiredField)
            {
                try
                {
                    (new $requiredField['class'])->validate($requiredField['label'], $data->{$requiredField['name']}, $requiredField['value']);
                }
                catch(Exception $e)
                {
                    $errors[] = $e->getMessage() . '.';
                }
             }
             if(count($errors) > 0)
             {
                 throw new Exception(implode('<br>', $errors));
             }

            $__row__id = !empty($data->agenda_profissional_agenda__row__id) ? $data->agenda_profissional_agenda__row__id : 'b'.uniqid();

            TTransaction::open(self::$database);

            $grid_data = new AgendaProfissional();
            $grid_data->__row__id = $__row__id;
            $grid_data->profissional_id = $data->agenda_profissional_agenda_profissional_id;
            $grid_data->id = $data->agenda_profissional_agenda_id;
            $grid_data->fl_manipula_atendimento = $data->agenda_profissional_agenda_fl_manipula_atendimento;

            $__row__data = array_merge($grid_data->toArray(), (array)$grid_data->getVirtualData());
            $__row__data['__row__id'] = $__row__id;
            $__row__data['__display__']['profissional_id'] =  $param['agenda_profissional_agenda_profissional_id'] ?? null;
            $__row__data['__display__']['id'] =  $param['agenda_profissional_agenda_id'] ?? null;
            $__row__data['__display__']['fl_manipula_atendimento'] =  $param['agenda_profissional_agenda_fl_manipula_atendimento'] ?? null;

            $grid_data->__row__data = base64_encode(serialize((object)$__row__data));
            $row = $this->agenda_profissional_agenda_list->addItem($grid_data);
            $row->id = $grid_data->__row__id;

            TDataGrid::replaceRowById('agenda_profissional_agenda_list', $grid_data->__row__id, $row);

            TTransaction::close();

            $data = new stdClass;
            $data->agenda_profissional_agenda_profissional_id = '';
            $data->agenda_profissional_agenda_id = '';
            $data->agenda_profissional_agenda_fl_manipula_atendimento = 'N';
            $data->agenda_profissional_agenda__row__id = '';

            TForm::sendData(self::$formName, $data);
            TScript::create("
               var element = $('#611d6c5e6b603');
               if(typeof element.attr('add') != 'undefined')
               {
                   element.html(base64_decode(element.attr('add')));
               }
            ");

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }

    public static function onEditDetailAgendaProfissional($param = null) 
    {
        try
        {

            $__row__data = unserialize(base64_decode($param['__row__data']));
            $__row__data->__display__ = is_array($__row__data->__display__) ? (object) $__row__data->__display__ : $__row__data->__display__;
            $fireEvents = true;
            $aggregate = false;

            $data = new stdClass;
            $data->agenda_profissional_agenda_profissional_id = $__row__data->__display__->profissional_id ?? null;
            $data->agenda_profissional_agenda_id = $__row__data->__display__->id ?? null;
            $data->agenda_profissional_agenda_fl_manipula_atendimento = $__row__data->__display__->fl_manipula_atendimento ?? null;
            $data->agenda_profissional_agenda__row__id = $__row__data->__row__id;

            TForm::sendData(self::$formName, $data, $aggregate, $fireEvents);
            TScript::create("
               var element = $('#611d6c5e6b603');
               if(!element.attr('add')){
                   element.attr('add', base64_encode(element.html()));
               }
               element.html(\"<span><i class='far fa-edit' style='color:#478fca;padding-right:4px;'></i>Editar</span>\");
               if(!element.attr('edit')){
                   element.attr('edit', base64_encode(element.html()));
               }
            ");

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }
    public static function onDeleteDetailAgendaProfissional($param = null) 
    {
        try
        {

            $__row__data = unserialize(base64_decode($param['__row__data']));

            $data = new stdClass;
            $data->agenda_profissional_agenda_profissional_id = '';
            $data->agenda_profissional_agenda_id = '';
            $data->agenda_profissional_agenda_fl_manipula_atendimento = '';
            $data->agenda_profissional_agenda__row__id = '';

            TForm::sendData(self::$formName, $data);

            TDataGrid::removeRowById('agenda_profissional_agenda_list', $__row__data->__row__id);
            TScript::create("
               var element = $('#611d6c5e6b603');
               if(typeof element.attr('add') != 'undefined')
               {
                   element.html(base64_decode(element.attr('add')));
               }
            ");

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }
    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Agenda(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $this->fireEvents($object);

            TForm::sendData(self::$formName, (object)['id' => $object->id]);

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            $agenda_profissional_agenda_items = $this->storeMasterDetailItems('AgendaProfissional', 'agenda_id', 'agenda_profissional_agenda', $object, $param['agenda_profissional_agenda_list___row__data'] ?? [], $this->form, $this->agenda_profissional_agenda_list, function($masterObject, $detailObject){ 

                $detailObject->clinica_id = $masterObject->clinica_id;

            }, $this->agenda_profissional_agenda_criteria); 

            if (($data->horario_inicio_intervalo AND empty($data->horario_fim_intervalo)) || (empty($data->horario_inicio_intervalo) AND $data->horario_fim_intervalo))
            {
                throw new Exception('Para preencher um horário de intervalo, é necessário preencher inicio e fim');
            }

            if ($data->horario_inicio_intervalo AND $data->horario_fim_intervalo)
            {
                if ($data->horario_inicio_intervalo >= $data->horario_fim_intervalo)
                {
                    throw new Exception('O inicio do Intervalo deve ser menor que o fim dele');
                }
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('AgendaList', 'onShow', $loadPageParam); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {

            $this->fireEvents($this->form->getData());  

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Agenda($key); // instantiates the Active Record 

                TSession::setValue('clinica_id_agenda_form', $object->clinica_id);

                $agenda_profissional_agenda_items = $this->loadMasterDetailItems('AgendaProfissional', 'agenda_id', 'agenda_profissional_agenda', $object, $this->form, $this->agenda_profissional_agenda_list, $this->agenda_profissional_agenda_criteria, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }); 

                $this->form->setData($object); // fill the form 

                $this->fireEvents($object);

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        TSession::setValue('clinica_id_agenda_form', PermissaoService::getUnidadeDefault());

        TTransaction::open(self::$database);

        $criteria = new TCriteria();
        $criteria->add(new TFilter('clinica_id','=', PermissaoService::getUnidadeDefault()));
        $criteria->add(new TFilter('ativo','=', 'T'));

        $this->form->getField('procedimento_id')->addItems(Procedimento::getIndexedArray('id', '{nome}', $criteria));

        TTransaction::close();

    }

    public function onShow($param = null)
    {

        TSession::setValue('clinica_id_agenda_form', PermissaoService::getUnidadeDefault());

        $procedimento_id = $this->form->getField('procedimento_id');

        TTransaction::open(self::$database);

        $criteria = new TCriteria();
        $criteria->add(new TFilter('clinica_id','=', PermissaoService::getUnidadeDefault()));
        $criteria->add(new TFilter('ativo','=', 'T'));

        $this->form->getField('procedimento_id')->addItems(Procedimento::getIndexedArray('id', '{nome}', $criteria));

        $criteria = new TCriteria();
        $criteria->add(new TFilter('clinica_id','=', PermissaoService::getUnidadeDefault()));
        $filterVar = Grupo::PROFISSIONAL;
        $criteria->add(new TFilter('id', 'in', "(SELECT pessoa_id FROM pessoa_grupo WHERE grupo_id = '{$filterVar}')")); 

        $this->form->getField('profissional_id')->addItems(Pessoa::getIndexedArray('id', '{nome}', $criteria));

        TTransaction::close();

    } 

    public function fireEvents( $object )
    {
        $obj = new stdClass;
        if(is_object($object) && get_class($object) == 'stdClass')
        {
            if(isset($object->clinica_id))
            {
                $value = $object->clinica_id;

                $obj->clinica_id = $value;
            }
            if(isset($object->profissional_id))
            {
                $value = $object->profissional_id;

                $obj->profissional_id = $value;
            }
            if(isset($object->procedimento_id))
            {
                $value = $object->procedimento_id;

                $obj->procedimento_id = $value;
            }
        }
        elseif(is_object($object))
        {
            if(isset($object->clinica_id))
            {
                $value = $object->clinica_id;

                $obj->clinica_id = $value;
            }
            if(isset($object->profissional_id))
            {
                $value = $object->profissional_id;

                $obj->profissional_id = $value;
            }
            if(isset($object->procedimento_id))
            {
                $value = $object->procedimento_id;

                $obj->procedimento_id = $value;
            }
        }
        TForm::sendData(self::$formName, $obj);
    }  

    public static function getFormName()
    {
        return self::$formName;
    }

}

