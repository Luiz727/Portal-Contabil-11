<?php

class SaasCompraViewEtapa4 extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_SaasCompraViewEtapa4';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Compra");

        $criteria_saas_gateway_pagamento_id = new TCriteria();

        $filterVar = "T";
        $criteria_saas_gateway_pagamento_id->add(new TFilter('ativo', '=', $filterVar)); 

        $etapas = new TPageStep();
        $produto = new BElement('div');
        $div_info = new BElement('div');
        $informacao = new BElement('div');
        $saas_gateway_pagamento_id = new TDBRadioGroup('saas_gateway_pagamento_id', 'clinica', 'SaasGatewayPagamento', 'id', '{nome}','nome asc' , $criteria_saas_gateway_pagamento_id );


        $saas_gateway_pagamento_id->setLayout('horizontal');
        $saas_gateway_pagamento_id->setUseButton();
        $produto->setSize('100%');
        $informacao->setSize('100%', 80);
        $div_info->setSize('calc(100% - 50px)');
        $saas_gateway_pagamento_id->setSize('100%');

        $etapas->addItem("Defina o Plano");
        $etapas->addItem("Defina o Valor");
        $etapas->addItem("Informações Fiscais");
        $etapas->addItem("Pagamento");

        $etapas->select("Pagamento");

        $this->etapas = $etapas;
        $this->produto = $produto;
        $this->div_info = $div_info;
        $this->informacao = $informacao;

        $link_termos = SaasConfiguracao::getDefaults()->contrato;

        $termo = new TCheckButton('termo');
        $termo->setIndexValue("T");
        $termo->setInactiveIndexValue("F");
        $termo->setId('termo');
        $termo->style = 'cursor:pointer';

        $div_info->add("
            <label style='cursor:pointer;' for='termo'> 
                {$termo} Li e assino neste ato o contrato da SaaS Meu Sistema na íntegra. Declaro neste momento também, que li as descrições dos produtos na loja antes de realizar a aquisição dos mesmos. 
                <a target='_blank' href='{$link_termos}'> 
                    Clique para ter acesso ao contrato.
                </a> 
            </label>");

        $info = $informacao->add("<b>Finalizar o Pagamento com:</b>");
        $informacao->style = 'text-align: center; font-size: 18px;';

        $row1 = $this->form->addFields([$etapas]);
        $row1->layout = [' col-sm-12'];

        $row2 = $this->form->addFields([],[new TFormSeparator("Confirmação & Pagamento", '#333', '19', '#eee')]);
        $row2->layout = [' col-sm-2',' col-sm-8'];

        $row3 = $this->form->addFields([],[$produto]);
        $row3->layout = [' col-sm-2',' col-sm-8'];

        $row4 = $this->form->addFields([],[$div_info]);
        $row4->layout = [' col-sm-2',' col-sm-8','col-sm-2'];

        $row5 = $this->form->addFields([],[new TFormSeparator("", '#333', '18', '#eee')]);
        $row5->layout = [' col-sm-2',' col-sm-8','col-sm-2'];

        $row6 = $this->form->addFields([],[$informacao]);
        $row6->layout = [' col-sm-2',' col-sm-8','col-sm-2'];

        $row7 = $this->form->addFields([],[$saas_gateway_pagamento_id]);
        $row7->layout = [' col-sm-2',' col-sm-8','col-sm-2'];

        $row2->style = 'text-align: center;';    

        $this->form->addField($termo);

        // create the form actions
        $btn_onshow = $this->form->addAction("Voltar", new TAction(['SaasCompraViewEtapa3', 'onShow']), 'fas:arrow-alt-circle-left #000000');
        $this->btn_onshow = $btn_onshow;

        $avancar = $this->form->addAction("Avançar", new TAction([$this, 'onNext'],['static' => 1]), 'fas:arrow-alt-circle-right #ffffff');
        $this->avancar = $avancar;
        $avancar->addStyleClass('btn-primary'); 

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        }
        $container->add($this->form);

        parent::add($container);

    }

    public function onNext($param = null) 
    {
        try
        {
            TTransaction::open(MAIN_DATABASE);

            $data = $this->form->getData();
            $dataCarrinho = TSession::getValue('saas_carrinho_compras');

            if (empty($data->termo) || $data->termo == 'F')
            {
                throw new Exception("Aceite os termos para continuar com a compra");
            }

            if (empty($data->saas_gateway_pagamento_id))
            {
                throw new Exception("Selecione a forma de pagamento");
            }

            $gateway = SaasGatewayPagamento::find($data->saas_gateway_pagamento_id);
            $plano_valor = SaasPlanoValor::find($dataCarrinho->saas_plano_valor_id);

            // caso queira trabalhar com recorrencia mercado pago usando checkout transparente
            // precisa ter este if habilitado
            if($gateway->id == SaasGatewayPagamento::MERCADO_PAGO && $plano_valor->recorrencia == 'T')
            {
                $dataCarrinho->etapa4 = $data;

                TSession::setValue('saas_carrinho_compras', $dataCarrinho);

                // enviamos usuário para checkout transparente
                TApplication::loadPage('SaasCompraViewEtapa5', 'onShow');
            }
            else
            {
                $contratoAntigo = null;
                $contrato = new SaasContrato;

                if($dataCarrinho->renovar && TSession::getValue('contrato_id'))
                {
                    $contratoAntigo = new SaasContrato(TSession::getValue('contrato_id'));
                }

                $contrato->account_id = TSession::getValue('account_id');
                $contrato->saas_plano_valor_id = $dataCarrinho->saas_plano_valor_id;
                $contrato->saas_contrato_status_id = SaasContratoStatus::AGUARDANDO_PAGAMENTO;
                $contrato->valor_total = $plano_valor->valor;
                $contrato->duracao_renovacao = $plano_valor->duracao;
                $contrato->data_inicial = date('Y-m-d');
                $contrato->data_final = date('Y-m-d', strtotime("+{$plano_valor->duracao} month"));    

                if($dataCarrinho->renovar)
                {
                    $contrato->data_inicial = $contratoAntigo->data_final;

                    $dataInicial = new DateTime($contrato->data_inicial);
                    $dataInicial->modify("+{$plano_valor->duracao} months");

                    $contrato->data_final = $dataInicial->format('Y-m-d');
                    $contrato->renovacao = 'T';
                }

                $contrato->store();

                $pagamento = SaasPagamentoService::createByContrato($contrato, $gateway);

                TApplication::loadPage('SaasMinhaContaDashboard', 'onShow');
                TSession::delValue('saas_carrinho_compras');
                TPage::openPage($pagamento->link_gateway);
            }

            TTransaction::close();
        }
        catch (Exception $e)
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());
        }
    }

    public function onShow($param = null)
    {               

        try
        {
            TTransaction::open(MAIN_DATABASE);

            $contrato = SaasContrato::find(TSession::getValue('contrato_id'));
            $data = TSession::getValue(__CLASS__.'_form_data') ?? new stdClass;
            $data->saas_plano_id = $data->saas_plano_id ?? $contrato->saas_plano->id;
            $data->saas_plano_valor_id = $data->saas_plano_valor_id ?? $contrato->saas_plano_valor_id;
            $data->current_step = $param['current_step'] ?? 1;
            $data->step = $param['step'] ?? 1;
            $this->form->setData($data);

            $this->produto->add($this->getProduto());

            TTransaction::close();
        }
        catch (Exception $e)
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());
        }
    } 

    public function getProduto()
    {
        try
        {
            TTransaction::open(MAIN_DATABASE);

            $data = TSession::getValue('saas_carrinho_compras') ?? false;

            $plano = new TElement('div');
            $categoria = new TElement('div');
            $valor = new TElement('div');

            if($data && !empty($data->saas_plano_id) && !empty($data->saas_plano_valor_id))
            {
                $saas_plano = SaasPlano::find($data->saas_plano_id);
                $saas_plano_valor = SaasPlanoValor::find($data->saas_plano_valor_id);

                $plano->add(TElement::tag('small', 'Plano'));
                $plano->add(TElement::tag('b', $saas_plano->nome));

                $categoria->add(TElement::tag('small', 'Categoria'));
                $categoria->add(TElement::tag('b', $saas_plano_valor->nome));

                $valor->add(TElement::tag('small', 'Valor'));
                $valor->add(TElement::tag('b', $saas_plano_valor->valor_f));
            }

            $div = new TElement('div');
            $div->class = 'compra-produto';
            $div->add($plano);
            $div->add($categoria);
            $div->add($valor);

            TTransaction::close();

            return $div;
        }
        catch (Exception $e)
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());
        }
    }

}

