<?php

class SaasCompraViewEtapa5 extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_SaasCompraViewEtapa5';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Etapa 5 de compra");


        $pageStep_672422110ebc1 = new TPageStep();
        $numero_cartao = new TEntry('numero_cartao');
        $titular = new TEntry('titular');
        $validade = new TEntry('validade');
        $cvv = new TEntry('cvv');
        $card_wrapper = new BElement('div');
        $tipo_documento = new TCombo('tipo_documento');
        $documento = new TEntry('documento');
        $email = new TEntry('email');
        $card_assinatura = new BElement('div');
        $banco = new TCombo('banco');
        $parcelas = new TCombo('parcelas');
        $card_token = new TEntry('card_token');


        $banco->enableSearch();
        $parcelas->enableSearch();

        $cvv->setMask('9999');
        $validade->setMask('99/99');
        $documento->setMask('999999999999999');
        $numero_cartao->setMask('9999999999999999');

        $email->setSize('100%');
        $banco->setSize('100%');
        $titular->setSize('100%');
        $validade->setSize('100%');
        $parcelas->setSize('100%');
        $documento->setSize('100%');
        $card_token->setSize('100%');
        $numero_cartao->setSize('100%');
        $tipo_documento->setSize('100%');
        $cvv->setSize('calc(100% - 10px)');
        $card_wrapper->setSize('100%', 220);
        $card_assinatura->setSize('100%', 80);

        $cvv->id = 'cvv';
        $email->id = 'email';
        $banco->id = 'banco';
        $titular->id = 'titular';
        $validade->id = 'validade';
        $parcelas->id = 'parcelas';
        $documento->id = 'documento';
        $banco->style = "display:none";
        $card_token->id = 'card_token';
        $parcelas->style = "display:none";
        $card_wrapper->id = 'card-wrapper';
        $card_token->style = "display:none";
        $numero_cartao->id = 'numero_cartao';
        $tipo_documento->id = 'tipo_documento';

        $pageStep_672422110ebc1->addItem("Defina o Plano");
        $pageStep_672422110ebc1->addItem("Defina o Valor");
        $pageStep_672422110ebc1->addItem("informações Fiscais");
        $pageStep_672422110ebc1->addItem("Pagamento");

        $pageStep_672422110ebc1->select("Pagamento");

        $this->pageStep_672422110ebc1 = $pageStep_672422110ebc1;
        $this->card_wrapper = $card_wrapper;
        $this->card_assinatura = $card_assinatura;

        $cvv->setId('cvv');
        $email->setId('email');
        $banco->setId('banco');
        $titular->setId('titular');
        $validade->setId('validade');
        $parcelas->setId('parcelas');
        $documento->setId('documento');
        $card_token->setId('card_token');
        $numero_cartao->setId('numero_cartao');
        $tipo_documento->setId('tipo_documento');

        $creditCardPreview = new THtmlRenderer('app/resources/credit_card_preview.html');
        $creditCardPreview->enableSection('main');

        $card_wrapper->add($creditCardPreview);

        $card_assinatura_pagamento = new THtmlRenderer('app/resources/card_assinatura_pagamento.html');

        TTransaction::open(MAIN_DATABASE);

        $dataCarrinho = TSession::getValue('saas_carrinho_compras');

        $data = $dataCarrinho->etapa4;

        $plano_valor = SaasPlanoValor::find($dataCarrinho->saas_plano_valor_id);

        $card_assinatura_pagamento->enableSection('main', [
            'plano' => $plano_valor->nome,
            'valor' => $plano_valor->valor_formatado
        ]);

        $mercadoPago = new SaasGatewayPagamento(SaasGatewayPagamento::MERCADO_PAGO);

        TTransaction::close();

        $card_assinatura->add($card_assinatura_pagamento);

        $row1 = $this->form->addFields([$pageStep_672422110ebc1]);
        $row1->layout = [' col-sm-12'];

        $row2 = $this->form->addFields([],[new TFormSeparator("Pagamento & Assinatura", '#333', '18', '#eee')]);
        $row2->layout = [' col-sm-2',' col-sm-8'];

        $bcontainer_672549a0496de = new BootstrapFormBuilder('bcontainer_672549a0496de');
        $this->bcontainer_672549a0496de = $bcontainer_672549a0496de;
        $bcontainer_672549a0496de->setProperty('style', 'border:none; box-shadow:none;');
        $row3 = $bcontainer_672549a0496de->addFields([new TLabel("Número do Cartão", null, '14px', null, '100%'),$numero_cartao]);
        $row3->layout = [' col-sm-12'];

        $row4 = $bcontainer_672549a0496de->addFields([new TLabel("Nome do Titular", null, '14px', null, '100%'),$titular]);
        $row4->layout = [' col-sm-12'];

        $row5 = $bcontainer_672549a0496de->addFields([new TLabel("Validade", null, '14px', null, '100%'),$validade],[new TLabel("CVV", null, '14px', null, '100%'),$cvv]);
        $row5->layout = [' col-sm-6',' col-sm-6'];

        $row6 = $this->form->addFields([$bcontainer_672549a0496de],[$card_wrapper]);
        $row6->layout = [' col-sm-6',' col-sm-6'];

        $row7 = $this->form->addContent([new TFormSeparator("", '#333', '18', '#eee')]);

        $bcontainer_67254a6c496ea = new BootstrapFormBuilder('bcontainer_67254a6c496ea');
        $this->bcontainer_67254a6c496ea = $bcontainer_67254a6c496ea;
        $bcontainer_67254a6c496ea->setProperty('style', 'border:none; box-shadow:none;');
        $row8 = $bcontainer_67254a6c496ea->addFields([new TLabel("Tipo do documento:", null, '14px', null, '100%'),$tipo_documento]);
        $row8->layout = [' col-sm-12'];

        $row9 = $bcontainer_67254a6c496ea->addFields([new TLabel("Documento:", null, '14px', null, '100%'),$documento]);
        $row9->layout = [' col-sm-12'];

        $row10 = $bcontainer_67254a6c496ea->addFields([new TLabel("Email:", null, '14px', null, '100%'),$email]);
        $row10->layout = [' col-sm-12'];

        $row11 = $this->form->addFields([$bcontainer_67254a6c496ea],[$card_assinatura]);
        $row11->layout = ['col-sm-6',' col-sm-6'];

        $row12 = $this->form->addFields([$banco,$parcelas,$card_token]);
        $row12->layout = ['col-sm-6'];

        $row2->style = 'text-align: center;';
        $row12->style = 'display:none !important;';

        // create the form actions
        $btnFinalizar = $this->form->addAction("CONFIRMAR PAGAMENTO & ASSINATURA", new TAction([$this, 'onFinalizar']), ' #ffffff');
        $this->btnFinalizar = $btnFinalizar;
        $btnFinalizar->addStyleClass('btn-primary'); 

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Minha Conta","Compra etapa 5"]));
        }
        $container->add($this->form);

        $btnFinalizar->onclick = '';
        $btnFinalizar->id = 'btn-finalizar';

        // documentação do checkout transparente para obter o card token
        // https://www.mercadopago.com.br/developers/pt/docs/checkout-api/integration-configuration/card/integrate-via-cardform

        $container->add(TScript::create("Sistema.loadScript('https://sdk.mercadopago.com/js/v2', function(){ Sistema.initMercadoPago('{$mercadoPago->public_key}');})", false));

        parent::add($container);

    }

    public static function onFinalizar($param = null) 
    {
        try
        {
            if(!$param['card_token'])
            {
                throw new Exception('Ocorreu um erro, verifique os dados informados');
            }

            TTransaction::open(MAIN_DATABASE);

            $dataCarrinho = TSession::getValue('saas_carrinho_compras');

            $data = $dataCarrinho->etapa4;

            $gateway = SaasGatewayPagamento::find($data->saas_gateway_pagamento_id);
            $plano_valor = SaasPlanoValor::find($dataCarrinho->saas_plano_valor_id);

            $contratoAntigo = null;
            $contrato = new SaasContrato;

            if($dataCarrinho->renovar && TSession::getValue('contrato_id'))
            {
                $contratoAntigo = new SaasContrato(TSession::getValue('contrato_id'));
            }

            $contrato->account_id = TSession::getValue('account_id');
            $contrato->saas_plano_valor_id = $dataCarrinho->saas_plano_valor_id;
            $contrato->saas_contrato_status_id = SaasContratoStatus::AGUARDANDO_PAGAMENTO;
            $contrato->valor_total = $plano_valor->valor;
            $contrato->duracao_renovacao = $plano_valor->duracao;
            $contrato->data_inicial = date('Y-m-d');
            $contrato->data_final = date('Y-m-d', strtotime("+{$plano_valor->duracao} month"));    

            if($dataCarrinho->renovar)
            {
                $contrato->data_inicial = $contratoAntigo->data_final;

                $dataInicial = new DateTime($contrato->data_inicial);
                $dataInicial->modify("+{$plano_valor->duracao} months");

                $contrato->data_final = $dataInicial->format('Y-m-d');
                $contrato->renovacao = 'T';
            }

            $contrato->store();

            $pagamento = SaasPagamentoService::createByContrato($contrato, $gateway, $param['card_token']);

            TSession::delValue('saas_carrinho_compras');

            TTransaction::close();

            new TMessage('info', 'Assinatura criada com sucesso, estamos aguardando o MercadoPago Confirmar se deu tudo certo.', new TAction(['SaasMinhaContaDashboard', 'onShow']));

        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
        }
    }

    public function onShow($param = null)
    {               

    } 

}

