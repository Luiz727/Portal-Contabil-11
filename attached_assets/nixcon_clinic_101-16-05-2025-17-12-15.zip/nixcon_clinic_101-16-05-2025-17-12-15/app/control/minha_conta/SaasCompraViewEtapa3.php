<?php

class SaasCompraViewEtapa3 extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_SaasCompraViewEtapa3';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Informações Fiscais");

        $criteria_cidade_id = new TCriteria();

        $etapas = new TPageStep();
        $tipo_pessoa = new TRadioGroup('tipo_pessoa');
        $razao_social = new TEntry('razao_social');
        $nome_responsavel = new TEntry('nome_responsavel');
        $documento = new TEntry('documento');
        $email = new TEntry('email');
        $telefone = new TEntry('telefone');
        $cep = new TEntry('cep');
        $cidade_id = new TDBUniqueSearch('cidade_id', 'clinica', 'Cidade', 'id', 'nome','nome asc' , $criteria_cidade_id );
        $bairro = new TEntry('bairro');
        $rua = new TEntry('rua');
        $numero = new TEntry('numero');
        $complemento = new TEntry('complemento');

        $cep->setExitAction(new TAction([$this,'onChangeCep']));

        $tipo_pessoa->addItems(["F"=>"Física","J"=>"Jurídica"]);
        $tipo_pessoa->setLayout('horizontal');
        $tipo_pessoa->setValue('F');
        $tipo_pessoa->setUseButton();
        $email->setEditable(false);
        $cidade_id->setMinLength(2);
        $cep->setMask('99.999-999');
        $telefone->setMask('(99) 9 9999-9999');
        $cidade_id->setMask('{nome} - {estado->sigla}');

        $cep->setSize('100%');
        $rua->setSize('100%');
        $email->setSize('100%');
        $bairro->setSize('100%');
        $numero->setSize('100%');
        $tipo_pessoa->setSize(150);
        $telefone->setSize('100%');
        $documento->setSize('100%');
        $cidade_id->setSize('100%');
        $complemento->setSize('100%');
        $razao_social->setSize('100%');
        $nome_responsavel->setSize('100%');

        $etapas->addItem("Defina o Plano");
        $etapas->addItem("Defina o Valor");
        $etapas->addItem("Informações Fiscais");
        $etapas->addItem("Pagamento");

        $etapas->select("Informações Fiscais");

        $this->etapas = $etapas;

        $row1 = $this->form->addFields([$etapas]);
        $row1->layout = [' col-sm-12'];

        $row2 = $this->form->addFields([new TFormSeparator("Informações Fiscais", '#333', '16', '#eee')],[new TLabel("Tipo:", null, '14px', null, '100%'),$tipo_pessoa],[new TLabel("Nome:", null, '14px', null),$razao_social],[new TLabel("Responsável:", null, '14px', null, '100%'),$nome_responsavel],[new TLabel("Documento:", null, '14px', null),$documento],[new TLabel("E-mail:", null, '14px', null),$email],[new TLabel("Telefone:", null, '14px', null),$telefone],[],[new TFormSeparator("Endereço", '#333', '16', '#eee')],[new TLabel("CEP:", null, '14px', null),$cep],[new TLabel("Cidade:", null, '14px', null),$cidade_id],[new TLabel("Bairro:", null, '14px', null),$bairro],[new TLabel("Rua:", null, '14px', null),$rua],[new TLabel("Número:", null, '14px', null),$numero],[new TLabel("Complemento:", null, '14px', null),$complemento]);
        $row2->layout = ['col-sm-12',' col-sm-12','col-sm-6','col-sm-6','col-sm-4','col-sm-4','col-sm-4','col-sm-12','col-sm-12','col-sm-4','col-sm-8','col-sm-4','col-sm-8','col-sm-4','col-sm-8'];

        // create the form actions
        $btn_onshow = $this->form->addAction("Voltar", new TAction(['SaasCompraViewEtapa2', 'onShow']), 'fas:arrow-alt-circle-left #000000');
        $this->btn_onshow = $btn_onshow;

        $avancar = $this->form->addAction("Avançar", new TAction([$this, 'onNext'],['static' => 1]), 'fas:arrow-alt-circle-right #ffffff');
        $this->avancar = $avancar;
        $avancar->addStyleClass('btn-primary'); 

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        }
        $container->add($this->form);

        parent::add($container);

    }

    public static function onChangeCep($param = null) 
    {
        try 
        {
            TTransaction::open(MAIN_DATABASE);

            if (! empty($param['cep']))
            {
                $cep = CEPService::get($param['cep']);

                $data = new stdClass;
                $data->cidade_id = $cep->cidade_id;
                $data->cidade = $cep->cidade;
                $data->bairro = $cep->bairro;
                $data->rua = $cep->rua;

                TForm::sendData(self::$formName, $data);
            }
            TTransaction::close(); 

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onNext($param = null) 
    {
        try
        {
            TTransaction::open(MAIN_DATABASE);

            $data = $this->form->getData();

            (new TRequiredValidator)->validate('Razão social', $data->razao_social);
            (new TRequiredValidator)->validate('Responsável', $data->nome_responsavel);
            (new TRequiredValidator)->validate('CNPJ', $data->documento);
            (new TRequiredValidator)->validate('E-mail', $data->email);
            (new TRequiredValidator)->validate('Telefone', $data->telefone);
            (new TRequiredValidator)->validate('Rua', $data->rua);
            (new TRequiredValidator)->validate('Bairro', $data->bairro);
            (new TRequiredValidator)->validate('Número', $data->numero);
            (new TRequiredValidator)->validate('Cidade', $data->cidade_id);

            $account = Account::find(AccountService::getId());

            if(!$account)
            {
                throw new Exception('Permissão negada!');
            }

            $account->cidade_id = $data->cidade_id;
            $account->nome_responsavel = $data->nome_responsavel;
            $account->razao_social = $data->razao_social;
            $account->documento = $data->documento;
            // $account->email = $data->email;
            $account->telefone = $data->telefone;
            $account->cep = $data->cep;
            $account->rua = $data->rua;
            $account->numero = $data->numero;
            $account->complemento = $data->complemento;
            $account->bairro = $data->bairro;
            $account->tipo_pessoa = $data->tipo_pessoa;
            $account->store();

            $dataCarrinho = TSession::getValue('saas_carrinho_compras');
            $dataCarrinho = (object) array_merge((array) $data, (array)  $dataCarrinho);

            TSession::setValue('saas_carrinho_compras', $dataCarrinho);

            TTransaction::close();

            TApplication::loadPage('SaasCompraViewEtapa4', 'onShow');

        }
        catch (Exception $e)
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());
        }
    }

    public function onShow($param = null)
    {               

        try
        {
            TTransaction::open(MAIN_DATABASE);

            $contrato = SaasContrato::find(TSession::getValue('contrato_id'));
            $data = TSession::getValue('saas_carrinho_compras') ?? new stdClass;

            $account = Account::find(AccountService::getId());

            if($account)
            {
                $this->form->setData($account);    
            }

            TTransaction::close();
        }
        catch (Exception $e)
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());
        }
    } 

}

