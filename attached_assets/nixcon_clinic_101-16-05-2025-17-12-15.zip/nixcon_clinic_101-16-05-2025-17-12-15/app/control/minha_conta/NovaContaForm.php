<?php

class NovaContaForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Account';
    private static $primaryKey = 'id';
    private static $formName = 'form_NovaContaForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Nova Conta");


        $email = new TEntry('email');
        $nome_responsavel = new TEntry('nome_responsavel');
        $telefone = new TEntry('telefone');
        $tipo_pessoa = new TRadioGroup('tipo_pessoa');
        $label_documento_pessoa = new TLabel("CNPJ:", null, '16px', null, '100%');
        $documento = new TEntry('documento');
        $label_nome_pessoa = new TLabel("Razão social:", null, '16px', null, '100%');
        $razao_social = new TEntry('razao_social');
        $nome_clinica = new TEntry('nome_clinica');
        $senha = new TPassword('senha');
        $confirmar_senha = new TPassword('confirmar_senha');
        $informacao = new BElement('div');

        $email->addValidation("Email", new TRequiredValidator()); 
        $nome_responsavel->addValidation("Nome", new TRequiredValidator()); 
        $telefone->addValidation("Telefone", new TRequiredValidator()); 
        $senha->addValidation("Senha", new TRequiredValidator()); 
        $confirmar_senha->addValidation("Confirmar a senha", new TRequiredValidator()); 

        $tipo_pessoa->addItems(["F"=>" Pessoa Física","J"=>" Pessoa Jurídica"]);
        $tipo_pessoa->setLayout('horizontal');
        $tipo_pessoa->setValue('J');
        $tipo_pessoa->setUseButton();
        $razao_social->setTip("Minha empresa ltda.");
        $telefone->setMask('(99) 9999-99999', true);
        $documento->setMask('99.999.999/9999-99', true);

        $label_nome_pessoa->setId("label_nome_pessoa");
        $label_documento_pessoa->setId("label_documento_pessoa");

        $email->setSize('100%');
        $senha->setSize('100%');
        $telefone->setSize('100%');
        $documento->setSize('100%');
        $tipo_pessoa->setSize('100%');
        $razao_social->setSize('100%');
        $nome_clinica->setSize('100%');
        $informacao->setSize('100%', 80);
        $confirmar_senha->setSize('100%');
        $nome_responsavel->setSize('100%');

        $documento->id = 'documento_pessoa';
        $email->placeholder = "nome@minhaempresa.com";
        $nome_responsavel->placeholder = "informe o seu nome";

        $this->informacao = $informacao;

        $documento->setId('documento_pessoa');
        $tipo_pessoa->setChangeFunction("Sistema.changeTipoPessoa(this);");

        $link_termos = SaasConfiguracao::getDefaults()->termo_uso;

        $termo = new TCheckButton('termo');
        $termo->setIndexValue("T");
        $termo->setInactiveIndexValue("F");
        $termo->setId('termo');
        $termo->style = 'cursor:pointer';

        $this->form->addField($termo);

        $this->informacao->add("<label style='cursor:pointer;' for='termo'> {$termo} Li e aceito os termos de uso do Sistema na íntegra. <a target='_blank' href='{$link_termos}'> Clique aqui para ler os termos de uso.</a> </label>");

        $row1 = $this->form->addFields([new TLabel("Email:", null, '16px', null, '100%'),$email,new TLabel("O email informado será utilizado como login no sistema", null, '11px', null)]);
        $row1->layout = [' col-sm-12'];

        $row2 = $this->form->addFields([new TLabel("Nome responsável:", null, '16px', null, '100%'),$nome_responsavel,new TLabel("Pessoa responsável pelo acesso admin do sistema", null, '11px', null)],[new TLabel("Telefone:", null, '16px', null, '100%'),$telefone]);
        $row2->layout = ['col-sm-6',' col-sm-6'];

        $row3 = $this->form->addContent([new TFormSeparator("", '#333', '18', '#eee')]);
        $row4 = $this->form->addFields([new TLabel("Tipo de cadastro:", null, '16px', null, '100%'),$tipo_pessoa],[]);
        $row4->layout = ['col-sm-6',' col-sm-6'];

        $row5 = $this->form->addFields([$label_documento_pessoa,$documento],[$label_nome_pessoa,$razao_social]);
        $row5->layout = ['col-sm-6',' col-sm-6'];

        $row6 = $this->form->addFields([new TLabel("Nome da clínica/unidade:", null, '14px', null),$nome_clinica,new TLabel("Será criada uma clínica/unidade teste", null, '11px', null)]);
        $row6->layout = [' col-sm-12'];

        $row7 = $this->form->addFields([new TLabel("Senha:", null, '16px', null, '100%'),$senha],[new TLabel("Confirmar senha:", null, '16px', null),$confirmar_senha]);
        $row7->layout = ['col-sm-6',' col-sm-6'];

        $row8 = $this->form->addFields([$informacao]);
        $row8->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("COMEÇAR O TESTE AGORA", new TAction([$this, 'onSave'],['static' => 1]), ' #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btnnovacontalogin'); 

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        }
        $container->add($this->form);

        $container->add('<div style="text-align:center;"> <a href="login" class="btn btn-link btnJaTemConta"><i class="fas fa-sign-in-alt"></i> Já tem conta? Faça login</a> </div>');

        parent::add($container);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $data = $this->form->getData(); // get form data as array

            if($data->termo != 'T')
            {
                throw new Exception('Para criar sua conta é necessário aceitar os termos de uso. ');
            }

            if($data->tipo_pessoa == 'F')
            {
                $this->form->getField('documento')->addValidation("CPF", new TRequiredValidator());
                $this->form->getField('razao_social')->addValidation("Nome", new TRequiredValidator());
            }
            else
            {
                $this->form->getField('documento')->addValidation("CNPJ", new TRequiredValidator());
                $this->form->getField('razao_social')->addValidation("Razão social", new TRequiredValidator());
            }

            $this->form->validate(); // validate form data

            $object = new Account(); // create an empty object 

            $object->mes_criacao = date('m');
            $object->ano_criacao = date('Y');

            if($data->senha != $data->confirmar_senha)
            {
                throw new Exception('As senhas informadas não conferem');
            }

            $data->email = trim($data->email);

            if(Account::where('email', '=', $data->email)->first())
            {
                throw new Exception('Já existe uma conta criada com o email informado!');
            }

            if(SystemUsers::where('login', '=', $data->email)->first())
            {
                throw new Exception('Já existe uma conta criada com o email informado!');
            }

            if(empty($data->nome_clinica))
            {
                throw new Exception('É necessário informar um nome de clínica para usar o sistema!');
            }
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $object->senha = $data->senha;

            $empresa = new StdClass;
            $empresa->nome = $data->nome_clinica ?? "Clínica trial"; 

            $usuario = AccountService::start($object, $empresa);

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            new TMessage('info', "Conta Criada com SUCESSO!", $messageAction); 

            TTransaction::open(self::$database);

            TSession::regenerate();
            ApplicationAuthenticationService::loadSessionVars($usuario);

            TTransaction::close();

            TScript::create('location.href = "index.php?class=SaasMinhaContaDashboard&method=onShow"');

            SaasEmailTemplateService::enviarBoasVindas($object->email, $object->nome_responsavel);

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage().$e->getTraceAsString()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Account($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

