<?php

class ProfissionalForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Pessoa';
    private static $primaryKey = 'id';
    private static $formName = 'form_Pessoa';

    use BuilderMasterDetailTrait;
    use Adianti\Base\AdiantiFileSaveTrait;
    use BuilderMasterDetailFieldListTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de profissional");

        $criteria_clinica_id = new TCriteria();
        $criteria_tratamento = new TCriteria();
        $criteria_pessoa_endereco_pessoa_cidade_id = new TCriteria();
        $criteria_system_users_id = new TCriteria();
        $criteria_pessoa_especialidade_pessoa_especialidade_id = new TCriteria();

        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_clinica_id->add(new TFilter('id', 'in', $filterVar)); 
        $filterVar = "{session.clinica_id_profissional_form}";
        $criteria_system_users_id->add(new TFilter('id', 'in', "(SELECT system_user_id FROM system_user_unit WHERE system_unit_id = '{$filterVar}')")); 
        $filterVar = PermissaoService::getAccountId();
        $criteria_system_users_id->add(new TFilter('account_id', '=', $filterVar)); 
        $filterVar = "{session.clinica_id_profissional_form}";
        $criteria_pessoa_especialidade_pessoa_especialidade_id->add(new TFilter('clinica_id', '=', $filterVar)); 

        // echo $criteria_system_users_id->dump();
        // var_dump(TSession::getValue('clinica_id_profissional_form'));

        $id = new TEntry('id');
        $clinica_id = new TDBCombo('clinica_id', 'clinica', 'Clinica', 'id', '{nome}','nome asc' , $criteria_clinica_id );
        $nome = new TEntry('nome');
        $assinatura = new TFile('assinatura');
        $documento = new TEntry('documento');
        $dt_nascimento = new TDate('dt_nascimento');
        $sexo = new TRadioGroup('sexo');
        $nome_civel = new TEntry('nome_civel');
        $rg = new TEntry('rg');
        $foto = new TImageCropper('foto');
        $telefone = new TEntry('telefone');
        $email = new TEntry('email');
        $tratamento = new TDBEntry('tratamento', 'clinica', 'Pessoa', 'tratamento','tratamento asc' , $criteria_tratamento );
        $profissao = new TEntry('profissao');
        $observacao = new THtmlEditor('observacao');
        $pessoa_endereco_pessoa_cep = new TEntry('pessoa_endereco_pessoa_cep');
        $button_buscar_pessoa_endereco_pessoa = new TButton('button_buscar_pessoa_endereco_pessoa');
        $pessoa_endereco_pessoa_id = new THidden('pessoa_endereco_pessoa_id');
        $pessoa_endereco_pessoa_cidade_id = new TDBUniqueSearch('pessoa_endereco_pessoa_cidade_id', 'clinica', 'Cidade', 'id', 'nome','nome asc' , $criteria_pessoa_endereco_pessoa_cidade_id );
        $pessoa_endereco_pessoa_bairro = new TEntry('pessoa_endereco_pessoa_bairro');
        $pessoa_endereco_pessoa_rua = new TEntry('pessoa_endereco_pessoa_rua');
        $pessoa_endereco_pessoa_numero = new TEntry('pessoa_endereco_pessoa_numero');
        $pessoa_endereco_pessoa_complemento = new TEntry('pessoa_endereco_pessoa_complemento');
        $button_adicionar_pessoa_endereco_pessoa = new TButton('button_adicionar_pessoa_endereco_pessoa');
        $system_users_id = new TDBUniqueSearch('system_users_id', 'clinica', 'SystemUsers', 'id', 'name','name asc' , $criteria_system_users_id );
        $pessoa_especialidade_pessoa_id = new THidden('pessoa_especialidade_pessoa_id[]');
        $pessoa_especialidade_pessoa___row__id = new THidden('pessoa_especialidade_pessoa___row__id[]');
        $pessoa_especialidade_pessoa___row__data = new THidden('pessoa_especialidade_pessoa___row__data[]');
        $pessoa_especialidade_pessoa_especialidade_id = new TDBUniqueSearch('pessoa_especialidade_pessoa_especialidade_id[]', 'clinica', 'Especialidade', 'id', 'descricao','descricao asc' , $criteria_pessoa_especialidade_pessoa_especialidade_id );
        $this->fieldList_62d07079690f0 = new TFieldList();

        $this->fieldList_62d07079690f0->addField(null, $pessoa_especialidade_pessoa_id, []);
        $this->fieldList_62d07079690f0->addField(null, $pessoa_especialidade_pessoa___row__id, ['uniqid' => true]);
        $this->fieldList_62d07079690f0->addField(null, $pessoa_especialidade_pessoa___row__data, []);
        $this->fieldList_62d07079690f0->addField(new TLabel("Especialidade:", null, '14px', null), $pessoa_especialidade_pessoa_especialidade_id, ['width' => '100%']);

        $this->fieldList_62d07079690f0->width = '100%';
        $this->fieldList_62d07079690f0->setFieldPrefix('pessoa_especialidade_pessoa');
        $this->fieldList_62d07079690f0->name = 'fieldList_62d07079690f0';

        $this->criteria_fieldList_62d07079690f0 = new TCriteria();
        $this->default_item_fieldList_62d07079690f0 = new stdClass();

        $this->form->addField($pessoa_especialidade_pessoa_id);
        $this->form->addField($pessoa_especialidade_pessoa___row__id);
        $this->form->addField($pessoa_especialidade_pessoa___row__data);
        $this->form->addField($pessoa_especialidade_pessoa_especialidade_id);

        $this->fieldList_62d07079690f0->setRemoveAction(null, 'fas:times #dd5a43', "Excluír");

        $clinica_id->setChangeAction(new TAction([$this,'onChangeClinica']));

        $clinica_id->addValidation("Clínica", new TRequiredValidator()); 
        $nome->addValidation("Nome", new TRequiredValidator()); 
        $documento->addValidation("CPF", new TRequiredValidator()); 
        $dt_nascimento->addValidation("Data nascimento", new TRequiredValidator()); 
        $sexo->addValidation("Sexo biológico", new TRequiredValidator()); 
        $system_users_id->addValidation("Usuário do sistema", new TRequiredValidator()); 

        $id->setEditable(false);
        $clinica_id->setValue(PermissaoService::getUnidadeDefault());
        $clinica_id->enableSearch();
        $dt_nascimento->setDatabaseMask('yyyy-mm-dd');
        $sexo->addItems(["M"=>"Masculino","F"=>"Feminino"]);
        $sexo->setLayout('horizontal');
        $sexo->setUseButton();
        $foto->setAllowedExtensions(["jpg","jpeg","png","gif"]);
        $foto->setImagePlaceholder(new TImage("fas:camera #dde5ec"));
        $tratamento->setDisplayMask('{tratamento}');
        $nome->setTip("Nome documento");
        $nome_civel->setTip("Nome social");

        $foto->enableFileHandling();
        $assinatura->enableFileHandling();

        $button_buscar_pessoa_endereco_pessoa->setAction(new TAction([$this, 'onChangeCEP'],['static' => 1]), "Buscar");
        $button_adicionar_pessoa_endereco_pessoa->setAction(new TAction([$this, 'onAddDetailPessoaEnderecoPessoa'],['static' => 1]), "Adicionar");

        $button_buscar_pessoa_endereco_pessoa->addStyleClass('btn-default');
        $button_adicionar_pessoa_endereco_pessoa->addStyleClass('btn-default');

        $button_buscar_pessoa_endereco_pessoa->setImage('fas:search #2196F3');
        $button_adicionar_pessoa_endereco_pessoa->setImage('fas:plus #2ecc71');

        $system_users_id->setMinLength(0);
        $pessoa_endereco_pessoa_cidade_id->setMinLength(1);
        $pessoa_especialidade_pessoa_especialidade_id->setMinLength(0);

        $system_users_id->setMask('{name}');
        $documento->setMask('999.999.999-99');
        $dt_nascimento->setMask('dd/mm/yyyy');
        $telefone->setMask('(99) 9 9999-9999');
        $pessoa_endereco_pessoa_cep->setMask('99.999-999');
        $pessoa_especialidade_pessoa_especialidade_id->setMask('{descricao}');
        $pessoa_endereco_pessoa_cidade_id->setMask('{nome} - {estado->sigla}');

        $nome->setMaxLength(255);
        $email->setMaxLength(255);
        $telefone->setMaxLength(20);
        $documento->setMaxLength(255);
        $pessoa_endereco_pessoa_cep->setMaxLength(8);
        $pessoa_endereco_pessoa_rua->setMaxLength(500);
        $pessoa_endereco_pessoa_bairro->setMaxLength(500);
        $pessoa_endereco_pessoa_numero->setMaxLength(100);
        $pessoa_endereco_pessoa_complemento->setMaxLength(500);

        $id->setSize(100);
        $rg->setSize('100%');
        $nome->setSize('100%');
        $sexo->setSize('100%');
        $email->setSize('100%');
        $telefone->setSize('100%');
        $documento->setSize('100%');
        $foto->setSize('100%', 200);
        $profissao->setSize('100%');
        $clinica_id->setSize('100%');
        $assinatura->setSize('100%');
        $nome_civel->setSize('100%');
        $tratamento->setSize('100%');
        $dt_nascimento->setSize('100%');
        $observacao->setSize('100%', 110);
        $system_users_id->setSize('100%');
        $pessoa_endereco_pessoa_id->setSize(200);
        $pessoa_endereco_pessoa_rua->setSize('100%');
        $pessoa_endereco_pessoa_bairro->setSize('100%');
        $pessoa_endereco_pessoa_numero->setSize('100%');
        $pessoa_endereco_pessoa_cidade_id->setSize('100%');
        $pessoa_endereco_pessoa_complemento->setSize('100%');
        $pessoa_endereco_pessoa_cep->setSize('calc(100% - 120px)');
        $pessoa_especialidade_pessoa_especialidade_id->setSize('100%');

        $button_adicionar_pessoa_endereco_pessoa->id = '60f6c58143f89';

        $email->addValidation("E-mail", new TEmailValidator()); 

        $this->form->appendPage("Dados cadastrais");

        $this->form->addFields([new THidden('current_tab')]);
        $this->form->setTabFunction("$('[name=current_tab]').val($(this).attr('data-current_page'));");

        $row1 = $this->form->addFields([new TLabel("Código:", null, '14px', null, '100%'),$id],[new TLabel("Clínica:", '#FF0000', '14px', null, '100%'),$clinica_id]);
        $row1->layout = ['col-sm-6',' col-sm-6'];

        $bcontainer_62d5b3609a876 = new BootstrapFormBuilder('bcontainer_62d5b3609a876');
        $this->bcontainer_62d5b3609a876 = $bcontainer_62d5b3609a876;
        $bcontainer_62d5b3609a876->setProperty('style', 'border:none; box-shadow:none;');
        $row2 = $bcontainer_62d5b3609a876->addFields([new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$nome]);
        $row2->layout = [' col-sm-12'];

        $row3 = $bcontainer_62d5b3609a876->addFields([new TLabel("Assinatura para documentos:", null, '14px', null),$assinatura],[new TLabel("CPF:", '#ff0000', '14px', null, '100%'),$documento]);
        $row3->layout = [' col-sm-6',' col-sm-6'];

        $row4 = $bcontainer_62d5b3609a876->addFields([new TLabel("Data nascimento:", '#ff0000', '14px', null, '100%'),$dt_nascimento],[new TLabel("Sexo biológico:", '#ff0000', '14px', null, '100%'),$sexo],[new TLabel("Nome cível:", null, '14px', null, '100%'),$nome_civel],[new TLabel("RG:", null, '14px', null, '100%'),$rg]);
        $row4->layout = ['col-sm-3','col-sm-3',' col-sm-3',' col-sm-3'];

        $row5 = $this->form->addFields([$bcontainer_62d5b3609a876],[$foto]);
        $row5->layout = ['col-sm-9',' col-sm-3'];

        $row6 = $this->form->addFields([new TLabel("Telefone:", null, '14px', null, '100%'),$telefone],[new TLabel("Email:", null, '14px', null, '100%'),$email],[new TLabel("Tratamento:", null, '14px', null, '100%'),$tratamento],[new TLabel("Profissão:", null, '14px', null, '100%'),$profissao]);
        $row6->layout = ['col-sm-3','col-sm-3',' col-sm-3',' col-sm-3'];

        $row7 = $this->form->addFields([new TLabel("Observação:", null, '14px', null, '100%'),$observacao]);
        $row7->layout = [' col-sm-12'];

        $this->form->appendPage("Endereços");

        $this->detailFormPessoaEnderecoPessoa = new BootstrapFormBuilder('detailFormPessoaEnderecoPessoa');
        $this->detailFormPessoaEnderecoPessoa->setProperty('style', 'border:none; box-shadow:none; width:100%;');

        $this->detailFormPessoaEnderecoPessoa->setProperty('class', 'form-horizontal builder-detail-form');

        $row8 = $this->detailFormPessoaEnderecoPessoa->addFields([new TLabel("CEP:", '#ff0000', '14px', null, '100%'),$pessoa_endereco_pessoa_cep,$button_buscar_pessoa_endereco_pessoa,$pessoa_endereco_pessoa_id],[new TLabel("Cidade:", '#ff0000', '14px', null, '100%'),$pessoa_endereco_pessoa_cidade_id]);
        $row8->layout = [' col-sm-4',' col-sm-8'];

        $row9 = $this->detailFormPessoaEnderecoPessoa->addFields([new TLabel("Bairro:", '#ff0000', '14px', null, '100%'),$pessoa_endereco_pessoa_bairro],[new TLabel("Rua:", '#ff0000', '14px', null, '100%'),$pessoa_endereco_pessoa_rua]);
        $row9->layout = [' col-sm-4',' col-sm-8'];

        $row10 = $this->detailFormPessoaEnderecoPessoa->addFields([new TLabel("Número:", '#ff0000', '14px', null, '100%'),$pessoa_endereco_pessoa_numero],[new TLabel("Complemento:", null, '14px', null, '100%'),$pessoa_endereco_pessoa_complemento]);
        $row10->layout = [' col-sm-4',' col-sm-8'];

        $row11 = $this->detailFormPessoaEnderecoPessoa->addFields([$button_adicionar_pessoa_endereco_pessoa]);
        $row11->layout = [' col-sm-12'];

        $row12 = $this->detailFormPessoaEnderecoPessoa->addFields([new THidden('pessoa_endereco_pessoa__row__id')]);
        $this->pessoa_endereco_pessoa_criteria = new TCriteria();

        $this->pessoa_endereco_pessoa_list = new BootstrapDatagridWrapper(new TDataGrid);
        $this->pessoa_endereco_pessoa_list->generateHiddenFields();
        $this->pessoa_endereco_pessoa_list->setId('pessoa_endereco_pessoa_list');
        $this->pessoa_endereco_pessoa_list->datatable = 'true';

        $this->pessoa_endereco_pessoa_list->style = 'width:100%';
        $this->pessoa_endereco_pessoa_list->class .= ' table-bordered';

        $column_pessoa_endereco_pessoa_cidade_nome = new TDataGridColumn('cidade->nome', "Cidade", 'left');
        $column_pessoa_endereco_pessoa_cep = new TDataGridColumn('cep', "CEP", 'left');
        $column_pessoa_endereco_pessoa_rua = new TDataGridColumn('rua', "Rua", 'left');
        $column_pessoa_endereco_pessoa_bairro = new TDataGridColumn('bairro', "Bairro", 'left');
        $column_pessoa_endereco_pessoa_numero = new TDataGridColumn('numero', "Número", 'left');
        $column_pessoa_endereco_pessoa_complemento = new TDataGridColumn('complemento', "Complemento", 'left');

        $column_pessoa_endereco_pessoa__row__data = new TDataGridColumn('__row__data', '', 'center');
        $column_pessoa_endereco_pessoa__row__data->setVisibility(false);

        $action_onEditDetailPessoaEndereco = new TDataGridAction(array('ProfissionalForm', 'onEditDetailPessoaEndereco'));
        $action_onEditDetailPessoaEndereco->setUseButton(false);
        $action_onEditDetailPessoaEndereco->setButtonClass('btn btn-default btn-sm');
        $action_onEditDetailPessoaEndereco->setLabel("Editar");
        $action_onEditDetailPessoaEndereco->setImage('far:edit #478fca');
        $action_onEditDetailPessoaEndereco->setFields(['__row__id', '__row__data']);

        $this->pessoa_endereco_pessoa_list->addAction($action_onEditDetailPessoaEndereco);
        $action_onDeleteDetailPessoaEndereco = new TDataGridAction(array('ProfissionalForm', 'onDeleteDetailPessoaEndereco'));
        $action_onDeleteDetailPessoaEndereco->setUseButton(false);
        $action_onDeleteDetailPessoaEndereco->setButtonClass('btn btn-default btn-sm');
        $action_onDeleteDetailPessoaEndereco->setLabel("Excluir");
        $action_onDeleteDetailPessoaEndereco->setImage('fas:trash-alt #dd5a43');
        $action_onDeleteDetailPessoaEndereco->setFields(['__row__id', '__row__data']);

        $this->pessoa_endereco_pessoa_list->addAction($action_onDeleteDetailPessoaEndereco);

        $this->pessoa_endereco_pessoa_list->addColumn($column_pessoa_endereco_pessoa_cidade_nome);
        $this->pessoa_endereco_pessoa_list->addColumn($column_pessoa_endereco_pessoa_cep);
        $this->pessoa_endereco_pessoa_list->addColumn($column_pessoa_endereco_pessoa_rua);
        $this->pessoa_endereco_pessoa_list->addColumn($column_pessoa_endereco_pessoa_bairro);
        $this->pessoa_endereco_pessoa_list->addColumn($column_pessoa_endereco_pessoa_numero);
        $this->pessoa_endereco_pessoa_list->addColumn($column_pessoa_endereco_pessoa_complemento);

        $this->pessoa_endereco_pessoa_list->addColumn($column_pessoa_endereco_pessoa__row__data);

        $this->pessoa_endereco_pessoa_list->createModel();
        $this->detailFormPessoaEnderecoPessoa->addContent([$this->pessoa_endereco_pessoa_list]);
        $row13 = $this->form->addFields([$this->detailFormPessoaEnderecoPessoa]);
        $row13->layout = [' col-sm-12'];

        $this->form->appendPage("Perfil");
        $row14 = $this->form->addFields([new TLabel("Usuário do sistema:", '#FF0000', '14px', null, '100%'),$system_users_id]);
        $row14->layout = [' col-sm-12'];

        $this->form->appendPage("Especialidades");
        $row15 = $this->form->addFields([$this->fieldList_62d07079690f0]);
        $row15->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave'],['static' => 1]), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['ProfissionalList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=ProfissionalForm]');
        $style->width = '70% !important';   
        $style->show(true);

    }

    public static function onChangeClinica($param = null) 
    {
        try 
        {
            if(!empty($param['key']))
            {
                TSession::setValue('clinica_id_profissional_form', $param['key']);
            }
            else
            {
                TSession::setValue('clinica_id_profissional_form', PermissaoService::getUnidadeDefault());
            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onChangeCEP($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);
            $dadosCEP = CEPService::get($param['pessoa_endereco_pessoa_cep']);
            TTransaction::close();

            if($dadosCEP)
            {
                $data = new stdClass;
                $data->pessoa_endereco_pessoa_cidade_id = $dadosCEP->cidade_id;
                $data->pessoa_endereco_pessoa_bairro = $dadosCEP->bairro;
                $data->pessoa_endereco_pessoa_rua = $dadosCEP->rua;

                TForm::sendData(self::$formName, $data);    
            }

        }
        catch (Exception $e) 
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());    
        }
    }

    public  function onAddDetailPessoaEnderecoPessoa($param = null) 
    {
        try
        {
            $data = $this->form->getData();

            $errors = [];
            $requiredFields = [];
            $requiredFields[] = ['label'=>"CEP", 'name'=>"pessoa_endereco_pessoa_cep", 'class'=>'TRequiredValidator', 'value'=>[]];
            $requiredFields[] = ['label'=>"Cidade", 'name'=>"pessoa_endereco_pessoa_cidade_id", 'class'=>'TRequiredValidator', 'value'=>[]];
            $requiredFields[] = ['label'=>"Bairro", 'name'=>"pessoa_endereco_pessoa_bairro", 'class'=>'TRequiredValidator', 'value'=>[]];
            $requiredFields[] = ['label'=>"Rua", 'name'=>"pessoa_endereco_pessoa_rua", 'class'=>'TRequiredValidator', 'value'=>[]];
            $requiredFields[] = ['label'=>"Número", 'name'=>"pessoa_endereco_pessoa_numero", 'class'=>'TRequiredValidator', 'value'=>[]];
            foreach($requiredFields as $requiredField)
            {
                try
                {
                    (new $requiredField['class'])->validate($requiredField['label'], $data->{$requiredField['name']}, $requiredField['value']);
                }
                catch(Exception $e)
                {
                    $errors[] = $e->getMessage() . '.';
                }
             }
             if(count($errors) > 0)
             {
                 throw new Exception(implode('<br>', $errors));
             }

            $__row__id = !empty($data->pessoa_endereco_pessoa__row__id) ? $data->pessoa_endereco_pessoa__row__id : 'b'.uniqid();

            TTransaction::open(self::$database);

            $grid_data = new PessoaEndereco();
            $grid_data->__row__id = $__row__id;
            $grid_data->cep = $data->pessoa_endereco_pessoa_cep;
            $grid_data->id = $data->pessoa_endereco_pessoa_id;
            $grid_data->cidade_id = $data->pessoa_endereco_pessoa_cidade_id;
            $grid_data->bairro = $data->pessoa_endereco_pessoa_bairro;
            $grid_data->rua = $data->pessoa_endereco_pessoa_rua;
            $grid_data->numero = $data->pessoa_endereco_pessoa_numero;
            $grid_data->complemento = $data->pessoa_endereco_pessoa_complemento;

            $__row__data = array_merge($grid_data->toArray(), (array)$grid_data->getVirtualData());
            $__row__data['__row__id'] = $__row__id;
            $__row__data['__display__']['cep'] =  $param['pessoa_endereco_pessoa_cep'] ?? null;
            $__row__data['__display__']['id'] =  $param['pessoa_endereco_pessoa_id'] ?? null;
            $__row__data['__display__']['cidade_id'] =  $param['pessoa_endereco_pessoa_cidade_id'] ?? null;
            $__row__data['__display__']['bairro'] =  $param['pessoa_endereco_pessoa_bairro'] ?? null;
            $__row__data['__display__']['rua'] =  $param['pessoa_endereco_pessoa_rua'] ?? null;
            $__row__data['__display__']['numero'] =  $param['pessoa_endereco_pessoa_numero'] ?? null;
            $__row__data['__display__']['complemento'] =  $param['pessoa_endereco_pessoa_complemento'] ?? null;

            $grid_data->__row__data = base64_encode(serialize((object)$__row__data));
            $row = $this->pessoa_endereco_pessoa_list->addItem($grid_data);
            $row->id = $grid_data->__row__id;

            TDataGrid::replaceRowById('pessoa_endereco_pessoa_list', $grid_data->__row__id, $row);

            TTransaction::close();

            $data = new stdClass;
            $data->pessoa_endereco_pessoa_cep = '';
            $data->pessoa_endereco_pessoa_id = '';
            $data->pessoa_endereco_pessoa_cidade_id = '';
            $data->pessoa_endereco_pessoa_bairro = '';
            $data->pessoa_endereco_pessoa_rua = '';
            $data->pessoa_endereco_pessoa_numero = '';
            $data->pessoa_endereco_pessoa_complemento = '';
            $data->pessoa_endereco_pessoa__row__id = '';

            TForm::sendData(self::$formName, $data);
            TScript::create("
               var element = $('#60f6c58143f89');
               if(typeof element.attr('add') != 'undefined')
               {
                   element.html(base64_decode(element.attr('add')));
               }
            ");

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }

    public static function onEditDetailPessoaEndereco($param = null) 
    {
        try
        {

            $__row__data = unserialize(base64_decode($param['__row__data']));
            $__row__data->__display__ = is_array($__row__data->__display__) ? (object) $__row__data->__display__ : $__row__data->__display__;
            $fireEvents = true;
            $aggregate = false;

            $data = new stdClass;
            $data->pessoa_endereco_pessoa_cep = $__row__data->__display__->cep ?? null;
            $data->pessoa_endereco_pessoa_id = $__row__data->__display__->id ?? null;
            $data->pessoa_endereco_pessoa_cidade_id = $__row__data->__display__->cidade_id ?? null;
            $data->pessoa_endereco_pessoa_bairro = $__row__data->__display__->bairro ?? null;
            $data->pessoa_endereco_pessoa_rua = $__row__data->__display__->rua ?? null;
            $data->pessoa_endereco_pessoa_numero = $__row__data->__display__->numero ?? null;
            $data->pessoa_endereco_pessoa_complemento = $__row__data->__display__->complemento ?? null;
            $data->pessoa_endereco_pessoa__row__id = $__row__data->__row__id;

            TForm::sendData(self::$formName, $data, $aggregate, $fireEvents);
            TScript::create("
               var element = $('#60f6c58143f89');
               if(!element.attr('add')){
                   element.attr('add', base64_encode(element.html()));
               }
               element.html(\"<span><i class='far fa-edit' style='color:#478fca;padding-right:4px;'></i>Editar</span>\");
               if(!element.attr('edit')){
                   element.attr('edit', base64_encode(element.html()));
               }
            ");

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }
    public static function onDeleteDetailPessoaEndereco($param = null) 
    {
        try
        {

            $__row__data = unserialize(base64_decode($param['__row__data']));

            $data = new stdClass;
            $data->pessoa_endereco_pessoa_cep = '';
            $data->pessoa_endereco_pessoa_id = '';
            $data->pessoa_endereco_pessoa_cidade_id = '';
            $data->pessoa_endereco_pessoa_bairro = '';
            $data->pessoa_endereco_pessoa_rua = '';
            $data->pessoa_endereco_pessoa_numero = '';
            $data->pessoa_endereco_pessoa_complemento = '';
            $data->pessoa_endereco_pessoa__row__id = '';

            TForm::sendData(self::$formName, $data);

            TDataGrid::removeRowById('pessoa_endereco_pessoa_list', $__row__data->__row__id);
            TScript::create("
               var element = $('#60f6c58143f89');
               if(typeof element.attr('add') != 'undefined')
               {
                   element.html(base64_decode(element.attr('add')));
               }
            ");

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }
    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Pessoa(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $assinatura_dir = 'app/profissional/assinatura';
            $foto_dir = 'fotos';  

            $object->store(); // save the object 

            $this->saveFile($object, $data, 'assinatura', $assinatura_dir);
            $this->saveFile($object, $data, 'foto', $foto_dir);
            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

//<generatedAutoCode>
            $this->criteria_fieldList_62d07079690f0->setProperty('order', 'id asc');
//</generatedAutoCode>
            $pessoa_especialidade_pessoa_items = $this->storeItems('PessoaEspecialidade', 'pessoa_id', $object, $this->fieldList_62d07079690f0, function($masterObject, $detailObject){ 

                //code here

            }, $this->criteria_fieldList_62d07079690f0); 

            $pessoa_endereco_pessoa_items = $this->storeMasterDetailItems('PessoaEndereco', 'pessoa_id', 'pessoa_endereco_pessoa', $object, $param['pessoa_endereco_pessoa_list___row__data'] ?? [], $this->form, $this->pessoa_endereco_pessoa_list, function($masterObject, $detailObject){ 

                //code here

            }, $this->pessoa_endereco_pessoa_criteria); 

            $object->deleteComposite('PessoaGrupo', 'pessoa_id', $object->id);

            $pessoaGrupo = new PessoaGrupo();
            $pessoaGrupo->pessoa_id = $object->id;
            $pessoaGrupo->grupo_id = Grupo::PROFISSIONAL;
            $pessoaGrupo->store();

            if ($object->system_users_id)
            {
                $criteria = new TCriteria;
                $criteria->add(new TFilter('system_users_id', '=', $object->system_users_id));
                $criteria->add(new TFilter('id', '!=', $object->id));

                $hasSystemUser = Pessoa::countObjects($criteria);

                if ($hasSystemUser)
                {
                    throw new Exception('Já existe uma pessoa vinculado com o usuário do sistema informado');
                }
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('ProfissionalList', 'onShow', $loadPageParam); 

                        TScript::create("Template.closeRightPanel();");
            TForm::sendData(self::$formName, (object)['id' => $object->id]);

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Pessoa($key); // instantiates the Active Record 

                TSession::setValue('clinica_id_profissional_form', $object->clinica_id);

                $this->criteria_fieldList_62d07079690f0->setProperty('order', 'id asc');
                $this->fieldList_62d07079690f0_items = $this->loadItems('PessoaEspecialidade', 'pessoa_id', $object, $this->fieldList_62d07079690f0, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }, $this->criteria_fieldList_62d07079690f0); 

                $pessoa_endereco_pessoa_items = $this->loadMasterDetailItems('PessoaEndereco', 'pessoa_id', 'pessoa_endereco_pessoa', $object, $this->form, $this->pessoa_endereco_pessoa_list, $this->pessoa_endereco_pessoa_criteria, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }); 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        $this->fieldList_62d07079690f0->addHeader();
        $this->fieldList_62d07079690f0->addDetail($this->default_item_fieldList_62d07079690f0);

        $this->fieldList_62d07079690f0->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        TSession::setValue('clinica_id_profissional_form', PermissaoService::getUnidadeDefault());

    }

    public function onShow($param = null)
    {
        $this->fieldList_62d07079690f0->addHeader();
        $this->fieldList_62d07079690f0->addDetail($this->default_item_fieldList_62d07079690f0);

        $this->fieldList_62d07079690f0->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        TSession::setValue('clinica_id_profissional_form', PermissaoService::getUnidadeDefault());

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

