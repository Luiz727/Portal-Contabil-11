<?php

class ProntuarioPacienteFormView extends TPage
{
    protected $form; // form
    private static $database = 'clinica';
    private static $activeRecord = 'Pessoa';
    private static $primaryKey = 'id';
    private static $formName = 'formView_Pessoa';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        TTransaction::open(self::$database);
        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        $this->form->setTagName('div');

        $pessoa = new Pessoa($param['key']);
        // define the form title
        $this->form->setFormTitle("Prontuário do paciente");

        $transformed_pessoa_sexo = call_user_func(function($value, $object, $row)
        {
            if ($value == 'M') {
                return 'Masculino';
            }

            return 'Feminino';

        }, $pessoa->sexo, $pessoa, null);

        $criteria = new TCriteria;
        $criteria->add(new TFilter('ativo', '=', 'S'));
        $tipos = Formulario::getIndexedArray('id', 'nome', $criteria);
        $tipos_formularios = '<span style="font-weight: normal">Formulários disponíveis:</span><br/>' . implode(', ', $tipos);

        $atendimentos = Atendimento::where('paciente_id',  '=', $param['key'])
                      ->orderBy('id')
                      ->getIndexedArray('id', 'id');

        if(!$atendimentos)
        {
            $atendimentos = [-1];
        }

        $label1 = new TLabel("Código:", '', '14px', 'B', '100%');
        $text1 = new TTextDisplay($pessoa->id, '', '18px', '');
        $label3 = new TLabel("Nome:", '', '14px', 'B', '100%');
        $text3 = new TTextDisplay($pessoa->nome, '', '18px', '');
        $label4 = new TLabel("CPF:", '', '14px', 'B', '100%');
        $text4 = new TTextDisplay($pessoa->documento, '', '18px', '');
        $label5 = new TLabel("Email:", '', '14px', 'B', '100%');
        $text5 = new TTextDisplay($pessoa->email, '', '18px', '');
        $label11 = new TLabel("Data nascimento:", '', '14px', 'B', '100%');
        $text11 = new TTextDisplay(TDate::convertToMask($pessoa->dt_nascimento, 'yyyy-mm-dd', 'dd/mm/yyyy'), '', '18px', '');
        $label6 = new TLabel("Telefone:", '', '14px', 'B', '100%');
        $text6 = new TTextDisplay($pessoa->telefone, '', '18px', '');
        $label12 = new TLabel("Profissão:", '', '14px', 'B', '100%');
        $text12 = new TTextDisplay($pessoa->profissao, '', '18px', '');
        $label8 = new TLabel("Sexo biológico:", '', '14px', 'B', '100%');
        $text8 = new TTextDisplay($transformed_pessoa_sexo, '', '18px', '');
        $label10 = new TLabel("RG:", '', '14px', 'B', '100%');
        $text10 = new TTextDisplay($pessoa->rg, '', '18px', '');
        $label_tratamento = new TLabel("Data do cadastro:", '', '14px', 'B', '100%');
        $text_tratamento = new TTextDisplay($pessoa->tratamento, '', '18px', '');
        $bpage_atendimentos = new BPageContainer();
        $bpage_exames = new BPageContainer();
        $bpage_materiais = new BPageContainer();
        $bpage_anexos = new BPageContainer();
        $bpage_documentos = new BPageContainer();
        $bpage_prescricoes = new BPageContainer();
        $label2 = new TLabel("{$tipos_formularios}", '', '12px', '');
        $bpage_formulario = new BPageContainer();

        $bpage_exames->setSize('100%');
        $bpage_anexos->setSize('100%');
        $bpage_materiais->setSize('100%');
        $bpage_documentos->setSize('100%');
        $bpage_formulario->setSize('100%');
        $bpage_prescricoes->setSize('100%');
        $bpage_atendimentos->setSize('100%');

        $bpage_anexos->setAction(new TAction(['AnexoSimpleList', 'onShow'], ['paciente_id' => $pessoa->id]));
        $bpage_prescricoes->setAction(new TAction(['PrescricaoSimpleList', 'onShow'], ['paciente_id' => $pessoa->id]));
        $bpage_exames->setAction(new TAction(['ExameAtendimentoSimpleList', 'onShow'], ['paciente_id' => $pessoa->id]));
        $bpage_atendimentos->setAction(new TAction(['AtendimentoSimpleList', 'onShow'], ['paciente_id' => $pessoa->id]));
        $bpage_documentos->setAction(new TAction(['MeusDocumentoPacienteList', 'onShow'], ['paciente_id' => $pessoa->id]));
        $bpage_materiais->setAction(new TAction(['AtendimentoMaterialSimpleList', 'onShow'], ['paciente_id' => $pessoa->id]));
        $bpage_formulario->setAction(new TAction(['RespostaFormularioSimpleList', 'onShow'], ['paciente_id' => $pessoa->id]));

        $bpage_exames->setId('b66c012787b5b0');
        $bpage_anexos->setId('b66c2212ace0ed');
        $bpage_materiais->setId('b66c0d3ec0ac9f');
        $bpage_documentos->setId('b66c223dcd09b3');
        $bpage_formulario->setId('b66c228a786f6b');
        $bpage_prescricoes->setId('b66c2242428ca8');
        $bpage_atendimentos->setId('b66c00f70e54ca');

        $loadingContainer = new TElement('div');
        $loadingContainer->style = 'text-align:center; padding:50px';

        $icon = new TElement('i');
        $icon->class = 'fas fa-spinner fa-spin fa-3x';

        $loadingContainer->add($icon);
        $loadingContainer->add('<br>Carregando');

        $bpage_atendimentos->add($loadingContainer);
        $loadingContainer = new TElement('div');
        $loadingContainer->style = 'text-align:center; padding:50px';

        $icon = new TElement('i');
        $icon->class = 'fas fa-spinner fa-spin fa-3x';

        $loadingContainer->add($icon);
        $loadingContainer->add('<br>Carregando');

        $bpage_exames->add($loadingContainer);
        $loadingContainer = new TElement('div');
        $loadingContainer->style = 'text-align:center; padding:50px';

        $icon = new TElement('i');
        $icon->class = 'fas fa-spinner fa-spin fa-3x';

        $loadingContainer->add($icon);
        $loadingContainer->add('<br>Carregando');

        $bpage_materiais->add($loadingContainer);
        $loadingContainer = new TElement('div');
        $loadingContainer->style = 'text-align:center; padding:50px';

        $icon = new TElement('i');
        $icon->class = 'fas fa-spinner fa-spin fa-3x';

        $loadingContainer->add($icon);
        $loadingContainer->add('<br>Carregando');

        $bpage_anexos->add($loadingContainer);
        $loadingContainer = new TElement('div');
        $loadingContainer->style = 'text-align:center; padding:50px';

        $icon = new TElement('i');
        $icon->class = 'fas fa-spinner fa-spin fa-3x';

        $loadingContainer->add($icon);
        $loadingContainer->add('<br>Carregando');

        $bpage_documentos->add($loadingContainer);
        $loadingContainer = new TElement('div');
        $loadingContainer->style = 'text-align:center; padding:50px';

        $icon = new TElement('i');
        $icon->class = 'fas fa-spinner fa-spin fa-3x';

        $loadingContainer->add($icon);
        $loadingContainer->add('<br>Carregando');

        $bpage_prescricoes->add($loadingContainer);
        $loadingContainer = new TElement('div');
        $loadingContainer->style = 'text-align:center; padding:50px';

        $icon = new TElement('i');
        $icon->class = 'fas fa-spinner fa-spin fa-3x';

        $loadingContainer->add($icon);
        $loadingContainer->add('<br>Carregando');

        $bpage_formulario->add($loadingContainer);


        $row1 = $this->form->addFields([$label1,$text1],[$label3,$text3],[$label4,$text4],[$label5,$text5]);
        $row1->layout = [' col-sm-2',' col-sm-4',' col-sm-3',' col-sm-3'];

        $row2 = $this->form->addFields([$label11,$text11],[$label6,$text6],[$label12,$text12],[$label8,$text8],[$label10,$text10],[$label_tratamento,$text_tratamento]);
        $row2->layout = [' col-sm-2',' col-sm-2',' col-sm-2','col-sm-2','col-sm-2','col-sm-2'];

        $row3 = $this->form->addContent([new TFormSeparator("", '#333', '18', '#eee')]);

        $Atendimentos = new BootstrapFormBuilder('Atendimentos');
        $this->Atendimentos = $Atendimentos;
        $Atendimentos->setProperty('style', 'border:none; box-shadow:none;');

        $Atendimentos->appendPage("Atendimentos");

        $Atendimentos->addFields([new THidden('current_tab_Atendimentos')]);
        $Atendimentos->setTabFunction("$('[name=current_tab_Atendimentos]').val($(this).attr('data-current_page'));");

        $row4 = $Atendimentos->addFields([$bpage_atendimentos]);
        $row4->layout = [' col-sm-12'];

        $Atendimentos->appendPage("Exames");
        $row5 = $Atendimentos->addFields([$bpage_exames]);
        $row5->layout = [' col-sm-12'];

        $Atendimentos->appendPage("Materiais");
        $row6 = $Atendimentos->addFields([$bpage_materiais]);
        $row6->layout = [' col-sm-12'];

        $Atendimentos->appendPage("Anexos");
        $row7 = $Atendimentos->addFields([$bpage_anexos]);
        $row7->layout = [' col-sm-12'];

        $Atendimentos->appendPage("Documentos/Laudos");
        $row8 = $Atendimentos->addFields([$bpage_documentos]);
        $row8->layout = [' col-sm-12'];

        $Atendimentos->appendPage("Prescrições");
        $row9 = $Atendimentos->addFields([$bpage_prescricoes]);
        $row9->layout = [' col-sm-12'];

        $Atendimentos->appendPage("Formulários");
        $row10 = $Atendimentos->addFields([$label2]);
        $row10->layout = [' col-sm-12'];

        $row11 = $Atendimentos->addFields([$bpage_formulario]);
        $row11->layout = [' col-sm-12'];

        $row12 = $this->form->addFields([$Atendimentos]);
        $row12->layout = [' col-sm-12'];

        if(!empty($param['current_tab']))
        {
            $this->form->setCurrentPage($param['current_tab']);
        }

        if(!empty($param['current_tab_Atendimentos']))
        {
            $this->Atendimentos->setCurrentPage($param['current_tab_Atendimentos']);
        }

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        TTransaction::close();
        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=ProntuarioPacienteFormView]');
        $style->width = '80% !important';   
        $style->show(true);

    }

    public function onShow($param = null)
    {     

    }

}

