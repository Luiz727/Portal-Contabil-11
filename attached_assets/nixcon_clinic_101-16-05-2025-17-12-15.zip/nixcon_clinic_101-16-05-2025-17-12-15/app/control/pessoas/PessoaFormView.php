<?php

class PessoaFormView extends TPage
{
    protected $form; // form
    private static $database = 'clinica';
    private static $activeRecord = 'Pessoa';
    private static $primaryKey = 'id';
    private static $formName = 'formView_Pessoa';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        TTransaction::open(self::$database);
        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        $this->form->setTagName('div');

        $pessoa = new Pessoa($param['key']);
        // define the form title
        $this->form->setFormTitle("Consulta");

        $transformed_pessoa_sexo = call_user_func(function($value, $object, $row)
        {
            if ($value == 'M') {
                return 'Masculino';
            }

            return 'Feminino';

        }, $pessoa->sexo, $pessoa, null);

        $label2 = new TLabel("Código:", '', '14px', 'B', '100%');
        $text1 = new TTextDisplay($pessoa->id, '', '16px', '');
        $label4 = new TLabel("Nome:", '', '14px', 'B', '100%');
        $text2 = new TTextDisplay($pessoa->nome_formatado, '', '16px', '');
        $image2 = new TImage($pessoa->foto);
        $label61 = new TLabel("CPF:", '', '14px', 'B', '100%');
        $text3 = new TTextDisplay($pessoa->documento, '', '16px', '');
        $label8 = new TLabel("E-mail:", '', '14px', 'B', '100%');
        $text4 = new TTextDisplay($pessoa->email, '', '16px', '');
        $label101 = new TLabel("Telefone:", '', '14px', 'B', '100%');
        $text5 = new TTextDisplay($pessoa->telefone, '', '16px', '');
        $label16 = new TLabel("Data nascimento:", '', '14px', 'B', '100%');
        $text10 = new TTextDisplay(TDate::convertToMask($pessoa->dt_nascimento, 'yyyy-mm-dd', 'dd/mm/yyyy'), '', '16px', '');
        $label18 = new TLabel("Profissão:", '', '14px', 'B', '100%');
        $text11 = new TTextDisplay($pessoa->profissao, '', '16px', '');
        $label121 = new TLabel("Sexo biológico:", '', '16px', 'B', '100%');
        $text7 = new TTextDisplay($transformed_pessoa_sexo, '', '16px', '');

        $image2->width = '100%';
        $image2->height = '50px';
        $image2->class = !empty($image2->class) ? $image2->class.' foto_perfil ' : ' foto_perfil ';

        $row1 = $this->form->addFields([$label2,$text1],[$label4,$text2],[$image2]);
        $row1->layout = ['col-sm-3',' col-sm-6',' col-sm-3'];

        $row2 = $this->form->addFields([$label61,$text3],[$label8,$text4],[$label101,$text5]);
        $row2->layout = ['col-sm-3','col-sm-3',' col-sm-3'];

        $row3 = $this->form->addFields([$label16,$text10],[$label18,$text11],[$label121,$text7]);
        $row3->layout = ['col-sm-3','col-sm-3',' col-sm-3'];

        $tab_detalhes = new BootstrapFormBuilder('tab_detalhes');
        $this->tab_detalhes = $tab_detalhes;
        $tab_detalhes->setProperty('style', 'border:none; box-shadow:none;');

        $tab_detalhes->appendPage("Agendamentos");

        $tab_detalhes->addFields([new THidden('current_tab_tab_detalhes')]);
        $tab_detalhes->setTabFunction("$('[name=current_tab_tab_detalhes]').val($(this).attr('data-current_page'));");

        $this->agendamento_paciente_id_list = new TQuickGrid;
        $this->agendamento_paciente_id_list->style = 'width:100%';
        $this->agendamento_paciente_id_list->disableDefaultClick();

        $column_agenda_nome = $this->agendamento_paciente_id_list->addQuickColumn("Agenda", 'agenda->nome', 'left');
        $column_especialidade_descricao = $this->agendamento_paciente_id_list->addQuickColumn("Especialidade", 'especialidade->descricao', 'left');
        $column_dt_inicial_transformed = $this->agendamento_paciente_id_list->addQuickColumn("Início ", 'dt_inicial', 'left' , '150px');
        $column_online_transformed = $this->agendamento_paciente_id_list->addQuickColumn("Online", 'online', 'left' , '150px');
        $column_estado_agenda_nome_transformed = $this->agendamento_paciente_id_list->addQuickColumn("Estado", 'estado_agenda->nome', 'left' , '150px');

        $column_dt_inicial_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y H:i');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_online_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            $label = new TElement('span');
            $label->{'class'} = 'label label-';

            if ($value == 'S' || $value == 'T') {
                $label->{'class'} .= 'success';
                $label->add('Sim');    

                return $label;
            }

            $label->{'class'} .= 'danger';
            $label->add('Não');

            return $label;
        });

        $column_estado_agenda_nome_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            return "<span class='label' style='width:235px;background-color:{$object->estado_agenda->cor}'> {$value} <span> "; 

        });

        $this->agendamento_paciente_id_list->createModel();

        $criteria_agendamento_paciente_id = new TCriteria();
        $criteria_agendamento_paciente_id->add(new TFilter('paciente_id', '=', $pessoa->id));

        $criteria_agendamento_paciente_id->setProperty('order', 'id desc');

        $agendamento_paciente_id_items = Agendamento::getObjects($criteria_agendamento_paciente_id);

        $this->agendamento_paciente_id_list->addItems($agendamento_paciente_id_items);

        $panel = new TElement('div');
        $panel->class = 'formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->agendamento_paciente_id_list));

        $tab_detalhes->addContent([$panel]);

        $tab_detalhes->appendPage("Atendimentos");

        $this->atendimento_paciente_id_list = new TQuickGrid;
        $this->atendimento_paciente_id_list->style = 'width:100%';
        $this->atendimento_paciente_id_list->disableDefaultClick();

        $column_dt_inicio_transformed = $this->atendimento_paciente_id_list->addQuickColumn("Início", 'dt_inicio', 'left' , '150px');
        $column_profissional_nome = $this->atendimento_paciente_id_list->addQuickColumn("Profissional", 'profissional->nome', 'left');
        $column_valor_total_transformed = $this->atendimento_paciente_id_list->addQuickColumn("Total", 'valor_total', 'center' , '150px');

        $column_valor_total_transformed->setTotalFunction( function($values) { 
            return array_sum((array) $values); 
        }); 

        $column_dt_inicio_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y H:i');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_valor_total_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });

        $this->atendimento_paciente_id_list->createModel();

        $criteria_atendimento_paciente_id = new TCriteria();
        $criteria_atendimento_paciente_id->add(new TFilter('paciente_id', '=', $pessoa->id));

        $criteria_atendimento_paciente_id->setProperty('order', 'id desc');

        $atendimento_paciente_id_items = Atendimento::getObjects($criteria_atendimento_paciente_id);

        $this->atendimento_paciente_id_list->addItems($atendimento_paciente_id_items);

        $panel = new TElement('div');
        $panel->class = 'formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->atendimento_paciente_id_list));

        $tab_detalhes->addContent([$panel]);

        $tab_detalhes->appendPage("Contas a receber");

        $this->conta_pessoa_id_list = new TQuickGrid;
        $this->conta_pessoa_id_list->style = 'width:100%';
        $this->conta_pessoa_id_list->disableDefaultClick();

        $column_descricao = $this->conta_pessoa_id_list->addQuickColumn("Descrição", 'descricao', 'left');
        $column_categoria_conta_nome = $this->conta_pessoa_id_list->addQuickColumn("Categoria", 'categoria_conta->nome', 'left');
        $column_total_conta_transformed = $this->conta_pessoa_id_list->addQuickColumn("Total", 'total_conta', 'center' , '175px');
        $column_quitada_transformed = $this->conta_pessoa_id_list->addQuickColumn("Quitada", 'quitada', 'left' , '75px');

        $column_total_conta_transformed->setTotalFunction( function($values) { 
            return array_sum((array) $values); 
        }); 

        $column_total_conta_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });

        $column_quitada_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            $label = new TElement('span');
            $label->{'class'} = 'label label-';

            if ($value == 'S' || $value == 'T') {
                $label->{'class'} .= 'success';
                $label->add('Sim');    

                return $label;
            }

            $label->{'class'} .= 'danger';
            $label->add('Não');

            return $label;
        });

        $this->conta_pessoa_id_list->createModel();

        $criteria_conta_pessoa_id = new TCriteria();
        $criteria_conta_pessoa_id->add(new TFilter('pessoa_id', '=', $pessoa->id));

        $criteria_conta_pessoa_id->setProperty('order', 'data_emissao desc');

        $filterVar = TipoConta::RECEBER;
        $criteria_conta_pessoa_id->add(new TFilter('tipo_conta_id', '=', $filterVar));

        $conta_pessoa_id_items = Conta::getObjects($criteria_conta_pessoa_id);

        $this->conta_pessoa_id_list->addItems($conta_pessoa_id_items);

        $panel = new TElement('div');
        $panel->class = 'formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->conta_pessoa_id_list));

        $tab_detalhes->addContent([$panel]);
        $row4 = $this->form->addFields([$tab_detalhes]);
        $row4->layout = [' col-sm-12'];

        if(!empty($param['current_tab']))
        {
            $this->form->setCurrentPage($param['current_tab']);
        }

        if(!empty($param['current_tab_tab_detalhes']))
        {
            $this->tab_detalhes->setCurrentPage($param['current_tab_tab_detalhes']);
        }

        $btnPacienteFormOnEditAction = new TAction(['PacienteForm', 'onEdit'],['key'=>$pessoa->id]);
        $btnPacienteFormOnEditLabel = new TLabel("Editar");

        $btnPacienteFormOnEdit = $this->form->addHeaderAction($btnPacienteFormOnEditLabel, $btnPacienteFormOnEditAction, 'fas:edit #2196F3'); 
        $btnPacienteFormOnEditLabel->setFontSize('12px'); 
        $btnPacienteFormOnEditLabel->setFontColor('#333'); 

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        TTransaction::close();
        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=PessoaFormView]');
        $style->width = '75% !important';   
        $style->show(true);

    }

    public function onShow($param = null)
    {     

    }

}

