<?php

class PrescricaoSimpleList extends TPage
{

    private $datagrid; // listing
    private $pageNavigation;
    private $loaded;
    private static $database = 'clinica';
    private static $activeRecord = 'Prescricao';
    private static $primaryKey = 'id';
    private static $formName = 'formList_Prescricao';
    private $limit = 20;

    public function __construct($param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        $this->limit = 20;

        // creates a Datagrid
        $this->datagrid = new TDataGrid;
        $this->datagrid->setId(__CLASS__.'_datagrid');

        $this->datagrid_form = new TForm('datagrid_'.self::$formName);
        $this->datagrid_form->onsubmit = 'return false';

        $this->datagrid = new BootstrapDatagridWrapper($this->datagrid);

        $this->datagrid->style = 'width: 100%';
        $this->datagrid->setHeight(320);

        $column_atendimento_id = new TDataGridColumn('atendimento_id', "Cód. do atendimento", 'center' , '100px');
        $column_dt_prescricao_transformed = new TDataGridColumn('dt_prescricao', "Data", 'left' , '20%');
        $column_id_transformed = new TDataGridColumn('id', "Medicamentos", 'left' , '60%');
        $column_controle_especial_transformed = new TDataGridColumn('controle_especial', "Receituário controle especial", 'left' , '10%');

        $column_dt_prescricao_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_id_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            $medicamentos = $object->getMedicamentos();

            $table = "<table class='table table-sm' style='width: 100%'>";

            if ($medicamentos)
            {
                $table .= "<thead><tr><th>Medicamento</th> <th>Posologia</th> <th>Qtde.</th></tr></thead>";

                foreach ($medicamentos as $medicamento)
                {
                    $table .= "<tr><td>{$medicamento->medicamento}</td> <td>{$medicamento->posologia}</td> <td>{$medicamento->quantidade}</td></tr>";
                }
            }

            $table .= "</table>";
            return $table;

        });

        $column_controle_especial_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            if($value === 'T' || $value === true || $value === 't' || $value === 'S' || $value === 'Y'  || $value === 'y'  )
            {
                return '<span class="label label-success">Sim</span>';
            }
            elseif($value === 'F' || $value === false || $value === 'f' || $value === 'N' || $value === 'n'  )
            {
                return '<span class="label label-danger">Não</span>';
            }

            return '';

        });        

        $this->datagrid->addColumn($column_atendimento_id);
        $this->datagrid->addColumn($column_dt_prescricao_transformed);
        $this->datagrid->addColumn($column_id_transformed);
        $this->datagrid->addColumn($column_controle_especial_transformed);

        $action_onGenerate = new TDataGridAction(array('PrescricaoDocument', 'onGenerate'));
        $action_onGenerate->setUseButton(false);
        $action_onGenerate->setButtonClass('btn btn-default btn-sm');
        $action_onGenerate->setLabel("Imprimir");
        $action_onGenerate->setImage('far:file-pdf #3F51B5');
        $action_onGenerate->setField(self::$primaryKey);

        $action_onGenerate->setParameter('key', '{id}');

        $this->datagrid->addAction($action_onGenerate);

        $action_onShow = new TDataGridAction(array('AtendimentoFormView', 'onShow'));
        $action_onShow->setUseButton(false);
        $action_onShow->setButtonClass('btn btn-default btn-sm');
        $action_onShow->setLabel("Abrir atendimento");
        $action_onShow->setImage('far:folder-open #000000');
        $action_onShow->setField(self::$primaryKey);

        $action_onShow->setParameter('key', '{atendimento_id}');

        $this->datagrid->addAction($action_onShow);

        // create the datagrid model
        $this->datagrid->createModel();

        // creates the page navigation
        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
        $this->pageNavigation->setWidth($this->datagrid->getWidth());

        $panel = new TPanelGroup();
        $panel->datagrid = 'datagrid-container';
        $this->datagridPanel = $panel;
        $this->datagrid_form->add($this->datagrid);
        $panel->add($this->datagrid_form);

        $panel->getBody()->class .= ' table-responsive';

        $panel->addFooter($this->pageNavigation);

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Pessoas","Lista das prescrições dos pacientes"]));
        }
        $container->add($panel);

        parent::add($container);

    }

    /**
     * Load the datagrid with data
     */
    public function onReload($param = NULL)
    {
        try
        {
            // open a transaction with database 'clinica'
            TTransaction::open(self::$database);

            // creates a repository for Prescricao
            $repository = new TRepository(self::$activeRecord);
            // creates a criteria
            $criteria = new TCriteria;

            if(!empty($param["paciente_id"] ?? ""))
        {
            TSession::setValue(__CLASS__.'load_filter_atendimento_id', $param["paciente_id"] ?? "");
        }
        $filterVar = TSession::getValue(__CLASS__.'load_filter_atendimento_id');

            $criteria->add(new TFilter('atendimento_id', 'in', "(SELECT id FROM atendimento WHERE paciente_id = '{$filterVar}')"));
            $filterVar = PermissaoService::getUnidadeIds();
        $filterVar = (is_array($filterVar) && $filterVar) ? "'".implode("','", $filterVar)."'" : $filterVar;
            $criteria->add(new TFilter('atendimento_id', 'in', "(SELECT id FROM atendimento WHERE clinica_id in ({$filterVar}))"));

            if (empty($param['order']))
            {
                $param['order'] = 'id';    
            }
            if (empty($param['direction']))
            {
                $param['direction'] = 'desc';
            }

            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $this->limit);

            if($filters = TSession::getValue(__CLASS__.'_filters'))
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            $this->datagrid->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {

                    $row = $this->datagrid->addItem($object);
                    $row->id = "row_{$object->id}";

                }
            }

            // reset the criteria for record count
            $criteria->resetProperties();
            $count= $repository->count($criteria);

            $this->pageNavigation->setCount($count); // count of records
            $this->pageNavigation->setProperties($param); // order, page
            $this->pageNavigation->setLimit($this->limit); // limit

            // close the transaction
            TTransaction::close();
            $this->loaded = true;

            return $objects;
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

    /**
     * method show()
     * Shows the page
     */
    public function show()
    {
        // check if the datagrid is already loaded
        if (!$this->loaded AND (!isset($_GET['method']) OR !(in_array($_GET['method'],  array('onReload', 'onSearch')))) )
        {
            if (func_num_args() > 0)
            {
                $this->onReload( func_get_arg(0) );
            }
            else
            {
                $this->onReload();
            }
        }
        parent::show();
    }

    public static function manageRow($id, $param = [])
    {
        $list = new self($param);

        $openTransaction = TTransaction::getDatabase() != self::$database ? true : false;

        if($openTransaction)
        {
            TTransaction::open(self::$database);    
        }

        $object = new Prescricao($id);

        $row = $list->datagrid->addItem($object);
        $row->id = "row_{$object->id}";

        if($openTransaction)
        {
            TTransaction::close();    
        }

        TDataGrid::replaceRowById(__CLASS__.'_datagrid', $row->id, $row);
    }

}

