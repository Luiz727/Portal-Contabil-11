<?php

class ClinicaServicoForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Servico';
    private static $primaryKey = 'id';
    private static $formName = 'form_ClinicaServicoForm';

    use BuilderMasterDetailFieldListTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de serviço");

        $criteria_servico_imposto_item_servico_imposto_id = new TCriteria();

        $id = new TEntry('id');
        $nome = new TEntry('nome');
        $codigo_cnae = new TEntry('codigo_cnae');
        $codigo_tributacao_municipio = new TEntry('codigo_tributacao_municipio');
        $codigo_nbs = new TEntry('codigo_nbs');
        $codigo = new TEntry('codigo');
        $descricao_servico_municipio = new TEntry('descricao_servico_municipio');
        $iss_retido = new TCombo('iss_retido');
        $natureza_operacao = new TCombo('natureza_operacao');
        $servico_imposto_item_servico_id = new THidden('servico_imposto_item_servico_id[]');
        $servico_imposto_item_servico___row__id = new THidden('servico_imposto_item_servico___row__id[]');
        $servico_imposto_item_servico___row__data = new THidden('servico_imposto_item_servico___row__data[]');
        $servico_imposto_item_servico_imposto_id = new TDBCombo('servico_imposto_item_servico_imposto_id[]', 'clinica', 'Imposto', 'id', '{nome}','nome asc' , $criteria_servico_imposto_item_servico_imposto_id );
        $servico_imposto_item_servico_aliquota = new TNumeric('servico_imposto_item_servico_aliquota[]', '2', ',', '.' );
        $this->fieldlist_impostos = new TFieldList();

        $this->fieldlist_impostos->addField(null, $servico_imposto_item_servico_id, []);
        $this->fieldlist_impostos->addField(null, $servico_imposto_item_servico___row__id, ['uniqid' => true]);
        $this->fieldlist_impostos->addField(null, $servico_imposto_item_servico___row__data, []);
        $this->fieldlist_impostos->addField(new TLabel("Imposto", null, '14px', null), $servico_imposto_item_servico_imposto_id, ['width' => '50%']);
        $this->fieldlist_impostos->addField(new TLabel("Aliquota", null, '14px', null), $servico_imposto_item_servico_aliquota, ['width' => '50%']);

        $this->fieldlist_impostos->width = '100%';
        $this->fieldlist_impostos->setFieldPrefix('servico_imposto_item_servico');
        $this->fieldlist_impostos->name = 'fieldlist_impostos';

        $this->criteria_fieldlist_impostos = new TCriteria();
        $this->default_item_fieldlist_impostos = new stdClass();

        $this->form->addField($servico_imposto_item_servico_id);
        $this->form->addField($servico_imposto_item_servico___row__id);
        $this->form->addField($servico_imposto_item_servico___row__data);
        $this->form->addField($servico_imposto_item_servico_imposto_id);
        $this->form->addField($servico_imposto_item_servico_aliquota);

        $this->fieldlist_impostos->setRemoveAction(null, 'fas:times #dd5a43', "Excluír");

        $nome->addValidation("Nome", new TRequiredValidator()); 
        $servico_imposto_item_servico_imposto_id->addValidation("Imposto id", new TRequiredListValidator()); 
        $servico_imposto_item_servico_aliquota->addValidation("Aliquota", new TRequiredListValidator()); 

        $id->setEditable(false);
        $iss_retido->addItems(["T"=>"Sim","F"=>"Não (ocorre apenas quando o serviço realizado fora do município, vide legislação)"]);
        $iss_retido->enableSearch();
        $natureza_operacao->enableSearch();
        $servico_imposto_item_servico_imposto_id->enableSearch();

        $id->setSize(100);
        $nome->setSize('100%');
        $codigo->setSize('100%');
        $codigo_nbs->setSize('100%');
        $iss_retido->setSize('100%');
        $codigo_cnae->setSize('100%');
        $natureza_operacao->setSize('100%');
        $codigo_tributacao_municipio->setSize('100%');
        $descricao_servico_municipio->setSize('100%');
        $servico_imposto_item_servico_aliquota->setSize('100%');
        $servico_imposto_item_servico_imposto_id->setSize('100%');


        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null, '100%'),$id]);
        $row1->layout = ['col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$nome]);
        $row2->layout = [' col-sm-12'];

        $tab_66dee0950d4b7 = new BootstrapFormBuilder('tab_66dee0950d4b7');
        $this->tab_66dee0950d4b7 = $tab_66dee0950d4b7;
        $tab_66dee0950d4b7->setProperty('style', 'border:none; box-shadow:none;');

        $tab_66dee0950d4b7->appendPage("Informações municipais");

        $tab_66dee0950d4b7->addFields([new THidden('current_tab_tab_66dee0950d4b7')]);
        $tab_66dee0950d4b7->setTabFunction("$('[name=current_tab_tab_66dee0950d4b7]').val($(this).attr('data-current_page'));");

        $row3 = $tab_66dee0950d4b7->addFields([new TLabel("Código CNAE:", null, '14px', null, '100%'),$codigo_cnae],[new TLabel("Código tributação município:", null, '14px', null, '100%'),$codigo_tributacao_municipio]);
        $row3->layout = ['col-sm-6','col-sm-6'];

        $row4 = $tab_66dee0950d4b7->addFields([new TLabel("Código NBS:", null, '14px', null, '100%'),$codigo_nbs],[new TLabel("Código do serviço", null, '14px', null, '100%'),$codigo]);
        $row4->layout = ['col-sm-6','col-sm-6'];

        $row5 = $tab_66dee0950d4b7->addFields([new TLabel("Descrição serviço no município:", null, '14px', null, '100%'),$descricao_servico_municipio],[new TLabel("Iss retido:", null, '14px', null, '100%'),$iss_retido]);
        $row5->layout = ['col-sm-6','col-sm-6'];

        $row6 = $tab_66dee0950d4b7->addFields([new TLabel("Natureza operacao:", null, '14px', null, '100%'),$natureza_operacao],[]);
        $row6->layout = ['col-sm-6','col-sm-6'];

        $tab_66dee0950d4b7->appendPage("Impostos");
        $row7 = $tab_66dee0950d4b7->addFields([$this->fieldlist_impostos]);
        $row7->layout = [' col-sm-12'];

        $row8 = $this->form->addFields([$tab_66dee0950d4b7]);
        $row8->layout = [' col-sm-12'];

        TTransaction::open(self::$database);
        ClinicaConfiguracaoService::ajustaCampos($this->form, $this);
        TTransaction::close();

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave'],['static' => 1]), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['ClinicaServicoList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Servico(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->account_id = PermissaoService::getAccountId();

            $object->store(); // save the object 

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            $servico_imposto_item_servico_items = $this->storeItems('ServicoImpostoItem', 'servico_id', $object, $this->fieldlist_impostos, function($masterObject, $detailObject){ 

                //code here

            }, $this->criteria_fieldlist_impostos); 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('ClinicaServicoList', 'onShow', $loadPageParam); 

                        TScript::create("Template.closeRightPanel();");
            TForm::sendData(self::$formName, (object)['id' => $object->id]);

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Servico($key); // instantiates the Active Record 

                $this->fieldlist_impostos_items = $this->loadItems('ServicoImpostoItem', 'servico_id', $object, $this->fieldlist_impostos, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }, $this->criteria_fieldlist_impostos); 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        $this->fieldlist_impostos->addHeader();
        $this->fieldlist_impostos->addDetail($this->default_item_fieldlist_impostos);

        $this->fieldlist_impostos->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

    }

    public function onShow($param = null)
    {
        $this->fieldlist_impostos->addHeader();
        $this->fieldlist_impostos->addDetail($this->default_item_fieldlist_impostos);

        $this->fieldlist_impostos->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

