<?php

class DashboardContasReceberGeral extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_DashboardContasReceberGeral';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Dashboard de contas a receber");

        $criteria_clinica_id = new TCriteria();
        $criteria_receber = new TCriteria();
        $criteria_quitado = new TCriteria();
        $criteria_total = new TCriteria();
        $criteria_categoria = new TCriteria();
        $criteria_movimentacao_mes = new TCriteria();
        $criteria_movimento = new TCriteria();

        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_clinica_id->add(new TFilter('id', 'in', $filterVar)); 
        $filterVar = TipoConta::RECEBER;
        $criteria_receber->add(new TFilter('conta.tipo_conta_id', '=', $filterVar)); 
        $filterVar = 'F';
        $criteria_receber->add(new TFilter('conta.quitada', '=', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_receber->add(new TFilter('conta.clinica_id', 'in', $filterVar)); 
        $filterVar = TipoConta::RECEBER;
        $criteria_quitado->add(new TFilter('conta.tipo_conta_id', '=', $filterVar)); 
        $filterVar = 'T';
        $criteria_quitado->add(new TFilter('conta.quitada', '=', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_quitado->add(new TFilter('conta.clinica_id', 'in', $filterVar)); 
        $filterVar = TipoConta::RECEBER;
        $criteria_total->add(new TFilter('conta.tipo_conta_id', '=', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_total->add(new TFilter('conta.clinica_id', 'in', $filterVar)); 
        $filterVar = TipoConta::RECEBER;
        $criteria_categoria->add(new TFilter('conta.tipo_conta_id', '=', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_categoria->add(new TFilter('conta.clinica_id', 'in', $filterVar)); 
        $filterVar = TipoConta::RECEBER;
        $criteria_movimentacao_mes->add(new TFilter('lancamento.conta_id', 'in', "(SELECT id FROM conta WHERE tipo_conta_id = '{$filterVar}')")); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_movimentacao_mes->add(new TFilter('lancamento.clinica_id', 'in', $filterVar)); 
        $filterVar = TipoConta::RECEBER;
        $criteria_movimento->add(new TFilter('lancamento.conta_id', 'in', "(SELECT id FROM conta WHERE tipo_conta_id = '{$filterVar}')")); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_movimento->add(new TFilter('lancamento.clinica_id', 'in', $filterVar)); 

        $clinica_id = new TDBCombo('clinica_id', 'clinica', 'Clinica', 'id', '{nome}','nome asc' , $criteria_clinica_id );
        $de = new TDate('de');
        $ate = new TDate('ate');
        $button_buscar = new TButton('button_buscar');
        $atalho = new TRadioGroup('atalho');
        $receber = new BIndicator('receber');
        $quitado = new BIndicator('quitado');
        $total = new BIndicator('total');
        $categoria = new BPieChart('categoria');
        $movimentacao_mes = new BBarChart('movimentacao_mes');
        $movimento = new BLineChart('movimento');

        $atalho->setChangeAction(new TAction([$this,'onChangeAtalho']));

        $clinica_id->enableSearch();
        $button_buscar->setAction(new TAction(['DashboardContasReceberGeral', 'onShow']), "Buscar");
        $button_buscar->addStyleClass('btn-default');
        $button_buscar->setImage('fas:search #00BCD4');
        $atalho->addItems(["mes_atual"=>"Mês atual","mes_seguinte"=>"Mês seguinte","mes_passado"=>"Mês passado","ano_atual"=>"Ano atual"]);
        $atalho->setLayout('horizontal');
        $atalho->setUseButton();
        $de->setMask('dd/mm/yyyy');
        $ate->setMask('dd/mm/yyyy');

        $de->setDatabaseMask('yyyy-mm-dd');
        $ate->setDatabaseMask('yyyy-mm-dd');

        $de->setSize(140);
        $ate->setSize(140);
        $atalho->setSize('100%');
        $clinica_id->setSize('100%');

        $receber->setDatabase('clinica');
        $receber->setFieldValue("conta.total_conta");
        $receber->setModel('Conta');
        $receber->setTransformerValue(function($value)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $receber->setTotal('sum');
        $receber->setColors('#16A085', '#FFFFFF', '#1ABC9C', '#FFFFFF');
        $receber->setTitle("TOTAL A RECEBER", '#FFFFFF', '20', '');
        $receber->setCriteria($criteria_receber);
        $receber->setIcon(new TImage('fas:plus #FFFFFF'));
        $receber->setValueSize("35");
        $receber->setValueColor("#FFFFFF", 'B');
        $receber->setSize('100%', 95);
        $receber->setLayout('horizontal', 'left');

        $quitado->setDatabase('clinica');
        $quitado->setFieldValue("conta.total_conta");
        $quitado->setModel('Conta');
        $quitado->setTransformerValue(function($value)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $quitado->setTotal('sum');
        $quitado->setColors('#3498DB', '#FFFFFF', '#2980B9', '#FFFFFF');
        $quitado->setTitle("TOTAL QUITADO", '#FFFFFF', '20', '');
        $quitado->setCriteria($criteria_quitado);
        $quitado->setIcon(new TImage('fas:check #FFFFFF'));
        $quitado->setValueSize("35");
        $quitado->setValueColor("#FFFFFF", 'B');
        $quitado->setSize('100%', 95);
        $quitado->setLayout('horizontal', 'left');

        $total->setDatabase('clinica');
        $total->setFieldValue("conta.total_conta");
        $total->setModel('Conta');
        $total->setTransformerValue(function($value)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $total->setTotal('sum');
        $total->setColors('#27AE60', '#ffffff', '#2ECC71', '#ffffff');
        $total->setTitle("TOTAL", '#ffffff', '20', '');
        $total->setCriteria($criteria_total);
        $total->setIcon(new TImage('fas:dollar-sign #ffffff'));
        $total->setValueSize("35");
        $total->setValueColor("#ffffff", 'B');
        $total->setSize('100%', 95);
        $total->setLayout('horizontal', 'left');

        $categoria->setDatabase('clinica');
        $categoria->setFieldValue("conta.total_conta");
        $categoria->setFieldGroup("categoria_conta.nome");
        $categoria->setModel('Conta');
        $categoria->setTitle("Total por categoria");
        $categoria->setTransformerValue(function($value, $row, $data)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $categoria->setJoins([
             'categoria_conta' => ['conta.categoria_conta_id', 'categoria_conta.id']
        ]);
        $categoria->setTotal('sum');
        $categoria->showLegend(true);
        $categoria->showPercentage();
        $categoria->enableOrderByValue('asc');
        $categoria->setCriteria($criteria_categoria);
        $categoria->setSize('100%', 280);
        $categoria->disableZoom();

        $movimentacao_mes->setDatabase('clinica');
        $movimentacao_mes->setFieldValue("lancamento.valor");
        $movimentacao_mes->setFieldGroup(["lancamento.ano_mes_vencimento"]);
        $movimentacao_mes->setModel('Lancamento');
        $movimentacao_mes->setTitle("Movimentação por mês");
        $movimentacao_mes->setTransformerLegend(function($value, $row, $data)
            {
                return TempoService::getMesAno($value);

            });
        $movimentacao_mes->setTransformerValue(function($value, $row, $data)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $movimentacao_mes->setLayout('vertical');
        $movimentacao_mes->setTotal('sum');
        $movimentacao_mes->showLegend(true);
        $movimentacao_mes->enableOrderByValue('asc');
        $movimentacao_mes->setCriteria($criteria_movimentacao_mes);
        $movimentacao_mes->setLabelValue("Total");
        $movimentacao_mes->setSize('100%', 280);
        $movimentacao_mes->disableZoom();

        $movimento->setDatabase('clinica');
        $movimento->setFieldValue("lancamento.valor");
        $movimento->setFieldGroup(["lancamento.dt_vencimento"]);
        $movimento->setModel('Lancamento');
        $movimento->setTitle("Movimentação por dia");
        $movimento->setTransformerLegend(function($value, $row, $data)
            {
                if(!empty(trim((string) $value)))
                {
                    try
                    {
                        $date = new DateTime($value);
                        return $date->format('d/m/Y');
                    }
                    catch (Exception $e)
                    {
                        return $value;
                    }
                }
            });
        $movimento->setTransformerValue(function($value, $row, $data)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $movimento->setTotal('sum');
        $movimento->showLegend(true);
        $movimento->setCriteria($criteria_movimento);
        $movimento->setLabelValue("Valor");
        $movimento->setRotateLegend('90');
        $movimento->setSize('100%', 280);
        $movimento->showArea(false);

        $row1 = $this->form->addFields([new TLabel("Clínica:", null, '14px', null, '100%'),$clinica_id],[new TLabel("Período:", null, '14px', null, '100%'),$de,new TLabel("até", null, '14px', null),$ate,$button_buscar]);
        $row1->layout = [' col-sm-7','col-sm-5'];

        $row2 = $this->form->addFields([new TLabel("Atalhos:", null, '14px', null, '100%'),$atalho]);
        $row2->layout = ['col-sm-7'];

        $row3 = $this->form->addFields([$receber],[$quitado],[$total]);
        $row3->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row4 = $this->form->addFields([$categoria],[$movimentacao_mes]);
        $row4->layout = [' col-sm-6',' col-sm-6'];

        $row5 = $this->form->addFields([$movimento]);
        $row5->layout = [' col-sm-12'];

        $searchData = $this->form->getData();
        $this->form->setData($searchData);

        $filterVar = $searchData->de;
        if($filterVar)
        {
            $criteria_receber->add(new TFilter('conta.data_emissao', '>=', $filterVar)); 
        }
        $filterVar = $searchData->ate;
        if($filterVar)
        {
            $criteria_receber->add(new TFilter('conta.data_emissao', '<=', $filterVar)); 
        }
        $filterVar = $searchData->clinica_id;
        if($filterVar)
        {
            $criteria_receber->add(new TFilter('conta.clinica_id', '=', $filterVar)); 
        }
        $filterVar = $searchData->de;
        if($filterVar)
        {
            $criteria_quitado->add(new TFilter('conta.data_emissao', '>=', $filterVar)); 
        }
        $filterVar = $searchData->ate;
        if($filterVar)
        {
            $criteria_quitado->add(new TFilter('conta.data_emissao', '<=', $filterVar)); 
        }
        $filterVar = $searchData->clinica_id;
        if($filterVar)
        {
            $criteria_quitado->add(new TFilter('conta.clinica_id', '=', $filterVar)); 
        }
        $filterVar = $searchData->de;
        if($filterVar)
        {
            $criteria_total->add(new TFilter('conta.data_emissao', '>=', $filterVar)); 
        }
        $filterVar = $searchData->ate;
        if($filterVar)
        {
            $criteria_total->add(new TFilter('conta.data_emissao', '<=', $filterVar)); 
        }
        $filterVar = $searchData->clinica_id;
        if($filterVar)
        {
            $criteria_total->add(new TFilter('conta.clinica_id', '=', $filterVar)); 
        }
        $filterVar = $searchData->de;
        if($filterVar)
        {
            $criteria_categoria->add(new TFilter('conta.data_emissao', '>=', $filterVar)); 
        }
        $filterVar = $searchData->ate;
        if($filterVar)
        {
            $criteria_categoria->add(new TFilter('conta.data_emissao', '<=', $filterVar)); 
        }
        $filterVar = $searchData->clinica_id;
        if($filterVar)
        {
            $criteria_categoria->add(new TFilter('conta.clinica_id', '=', $filterVar)); 
        }
        $filterVar = $searchData->de;
        if($filterVar)
        {
            $criteria_movimentacao_mes->add(new TFilter('lancamento.dt_vencimento', '>=', $filterVar)); 
        }
        $filterVar = $searchData->ate;
        if($filterVar)
        {
            $criteria_movimentacao_mes->add(new TFilter('lancamento.dt_vencimento', '<=', $filterVar)); 
        }
        $filterVar = $searchData->clinica_id;
        if($filterVar)
        {
            $criteria_movimentacao_mes->add(new TFilter('lancamento.clinica_id', '=', $filterVar)); 
        }
        $filterVar = $searchData->de;
        if($filterVar)
        {
            $criteria_movimento->add(new TFilter('lancamento.dt_vencimento', '>=', $filterVar)); 
        }
        $filterVar = $searchData->ate;
        if($filterVar)
        {
            $criteria_movimento->add(new TFilter('lancamento.dt_vencimento', '<=', $filterVar)); 
        }
        $filterVar = $searchData->clinica_id;
        if($filterVar)
        {
            $criteria_movimento->add(new TFilter('lancamento.clinica_id', '=', $filterVar)); 
        }

        BChart::generate($receber, $quitado, $total, $categoria, $movimentacao_mes, $movimento);

        // create the form actions

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Financeiro","Dashboard a receber"]));
        }
        $container->add($this->form);

// var_dump($criteria_total_por_agenda->dump()); die();

        parent::add($container);

    }

    public static function onChangeAtalho($param = null) 
    {
        try 
        {
            if (! empty($param['atalho']))
            {
                $data = new stdClass;

                if ($param['atalho'] == 'mes_atual')
                {
                    $data->de = date('01/m/Y', strtotime('now'));
                    $data->ate = date('t/m/Y', strtotime('now'));
                }
                else if ($param['atalho'] == 'mes_seguinte')
                {
                    $data->de = date('01/m/Y', strtotime('now +1 month'));
                    $data->ate = date('t/m/Y', strtotime('now +1 month'));
                }
                else if ($param['atalho'] == 'mes_passado')
                {
                    $data->de = date('01/m/Y', strtotime('now -1 month'));
                    $data->ate = date('t/m/Y', strtotime('now -1 month'));
                }
                else if ($param['atalho'] == 'ano_atual')
                {
                    $data->de = date('01/01/Y', strtotime('now'));
                    $data->ate = date('t/12/Y', strtotime('now'));
                }

                TForm::sendData(self::$formName, $data);
            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onShow($param = null)
    {               

    } 

}

