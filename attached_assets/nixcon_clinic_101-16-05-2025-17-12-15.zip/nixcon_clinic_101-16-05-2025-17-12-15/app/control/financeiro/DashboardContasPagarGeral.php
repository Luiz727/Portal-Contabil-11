<?php

class DashboardContasPagarGeral extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_DashboardContasPagarGeral';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Dashboard de contas a receber");

        $criteria_pagar = new TCriteria();
        $criteria_quitado = new TCriteria();
        $criteria_total = new TCriteria();
        $criteria_categoria = new TCriteria();
        $criteria_movimento_mes = new TCriteria();
        $criteria_movimento = new TCriteria();

        $filterVar = TipoConta::PAGAR;
        $criteria_pagar->add(new TFilter('conta.tipo_conta_id', '=', $filterVar)); 
        $filterVar = 'F';
        $criteria_pagar->add(new TFilter('conta.quitada', '=', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_pagar->add(new TFilter('conta.clinica_id', 'in', $filterVar)); 
        $filterVar = TipoConta::PAGAR;
        $criteria_quitado->add(new TFilter('conta.tipo_conta_id', '=', $filterVar)); 
        $filterVar = 'T';
        $criteria_quitado->add(new TFilter('conta.quitada', '=', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_quitado->add(new TFilter('conta.clinica_id', 'in', $filterVar)); 
        $filterVar = TipoConta::PAGAR;
        $criteria_total->add(new TFilter('conta.tipo_conta_id', '=', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_total->add(new TFilter('conta.clinica_id', 'in', $filterVar)); 
        $filterVar = TipoConta::PAGAR;
        $criteria_categoria->add(new TFilter('conta.tipo_conta_id', '=', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_categoria->add(new TFilter('conta.clinica_id', 'in', $filterVar)); 
        $filterVar = TipoConta::PAGAR;
        $criteria_movimento_mes->add(new TFilter('lancamento.conta_id', 'in', "(SELECT id FROM conta WHERE tipo_conta_id = '{$filterVar}')")); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_movimento_mes->add(new TFilter('lancamento.clinica_id', 'in', $filterVar)); 
        $filterVar = TipoConta::PAGAR;
        $criteria_movimento->add(new TFilter('lancamento.conta_id', 'in', "(SELECT id FROM conta WHERE tipo_conta_id = '{$filterVar}')")); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_movimento->add(new TFilter('lancamento.clinica_id', 'in', $filterVar)); 

        $atalho = new TRadioGroup('atalho');
        $de = new TDate('de');
        $ate = new TDate('ate');
        $button_buscar = new TButton('button_buscar');
        $pagar = new BIndicator('pagar');
        $quitado = new BIndicator('quitado');
        $total = new BIndicator('total');
        $categoria = new BPieChart('categoria');
        $movimento_mes = new BBarChart('movimento_mes');
        $movimento = new BLineChart('movimento');

        $atalho->setChangeAction(new TAction([$this,'onChangeAtalho']));

        $atalho->addItems(["mes_atual"=>"Mês atual","mes_seguinte"=>"Mês seguinte","mes_passado"=>"Mês passado","ano_atual"=>"Ano atual"]);
        $atalho->setLayout('horizontal');
        $atalho->setUseButton();
        $button_buscar->setAction(new TAction(['DashboardContasPagarGeral', 'onShow']), "Buscar");
        $button_buscar->addStyleClass('btn-default');
        $button_buscar->setImage('fas:search #00BCD4');
        $de->setMask('dd/mm/yyyy');
        $ate->setMask('dd/mm/yyyy');

        $de->setDatabaseMask('yyyy-mm-dd');
        $ate->setDatabaseMask('yyyy-mm-dd');

        $de->setSize(140);
        $ate->setSize(140);
        $atalho->setSize('100%');

        $pagar->setDatabase('clinica');
        $pagar->setFieldValue("conta.total_conta");
        $pagar->setModel('Conta');
        $pagar->setTransformerValue(function($value)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $pagar->setTotal('sum');
        $pagar->setColors('#1ABC9C', '#FFFFFF', '#16A085', '#FFFFFF');
        $pagar->setTitle("TOTAL A PAGAR", '#FFFFFF', '20', '');
        $pagar->setCriteria($criteria_pagar);
        $pagar->setIcon(new TImage('fas:plus #FFFFFF'));
        $pagar->setValueSize("35");
        $pagar->setValueColor("#FFFFFF", 'B');
        $pagar->setSize('100%', 95);
        $pagar->setLayout('horizontal', 'left');

        $quitado->setDatabase('clinica');
        $quitado->setFieldValue("conta.total_conta");
        $quitado->setModel('Conta');
        $quitado->setTransformerValue(function($value)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $quitado->setTotal('sum');
        $quitado->setColors('#2980B9', '#FFFFFF', '#3498DB', '#FFFFFF');
        $quitado->setTitle("TOTAL QUITADO", '#FFFFFF', '20', '');
        $quitado->setCriteria($criteria_quitado);
        $quitado->setIcon(new TImage('fas:plus #FFFFFF'));
        $quitado->setValueSize("35");
        $quitado->setValueColor("#FFFFFF", 'B');
        $quitado->setSize('100%', 95);
        $quitado->setLayout('horizontal', 'left');

        $total->setDatabase('clinica');
        $total->setFieldValue("conta.total_conta");
        $total->setModel('Conta');
        $total->setTransformerValue(function($value)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $total->setTotal('sum');
        $total->setColors('#27AE60', '#ffffff', '#2ECC71', '#ffffff');
        $total->setTitle("TOTAL", '#ffffff', '20', '');
        $total->setCriteria($criteria_total);
        $total->setIcon(new TImage('fas:plus #ffffff'));
        $total->setValueSize("35");
        $total->setValueColor("#ffffff", 'B');
        $total->setSize('100%', 95);
        $total->setLayout('horizontal', 'left');

        $categoria->setDatabase('clinica');
        $categoria->setFieldValue("conta.total_conta");
        $categoria->setFieldGroup("categoria_conta.nome");
        $categoria->setModel('Conta');
        $categoria->setTitle("Total por categoria");
        $categoria->setTransformerValue(function($value, $row, $data)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $categoria->setJoins([
             'categoria_conta' => ['conta.categoria_conta_id', 'categoria_conta.id']
        ]);
        $categoria->setTotal('sum');
        $categoria->showLegend(true);
        $categoria->showPercentage();
        $categoria->enableOrderByValue('asc');
        $categoria->setCriteria($criteria_categoria);
        $categoria->setSize('100%', 280);
        $categoria->disableZoom();

        $movimento_mes->setDatabase('clinica');
        $movimento_mes->setFieldValue("lancamento.valor");
        $movimento_mes->setFieldGroup(["lancamento.ano_mes_vencimento"]);
        $movimento_mes->setModel('Lancamento');
        $movimento_mes->setTitle("Movimentação por mês");
        $movimento_mes->setTransformerLegend(function($value, $row, $data)
            {
                return TempoService::getMesAno($value);

            });
        $movimento_mes->setLayout('vertical');
        $movimento_mes->setTotal('sum');
        $movimento_mes->showLegend(true);
        $movimento_mes->setCriteria($criteria_movimento_mes);
        $movimento_mes->setLabelValue("Total");
        $movimento_mes->setSize('100%', 280);
        $movimento_mes->disableZoom();

        $movimento->setDatabase('clinica');
        $movimento->setFieldValue("lancamento.valor");
        $movimento->setFieldGroup(["lancamento.dt_vencimento"]);
        $movimento->setModel('Lancamento');
        $movimento->setTitle("Movimentação por dia");
        $movimento->setTransformerLegend(function($value, $row, $data)
            {
                if(!empty(trim((string) $value)))
                {
                    try
                    {
                        $date = new DateTime($value);
                        return $date->format('d/m/Y');
                    }
                    catch (Exception $e)
                    {
                        return $value;
                    }
                }
            });
        $movimento->setTransformerValue(function($value, $row, $data)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $movimento->setTotal('sum');
        $movimento->showLegend(true);
        $movimento->setCriteria($criteria_movimento);
        $movimento->setLabelValue("Valor");
        $movimento->setSize('100%', 280);
        $movimento->showArea(false);

        $row1 = $this->form->addFields([new TLabel("Atalhos:", null, '14px', null, '100%'),$atalho],[new TLabel("Período:", null, '14px', null, '100%'),$de,new TLabel("até", null, '14px', null),$ate,$button_buscar]);
        $row1->layout = [' col-sm-7',' col-sm-5'];

        $row2 = $this->form->addFields([$pagar],[$quitado],[$total]);
        $row2->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row3 = $this->form->addFields([$categoria],[$movimento_mes]);
        $row3->layout = [' col-sm-6',' col-sm-6'];

        $row4 = $this->form->addFields([$movimento]);
        $row4->layout = [' col-sm-12'];

        $searchData = $this->form->getData();
        $this->form->setData($searchData);

        $filterVar = $searchData->de;
        if($filterVar)
        {
            $criteria_pagar->add(new TFilter('conta.data_emissao', '>=', $filterVar)); 
        }
        $filterVar = $searchData->ate;
        if($filterVar)
        {
            $criteria_pagar->add(new TFilter('conta.data_emissao', '<=', $filterVar)); 
        }
        $filterVar = $searchData->de;
        if($filterVar)
        {
            $criteria_quitado->add(new TFilter('conta.data_emissao', '>=', $filterVar)); 
        }
        $filterVar = $searchData->ate;
        if($filterVar)
        {
            $criteria_quitado->add(new TFilter('conta.data_emissao', '<=', $filterVar)); 
        }
        $filterVar = $searchData->de;
        if($filterVar)
        {
            $criteria_total->add(new TFilter('conta.data_emissao', '>=', $filterVar)); 
        }
        $filterVar = $searchData->ate;
        if($filterVar)
        {
            $criteria_total->add(new TFilter('conta.data_emissao', '<=', $filterVar)); 
        }
        $filterVar = $searchData->de;
        if($filterVar)
        {
            $criteria_categoria->add(new TFilter('conta.data_emissao', '>=', $filterVar)); 
        }
        $filterVar = $searchData->ate;
        if($filterVar)
        {
            $criteria_categoria->add(new TFilter('conta.data_emissao', '<=', $filterVar)); 
        }
        $filterVar = $searchData->de;
        if($filterVar)
        {
            $criteria_movimento_mes->add(new TFilter('lancamento.dt_vencimento', '>=', $filterVar)); 
        }
        $filterVar = $searchData->ate;
        if($filterVar)
        {
            $criteria_movimento_mes->add(new TFilter('lancamento.dt_vencimento', '<=', $filterVar)); 
        }
        $filterVar = $searchData->de;
        if($filterVar)
        {
            $criteria_movimento->add(new TFilter('lancamento.dt_vencimento', '>=', $filterVar)); 
        }
        $filterVar = $searchData->ate;
        if($filterVar)
        {
            $criteria_movimento->add(new TFilter('lancamento.dt_vencimento', '<=', $filterVar)); 
        }

        BChart::generate($pagar, $quitado, $total, $categoria, $movimento_mes, $movimento);

        // create the form actions

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Financeiro","Dashboard a pagar"]));
        }
        $container->add($this->form);

// var_dump($criteria_total_por_agenda->dump()); die();

        parent::add($container);

    }

    public static function onChangeAtalho($param = null) 
    {
        try 
        {
            if (! empty($param['atalho']))
            {
                $data = new stdClass;

                if ($param['atalho'] == 'mes_atual')
                {
                    $data->de = date('01/m/Y', strtotime('now'));
                    $data->ate = date('t/m/Y', strtotime('now'));
                }
                else if ($param['atalho'] == 'mes_seguinte')
                {
                    $data->de = date('01/m/Y', strtotime('now +1 month'));
                    $data->ate = date('t/m/Y', strtotime('now +1 month'));
                }
                else if ($param['atalho'] == 'mes_passado')
                {
                    $data->de = date('01/m/Y', strtotime('now -1 month'));
                    $data->ate = date('t/m/Y', strtotime('now -1 month'));
                }
                else if ($param['atalho'] == 'ano_atual')
                {
                    $data->de = date('01/01/Y', strtotime('now'));
                    $data->ate = date('t/12/Y', strtotime('now'));
                }

                TForm::sendData(self::$formName, $data);
            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onShow($param = null)
    {               

    } 

}

