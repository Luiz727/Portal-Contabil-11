<?php

class NFSeEmailForm extends TWindow
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_NFSeEmailForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();
        parent::setSize(0.80, null);
        parent::setTitle("Enviar email com a NFS-e");
        parent::setProperty('class', 'window_modal');

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Enviar email com a NFS-e");


        $id = new TEntry('id');
        $email = new TEntry('email');
        $email_container = new BElement('div');


        $id->setValue($param["key"] ?? "");
        $id->setEditable(false);
        $email->setEditable(false);

        $id->setSize('100%');
        $email->setSize('100%');
        $email_container->setSize('100%', 80);

        $this->email_container = $email_container;

        TTransaction::open(MAIN_DATABASE);

        $notaFiscal = NotaFiscalServico::find($param['key']);

        $email->setValue($notaFiscal->email_tomador);

        $template = TemplateClinica::getTemplate('EMAIL_NFSE', $notaFiscal->clinica_id);

        $conteudo = TemplateClinica::replaceNotaFiscal($notaFiscal, $template->template, $notaFiscal->clinica);

        TTransaction::close();

        $this->email_container->style = 'max-height:400px; overflow:auto;';
        $this->email_container->add($conteudo);

        $row1 = $this->form->addFields([new TLabel("ID da NFS-e:", null, '14px', null),$id]);
        $row1->layout = [' col-sm-12'];

        $row2 = $this->form->addFields([new TLabel("Email:", null, '14px', null, '100%'),$email]);
        $row2->layout = [' col-sm-12'];

        $row3 = $this->form->addFields([new TLabel("Pré-visualização do email", null, '14px', null)]);
        $row3->layout = [' col-sm-12'];

        $row4 = $this->form->addFields([$email_container]);
        $row4->layout = [' col-sm-12'];

        // create the form actions
        $btn_onenviar = $this->form->addAction("Enviar", new TAction([$this, 'onEnviar']), 'fas:rocket #ffffff');
        $this->btn_onenviar = $btn_onenviar;
        $btn_onenviar->addStyleClass('btn-primary'); 

        parent::add($this->form);

    }

    public static function onEnviar($param = null) 
    {
        try
        {
            TTransaction::open(MAIN_DATABASE);

            $nfse = new NotaFiscalServico($param['id']);

            $template = TemplateClinica::getTemplate('EMAIL_NFSE', $nfse->clinica_id);

            $conteudo = TemplateClinica::replaceNotaFiscal($nfse, $template->template, $nfse->clinica);
            $titulo = TemplateClinica::replaceNotaFiscal($nfse, $template->titulo, $nfse->clinica);

            TTransaction::close();

            $dados = json_decode($nfse->dados_gateway_externo ?? '');

            if (!empty($dados->documento))
            {

                TTransaction::open(MAIN_DATABASE);

                ClinicaEmailService::send($nfse->email_tomador, $titulo, $conteudo, [$dados->documento]);

                $nfse = new NotaFiscalServico($param['id']);
                $nfse->email_enviado = 'T';
                $nfse->store();

                TTransaction::close();

                new TMessage('info', 'Email enviado');

                TWindow::closeWindow();

                NotaFiscalServicoList::manageRow($nfse->id);
            }
            else
            {
                throw new Exception('PDF da nota fiscal não encontrado');
            }
        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
        }
    }

    public function onShow($param = null)
    {               

    } 

}

