<?php

class CriarNFSeForm extends TWindow
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_CriarNFSeForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();
        parent::setSize(650, null);
        parent::setTitle("Criar NFS-e");
        parent::setProperty('class', 'window_modal');

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Criar NFS-e");

        $criteria_lancamento_id = new TCriteria();
        $criteria_servico_id = new TCriteria();

        if(!empty($param["conta_id"] ?? ""))
        {
            TSession::setValue(__CLASS__.'load_filter_conta_id', $param["conta_id"] ?? "");
        }
        $filterVar = TSession::getValue(__CLASS__.'load_filter_conta_id');
        $criteria_lancamento_id->add(new TFilter('conta_id', '=', $filterVar)); 
        $filterVar = NULL;
        $criteria_lancamento_id->add(new TFilter('nota_fiscal_servico_id', 'is', $filterVar)); 
        $filterVar = PermissaoService::getAccountId();
        $criteria_servico_id->add(new TFilter('account_id', '=', $filterVar)); 

        $conta_id = new THidden('conta_id');
        $clinica_id_nfse = new THidden('clinica_id_nfse');
        $lancamento_id = new TCheckList('lancamento_id');
        $servico_id = new TDBCombo('servico_id', 'clinica', 'Servico', 'id', '{nome}','nome asc' , $criteria_servico_id );
        $observacoes = new TText('observacoes');

        $servico_id->addValidation("Serviço", new TRequiredValidator()); 
        $observacoes->addValidation("Digite as observações que irão conter na nota fiscal de serviço", new TRequiredValidator()); 

        $servico_id->enableSearch();
        $conta_id->setValue($param["conta_id"] ?? "");
        $clinica_id_nfse->setValue($param["clinica_id_nfse"] ?? "");

        $conta_id->setSize(200);
        $servico_id->setSize('100%');
        $clinica_id_nfse->setSize(200);
        $observacoes->setSize('100%', 140);

        $lancamento_id->setIdColumn('id');

        $column_lancamento_id_parcela = $lancamento_id->addColumn('parcela', "Parcela", 'center' , '25%');
        $column_lancamento_id_tipo_pagamento_nome = $lancamento_id->addColumn('tipo_pagamento->nome', "Tipo de pagamento", 'center' , '25%');
        $column_lancamento_id_dt_vencimento_transformed = $lancamento_id->addColumn('dt_vencimento', "Data vencimento", 'center' , '25%');
        $column_lancamento_id_valor_transformed = $lancamento_id->addColumn('valor', "Valor", 'center' , '25%');

        $column_lancamento_id_dt_vencimento_transformed->setTransformer(function($value, $object, $row) 
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_lancamento_id_valor_transformed->setTransformer(function($value, $object, $row) 
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });        

        $lancamento_id->fillWith('clinica', 'Lancamento', 'id', 'dt_vencimento asc' , $criteria_lancamento_id);


        $row1 = $this->form->addFields([$conta_id,$clinica_id_nfse]);
        $row1->layout = [' col-sm-12'];

        $row2 = $this->form->addFields([new TLabel("Escolha as parcelas para gerar a nota fiscal:", '#FF0000', '14px', null),$lancamento_id]);
        $row2->layout = [' col-sm-12'];

        $row3 = $this->form->addFields([new TLabel("Informe o serviço:", '#FF0000', '14px', null),$servico_id]);
        $row3->layout = [' col-sm-12'];

        $row4 = $this->form->addFields([new TLabel("Digite as observações que irão conter na nota fiscal de serviço:", '#FF0000', '14px', null),$observacoes]);
        $row4->layout = [' col-sm-12'];

        // create the form actions
        $btn_ongerarnotafiscal = $this->form->addAction("Gerar Nota Fiscal", new TAction([$this, 'onGerarNotaFiscal']), 'fas:rocket #ffffff');
        $this->btn_ongerarnotafiscal = $btn_ongerarnotafiscal;
        $btn_ongerarnotafiscal->addStyleClass('btn-primary'); 

        parent::add($this->form);

    }

    public function onGerarNotaFiscal($param = null) 
    {
        try
        {
            $data = $this->form->getData();

            $this->form->validate();

            if(!$data->lancamento_id)
            {
                throw new Exception('Informe um lançamento ');
            }

            if ($data->conta_id)
            {
                TTransaction::open(MAIN_DATABASE);
                $conta = new Conta($param['conta_id']);

                $conta->gerarNotaFiscal($data->lancamento_id, $data->servico_id, $data->observacoes);

                TToast::show("success", "Nota criada", "topRight", "far:file-pdf");

                TTransaction::close();

                TWindow::closeWindow();
            }
            else
            {
                throw new Exception('Conta não informada');
            }
        }
        catch (Exception $e)
        {
            $this->form->setData($data);
            new TMessage('error', $e->getMessage());
        }
    }

    public function onShow($param = null)
    {               

    } 

}

