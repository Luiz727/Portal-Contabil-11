<?php

class ContaFormView extends TPage
{
    protected $form; // form
    private static $database = 'clinica';
    private static $activeRecord = 'Conta';
    private static $primaryKey = 'id';
    private static $formName = 'formView_Conta';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        TTransaction::open(self::$database);
        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        $this->form->setTagName('div');

        $conta = new Conta($param['key']);
        // define the form title
        $this->form->setFormTitle("Detalhe da conta #{$param['key']}");

        $transformed_conta_total_conta = call_user_func(function($value, $object, $row) 
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        }, $conta->total_conta, $conta, null);

        $label = new TElement('span');
        $label->{'class'} = 'label label-';

        if ($conta->quitada  == 'T') {
            $label->{'class'} .= 'success';
            $label->add('Sim');    
        } else {
            $label->{'class'} .= 'danger';
            $label->add('Não');
        }

        $conta->quitada = $label;

        $label2 = new TLabel("Pessoa:", '', '14px', 'B', '100%');
        $text2 = new TTextDisplay($conta->pessoa->nome, '', '16px', '');
        $label6 = new TLabel("Tipo:", '', '14px', 'B', '100%');
        $text4 = new TTextDisplay($conta->tipo_conta->nome, '', '16px', '');
        $label8 = new TLabel("Quitada:", '', '14px', 'B', '100%');
        $text8 = new TTextDisplay($conta->quitada, '', '16px', '');
        $label4 = new TLabel("Categoria:", '', '14px', 'B', '100%');
        $text3 = new TTextDisplay($conta->categoria_conta->nome, '', '16px', '');
        $label25 = new TLabel("Clínica:", '', '14px', 'B', '100%');
        $text7 = new TTextDisplay($conta->clinica->nome, '', '16px', '');
        $label12 = new TLabel("Total:", '', '14px', 'B', '100%');
        $text6 = new TTextDisplay($transformed_conta_total_conta, '', '16px', '');
        $label10 = new TLabel("Descrição:", '', '14px', 'B', '100%');
        $text9 = new TTextDisplay($conta->descricao, '', '16px', '');


        $row1 = $this->form->addFields([$label2,$text2],[$label6,$text4],[$label8,$text8]);
        $row1->layout = [' col-sm-6',' col-sm-3',' col-sm-3'];

        $row2 = $this->form->addFields([$label4,$text3],[$label25,$text7],[$label12,$text6]);
        $row2->layout = [' col-sm-6','col-sm-3',' col-sm-3'];

        $row3 = $this->form->addFields([$label10,$text9]);
        $row3->layout = [' col-sm-12'];

        $this->lancamento_conta_id_list = new TQuickGrid;
        $this->lancamento_conta_id_list->style = 'width:100%';
        $this->lancamento_conta_id_list->disableDefaultClick();

        $action_onPagar = new TDataGridAction(array('ContaFormView', 'onPagar'));
        $action_onPagar->setUseButton(true);
        $action_onPagar->setButtonClass('btn btn-default btn-sm');
        $action_onPagar->setLabel("Pagar");
        $action_onPagar->setImage('fas:check #4CAF50');
        $action_onPagar->setField('id');
        $action_onPagar->setDisplayCondition('ContaFormView::canPagar');
        $action_onPagar->setParameter('lancamento_id', '{id}');
        $this->lancamento_conta_id_list->addAction($action_onPagar);

        $column_parcela = $this->lancamento_conta_id_list->addQuickColumn("Parcela", 'parcela', 'center' , '150px');
        $column_dt_vencimento_transformed = $this->lancamento_conta_id_list->addQuickColumn("Vencimento", 'dt_vencimento', 'left');
        $column_tipo_pagamento_nome = $this->lancamento_conta_id_list->addQuickColumn("Tipo", 'tipo_pagamento->nome', 'left');
        $column_valor_transformed = $this->lancamento_conta_id_list->addQuickColumn("Valor", 'valor', 'left');
        $column_dt_pagamento_transformed = $this->lancamento_conta_id_list->addQuickColumn("Paga", 'dt_pagamento', 'center' , '150px');

        $column_dt_vencimento_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_valor_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });

        $column_dt_pagamento_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            $label = new TElement('span');
            $label->{'class'} = 'label label-';

            if ($value) {
                $label->{'class'} .= 'success';
                $label->add('Sim');    

                return $label;
            }

            $label->{'class'} .= 'danger';
            $label->add('Não');

            return $label;
        });

        $this->lancamento_conta_id_list->createModel();

        $criteria_lancamento_conta_id = new TCriteria();
        $criteria_lancamento_conta_id->add(new TFilter('conta_id', '=', $conta->id));

        $criteria_lancamento_conta_id->setProperty('order', 'parcela asc');

        $lancamento_conta_id_items = Lancamento::getObjects($criteria_lancamento_conta_id);

        $this->lancamento_conta_id_list->addItems($lancamento_conta_id_items);

        $icon = new TImage('fas:dollar-sign #4CAF50');
        $title = new TTextDisplay("{$icon} Parcelas", '#555555', '16px', '{$fontStyle}');

        $panel = new TPanelGroup($title, '#FFFFFF');
        $panel->class = 'panel panel-default formView-detail';
        $tableResponsiveDiv = new TElement('div');
        $tableResponsiveDiv->class = 'table-responsive';
        $tableResponsiveDiv->add(new BootstrapDatagridWrapper($this->lancamento_conta_id_list));
        $panel->add($tableResponsiveDiv);

        $this->form->addContent([$panel]);

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        TTransaction::close();
        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=ContaFormView]');
        $style->width = '50% !important';   
        $style->show(true);

    }

    public static function onPagar($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $lancamento = Lancamento::find($param['lancamento_id']);

            if ($lancamento->dt_pagamento)
            {
                throw new Exception('Esse lançamento já foi quitado em '. TDate::date2br($lancamento->dt_pagamento));
            }

            if (! empty($param['pagar']) && $param['pagar'] == 'T')
            {
                $lancamento->dt_pagamento = date('Y-m-d');
                $lancamento->store();

                $criteria = new TCriteria;
                $criteria->add(new TFilter('dt_pagamento', 'IS', NULL));
                $criteria->add(new TFilter('conta_id', '=', $lancamento->conta_id));

                $lancamentoAbertos = Lancamento::countObjects($criteria);

                if ($lancamentoAbertos == 0)
                {
                    $lancamento->conta->quitada = 'T';
                    $lancamento->conta->store();
                }

                TToast::show('success', 'Lançamento quitado com sucesso', 'bottom right');
                AdiantiCoreApplication::loadPage(__CLASS__, 'onShow', ['key' => $lancamento->conta_id]);

                $tipo_conta_id = $lancamento->conta->tipo_conta_id;
                TTransaction::close();

                if($tipo_conta_id == TipoConta::PAGAR)
                {
                    ContaPagarList::manageRow($lancamento->conta_id);    
                }
                else
                {
                    ContaReceberList::manageRow($lancamento->conta_id);
                }
            }
            else
            {
                TTransaction::close();

                $valor = number_format($lancamento->valor, 2, ',', '.');

                $param['pagar'] = 'T';
                $actionYes = new TAction([__CLASS__, 'onPagar'], $param);

                new TQuestion("Deseja quitar o lançamento: {$lancamento->parcela} no valor de R$ {$valor}", $actionYes);
            }

            //</autoCode>
        }
        catch (Exception $e) 
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function canPagar($object)
    {
        try 
        {
            return empty($object->dt_pagamento);
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onShow($param = null)
    {     

    }

}

