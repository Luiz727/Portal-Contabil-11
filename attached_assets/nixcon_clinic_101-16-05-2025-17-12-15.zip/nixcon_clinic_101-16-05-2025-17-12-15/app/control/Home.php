<?php

class Home extends TPage
{
    private $html;
    
    public function __construct($param)
    {
        parent::__construct();
        
        if(TSession::getValue('clinica_token') && empty($param['token']))
        {
            $param['token'] = TSession::getValue('clinica_token');
        }
        
        if(!TSession::getValue('clinica_token') && empty($param['token']))
        {
            new TMessage('info', 'Sem permissão');
            return false;
        }
        
        $background = '';
        
        TSession::setValue('clinica_background', '');
        if (!empty($param['token']))
        {
            TTransaction::open(MAIN_DATABASE);
            $clinica = Clinica::where('token', '=', $param['token'])->first();
            TTransaction::close();
            
            if(!$clinica)
            {
                new TMessage('info', 'Sem permissão');
                return false;
            }
            
            TSession::setValue('clinica_token', $param['token']);
            TSession::setValue('clinica_id', $clinica->id);
            
            if($clinica->logo_horizontal_grande)
            {
                $background = "background-image: url('{$clinica->logo_horizontal_grande}')";
                
                TSession::setValue('clinica_background', $background);
            }
        }
        
        $documentosLink = 'portal-documentos';
        
        if(TSession::getValue('portal_paciente_id'))
        {
            $documentosLink = 'meus-documentos';
        }
        
        $this->html = new THtmlRenderer('app/resources/home.html');
        $this->html->enableSection('main',[
            'background' => $background,
            'documentosLink' => $documentosLink
        ]);
        
        parent::add($this->html);
    }
    
    public function onDocumentos($param)
    {
        try
        {
            TTransaction::open(MAIN_DATABASE);
            
            if (! empty(TSession::getValue('portal_paciente_id')))
            {
                TApplication::loadPage('MeusDocumentoList', 'onShow', ['register_state' => 'false']);
            }
            else
            {
                if (empty($param['usuario']) &&  empty($param['senha']))
                {
                    $form = new BootstrapFormBuilder('input_form');
                    $form->setFieldSizes('100%');
            
                    $login = new TEntry('usuario');
                    $pass  = new TPassword('senha');
                    
                    $form->addFields( [new TLabel('Usuário'), $login]);
                    $form->addFields( [new TLabel('Senha'), $pass]);
                    
                    $form->addAction('Entrar', new TAction([__CLASS__, 'onDocumentos']), 'fa:sign-in-alt green');
                    
                    new TInputDialog('Informe o seu usuário e senha', $form);
                }
                else
                {
                    $pessoa = Pessoa::where('usuario', '=', $param['usuario'])
                                    ->where('senha', '=', $param['senha'])
                                    ->where('clinica_id', '=', TSession::getValue('clinica_id'))
                                    ->first();
                    
                    if (empty($pessoa))
                    {
                        throw new Exception('Você ainda não é um paciente registrado. Verifique os dados informado!');
                    }
                    
                    TSession::setValue('portal_paciente_id', $pessoa->id);
                    
                    TApplication::loadPage('MeusDocumentoList', 'onShow', ['register_state' => 'false']);
                }
            }
            
            TTransaction::close();
        }
        catch (Exception $e)
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());
        }
    }
    
    // função executa ao clicar no item de menu
    public function onShow($param = null)
    {
        
    }
    
    public static function getHeader($type = 'normal')
    {
        $container = new TElement('div');
        
        $container->add('<div class="logo-public" style="'.TSession::getValue('clinica_background').'"></div>');
        
        
        $clinica_token = TSession::getValue('clinica_token');
        
        $divBotoes = new TElement('div');
        $divBotoes->style = 'clear:both; height:30px';
        $divBotoes->add("<a class='btn btn-default' style='float:left' href='home-{$clinica_token}' generator='adianti'>VOLTAR</a>");
        $divBotoes->add("<a class='btn btn-default' style='float:right' href='portal-logout' generator='adianti'> SAIR </a>");
        
        $container->add($divBotoes);
        $container->add('<hr/>');
        
        
        return $container;
    }
    
    public static function onLogout($param)
    {
        $clinica_token = TSession::getValue('clinica_token');
        TSession::clear();
        
        TSession::regenerate();
        
        TSession::setValue('clinica_token', $clinica_token);
        
        TScript::create("location.href = 'home-{$clinica_token}';");
        
    }
}
