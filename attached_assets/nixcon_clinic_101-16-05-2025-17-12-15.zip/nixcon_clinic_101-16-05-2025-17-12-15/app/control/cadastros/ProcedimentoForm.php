<?php

class ProcedimentoForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Procedimento';
    private static $primaryKey = 'id';
    private static $formName = 'form_Procedimento';

    use BuilderMasterDetailFieldListTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de procedimento");

        $criteria_clinica_id = new TCriteria();
        $criteria_procedimento_preco_procedimento_convenio_id = new TCriteria();

        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_clinica_id->add(new TFilter('id', 'in', $filterVar)); 
        $filterVar = PermissaoService::getAccountId();
        $criteria_procedimento_preco_procedimento_convenio_id->add(new TFilter('account_id', '=', $filterVar)); 

        $id = new TEntry('id');
        $clinica_id = new TDBCombo('clinica_id', 'clinica', 'Clinica', 'id', '{nome}','nome asc' , $criteria_clinica_id );
        $nome = new TEntry('nome');
        $codigo_referencia = new TEntry('codigo_referencia');
        $cor = new TColor('cor');
        $duracao = new TEntry('duracao');
        $ativo = new TRadioGroup('ativo');
        $procedimento_preco_procedimento_id = new THidden('procedimento_preco_procedimento_id[]');
        $procedimento_preco_procedimento___row__id = new THidden('procedimento_preco_procedimento___row__id[]');
        $procedimento_preco_procedimento___row__data = new THidden('procedimento_preco_procedimento___row__data[]');
        $procedimento_preco_procedimento_convenio_id = new TDBCombo('procedimento_preco_procedimento_convenio_id[]', 'clinica', 'Convenio', 'id', '{nome}','nome asc' , $criteria_procedimento_preco_procedimento_convenio_id );
        $procedimento_preco_procedimento_valor = new TNumeric('procedimento_preco_procedimento_valor[]', '2', ',', '.' );
        $this->fieldList_60f87238c3d31 = new TFieldList();
        $procedimento_material_procedimento_id = new THidden('procedimento_material_procedimento_id[]');
        $procedimento_material_procedimento___row__id = new THidden('procedimento_material_procedimento___row__id[]');
        $procedimento_material_procedimento___row__data = new THidden('procedimento_material_procedimento___row__data[]');
        $procedimento_material_procedimento_material_id = new TCombo('procedimento_material_procedimento_material_id[]');
        $procedimento_material_procedimento_quantidade = new TNumeric('procedimento_material_procedimento_quantidade[]', '2', ',', '.' );
        $this->fieldList_60f8725fc3d33 = new TFieldList();

        $this->fieldList_60f87238c3d31->addField(null, $procedimento_preco_procedimento_id, []);
        $this->fieldList_60f87238c3d31->addField(null, $procedimento_preco_procedimento___row__id, ['uniqid' => true]);
        $this->fieldList_60f87238c3d31->addField(null, $procedimento_preco_procedimento___row__data, []);
        $this->fieldList_60f87238c3d31->addField(new TLabel("Convênio", null, '14px', null), $procedimento_preco_procedimento_convenio_id, ['width' => '70%']);
        $this->fieldList_60f87238c3d31->addField(new TLabel("Valor", null, '14px', null), $procedimento_preco_procedimento_valor, ['width' => '30%']);

        $this->fieldList_60f87238c3d31->width = '100%';
        $this->fieldList_60f87238c3d31->setFieldPrefix('procedimento_preco_procedimento');
        $this->fieldList_60f87238c3d31->name = 'fieldList_60f87238c3d31';

        $this->criteria_fieldList_60f87238c3d31 = new TCriteria();
        $this->default_item_fieldList_60f87238c3d31 = new stdClass();

        $this->form->addField($procedimento_preco_procedimento_id);
        $this->form->addField($procedimento_preco_procedimento___row__id);
        $this->form->addField($procedimento_preco_procedimento___row__data);
        $this->form->addField($procedimento_preco_procedimento_convenio_id);
        $this->form->addField($procedimento_preco_procedimento_valor);

        $this->fieldList_60f87238c3d31->setRemoveAction(null, 'fas:times #dd5a43', "Excluír");

        $this->fieldList_60f8725fc3d33->addField(null, $procedimento_material_procedimento_id, []);
        $this->fieldList_60f8725fc3d33->addField(null, $procedimento_material_procedimento___row__id, ['uniqid' => true]);
        $this->fieldList_60f8725fc3d33->addField(null, $procedimento_material_procedimento___row__data, []);
        $this->fieldList_60f8725fc3d33->addField(new TLabel("Material", null, '14px', null), $procedimento_material_procedimento_material_id, ['width' => '70%']);
        $this->fieldList_60f8725fc3d33->addField(new TLabel("Quantidade", null, '14px', null), $procedimento_material_procedimento_quantidade, ['width' => '30%']);

        $this->fieldList_60f8725fc3d33->width = '100%';
        $this->fieldList_60f8725fc3d33->setFieldPrefix('procedimento_material_procedimento');
        $this->fieldList_60f8725fc3d33->name = 'fieldList_60f8725fc3d33';

        $this->criteria_fieldList_60f8725fc3d33 = new TCriteria();
        $this->default_item_fieldList_60f8725fc3d33 = new stdClass();

        $this->form->addField($procedimento_material_procedimento_id);
        $this->form->addField($procedimento_material_procedimento___row__id);
        $this->form->addField($procedimento_material_procedimento___row__data);
        $this->form->addField($procedimento_material_procedimento_material_id);
        $this->form->addField($procedimento_material_procedimento_quantidade);

        $this->fieldList_60f8725fc3d33->setRemoveAction(null, 'fas:times #dd5a43', "Excluír");

        $clinica_id->setChangeAction(new TAction([$this,'onChangeClinica']));

        $clinica_id->addValidation("Clínica", new TRequiredValidator()); 
        $nome->addValidation("Nome", new TRequiredValidator()); 
        $cor->addValidation("Cor", new TRequiredValidator()); 
        $ativo->addValidation("Ativo", new TRequiredValidator()); 
        $procedimento_preco_procedimento_valor->addValidation("Valor", new TRequiredListValidator()); 

        $id->setEditable(false);
        $duracao->setMask('99:99');
        $ativo->addItems(["T"=>"Sim","N"=>"Não"]);
        $ativo->setLayout('horizontal');
        $ativo->setUseButton();
        $ativo->setValue('T');
        $cor->setValue('#ffffff');
        $clinica_id->setValue(PermissaoService::getUnidadeDefault());

        $clinica_id->enableSearch();
        $procedimento_preco_procedimento_convenio_id->enableSearch();
        $procedimento_material_procedimento_material_id->enableSearch();

        $id->setSize(100);
        $cor->setSize('100%');
        $nome->setSize('100%');
        $ativo->setSize('100%');
        $duracao->setSize('100%');
        $clinica_id->setSize('100%');
        $codigo_referencia->setSize('100%');
        $procedimento_preco_procedimento_valor->setSize('100%');
        $procedimento_preco_procedimento_convenio_id->setSize('100%');
        $procedimento_material_procedimento_quantidade->setSize('100%');
        $procedimento_material_procedimento_material_id->setSize('100%');


        $row1 = $this->form->addFields([new TLabel("Código:", null, '14px', null, '100%'),$id],[new TLabel("Clínica:", null, '14px', null, '100%'),$clinica_id]);
        $row1->layout = ['col-sm-6',' col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$nome],[new TLabel("Código de referência:", null, '14px', null),$codigo_referencia]);
        $row2->layout = [' col-sm-9',' col-sm-3'];

        $row3 = $this->form->addFields([new TLabel("Cor:", '#ff0000', '14px', null, '100%'),$cor],[new TLabel("Duração:", null, '14px', null, '100%'),$duracao],[new TLabel("Ativo:", null, '14px', null, '100%'),$ativo]);
        $row3->layout = ['col-sm-2','col-sm-2',' col-sm-5'];

        $row4 = $this->form->addFields([new TFormSeparator("Preços", '#333', '18', '#eee')],[new TFormSeparator("Materiais", '#333', '18', '#eee')]);
        $row4->layout = [' col-sm-6','col-sm-6'];

        $row5 = $this->form->addFields([$this->fieldList_60f87238c3d31],[$this->fieldList_60f8725fc3d33]);
        $row5->layout = [' col-sm-6','col-sm-6'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave'],['static' => 1]), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['ProcedimentosList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=ProcedimentoForm]');
        $style->width = '70% !important';   
        $style->show(true);

    }

    public static function onChangeClinica($param = null) 
    {
        try 
        {
            if(!empty($param['key']))
            {
                TSession::setValue('clinica_id_procedimento_form', $param['key']);
            }
            else
            {
                TSession::setValue('clinica_id_procedimento_form', PermissaoService::getUnidadeDefault());
            } 

            if(!empty($param['key']))
            {
                TTransaction::open(MAIN_DATABASE);

                $materiais = Material::getIndexedArray('id', 'nome', TCriteria::create(['clinica_id' => $param['key']]));

                TCombo::reload(self::$formName, 'procedimento_material_procedimento_material_id[]', $materiais, true);

                TTransaction::close();
            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Procedimento(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            $procedimento_material_procedimento_items = $this->storeItems('ProcedimentoMaterial', 'procedimento_id', $object, $this->fieldList_60f8725fc3d33, function($masterObject, $detailObject){ 

                //code here

            }, $this->criteria_fieldList_60f8725fc3d33); 

            $procedimento_preco_procedimento_items = $this->storeItems('ProcedimentoPreco', 'procedimento_id', $object, $this->fieldList_60f87238c3d31, function($masterObject, $detailObject){ 

                //code here

            }, $this->criteria_fieldList_60f87238c3d31); 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('ProcedimentosList', 'onShow', $loadPageParam); 

                        TScript::create("Template.closeRightPanel();");
            TForm::sendData(self::$formName, (object)['id' => $object->id]);

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Procedimento($key); // instantiates the Active Record 
                TSession::setValue('clinica_id_procedimento_form', $object->clinica_id);

                $materiais = Material::getIndexedArray('id', 'nome', TCriteria::create(['clinica_id' => $object->clinica_id]));

                $this->form->getField('procedimento_material_procedimento_material_id[]')->addItems($materiais);

                $this->fieldList_60f8725fc3d33_items = $this->loadItems('ProcedimentoMaterial', 'procedimento_id', $object, $this->fieldList_60f8725fc3d33, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }, $this->criteria_fieldList_60f8725fc3d33); 

                $this->fieldList_60f87238c3d31_items = $this->loadItems('ProcedimentoPreco', 'procedimento_id', $object, $this->fieldList_60f87238c3d31, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }, $this->criteria_fieldList_60f87238c3d31); 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        $this->fieldList_60f87238c3d31->addHeader();
        $this->fieldList_60f87238c3d31->addDetail($this->default_item_fieldList_60f87238c3d31);

        $this->fieldList_60f87238c3d31->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        $this->fieldList_60f8725fc3d33->addHeader();
        $this->fieldList_60f8725fc3d33->addDetail($this->default_item_fieldList_60f8725fc3d33);

        $this->fieldList_60f8725fc3d33->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        $obj = new stdClass();
        $obj->clinica_id = PermissaoService::getUnidadeDefault();

        TForm::sendData(self::$formName, $obj);

        TSession::setValue('clinica_id_procedimento_form', PermissaoService::getUnidadeDefault());

    }

    public function onShow($param = null)
    {
        $this->fieldList_60f87238c3d31->addHeader();
        $this->fieldList_60f87238c3d31->addDetail($this->default_item_fieldList_60f87238c3d31);

        $this->fieldList_60f87238c3d31->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        $this->fieldList_60f8725fc3d33->addHeader();
        $this->fieldList_60f8725fc3d33->addDetail($this->default_item_fieldList_60f8725fc3d33);

        $this->fieldList_60f8725fc3d33->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        $obj = new stdClass();
        $obj->clinica_id = PermissaoService::getUnidadeDefault();

        TForm::sendData(self::$formName, $obj);

        TSession::setValue('clinica_id_procedimento_form', PermissaoService::getUnidadeDefault());

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

