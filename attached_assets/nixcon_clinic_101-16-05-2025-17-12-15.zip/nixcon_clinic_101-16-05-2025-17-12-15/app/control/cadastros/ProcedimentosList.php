<?php

class ProcedimentosList extends TPage
{
    private $form; // form
    private $datagrid; // listing
    private $pageNavigation;
    private $loaded;
    private $filter_criteria;
    private static $database = 'clinica';
    private static $activeRecord = 'Procedimento';
    private static $primaryKey = 'id';
    private static $formName = 'formList_Procedimento';
    private $showMethods = ['onReload', 'onSearch', 'onRefresh', 'onClearFilters'];
    private $limit = 20;

    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct($param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        // define the form title
        $this->form->setFormTitle("Procedimentos");
        $this->limit = 20;

        $criteria_clinica_id = new TCriteria();
        $criteria_material_id = new TCriteria();
        $criteria_convenio = new TCriteria();

        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_clinica_id->add(new TFilter('id', 'in', $filterVar)); 
        $filterVar = PermissaoService::getUnidadeIds();
        $criteria_material_id->add(new TFilter('clinica_id', 'in', $filterVar)); 
        $filterVar = PermissaoService::getAccountId();
        $criteria_convenio->add(new TFilter('account_id', '=', $filterVar)); 

        $clinica_id = new TDBCombo('clinica_id', 'clinica', 'Clinica', 'id', '{nome}','nome asc' , $criteria_clinica_id );
        $nome = new TEntry('nome');
        $codigo_referencia = new TEntry('codigo_referencia');
        $material_id = new TDBCombo('material_id', 'clinica', 'Material', 'id', '{nome}','nome asc' , $criteria_material_id );
        $convenio = new TDBCombo('convenio', 'clinica', 'Convenio', 'id', '{nome}','nome asc' , $criteria_convenio );


        $convenio->enableSearch();
        $clinica_id->enableSearch();
        $material_id->enableSearch();

        $nome->setSize('100%');
        $convenio->setSize('100%');
        $clinica_id->setSize('100%');
        $material_id->setSize('100%');
        $codigo_referencia->setSize('100%');

        $row1 = $this->form->addFields([new TLabel("Clínica:", null, '14px', null, '100%'),$clinica_id],[]);
        $row1->layout = ['col-sm-6','col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Nome:", null, '14px', null, '100%'),$nome],[new TLabel("Código de referência:", null, '14px', null, '100%'),$codigo_referencia]);
        $row2->layout = ['col-sm-6','col-sm-6'];

        $row3 = $this->form->addFields([new TLabel("Material:", null, '14px', null),$material_id],[new TLabel("Convênio:", null, '14px', null),$convenio]);
        $row3->layout = [' col-sm-6','col-sm-6'];

        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );

        $btn_onsearch = $this->form->addAction("Buscar", new TAction([$this, 'onSearch']), 'fas:search #ffffff');
        $this->btn_onsearch = $btn_onsearch;
        $btn_onsearch->addStyleClass('btn-primary'); 

        // creates a Datagrid
        $this->datagrid = new TDataGrid;
        $this->datagrid->setId(__CLASS__.'_datagrid');

        $this->datagrid_form = new TForm('datagrid_'.self::$formName);
        $this->datagrid_form->onsubmit = 'return false';

        $this->datagrid = new BootstrapDatagridWrapper($this->datagrid);
        $this->filter_criteria = new TCriteria;

        $filterVar = PermissaoService::getUnidadeIds();
        $this->filter_criteria->add(new TFilter('clinica_id', 'in', $filterVar));

        $this->datagrid->style = 'width: 100%';
        $this->datagrid->setHeight(250);

        $column_nome = new TDataGridColumn('nome', "Nome", 'left');
        $column_codigo_referencia = new TDataGridColumn('codigo_referencia', "Código de referência", 'center' , '250px');
        $column_count_materiais = new TDataGridColumn('{count_materiais}', "Materiais", 'center' , '150px');
        $column_duracao_transformed = new TDataGridColumn('duracao', "Duração", 'center' , '150px');
        $column_cor_transformed = new TDataGridColumn('cor', "Cor", 'center' , '150px');
        $column_ativo_transformed = new TDataGridColumn('ativo', "Ativo", 'left');
        $column_clinica_nome = new TDataGridColumn('clinica->nome', "Clínica", 'center');

        $column_duracao_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if ($value)
            {
                $time = explode(':', $value);
                return $time[0]. 'h ' . $time[1] . 'min';
            }

            return '';
        });

        $column_cor_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            return "<span class='label' style='background-color:{$value}'> {$value} <span> ";    
        });

        $column_ativo_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            if($value === 'T' || $value === true || $value === 't' || $value === 'S' || $value === 'Y'  || $value === 'y'  )
            {
                return '<span class="label label-success">Sim</span>';
            }
            elseif($value === 'F' || $value === false || $value === 'f' || $value === 'N' || $value === 'n'  )
            {
                return '<span class="label label-danger">Não</span>';
            }

            return '';

        });        

        $this->datagrid->addColumn($column_nome);
        $this->datagrid->addColumn($column_codigo_referencia);
        $this->datagrid->addColumn($column_count_materiais);
        $this->datagrid->addColumn($column_duracao_transformed);
        $this->datagrid->addColumn($column_cor_transformed);
        $this->datagrid->addColumn($column_ativo_transformed);
        $this->datagrid->addColumn($column_clinica_nome);

        $action_onEdit = new TDataGridAction(array('ProcedimentoForm', 'onEdit'));
        $action_onEdit->setUseButton(false);
        $action_onEdit->setButtonClass('btn btn-default btn-sm');
        $action_onEdit->setLabel("Editar");
        $action_onEdit->setImage('far:edit #478fca');
        $action_onEdit->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onEdit);

        $action_onDelete = new TDataGridAction(array('ProcedimentosList', 'onDelete'));
        $action_onDelete->setUseButton(false);
        $action_onDelete->setButtonClass('btn btn-default btn-sm');
        $action_onDelete->setLabel("Excluir");
        $action_onDelete->setImage('fas:trash-alt #dd5a43');
        $action_onDelete->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onDelete);

        // create the datagrid model
        $this->datagrid->createModel();

        // creates the page navigation
        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
        $this->pageNavigation->setWidth($this->datagrid->getWidth());

        $panel = new TPanelGroup("Procedimentos");
        $panel->datagrid = 'datagrid-container';
        $this->datagridPanel = $panel;
        $this->datagrid_form->add($this->datagrid);
        $panel->add($this->datagrid_form);

        $panel->addFooter($this->pageNavigation);

        $headerActions = new TElement('div');
        $headerActions->class = ' datagrid-header-actions ';
        $headerActions->style = 'justify-content: space-between;';

        $head_left_actions = new TElement('div');
        $head_left_actions->class = ' datagrid-header-actions-left-actions ';

        $head_right_actions = new TElement('div');
        $head_right_actions->class = ' datagrid-header-actions-left-actions ';

        $headerActions->add($head_left_actions);
        $headerActions->add($head_right_actions);

        $panel->getBody()->insert(0, $headerActions);

        $button_cadastrar = new TButton('button_button_cadastrar');
        $button_cadastrar->setAction(new TAction(['ProcedimentoForm', 'onShow']), "Cadastrar");
        $button_cadastrar->addStyleClass('btn-default');
        $button_cadastrar->setImage('fas:plus #69aa46');

        $this->datagrid_form->addField($button_cadastrar);

        $button_filtros = new TButton('button_button_filtros');
        $button_filtros->setAction(new TAction(['ProcedimentosList', 'onShowCurtainFilters']), "Filtros");
        $button_filtros->addStyleClass('btn-default');
        $button_filtros->setImage('fas:filter #000000');

        $this->datagrid_form->addField($button_filtros);

        $button_atualizar = new TButton('button_button_atualizar');
        $button_atualizar->setAction(new TAction(['ProcedimentosList', 'onRefresh']), "Atualizar");
        $button_atualizar->addStyleClass('btn-default');
        $button_atualizar->setImage('fas:sync-alt #03a9f4');

        $this->datagrid_form->addField($button_atualizar);

        $button_limpar_filtros = new TButton('button_button_limpar_filtros');
        $button_limpar_filtros->setAction(new TAction(['ProcedimentosList', 'onClearFilters']), "Limpar filtros");
        $button_limpar_filtros->addStyleClass('btn-default');
        $button_limpar_filtros->setImage('fas:eraser #f44336');

        $this->datagrid_form->addField($button_limpar_filtros);

        $head_left_actions->add($button_cadastrar);
        $head_left_actions->add($button_filtros);
        $head_left_actions->add($button_atualizar);
        $head_left_actions->add($button_limpar_filtros);

        $this->button_filtros = $button_filtros;

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Cadastros","Procedimentos"]));
        }

        $container->add($panel);

        parent::add($container);

    }

    public function onDelete($param = null) 
    { 
        if(isset($param['delete']) && $param['delete'] == 1)
        {
            try
            {
                // get the paramseter $key
                $key = $param['key'];
                // open a transaction with database
                TTransaction::open(self::$database);

                // instantiates object
                $object = new Procedimento($key, FALSE); 

                $atendimentos = $object->getAtendimentoProcedimentos();

                if ($atendimentos)
                {
                    throw new Exception('Esse procedimento já possui atendimentos');
                }

                $object->deleteComposite('ProcedimentoMaterial', 'procedimento_id', $object->id);
                $object->deleteComposite('ProcedimentoPreco', 'procedimento_id', $object->id);

                $object->delete();

                // close the transaction
                TTransaction::close();

                // reload the listing
                $this->onReload( $param );
                // shows the success message
                new TMessage('info', AdiantiCoreTranslator::translate('Record deleted'));
            }
            catch (Exception $e) // in case of exception
            {
                // shows the exception error message
                new TMessage('error', $e->getMessage());
                // undo all pending operations
                TTransaction::rollback();
            }
        }
        else if (isset($param['inativar']) && $param['inativar'] == 1 )
        {
            try
            {
                $key = $param['key'];
                TTransaction::open(self::$database);

                $object = new Procedimento($key, FALSE);
                $object->ativo = 'N';

                $object->delete();

                TTransaction::close();

                $this->onReload( $param );

                new TMessage('info', 'Registro inativado');
            }
            catch (Exception $e) // in case of exception
            {
                // shows the exception error message
                new TMessage('error', $e->getMessage());
                // undo all pending operations
                TTransaction::rollback();
            }
        }
        else
        {

            try
            {
                $key = $param['key'];
                TTransaction::open(self::$database);

                $object = new Procedimento($key, FALSE);
                $atendimentos = $object->getAtendimentoProcedimentos();

                $action = new TAction(array($this, 'onDelete'));
                $action->setParameters($param);

                if ($atendimentos)
                {
                    $action->setParameter('delete', 1);
                    new TQuestion(AdiantiCoreTranslator::translate('Do you really want to delete ?'), $action);   
                }
                else
                {
                    $action->setParameter('inativar', 1);
                    new TQuestion('Esse procedimento já possui atendimentos.<br>Deseja inativar ?', $action);   
                }

                TTransaction::close();
            }
            catch (Exception $e) // in case of exception
            {
                new TMessage('error', $e->getMessage());
                TTransaction::rollback();
            }
        }
    }
    public static function onShowCurtainFilters($param = null) 
    {
        try 
        {
            //code here

                        $filter = new self([]);

            $btnClose = new TButton('closeCurtain');
            $btnClose->class = 'btn btn-sm btn-default';
            $btnClose->style = 'margin-right:10px;';
            $btnClose->onClick = "Template.closeRightPanel();";
            $btnClose->setLabel("Fechar");
            $btnClose->setImage('fas:times');

            $filter->form->addHeaderWidget($btnClose);

            $page = new TPage();
            $page->setTargetContainer('adianti_right_panel');
            $page->setProperty('page-name', 'ProcedimentosListSearch');
            $page->setProperty('page_name', 'ProcedimentosListSearch');
            $page->adianti_target_container = 'adianti_right_panel';
            $page->target_container = 'adianti_right_panel';
            $page->add($filter->form);
            $page->setIsWrapped(true);
            $page->show();

            $style = new TStyle('right-panel > .container-part[page-name=ProcedimentosListSearch]');
            $style->width = '50% !important';
            $style->show(true);

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onRefresh($param = null) 
    {
        $this->onReload([]);
    }
    public function onClearFilters($param = null) 
    {
        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }

    /**
     * Register the filter in the session
     */
    public function onSearch($param = null)
    {
        $data = $this->form->getData();
        $filters = [];

        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        if (isset($data->clinica_id) AND ( (is_scalar($data->clinica_id) AND $data->clinica_id !== '') OR (is_array($data->clinica_id) AND (!empty($data->clinica_id)) )) )
        {

            $filters[] = new TFilter('clinica_id', '=', $data->clinica_id);// create the filter 
        }

        if (isset($data->nome) AND ( (is_scalar($data->nome) AND $data->nome !== '') OR (is_array($data->nome) AND (!empty($data->nome)) )) )
        {

            $filters[] = new TFilter('nome', 'like', "%{$data->nome}%");// create the filter 
        }

        if (isset($data->codigo_referencia) AND ( (is_scalar($data->codigo_referencia) AND $data->codigo_referencia !== '') OR (is_array($data->codigo_referencia) AND (!empty($data->codigo_referencia)) )) )
        {

            $filters[] = new TFilter('codigo_referencia', 'like', "%{$data->codigo_referencia}%");// create the filter 
        }

        if (isset($data->material_id) AND ( (is_scalar($data->material_id) AND $data->material_id !== '') OR (is_array($data->material_id) AND (!empty($data->material_id)) )) )
        {

            $filters[] = new TFilter('id', 'in', "(SELECT procedimento_id FROM procedimento_material WHERE material_id = '{$data->material_id}')");// create the filter 
        }

        if (isset($data->convenio) AND ( (is_scalar($data->convenio) AND $data->convenio !== '') OR (is_array($data->convenio) AND (!empty($data->convenio)) )) )
        {

            $filters[] = new TFilter('id', 'in', "(SELECT procedimento_id FROM procedimento_preco WHERE convenio_id = '{$data->convenio}')");// create the filter 
        }

        $this->button_filtros->style = 'position: relative';
        $countFiltros = count($filters);

        if ($countFiltros)
        {
            $this->button_filtros->setLabel('Filtros'. "<span class='badge badge-success' style='position: absolute'>{$countFiltros}<span>");
        }

        // fill the form with data again
        $this->form->setData($data);

        // keep the search data in the session
        TSession::setValue(__CLASS__.'_filter_data', $data);
        TSession::setValue(__CLASS__.'_filters', $filters);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }

    /**
     * Load the datagrid with data
     */
    public function onReload($param = NULL)
    {
        try
        {
            // open a transaction with database 'clinica'
            TTransaction::open(self::$database);

            // creates a repository for Procedimento
            $repository = new TRepository(self::$activeRecord);

            $criteria = clone $this->filter_criteria;

            if (empty($param['order']))
            {
                $param['order'] = 'id';    
            }

            if (empty($param['direction']))
            {
                $param['direction'] = 'desc';
            }

            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $this->limit);

            if($filters = TSession::getValue(__CLASS__.'_filters'))
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            $this->datagrid->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {

                    $row = $this->datagrid->addItem($object);
                    $row->id = "row_{$object->id}";

                }
            }

            // reset the criteria for record count
            $criteria->resetProperties();
            $count= $repository->count($criteria);

            $this->pageNavigation->setCount($count); // count of records
            $this->pageNavigation->setProperties($param); // order, page
            $this->pageNavigation->setLimit($this->limit); // limit

            // close the transaction
            TTransaction::close();
            $this->loaded = true;

            return $objects;
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

    /**
     * method show()
     * Shows the page
     */
    public function show()
    {
        // check if the datagrid is already loaded
        if (!$this->loaded AND (!isset($_GET['method']) OR !(in_array($_GET['method'],  $this->showMethods))) )
        {
            if (func_num_args() > 0)
            {
                $this->onReload( func_get_arg(0) );
            }
            else
            {
                $this->onReload();
            }
        }
        parent::show();
    }

    public static function manageRow($id, $param = [])
    {
        $list = new self($param);

        $openTransaction = TTransaction::getDatabase() != self::$database ? true : false;

        if($openTransaction)
        {
            TTransaction::open(self::$database);    
        }

        $object = new Procedimento($id);

        $row = $list->datagrid->addItem($object);
        $row->id = "row_{$object->id}";

        if($openTransaction)
        {
            TTransaction::close();    
        }

        TDataGrid::replaceRowById(__CLASS__.'_datagrid', $row->id, $row);
    }

}

