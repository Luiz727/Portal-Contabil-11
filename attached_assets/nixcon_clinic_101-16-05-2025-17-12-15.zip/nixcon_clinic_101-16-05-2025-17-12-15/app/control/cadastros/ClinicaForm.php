<?php

class ClinicaForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'Clinica';
    private static $primaryKey = 'id';
    private static $formName = 'form_Clinica';

    use Adianti\Base\AdiantiFileSaveTrait;
    use BuilderMasterDetailFieldListTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de clínica");

        $criteria_cidade_id = new TCriteria();
        $criteria_clinica_convenio_clinica_convenio_id = new TCriteria();
        $criteria_atendimento_categoria_conta_id = new TCriteria();
        $criteria_usuarios = new TCriteria();

        $filterVar = PermissaoService::getAccountId();
        $criteria_clinica_convenio_clinica_convenio_id->add(new TFilter('account_id', '=', $filterVar)); 
        $filterVar = TipoConta::RECEBER;
        $criteria_atendimento_categoria_conta_id->add(new TFilter('tipo_conta_id', '=', $filterVar)); 
        $filterVar = PermissaoService::getAccountId();
        $criteria_atendimento_categoria_conta_id->add(new TFilter('account_id', '=', $filterVar)); 
        $filterVar = AccountService::getId();
        $criteria_usuarios->add(new TFilter('account_id', '=', $filterVar)); 

        $id = new TEntry('id');
        $nome = new TEntry('nome');
        $razao_social = new TEntry('razao_social');
        $cnpj = new TEntry('cnpj');
        $button_ = new TButton('button_');
        $telefone = new TEntry('telefone');
        $email = new TEntry('email');
        $cep = new TEntry('cep');
        $button_buscar = new TButton('button_buscar');
        $cidade_id = new TDBUniqueSearch('cidade_id', 'clinica', 'Cidade', 'id', 'nome','nome asc' , $criteria_cidade_id );
        $bairro = new TEntry('bairro');
        $endereco = new TEntry('endereco');
        $numero = new TEntry('numero');
        $complemento = new TEntry('complemento');
        $logo_documento = new TFile('logo_documento');
        $logo_horizontal_grande = new TFile('logo_horizontal_grande');
        $clinica_convenio_clinica_id = new THidden('clinica_convenio_clinica_id[]');
        $clinica_convenio_clinica___row__id = new THidden('clinica_convenio_clinica___row__id[]');
        $clinica_convenio_clinica___row__data = new THidden('clinica_convenio_clinica___row__data[]');
        $clinica_convenio_clinica_convenio_id = new TDBCombo('clinica_convenio_clinica_convenio_id[]', 'clinica', 'Convenio', 'id', '{nome}','nome asc' , $criteria_clinica_convenio_clinica_convenio_id );
        $this->fieldList_60f6decfd616d = new TFieldList();
        $api_key = new TPassword('api_key');
        $whatsapp_config_id = new THidden('whatsapp_config_id');
        $api_token = new TPassword('api_token');
        $api_client_token = new TEntry('api_client_token');
        $phone = new TEntry('phone');
        $status = new TEntry('status');
        $device = new TEntry('device');
        $button_gerar_qrcode = new TButton('button_gerar_qrcode');
        $button_desconectar = new TButton('button_desconectar');
        $button_testar = new TButton('button_testar');
        $host = new TEntry('host');
        $email_config_id = new THidden('email_config_id');
        $smtp_auth = new TCombo('smtp_auth');
        $username = new TEntry('username');
        $password = new TPassword('password');
        $from_email = new TEntry('from_email');
        $from_name = new TEntry('from_name');
        $port = new TEntry('port');
        $button_testar1 = new TButton('button_testar1');
        $atendimento_categoria_conta_id = new TDBCombo('atendimento_categoria_conta_id', 'clinica', 'CategoriaConta', 'id', '{nome}','nome asc' , $criteria_atendimento_categoria_conta_id );
        $nfse_numero = new TEntry('nfse_numero');
        $nfse_serie = new TEntry('nfse_serie');
        $regime_tributacao = new TCombo('regime_tributacao');
        $certificado_a1_conteudo = new TFile('certificado_a1_conteudo');
        $senha_certificado_a1 = new TPassword('senha_certificado_a1');
        $nfse_emissao_producao = new TCheckButton('nfse_emissao_producao');
        $usuarios = new TCheckList('usuarios');

        $this->fieldList_60f6decfd616d->addField(null, $clinica_convenio_clinica_id, []);
        $this->fieldList_60f6decfd616d->addField(null, $clinica_convenio_clinica___row__id, ['uniqid' => true]);
        $this->fieldList_60f6decfd616d->addField(null, $clinica_convenio_clinica___row__data, []);
        $this->fieldList_60f6decfd616d->addField(new TLabel("Convênio", null, '14px', null), $clinica_convenio_clinica_convenio_id, ['width' => '100%']);

        $this->fieldList_60f6decfd616d->width = '100%';
        $this->fieldList_60f6decfd616d->setFieldPrefix('clinica_convenio_clinica');
        $this->fieldList_60f6decfd616d->name = 'fieldList_60f6decfd616d';

        $this->criteria_fieldList_60f6decfd616d = new TCriteria();
        $this->default_item_fieldList_60f6decfd616d = new stdClass();

        $this->form->addField($clinica_convenio_clinica_id);
        $this->form->addField($clinica_convenio_clinica___row__id);
        $this->form->addField($clinica_convenio_clinica___row__data);
        $this->form->addField($clinica_convenio_clinica_convenio_id);

        $this->fieldList_60f6decfd616d->setRemoveAction(null, 'fas:times #dd5a43', "Excluír");

        $nome->addValidation("nome", new TRequiredValidator()); 
        $razao_social->addValidation("Razão social", new TRequiredValidator()); 
        $cnpj->addValidation("CNPJ", new TRequiredValidator()); 
        $telefone->addValidation("Telefone", new TRequiredValidator()); 
        $email->addValidation("E-mail", new TRequiredValidator()); 
        $cep->addValidation("CEP", new TRequiredValidator()); 
        $cidade_id->addValidation("Cidade", new TRequiredValidator()); 
        $bairro->addValidation("Bairro", new TRequiredValidator()); 
        $endereco->addValidation("Endereço", new TRequiredValidator()); 
        $usuarios->addValidation("Usuários", new TRequiredValidator()); 
        $clinica_convenio_clinica_convenio_id->addValidation("Convênio", new TRequiredListValidator()); 

        $cidade_id->setMinLength(1);
        $nfse_emissao_producao->setValue('F');
        $nfse_emissao_producao->setUseSwitch(true, 'blue');
        $nfse_emissao_producao->setIndexValue("T");
        $nfse_emissao_producao->setInactiveIndexValue("F");
        $logo_documento->setTip("Apenas PNG");
        $logo_horizontal_grande->setTip("Apenas PNG");

        $logo_documento->setAllowedExtensions(["png"]);
        $logo_horizontal_grande->setAllowedExtensions(["png"]);

        $logo_documento->enableImageGallery('0', NULL);
        $logo_horizontal_grande->enableImageGallery('0', NULL);

        $api_key->enableToggleVisibility(true);
        $api_token->enableToggleVisibility(true);

        $smtp_auth->addItems(["T"=>"Sim","N"=>"Não"]);
        $regime_tributacao->addItems(["1"=>"Tributação no Município","2"=>"Tributação Fora do Município","3"=>"Isenção","4"=>"Imunidade","5"=>"Exportação de Serviços","6"=>" Não Incidência","7"=>" Exigibilidade Suspensa por Decisão Judicial","8"=>" Exigibilidade Suspensa por Processo Administrativo"]);

        $logo_documento->enableFileHandling();
        $logo_horizontal_grande->enableFileHandling();
        $certificado_a1_conteudo->enableFileHandling();

        $smtp_auth->enableSearch();
        $regime_tributacao->enableSearch();
        $atendimento_categoria_conta_id->enableSearch();

        $id->setEditable(false);
        $phone->setEditable(false);
        $status->setEditable(false);
        $device->setEditable(false);

        $cep->setMask('99.999-999');
        $cnpj->setMask('99.999.999/9999-99');
        $telefone->setMask('(99) 9 9999-9999');
        $cidade_id->setMask('{nome} - {estado->sigla}');

        $button_->setAction(new TAction([$this, 'onBuscarCNPJ']), "");
        $button_testar1->setAction(new TAction([$this, 'onTestarEnvioEmail']), "Testar");
        $button_testar->setAction(new TAction([$this, 'onTestarEnvioWhatsapp']), "Testar");
        $button_desconectar->setAction(new TAction([$this, 'onDesconectar']), "Desconectar");
        $button_buscar->setAction(new TAction([$this, 'onChangeCEP'],['static' => 1]), "Buscar");
        $button_gerar_qrcode->setAction(new TAction([$this, 'onGenerateQrCode']), "Gerar qrcode");

        $button_->addStyleClass('btn-default');
        $button_buscar->addStyleClass('btn-default');
        $button_testar->addStyleClass('btn-default');
        $button_testar1->addStyleClass('btn-default');
        $button_desconectar->addStyleClass('btn-default');
        $button_gerar_qrcode->addStyleClass('btn-default');

        $button_->setImage('fas:search #03A9F4');
        $button_buscar->setImage('fas:search #2196F3');
        $button_testar->setImage('fas:paper-plane #4CAF50');
        $button_gerar_qrcode->setImage('fas:qrcode #4CAF50');
        $button_testar1->setImage('fas:paper-plane #4CAF50');
        $button_desconectar->setImage('fas:power-off #F44336');

        $id->setSize(100);
        $nome->setSize('100%');
        $host->setSize('100%');
        $port->setSize('100%');
        $email->setSize('100%');
        $phone->setSize('100%');
        $bairro->setSize('100%');
        $numero->setSize('100%');
        $status->setSize('100%');
        $device->setSize('100%');
        $api_key->setSize('100%');
        $telefone->setSize('100%');
        $endereco->setSize('100%');
        $username->setSize('100%');
        $password->setSize('100%');
        $cidade_id->setSize('100%');
        $api_token->setSize('100%');
        $smtp_auth->setSize('100%');
        $from_name->setSize('100%');
        $from_email->setSize('100%');
        $nfse_serie->setSize('100%');
        $complemento->setSize('100%');
        $nfse_numero->setSize('100%');
        $razao_social->setSize('100%');
        $email_config_id->setSize(200);
        $logo_documento->setSize('100%');
        $whatsapp_config_id->setSize(200);
        $api_client_token->setSize('100%');
        $cnpj->setSize('calc(100% - 60px)');
        $cep->setSize('calc(100% - 120px)');
        $regime_tributacao->setSize('100%');
        $senha_certificado_a1->setSize('100%');
        $logo_horizontal_grande->setSize('100%');
        $certificado_a1_conteudo->setSize('100%');
        $atendimento_categoria_conta_id->setSize('100%');
        $clinica_convenio_clinica_convenio_id->setSize('100%');

        $usuarios->setIdColumn('id');

        $column_usuarios_name = $usuarios->addColumn('name', "Nome", 'left' , '50%');
        $column_usuarios_login = $usuarios->addColumn('login', "Login", 'left' , '50%');

        $usuarios->setHeight(250);
        $usuarios->makeScrollable();

        $usuarios->fillWith('clinica', 'SystemUsers', 'id', 'name asc' , $criteria_usuarios);

        $cnpj->addValidation("CNPJ", new TCNPJValidator()); 
        $email->addValidation("E-mail", new TEmailValidator()); 

        $this->form->appendPage("Dados cadastrais");

        $this->form->addFields([new THidden('current_tab')]);
        $this->form->setTabFunction("$('[name=current_tab]').val($(this).attr('data-current_page'));");

        $row1 = $this->form->addFields([new TLabel("Código:", null, '14px', null, '100%'),$id],[]);
        $row1->layout = ['col-sm-6','col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Nome Fantasia:", '#ff0000', '14px', null, '100%'),$nome],[new TLabel("Razão Social:", '#F44336', '14px', null, '100%'),$razao_social]);
        $row2->layout = [' col-sm-6',' col-sm-6'];

        $row3 = $this->form->addFields([new TLabel("CNPJ:", '#ff0000', '14px', null, '100%'),$cnpj,$button_],[new TLabel("Telefone:", '#ff0000', '14px', null, '100%'),$telefone],[new TLabel("E-mail:", '#ff0000', '14px', null, '100%'),$email]);
        $row3->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row4 = $this->form->addContent([new TFormSeparator("Endereço", '#333', '18', '#eee')]);
        $row5 = $this->form->addFields([new TLabel("CEP:", '#000000', '14px', null, '100%'),$cep,$button_buscar],[new TLabel("Cidade:", '#000000', '14px', null, '100%'),$cidade_id]);
        $row5->layout = [' col-sm-4',' col-sm-8'];

        $row6 = $this->form->addFields([new TLabel("Bairro:", '#000000', '14px', null, '100%'),$bairro],[new TLabel("Endereço:", '#000000', '14px', null, '100%'),$endereco]);
        $row6->layout = [' col-sm-4',' col-sm-8'];

        $row7 = $this->form->addFields([new TLabel("Número:", null, '14px', null, '100%'),$numero],[new TLabel("Complemento:", null, '14px', null, '100%'),$complemento]);
        $row7->layout = [' col-sm-4',' col-sm-8'];

        $row8 = $this->form->addContent([new TFormSeparator("Imagens", '#333', '18', '#eee')]);
        $row9 = $this->form->addFields([new TLabel("Logo para documentos ( tamanho preferencial:<small> 900px X 300px em .png</small>):", null, '14px', null, '100%'),$logo_documento]);
        $row9->layout = [' col-sm-12'];

        $row10 = $this->form->addFields([new TLabel("Logo para agendamento online ( tamanho preferencial:<small> 1200px X 400px em .png</small>):", null, '14px', null, '100%'),$logo_horizontal_grande]);
        $row10->layout = [' col-sm-12'];

        $this->form->appendPage("Convênios");
        $row11 = $this->form->addFields([$this->fieldList_60f6decfd616d]);
        $row11->layout = [' col-sm-12'];

        $this->form->appendPage("Email / Whatsapp");

        $whatsapp_container = new BContainer('whatsapp_container');
        $this->whatsapp_container = $whatsapp_container;

        $whatsapp_container->setTitle("Whatsapp", '#4CAF50', '13px', 'B', '#fff');
        $whatsapp_container->setBorderColor('#4CAF50');

        $row12 = $whatsapp_container->addFields([new TLabel("ID:", null, '14px', null),$api_key,$whatsapp_config_id],[new TLabel("Token:", null, '14px', null),$api_token]);
        $row12->layout = ['col-sm-6','col-sm-6'];

        $row13 = $whatsapp_container->addFields([new TLabel("Client Token:", null, '14px', null, '100%'),$api_client_token],[]);
        $row13->layout = ['col-sm-6','col-sm-6'];

        $row14 = $whatsapp_container->addFields([new TLabel("Número:", null, '14px', null),$phone],[new TLabel("Status:", null, '14px', null),$status],[new TLabel("Device:", null, '14px', null),$device]);
        $row14->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row15 = $whatsapp_container->addFields([new TLabel("Conexão:", null, '14px', null, '100%'),$button_gerar_qrcode,$button_desconectar,$button_testar]);
        $row15->layout = [' col-sm-12'];

        $row16 = $this->form->addFields([$whatsapp_container]);
        $row16->layout = [' col-sm-12'];

        $mail_container = new BContainer('mail_container');
        $this->mail_container = $mail_container;

        $mail_container->setTitle("E-mail", '#F44336', '13px', 'B', '#fff');
        $mail_container->setBorderColor('#F44336');

        $row17 = $mail_container->addFields([new TLabel("Host:", null, '14px', null),$host,$email_config_id],[new TLabel("Autenticar SMTP:", null, '14px', null),$smtp_auth],[new TLabel("Usuário:", null, '14px', null),$username],[new TLabel("Senha:", null, '14px', null),$password]);
        $row17->layout = [' col-sm-3',' col-sm-3',' col-sm-3',' col-sm-3'];

        $row18 = $mail_container->addFields([new TLabel("E-mail origem", null, '14px', null),$from_email],[new TLabel("Nome origem", null, '14px', null),$from_name],[new TLabel("Porta:", null, '14px', null),$port],[new TLabel(" ", null, '14px', null, '100%'),$button_testar1]);
        $row18->layout = [' col-sm-3',' col-sm-3','col-sm-3',' col-sm-3'];

        $row19 = $this->form->addFields([$mail_container]);
        $row19->layout = [' col-sm-12'];

        $this->form->appendPage("Fiscal / Financeiro");
        $row20 = $this->form->addContent([new TFormSeparator("Configurações Financeiro", '#333', '18', '#eee')]);
        $row21 = $this->form->addFields([new TLabel("Categoria padrão de contas a receber para atendimentos realizados:", null, '14px', null, '100%'),$atendimento_categoria_conta_id]);
        $row21->layout = [' col-sm-12'];

        $row22 = $this->form->addFields([new TFormSeparator("Configurações NFS-e", '#333', '18', '#eee')]);
        $row22->layout = [' col-sm-12'];

        $row23 = $this->form->addFields([new TLabel("Número da última NFS-e:", null, '14px', null, '100%'),$nfse_numero],[new TLabel("Série da NFS-e:", null, '14px', null, '100%'),$nfse_serie],[new TLabel("Regime de tributação:", null, '14px', null, '100%'),$regime_tributacao]);
        $row23->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row24 = $this->form->addFields([new TLabel("Certificado A1:", null, '14px', null, '100%'),$certificado_a1_conteudo],[new TLabel("Senha do Certificado A1:", null, '14px', null, '100%'),$senha_certificado_a1]);
        $row24->layout = [' col-sm-6','col-sm-6'];

        $row25 = $this->form->addFields([new TLabel("Envio de NFS-e em produção", null, '14px', null, '100%'),$nfse_emissao_producao]);
        $row25->layout = ['col-sm-6'];

        $this->form->appendPage("Permissões");
        $row26 = $this->form->addContent([new TFormSeparator("Usuários com permissão para esta clínica:", '#333', '18', '#eee')]);
        $row27 = $this->form->addFields([$usuarios]);
        $row27->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave'],['static' => 1]), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['ClinicaList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=ClinicaForm]');
        $style->width = '70% !important';   
        $style->show(true);

    }

    public static function onBuscarCNPJ($param = null) 
    {
        try 
        {

            TTransaction::open(self::$database);
            $dados = CNPJService::get($param['cnpj']);
            TTransaction::close();

            $object = new stdClass();

            // dados principais
            $object->nome = $dados->razao_social;
            $object->razao_social = $dados->razao_social;
            $object->telefone = $dados->ddd_telefone_1;

            // dados relacionados ao endereço
            $object->cep = $dados->cep;
            $object->endereco = $dados->logradouro;
            $object->bairro = $dados->bairro;
            $object->numero = $dados->numero;
            $object->complemento = $dados->complemento;
            $object->cidade_id = $dados->cidade_id;

            TForm::sendData(self::$formName, $object);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onChangeCEP($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);
            $dadosCEP = CEPService::get($param['cep']);
            TTransaction::close();

            $data = new stdClass;
            $data->cidade_id = $dadosCEP->cidade_id;
            $data->bairro = $dadosCEP->bairro;
            $data->endereco = $dadosCEP->rua;

            TForm::sendData(self::$formName, $data);

        }
        catch (Exception $e) 
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onGenerateQrCode($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            if (empty($param['whatsapp_config_id']))
            {
                throw new Exception('Salve as configurações de whastapp antes');
            }

            $whatsappConfig = WhatsappConfig::find($param['whatsapp_config_id']);
            $cliente = new WhatsAppClient($whatsappConfig);

            $image = $cliente->getQrCode();

            $window = TWindow::create('QR Code', 500, null);
            $window->add(TElement::tag('div', '', ['style' => "background-image: url({$image});", 'id' => 'qrcode']));
            $window->setCloseAction(new TAction([__CLASS__, 'refreshStatus'], $param));
            $window->show();

            TTransaction::close();

        }
        catch (Exception $e) 
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onDesconectar($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            if (empty($param['whatsapp_config_id']))
            {
                throw new Exception('Salve as configurações de whastapp antes');
            }

            $whatsappConfig = WhatsappConfig::find($param['whatsapp_config_id']);
            $cliente = new WhatsAppClient($whatsappConfig);

            $image = $cliente->disconnect();
            $data = (object) ['status' => 'Não conectado', 'phone' => ''];

            TForm::sendData(self::$formName, $data);

            TTransaction::close();

        }
        catch (Exception $e) 
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onTestarEnvioWhatsapp($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            if (empty($param['whatsapp_config_id']))
            {
                throw new Exception('Salve as configurações de WhatsApp antes');
            }

            $whastappConfig = WhatsappConfig::find($param['whatsapp_config_id']);

            if (! empty($param['enviar']) && $param['enviar'] == 'T' && ! empty($param['to']))
            {
                $cliente = new WhatsAppClient($whastappConfig);

                $cliente->testarEnvio($param['to']);

                TToast::show('success', 'Mensagem de teste enviada');
            }
            else
            {
                $form = new BootstrapFormBuilder('input_form');
                $form->setFieldSizes('100%');
                $to  = new TEntry('to');
                $to->placeholder = 'ex: ' . $whastappConfig->phone;

                $form->addFields( [new TLabel('Número', null, null, null, '100%'), $to]);
                $param['enviar'] = 'T';
                $form->addAction('Enviar', new TAction([__CLASS__, 'onTestarEnvioWhatsapp'], $param), 'fas:paper-plane #4CAF50');

                // show the input dialog
                new TInputDialog('Enviar teste', $form);
            }

            TTransaction::close();

        }
        catch (Exception $e) 
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onTestarEnvioEmail($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            if (empty($param['email_config_id']))
            {
                throw new Exception('Salve as configurações de e-mail antes');
            }

            $emailConfig = EmailConfig::find($param['email_config_id']);

            if (! empty($param['enviar']) && $param['enviar'] == 'T' && ! empty($param['to']))
            {
                $cliente = new EmailClient($emailConfig);

                $cliente->testarEnvio($param['to']);

                TToast::show('success', 'E-mail de teste enviado');
            }
            else
            {
                $form = new BootstrapFormBuilder('input_form');
                $form->setFieldSizes('100%');

                $to  = new TEntry('to');
                $to->setValue($emailConfig->from_email);

                $form->addFields( [new TLabel('E-mail', null, null, null, '100%'), $to]);
                $param['enviar'] = 'T';
                $form->addAction('Enviar', new TAction([__CLASS__, 'onTestarEnvioEmail'], $param), 'fas:paper-plane #4CAF50');

                // show the input dialog
                new TInputDialog('Enviar teste', $form);
            }

            TTransaction::close();

        }
        catch (Exception $e) 
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Clinica(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $logo_documento_dir = 'app/clinicas/logo_documentos';
            $logo_horizontal_grande_dir = 'app/clinicas/logo_publico';  

            $object->store(); // save the object 

            // sempre edita a unidade com mesmo id da clinica
            $systemUnit = new SystemUnit();
            $systemUnit->id = $object->id;
            $systemUnit->name = $object->nome;
            $systemUnit->account_id = AccountService::getId();
            $systemUnit->active = 'T';
            $systemUnit->store();

            $object->system_unit_id = $systemUnit->id;
            $object->store();

            if(!$data->id)
            {
                $countUnidades = SystemUnit::where('account_id', '=', PermissaoService::getAccountId())->count();

                if($countUnidades >= PermissaoService::getLimiteUnidades())
                {
                    throw new Exception(" Não é possível criar uma nova clínica pois você atingiu o limite do seu plano. ");
                }
            }

            if($data->id)
            {

                $dbUnit = SystemUnit::find($data->id);
                if($dbUnit && $dbUnit->account_id != PermissaoService::getAccountId())
                {
                    throw new Exception('Permissão negada');
                }
            }

            if ($data->usuarios) 
            {
                foreach ($data->usuarios as $usuario_id) 
                {
                    $user = new SystemUsers($usuario_id);

                    if($user->account_id != PermissaoService::getAccountId())
                    {
                        throw new Exception('Permissão negada!');
                    }
                }
            }

            $repository = SystemUserUnit::where('system_unit_id', '=', $object->id);
            $repository->delete(); 

            if ($data->usuarios) 
            {
                foreach ($data->usuarios as $usuarios_value) 
                {
                    $system_user_unit = new SystemUserUnit;

                    $system_user_unit->system_user_id = $usuarios_value;
                    $system_user_unit->system_unit_id = $object->id;
                    $system_user_unit->store();
                }
            }

            if(!$data->id && !$data->whatsapp_config_id)
            {
                PermissaoService::enableNewUnit();
            }
            $whatsappConfig = new WhatsappConfig();
            $whatsappConfig->id = $data->whatsapp_config_id ?? null;
            $whatsappConfig->clinica_id = $object->id; 
            $whatsappConfig->phone = $data->phone; 
            $whatsappConfig->status = $data->status; 
            $whatsappConfig->api_token = $data->api_token; 
            $whatsappConfig->api_key = $data->api_key; 
            $whatsappConfig->api_client_token = $data->api_client_token; 
            $whatsappConfig->store();

            PermissaoService::disableNewUnit();

            if(!$data->id && !$data->email_config_id)
            {
                PermissaoService::enableNewUnit();
            }

            $emailConfig = new EmailConfig($data->email_config_id ?? null);
            $emailConfig->clinica_id = $object->id;
            $emailConfig->port = $data->port;
            $emailConfig->username = $data->username;
            $emailConfig->password = $data->password;
            $emailConfig->host = $data->host;
            $emailConfig->from_email = $data->from_email;
            $emailConfig->from_name = $data->from_name;
            $emailConfig->smtp_auth = $data->smtp_auth;
            $emailConfig->store();

            PermissaoService::disableNewUnit();

            $data->email_config_id = $emailConfig->id;
            $data->whatsapp_config_id = $whatsappConfig->id;

            $this->saveFile($object, $data, 'logo_documento', $logo_documento_dir);
            $this->saveFile($object, $data, 'logo_horizontal_grande', $logo_horizontal_grande_dir);
            $this->saveBinaryFile($object, $data, 'certificado_a1_conteudo', 'email');
            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            $clinica_convenio_clinica_items = $this->storeItems('ClinicaConvenio', 'clinica_id', $object, $this->fieldList_60f6decfd616d, function($masterObject, $detailObject){ 

                //code here

            }, $this->criteria_fieldList_60f6decfd616d); 

            $novaClinica = false;
            if(!$data->id)
            {
                $novaClinica = true;
                ClinicaService::criaTemplatesPadroes($object->id);
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data

            $clinica = new Clinica($object->id);

            if(!$clinica->token)
            {
                $token = TextService::slug($clinica->nome);

                if(Clinica::where('token', '=', $token)->first())
                {
                    $token = $token.uniqid();
                }

                $clinica->token = $token;
                $clinica->store();
            }

            TTransaction::close(); // close the transaction

            if($clinica->certificado_a1_conteudo && $clinica->senha_certificado_a1)
            {
                TTransaction::open(self::$database);

                $clinicaConfig = new Clinica($object->id);
                $clinicaConfig->nfse_emissao_producao = 'T';

                $gateway = ClinicaConfiguracaoService::getGatewayNFSE($clinicaConfig);
                $gateway->atualizaCertificadoEmitente([
                    'certificado' => $clinica->certificado_a1_conteudo,
                    'senha' => $clinica->senha_certificado_a1
                ]);

                TTransaction::close();
            }

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('ClinicaList', 'onShow', $loadPageParam); 

            TForm::sendData(self::$formName, (object)['id' => $object->id]);

            TForm::sendData(self::$formName, (object)[
                'email_config_id' => $emailConfig->id, 
                'whatsapp_config_id' => $whatsappConfig->id, 
            ]);

            if($novaClinica)
            {
                PermissaoService::atualizarPermissoes();
            }

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage() ); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Clinica($key); // instantiates the Active Record 

                $this->loadBinaryFile($object, 'certificado_a1_conteudo', 'email'); 

                $this->fieldList_60f6decfd616d_items = $this->loadItems('ClinicaConvenio', 'clinica_id', $object, $this->fieldList_60f6decfd616d, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }, $this->criteria_fieldList_60f6decfd616d); 
                $id = $object->id;

                $data = $object->toArray();

                $whatsappConfig = WhatsappConfig::where('clinica_id', '=', $id)->first();
                $emailConfig = EmailConfig::where('clinica_id', '=', $id)->first();

                if ($whatsappConfig && $emailConfig)
                {
                    $data['whatsapp_config_id'] = $whatsappConfig->id;
                    $data['email_config_id'] = $emailConfig->id;

                    $whatsappConfig = WhatsappConfig::find($data['whatsapp_config_id']);

                    if(!empty($whatsappConfig->api_token) && !empty($whatsappConfig->api_key))
                    {
                        try 
                        {
                            $cliente = new WhatsAppClient($whatsappConfig);

                            $whatsappConfig->status = $cliente->getStatus();
                            $whatsappConfig->phone = $cliente->getNumber();
                            $whatsappConfig->store();    
                        } 
                        catch (Exception $e) 
                        {
                            $whatsappConfig->phone = '';
                            $whatsappConfig->status = 'Não conectado';
                            $whatsappConfig->store();
                        }
                    }

                    $data = array_merge($data, $whatsappConfig->toArray(), $emailConfig->toArray());
                }
                else
                {
                    TScript::create("$('#qrcode').closest('.tformrow').hide()");
                }

                $data['id'] = $id;

                $object = (object)  $data;

                $criteria = new TCriteria();
                $criteria->add(new TFilter('system_unit_id', '=', $object->id));
                $usuarios = SystemUserUnit::getIndexedArray('system_user_id', 'system_user_id', $criteria);

                $object->usuarios = $usuarios;

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        $this->fieldList_60f6decfd616d->addHeader();
        $this->fieldList_60f6decfd616d->addDetail($this->default_item_fieldList_60f6decfd616d);

        $this->fieldList_60f6decfd616d->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

    }

    public function onShow($param = null)
    {
        $this->fieldList_60f6decfd616d->addHeader();
        $this->fieldList_60f6decfd616d->addDetail($this->default_item_fieldList_60f6decfd616d);

        $this->fieldList_60f6decfd616d->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        try
        {

            TTransaction::open(self::$database); // open a transaction

            $object = Clinica::where('system_unit_id', '=', TSession::getValue('userunitid')); // instantiates the Active Record

            TTransaction::close(); // close the transaction 
            if ($object)
            {
                if(isset($object->nfse_info))
                {
                    $this->form->setData((object) json_encode($object->nfse_info)); // fill the form
                }
            }
            else
            {
                $this->form->clear();
            }

        }
        catch(Exception $e)
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    } 

    public static function getFormName()
    {
        return self::$formName;
    }

    public static function refreshStatus($param)
    {
        try
        {
            TTransaction::open(self::$database);

            $wc = WhatsappConfig::find($param['whatsapp_config_id']);
            $cliente = new WhatsAppClient($wc);
            $wc->status = $cliente->getStatus();
            $wc->phone = $cliente->getNumber();
            $wc->store();

            $data = (object) ['status' => $wc->status, 'phone' => $wc->number];

            TForm::sendData(self::$formName, $data);

            TTransaction::close();
        }
        catch(Exception $e)
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());
        }
        finally
        {
            TWindow::closeWindow();
        }
    }

}

