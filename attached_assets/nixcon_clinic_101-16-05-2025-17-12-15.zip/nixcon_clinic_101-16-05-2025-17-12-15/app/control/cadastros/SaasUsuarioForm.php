<?php

class SaasUsuarioForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'clinica';
    private static $activeRecord = 'SystemUsers';
    private static $primaryKey = 'id';
    private static $formName = 'form_UsuarioForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de usuário");

        $criteria_system_unit_id = new TCriteria();
        $criteria_unidades = new TCriteria();
        $criteria_grupos_permissao = new TCriteria();

        $filterVar = AccountService::getId();
        $criteria_system_unit_id->add(new TFilter('account_id', '=', $filterVar)); 
        $filterVar = AccountService::getId();
        $criteria_unidades->add(new TFilter('account_id', '=', $filterVar)); 
        $filterVar = AccountService::getGroupsByAccount(TSession::getValue('contrato_id'));
        $criteria_grupos_permissao->add(new TFilter('id', 'in', $filterVar)); 

        $name = new TEntry('name');
        $id = new THidden('id');
        $login = new TEntry('login');
        $labelSenha = new TLabel("Senha:", '#FF0000', '14px', null, '100%');
        $password = new TPassword('password');
        $labelConfirmaSenha = new TLabel("Confirmar senha:", '#FF0000', '14px', null, '100%');
        $repassword = new TPassword('repassword');
        $active = new TCheckButton('active');
        $system_unit_id = new TDBCombo('system_unit_id', 'clinica', 'SystemUnit', 'id', '{name}','name asc' , $criteria_system_unit_id );
        $unidades = new TDBCheckGroup('unidades', 'clinica', 'SystemUnit', 'id', '{name}','name asc' , $criteria_unidades );
        $grupos_permissao = new TDBCheckGroup('grupos_permissao', 'clinica', 'SystemGroup', 'id', '{name}','name asc' , $criteria_grupos_permissao );

        $name->addValidation("Name", new TRequiredValidator()); 
        $login->addValidation("Login", new TRequiredValidator()); 
        $system_unit_id->addValidation("Unidade principal", new TRequiredValidator()); 
        $unidades->addValidation("Unidades que o usuário terá acesso", new TRequiredValidator()); 

        $active->setValue('Y');
        $active->setUseSwitch(true, 'blue');
        $active->setIndexValue("Y");
        $active->setInactiveIndexValue("N");
        $system_unit_id->enableSearch();
        $unidades->setBreakItems(2);
        $unidades->setLayout('horizontal');
        $grupos_permissao->setLayout('vertical');

        $id->setSize(200);
        $name->setSize('100%');
        $login->setSize('100%');
        $password->setSize('100%');
        $unidades->setSize('100%');
        $repassword->setSize('100%');
        $system_unit_id->setSize('100%');
        $grupos_permissao->setSize('100%');

        $this->labelSenha = $labelSenha;
        $this->labelConfirmaSenha = $labelConfirmaSenha;

        $row1 = $this->form->addFields([new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$name,$id],[new TLabel("Email:", '#ff0000', '14px', null, '100%'),$login,new TLabel("O email será utilizado como o login do usuário", null, '11px', null)]);
        $row1->layout = ['col-sm-6','col-sm-6'];

        $row2 = $this->form->addFields([$labelSenha,$password],[$labelConfirmaSenha,$repassword]);
        $row2->layout = ['col-sm-6',' col-sm-6'];

        $row3 = $this->form->addFields([new TLabel("Ativo:", null, '14px', null, '100%'),$active]);
        $row3->layout = ['col-sm-6'];

        $tab_654a8074828db = new BootstrapFormBuilder('tab_654a8074828db');
        $this->tab_654a8074828db = $tab_654a8074828db;
        $tab_654a8074828db->setProperty('style', 'border:none; box-shadow:none;');

        $tab_654a8074828db->appendPage("Unidades");

        $tab_654a8074828db->addFields([new THidden('current_tab_tab_654a8074828db')]);
        $tab_654a8074828db->setTabFunction("$('[name=current_tab_tab_654a8074828db]').val($(this).attr('data-current_page'));");

        $row4 = $tab_654a8074828db->addFields([new TLabel("<b>Obs.:</b> <small>O usuário precisará realizar um logout e login na plataforma para que as permissões entrem em vigor</small>", null, '14px', null, '100%')]);
        $row4->layout = [' col-sm-12'];

        $row5 = $tab_654a8074828db->addFields([new TLabel("Unidade principal:", '#FF0000', '14px', null, '100%'),$system_unit_id]);
        $row5->layout = [' col-sm-12'];

        $row6 = $tab_654a8074828db->addFields([new TLabel("Unidades que o usuário terá acesso:", null, '14px', null, '100%'),$unidades]);
        $row6->layout = [' col-sm-12'];

        $tab_654a8074828db->appendPage("Grupos de permissão");
        $row7 = $tab_654a8074828db->addFields([new TLabel("<b>Obs.:</b> <small>O usuário precisará realizar um logout e login na plataforma para que as permissões entrem em vigor</small>", null, '14px', null, '100%'),$grupos_permissao]);
        $row7->layout = [' col-sm-12'];

        $row8 = $this->form->addFields([$tab_654a8074828db]);
        $row8->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new SystemUsers(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $senha = $object->password;

            // if( empty($object->login) )
            // {
            //     throw new Exception(TAdiantiCoreTranslator::translate('The field ^1 is required', _t('CPF')));
            // }

            $object->email = $object->login;
            $object->account_id = AccountService::getId();

            if( empty($object->id) )
            {
                if(SystemUsers::where('login', '=', $object->login)->first())
                {
                    throw new Exception('O email informado para o usuário já está em utilização, informe outro! ');
                }

                if ( empty($object->password) )
                {
                    throw new Exception('O campo senha é obrigatório');
                }

                $object->active = 'Y';

                $countUsers = SystemUsers::where('account_id', '=', AccountService::getId())->count();

                if($countUsers >= PermissaoService::getLimiteUsuarios())
                {
                    throw new Exception(" Não é possível criar um novo usuários pois você atingiu o limite do seu plano. ");
                }
            }
            else
            {
                unset($object->login);
                unset($object->email);
            }

            if( $object->password )
            {
                if( $object->password !== $param['repassword'] )
                {
                    throw new Exception('As senhas informadas não conferem!');
                }

                $object->password = md5($object->password);
            }
            else
            {
                unset($object->password);
            }

            // var_dump($object->system_unit_id, PermissaoService::getUnidadeIds());
            // if(!in_array($object->system_unit_id, PermissaoService::getUnidadeIds()))
            // {
            //     throw new Exception('Permissão negada');
            // }

            // if ($data->unidades) 
            // {
            //     foreach ($data->unidades as $value) 
            //     {
            //         if(!in_array($value, PermissaoService::getUnidadeIds()))
            //         {
            //             throw new Exception('Permissão negada');
            //         }
            //     }
            // }

            $gruposPermissaoAccount = AccountService::getGroupsByAccount(TSession::getValue('contrato_id'));

            if ($data->grupos_permissao) 
            {
                foreach ($data->grupos_permissao as $value) 
                {
                    if(!in_array($value, $gruposPermissaoAccount))
                    {
                        throw new Exception('Permissão negada');
                    }
                }
            }

            $object->store(); // save the object 

            $repository = SystemUserUnit::where('system_user_id', '=', $object->id);
            $repository->delete(); 

            if ($data->unidades) 
            {
                foreach ($data->unidades as $unidades_value) 
                {
                    $system_user_unit = new SystemUserUnit;

                    $system_user_unit->system_unit_id = $unidades_value;
                    $system_user_unit->system_user_id = $object->id;
                    $system_user_unit->store();
                }
            }

            $repository = SystemUserGroup::where('system_user_id', '=', $object->id);
            $repository->delete(); 

            if ($data->grupos_permissao) 
            {
                foreach ($data->grupos_permissao as $grupos_permissao_value) 
                {
                    $system_user_group = new SystemUserGroup;

                    $system_user_group->system_group_id = $grupos_permissao_value;
                    $system_user_group->system_user_id = $object->id;
                    $system_user_group->store();
                }
            }

            $messageAction = new TAction(['SaasUsuarioList', 'onShow']);   

            if(!empty($param['target_container']))
            {
                $messageAction->setParameter('target_container', $param['target_container']);
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            new TMessage('info', "Registro salvo", $messageAction); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {

                $this->labelSenha->setFontColor('#333333');
                $this->labelConfirmaSenha->setFontColor('#333333');
                $this->form->getField('login')->setEditable(false);

                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new SystemUsers($key); // instantiates the Active Record 

                if($object->account_id != PermissaoService::getAccountId())
                {
                    throw new Exception('Permissão negada');
                }

                $object->unidades = SystemUserUnit::where('system_user_id', '=', $object->id)->getIndexedArray('system_unit_id', 'system_unit_id');

                $object->grupos_permissao = SystemUserGroup::where('system_user_id', '=', $object->id)->getIndexedArray('system_group_id', 'system_group_id');

                unset($object->password);

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

