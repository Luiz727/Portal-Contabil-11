<?php

class SystemDocumentForm extends TPage
{
    protected $form; // form
    

    public function __construct( $param )
    {
        parent::__construct();
        
    }

}
