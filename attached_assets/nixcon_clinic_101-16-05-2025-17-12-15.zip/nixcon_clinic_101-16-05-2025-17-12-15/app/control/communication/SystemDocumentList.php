<?php

class SystemDocumentList extends TPage
{
   
    public function __construct()
    {
        parent::__construct();
    }
}
