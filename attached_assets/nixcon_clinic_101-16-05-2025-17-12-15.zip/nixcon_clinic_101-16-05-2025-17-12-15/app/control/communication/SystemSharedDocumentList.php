<?php

class SystemSharedDocumentList extends TPage
{
   
    public function __construct()
    {
        parent::__construct();
    }
    
}
