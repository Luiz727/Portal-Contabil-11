<?php

class SystemDocumentUploadForm extends TPage
{
   
    public function __construct( $param )
    {
        parent::__construct();
    }
}
