<?php

class Pessoa extends TRecord
{
    const TABLENAME  = 'pessoa';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SystemUsers $system_users;
    private Clinica $clinica;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByUnit');
    
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
            
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('clinica_id');
        parent::addAttribute('nome');
        parent::addAttribute('documento');
        parent::addAttribute('email');
        parent::addAttribute('telefone');
        parent::addAttribute('system_users_id');
        parent::addAttribute('sexo');
        parent::addAttribute('nome_civel');
        parent::addAttribute('rg');
        parent::addAttribute('dt_nascimento');
        parent::addAttribute('profissao');
        parent::addAttribute('tratamento');
        parent::addAttribute('observacao');
        parent::addAttribute('assinatura');
        parent::addAttribute('usuario');
        parent::addAttribute('senha');
        parent::addAttribute('foto');
        parent::addAttribute('aceita_receber_mensagen_whatsapp');
    
    }

    /**
     * Method set_system_users
     * Sample of usage: $var->system_users = $object;
     * @param $object Instance of SystemUsers
     */
    public function set_system_users(SystemUsers $object)
    {
        $this->system_users = $object;
        $this->system_users_id = $object->id;
    }

    /**
     * Method get_system_users
     * Sample of usage: $var->system_users->attribute;
     * @returns SystemUsers instance
     */
    public function get_system_users()
    {
    
        // loads the associated object
        if (empty($this->system_users))
            $this->system_users = new SystemUsers($this->system_users_id);
    
        // returns the associated object
        return $this->system_users;
    }
    /**
     * Method set_clinica
     * Sample of usage: $var->clinica = $object;
     * @param $object Instance of Clinica
     */
    public function set_clinica(Clinica $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns Clinica instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new Clinica($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }

    /**
     * Method getAgendas
     */
    public function getAgendas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('profissional_id', '=', $this->id));
        return Agenda::getObjects( $criteria );
    }
    /**
     * Method getAgendamentos
     */
    public function getAgendamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('paciente_id', '=', $this->id));
        return Agendamento::getObjects( $criteria );
    }
    /**
     * Method getAgendaProfissionals
     */
    public function getAgendaProfissionals()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('profissional_id', '=', $this->id));
        return AgendaProfissional::getObjects( $criteria );
    }
    /**
     * Method getAtendimentos
     */
    public function getAtendimentosByPacientes()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('paciente_id', '=', $this->id));
        return Atendimento::getObjects( $criteria );
    }
    /**
     * Method getAtendimentos
     */
    public function getAtendimentosByProfissionals()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('profissional_id', '=', $this->id));
        return Atendimento::getObjects( $criteria );
    }
    /**
     * Method getContas
     */
    public function getContas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('pessoa_id', '=', $this->id));
        return Conta::getObjects( $criteria );
    }
    /**
     * Method getNotaFiscalServicos
     */
    public function getNotaFiscalServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('cliente_id', '=', $this->id));
        return NotaFiscalServico::getObjects( $criteria );
    }
    /**
     * Method getPessoaEnderecos
     */
    public function getPessoaEnderecos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('pessoa_id', '=', $this->id));
        return PessoaEndereco::getObjects( $criteria );
    }
    /**
     * Method getPessoaEspecialidades
     */
    public function getPessoaEspecialidades()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('pessoa_id', '=', $this->id));
        return PessoaEspecialidade::getObjects( $criteria );
    }
    /**
     * Method getPessoaGrupos
     */
    public function getPessoaGrupos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('pessoa_id', '=', $this->id));
        return PessoaGrupo::getObjects( $criteria );
    }

    public function set_agenda_clinica_to_string($agenda_clinica_to_string)
    {
        if(is_array($agenda_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $agenda_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_clinica_to_string = $agenda_clinica_to_string;
        }

        $this->vdata['agenda_clinica_to_string'] = $this->agenda_clinica_to_string;
    }

    public function get_agenda_clinica_to_string()
    {
        if(!empty($this->agenda_clinica_to_string))
        {
            return $this->agenda_clinica_to_string;
        }
    
        $values = Agenda::where('profissional_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_agenda_profissional_to_string($agenda_profissional_to_string)
    {
        if(is_array($agenda_profissional_to_string))
        {
            $values = Pessoa::where('id', 'in', $agenda_profissional_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_profissional_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_profissional_to_string = $agenda_profissional_to_string;
        }

        $this->vdata['agenda_profissional_to_string'] = $this->agenda_profissional_to_string;
    }

    public function get_agenda_profissional_to_string()
    {
        if(!empty($this->agenda_profissional_to_string))
        {
            return $this->agenda_profissional_to_string;
        }
    
        $values = Agenda::where('profissional_id', '=', $this->id)->getIndexedArray('profissional_id','{profissional->nome}');
        return implode(', ', $values);
    }

    public function set_agenda_procedimento_to_string($agenda_procedimento_to_string)
    {
        if(is_array($agenda_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $agenda_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_procedimento_to_string = $agenda_procedimento_to_string;
        }

        $this->vdata['agenda_procedimento_to_string'] = $this->agenda_procedimento_to_string;
    }

    public function get_agenda_procedimento_to_string()
    {
        if(!empty($this->agenda_procedimento_to_string))
        {
            return $this->agenda_procedimento_to_string;
        }
    
        $values = Agenda::where('profissional_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_paciente_to_string($agendamento_paciente_to_string)
    {
        if(is_array($agendamento_paciente_to_string))
        {
            $values = Pessoa::where('id', 'in', $agendamento_paciente_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_paciente_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_paciente_to_string = $agendamento_paciente_to_string;
        }

        $this->vdata['agendamento_paciente_to_string'] = $this->agendamento_paciente_to_string;
    }

    public function get_agendamento_paciente_to_string()
    {
        if(!empty($this->agendamento_paciente_to_string))
        {
            return $this->agendamento_paciente_to_string;
        }
    
        $values = Agendamento::where('paciente_id', '=', $this->id)->getIndexedArray('paciente_id','{paciente->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_estado_agenda_to_string($agendamento_estado_agenda_to_string)
    {
        if(is_array($agendamento_estado_agenda_to_string))
        {
            $values = EstadoAgenda::where('id', 'in', $agendamento_estado_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_estado_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_estado_agenda_to_string = $agendamento_estado_agenda_to_string;
        }

        $this->vdata['agendamento_estado_agenda_to_string'] = $this->agendamento_estado_agenda_to_string;
    }

    public function get_agendamento_estado_agenda_to_string()
    {
        if(!empty($this->agendamento_estado_agenda_to_string))
        {
            return $this->agendamento_estado_agenda_to_string;
        }
    
        $values = Agendamento::where('paciente_id', '=', $this->id)->getIndexedArray('estado_agenda_id','{estado_agenda->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_agenda_to_string($agendamento_agenda_to_string)
    {
        if(is_array($agendamento_agenda_to_string))
        {
            $values = Agenda::where('id', 'in', $agendamento_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_agenda_to_string = $agendamento_agenda_to_string;
        }

        $this->vdata['agendamento_agenda_to_string'] = $this->agendamento_agenda_to_string;
    }

    public function get_agendamento_agenda_to_string()
    {
        if(!empty($this->agendamento_agenda_to_string))
        {
            return $this->agendamento_agenda_to_string;
        }
    
        $values = Agendamento::where('paciente_id', '=', $this->id)->getIndexedArray('agenda_id','{agenda->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_clinica_to_string($agendamento_clinica_to_string)
    {
        if(is_array($agendamento_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $agendamento_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_clinica_to_string = $agendamento_clinica_to_string;
        }

        $this->vdata['agendamento_clinica_to_string'] = $this->agendamento_clinica_to_string;
    }

    public function get_agendamento_clinica_to_string()
    {
        if(!empty($this->agendamento_clinica_to_string))
        {
            return $this->agendamento_clinica_to_string;
        }
    
        $values = Agendamento::where('paciente_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_especialidade_to_string($agendamento_especialidade_to_string)
    {
        if(is_array($agendamento_especialidade_to_string))
        {
            $values = Especialidade::where('id', 'in', $agendamento_especialidade_to_string)->getIndexedArray('descricao', 'descricao');
            $this->agendamento_especialidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_especialidade_to_string = $agendamento_especialidade_to_string;
        }

        $this->vdata['agendamento_especialidade_to_string'] = $this->agendamento_especialidade_to_string;
    }

    public function get_agendamento_especialidade_to_string()
    {
        if(!empty($this->agendamento_especialidade_to_string))
        {
            return $this->agendamento_especialidade_to_string;
        }
    
        $values = Agendamento::where('paciente_id', '=', $this->id)->getIndexedArray('especialidade_id','{especialidade->descricao}');
        return implode(', ', $values);
    }

    public function set_agenda_profissional_profissional_to_string($agenda_profissional_profissional_to_string)
    {
        if(is_array($agenda_profissional_profissional_to_string))
        {
            $values = Pessoa::where('id', 'in', $agenda_profissional_profissional_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_profissional_profissional_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_profissional_profissional_to_string = $agenda_profissional_profissional_to_string;
        }

        $this->vdata['agenda_profissional_profissional_to_string'] = $this->agenda_profissional_profissional_to_string;
    }

    public function get_agenda_profissional_profissional_to_string()
    {
        if(!empty($this->agenda_profissional_profissional_to_string))
        {
            return $this->agenda_profissional_profissional_to_string;
        }
    
        $values = AgendaProfissional::where('profissional_id', '=', $this->id)->getIndexedArray('profissional_id','{profissional->nome}');
        return implode(', ', $values);
    }

    public function set_agenda_profissional_clinica_to_string($agenda_profissional_clinica_to_string)
    {
        if(is_array($agenda_profissional_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $agenda_profissional_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_profissional_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_profissional_clinica_to_string = $agenda_profissional_clinica_to_string;
        }

        $this->vdata['agenda_profissional_clinica_to_string'] = $this->agenda_profissional_clinica_to_string;
    }

    public function get_agenda_profissional_clinica_to_string()
    {
        if(!empty($this->agenda_profissional_clinica_to_string))
        {
            return $this->agenda_profissional_clinica_to_string;
        }
    
        $values = AgendaProfissional::where('profissional_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_agenda_profissional_agenda_to_string($agenda_profissional_agenda_to_string)
    {
        if(is_array($agenda_profissional_agenda_to_string))
        {
            $values = Agenda::where('id', 'in', $agenda_profissional_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_profissional_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_profissional_agenda_to_string = $agenda_profissional_agenda_to_string;
        }

        $this->vdata['agenda_profissional_agenda_to_string'] = $this->agenda_profissional_agenda_to_string;
    }

    public function get_agenda_profissional_agenda_to_string()
    {
        if(!empty($this->agenda_profissional_agenda_to_string))
        {
            return $this->agenda_profissional_agenda_to_string;
        }
    
        $values = AgendaProfissional::where('profissional_id', '=', $this->id)->getIndexedArray('agenda_id','{agenda->nome}');
        return implode(', ', $values);
    }

    public function set_atendimento_agendamento_to_string($atendimento_agendamento_to_string)
    {
        if(is_array($atendimento_agendamento_to_string))
        {
            $values = Agendamento::where('id', 'in', $atendimento_agendamento_to_string)->getIndexedArray('id', 'id');
            $this->atendimento_agendamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_agendamento_to_string = $atendimento_agendamento_to_string;
        }

        $this->vdata['atendimento_agendamento_to_string'] = $this->atendimento_agendamento_to_string;
    }

    public function get_atendimento_agendamento_to_string()
    {
        if(!empty($this->atendimento_agendamento_to_string))
        {
            return $this->atendimento_agendamento_to_string;
        }
    
        $values = Atendimento::where('profissional_id', '=', $this->id)->getIndexedArray('agendamento_id','{agendamento->id}');
        return implode(', ', $values);
    }

    public function set_atendimento_paciente_to_string($atendimento_paciente_to_string)
    {
        if(is_array($atendimento_paciente_to_string))
        {
            $values = Pessoa::where('id', 'in', $atendimento_paciente_to_string)->getIndexedArray('nome', 'nome');
            $this->atendimento_paciente_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_paciente_to_string = $atendimento_paciente_to_string;
        }

        $this->vdata['atendimento_paciente_to_string'] = $this->atendimento_paciente_to_string;
    }

    public function get_atendimento_paciente_to_string()
    {
        if(!empty($this->atendimento_paciente_to_string))
        {
            return $this->atendimento_paciente_to_string;
        }
    
        $values = Atendimento::where('profissional_id', '=', $this->id)->getIndexedArray('paciente_id','{paciente->nome}');
        return implode(', ', $values);
    }

    public function set_atendimento_profissional_to_string($atendimento_profissional_to_string)
    {
        if(is_array($atendimento_profissional_to_string))
        {
            $values = Pessoa::where('id', 'in', $atendimento_profissional_to_string)->getIndexedArray('nome', 'nome');
            $this->atendimento_profissional_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_profissional_to_string = $atendimento_profissional_to_string;
        }

        $this->vdata['atendimento_profissional_to_string'] = $this->atendimento_profissional_to_string;
    }

    public function get_atendimento_profissional_to_string()
    {
        if(!empty($this->atendimento_profissional_to_string))
        {
            return $this->atendimento_profissional_to_string;
        }
    
        $values = Atendimento::where('profissional_id', '=', $this->id)->getIndexedArray('profissional_id','{profissional->nome}');
        return implode(', ', $values);
    }

    public function set_atendimento_clinica_to_string($atendimento_clinica_to_string)
    {
        if(is_array($atendimento_clinica_to_string))
        {
            $values = SystemUnit::where('id', 'in', $atendimento_clinica_to_string)->getIndexedArray('name', 'name');
            $this->atendimento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_clinica_to_string = $atendimento_clinica_to_string;
        }

        $this->vdata['atendimento_clinica_to_string'] = $this->atendimento_clinica_to_string;
    }

    public function get_atendimento_clinica_to_string()
    {
        if(!empty($this->atendimento_clinica_to_string))
        {
            return $this->atendimento_clinica_to_string;
        }
    
        $values = Atendimento::where('profissional_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->name}');
        return implode(', ', $values);
    }

    public function set_conta_pessoa_to_string($conta_pessoa_to_string)
    {
        if(is_array($conta_pessoa_to_string))
        {
            $values = Pessoa::where('id', 'in', $conta_pessoa_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_pessoa_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_pessoa_to_string = $conta_pessoa_to_string;
        }

        $this->vdata['conta_pessoa_to_string'] = $this->conta_pessoa_to_string;
    }

    public function get_conta_pessoa_to_string()
    {
        if(!empty($this->conta_pessoa_to_string))
        {
            return $this->conta_pessoa_to_string;
        }
    
        $values = Conta::where('pessoa_id', '=', $this->id)->getIndexedArray('pessoa_id','{pessoa->nome}');
        return implode(', ', $values);
    }

    public function set_conta_categoria_conta_to_string($conta_categoria_conta_to_string)
    {
        if(is_array($conta_categoria_conta_to_string))
        {
            $values = CategoriaConta::where('id', 'in', $conta_categoria_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_categoria_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_categoria_conta_to_string = $conta_categoria_conta_to_string;
        }

        $this->vdata['conta_categoria_conta_to_string'] = $this->conta_categoria_conta_to_string;
    }

    public function get_conta_categoria_conta_to_string()
    {
        if(!empty($this->conta_categoria_conta_to_string))
        {
            return $this->conta_categoria_conta_to_string;
        }
    
        $values = Conta::where('pessoa_id', '=', $this->id)->getIndexedArray('categoria_conta_id','{categoria_conta->nome}');
        return implode(', ', $values);
    }

    public function set_conta_tipo_conta_to_string($conta_tipo_conta_to_string)
    {
        if(is_array($conta_tipo_conta_to_string))
        {
            $values = TipoConta::where('id', 'in', $conta_tipo_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_tipo_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_tipo_conta_to_string = $conta_tipo_conta_to_string;
        }

        $this->vdata['conta_tipo_conta_to_string'] = $this->conta_tipo_conta_to_string;
    }

    public function get_conta_tipo_conta_to_string()
    {
        if(!empty($this->conta_tipo_conta_to_string))
        {
            return $this->conta_tipo_conta_to_string;
        }
    
        $values = Conta::where('pessoa_id', '=', $this->id)->getIndexedArray('tipo_conta_id','{tipo_conta->nome}');
        return implode(', ', $values);
    }

    public function set_conta_clinica_to_string($conta_clinica_to_string)
    {
        if(is_array($conta_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $conta_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_clinica_to_string = $conta_clinica_to_string;
        }

        $this->vdata['conta_clinica_to_string'] = $this->conta_clinica_to_string;
    }

    public function get_conta_clinica_to_string()
    {
        if(!empty($this->conta_clinica_to_string))
        {
            return $this->conta_clinica_to_string;
        }
    
        $values = Conta::where('pessoa_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_conta_atendimento_to_string($conta_atendimento_to_string)
    {
        if(is_array($conta_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $conta_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->conta_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_atendimento_to_string = $conta_atendimento_to_string;
        }

        $this->vdata['conta_atendimento_to_string'] = $this->conta_atendimento_to_string;
    }

    public function get_conta_atendimento_to_string()
    {
        if(!empty($this->conta_atendimento_to_string))
        {
            return $this->conta_atendimento_to_string;
        }
    
        $values = Conta::where('pessoa_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cidade_tomador_to_string($nota_fiscal_servico_cidade_tomador_to_string)
    {
        if(is_array($nota_fiscal_servico_cidade_tomador_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_cidade_tomador_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cidade_tomador_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cidade_tomador_to_string = $nota_fiscal_servico_cidade_tomador_to_string;
        }

        $this->vdata['nota_fiscal_servico_cidade_tomador_to_string'] = $this->nota_fiscal_servico_cidade_tomador_to_string;
    }

    public function get_nota_fiscal_servico_cidade_tomador_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cidade_tomador_to_string))
        {
            return $this->nota_fiscal_servico_cidade_tomador_to_string;
        }
    
        $values = NotaFiscalServico::where('cliente_id', '=', $this->id)->getIndexedArray('cidade_tomador_id','{cidade_tomador->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cidade_prestador_to_string($nota_fiscal_servico_cidade_prestador_to_string)
    {
        if(is_array($nota_fiscal_servico_cidade_prestador_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_cidade_prestador_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cidade_prestador_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cidade_prestador_to_string = $nota_fiscal_servico_cidade_prestador_to_string;
        }

        $this->vdata['nota_fiscal_servico_cidade_prestador_to_string'] = $this->nota_fiscal_servico_cidade_prestador_to_string;
    }

    public function get_nota_fiscal_servico_cidade_prestador_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cidade_prestador_to_string))
        {
            return $this->nota_fiscal_servico_cidade_prestador_to_string;
        }
    
        $values = NotaFiscalServico::where('cliente_id', '=', $this->id)->getIndexedArray('cidade_prestador_id','{cidade_prestador->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_municipio_prestacao_servico_to_string($nota_fiscal_servico_municipio_prestacao_servico_to_string)
    {
        if(is_array($nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_municipio_prestacao_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_municipio_prestacao_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_municipio_prestacao_servico_to_string = $nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }

        $this->vdata['nota_fiscal_servico_municipio_prestacao_servico_to_string'] = $this->nota_fiscal_servico_municipio_prestacao_servico_to_string;
    }

    public function get_nota_fiscal_servico_municipio_prestacao_servico_to_string()
    {
        if(!empty($this->nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            return $this->nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }
    
        $values = NotaFiscalServico::where('cliente_id', '=', $this->id)->getIndexedArray('municipio_prestacao_servico_id','{municipio_prestacao_servico->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_nota_fiscal_status_to_string($nota_fiscal_servico_nota_fiscal_status_to_string)
    {
        if(is_array($nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            $values = NotaFiscalStatus::where('id', 'in', $nota_fiscal_servico_nota_fiscal_status_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_nota_fiscal_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_nota_fiscal_status_to_string = $nota_fiscal_servico_nota_fiscal_status_to_string;
        }

        $this->vdata['nota_fiscal_servico_nota_fiscal_status_to_string'] = $this->nota_fiscal_servico_nota_fiscal_status_to_string;
    }

    public function get_nota_fiscal_servico_nota_fiscal_status_to_string()
    {
        if(!empty($this->nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            return $this->nota_fiscal_servico_nota_fiscal_status_to_string;
        }
    
        $values = NotaFiscalServico::where('cliente_id', '=', $this->id)->getIndexedArray('nota_fiscal_status_id','{nota_fiscal_status->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_clinica_to_string($nota_fiscal_servico_clinica_to_string)
    {
        if(is_array($nota_fiscal_servico_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $nota_fiscal_servico_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_clinica_to_string = $nota_fiscal_servico_clinica_to_string;
        }

        $this->vdata['nota_fiscal_servico_clinica_to_string'] = $this->nota_fiscal_servico_clinica_to_string;
    }

    public function get_nota_fiscal_servico_clinica_to_string()
    {
        if(!empty($this->nota_fiscal_servico_clinica_to_string))
        {
            return $this->nota_fiscal_servico_clinica_to_string;
        }
    
        $values = NotaFiscalServico::where('cliente_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cliente_to_string($nota_fiscal_servico_cliente_to_string)
    {
        if(is_array($nota_fiscal_servico_cliente_to_string))
        {
            $values = Pessoa::where('id', 'in', $nota_fiscal_servico_cliente_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cliente_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cliente_to_string = $nota_fiscal_servico_cliente_to_string;
        }

        $this->vdata['nota_fiscal_servico_cliente_to_string'] = $this->nota_fiscal_servico_cliente_to_string;
    }

    public function get_nota_fiscal_servico_cliente_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cliente_to_string))
        {
            return $this->nota_fiscal_servico_cliente_to_string;
        }
    
        $values = NotaFiscalServico::where('cliente_id', '=', $this->id)->getIndexedArray('cliente_id','{cliente->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_conta_to_string($nota_fiscal_servico_conta_to_string)
    {
        if(is_array($nota_fiscal_servico_conta_to_string))
        {
            $values = Conta::where('id', 'in', $nota_fiscal_servico_conta_to_string)->getIndexedArray('descricao', 'descricao');
            $this->nota_fiscal_servico_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_conta_to_string = $nota_fiscal_servico_conta_to_string;
        }

        $this->vdata['nota_fiscal_servico_conta_to_string'] = $this->nota_fiscal_servico_conta_to_string;
    }

    public function get_nota_fiscal_servico_conta_to_string()
    {
        if(!empty($this->nota_fiscal_servico_conta_to_string))
        {
            return $this->nota_fiscal_servico_conta_to_string;
        }
    
        $values = NotaFiscalServico::where('cliente_id', '=', $this->id)->getIndexedArray('conta_id','{conta->descricao}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_lancamento_to_string($nota_fiscal_servico_lancamento_to_string)
    {
        if(is_array($nota_fiscal_servico_lancamento_to_string))
        {
            $values = Lancamento::where('id', 'in', $nota_fiscal_servico_lancamento_to_string)->getIndexedArray('id', 'id');
            $this->nota_fiscal_servico_lancamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_lancamento_to_string = $nota_fiscal_servico_lancamento_to_string;
        }

        $this->vdata['nota_fiscal_servico_lancamento_to_string'] = $this->nota_fiscal_servico_lancamento_to_string;
    }

    public function get_nota_fiscal_servico_lancamento_to_string()
    {
        if(!empty($this->nota_fiscal_servico_lancamento_to_string))
        {
            return $this->nota_fiscal_servico_lancamento_to_string;
        }
    
        $values = NotaFiscalServico::where('cliente_id', '=', $this->id)->getIndexedArray('lancamento_id','{lancamento->id}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_servico_to_string($nota_fiscal_servico_servico_to_string)
    {
        if(is_array($nota_fiscal_servico_servico_to_string))
        {
            $values = Servico::where('id', 'in', $nota_fiscal_servico_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_servico_to_string = $nota_fiscal_servico_servico_to_string;
        }

        $this->vdata['nota_fiscal_servico_servico_to_string'] = $this->nota_fiscal_servico_servico_to_string;
    }

    public function get_nota_fiscal_servico_servico_to_string()
    {
        if(!empty($this->nota_fiscal_servico_servico_to_string))
        {
            return $this->nota_fiscal_servico_servico_to_string;
        }
    
        $values = NotaFiscalServico::where('cliente_id', '=', $this->id)->getIndexedArray('servico_id','{servico->nome}');
        return implode(', ', $values);
    }

    public function set_pessoa_endereco_pessoa_to_string($pessoa_endereco_pessoa_to_string)
    {
        if(is_array($pessoa_endereco_pessoa_to_string))
        {
            $values = Pessoa::where('id', 'in', $pessoa_endereco_pessoa_to_string)->getIndexedArray('nome', 'nome');
            $this->pessoa_endereco_pessoa_to_string = implode(', ', $values);
        }
        else
        {
            $this->pessoa_endereco_pessoa_to_string = $pessoa_endereco_pessoa_to_string;
        }

        $this->vdata['pessoa_endereco_pessoa_to_string'] = $this->pessoa_endereco_pessoa_to_string;
    }

    public function get_pessoa_endereco_pessoa_to_string()
    {
        if(!empty($this->pessoa_endereco_pessoa_to_string))
        {
            return $this->pessoa_endereco_pessoa_to_string;
        }
    
        $values = PessoaEndereco::where('pessoa_id', '=', $this->id)->getIndexedArray('pessoa_id','{pessoa->nome}');
        return implode(', ', $values);
    }

    public function set_pessoa_endereco_cidade_to_string($pessoa_endereco_cidade_to_string)
    {
        if(is_array($pessoa_endereco_cidade_to_string))
        {
            $values = Cidade::where('id', 'in', $pessoa_endereco_cidade_to_string)->getIndexedArray('nome', 'nome');
            $this->pessoa_endereco_cidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->pessoa_endereco_cidade_to_string = $pessoa_endereco_cidade_to_string;
        }

        $this->vdata['pessoa_endereco_cidade_to_string'] = $this->pessoa_endereco_cidade_to_string;
    }

    public function get_pessoa_endereco_cidade_to_string()
    {
        if(!empty($this->pessoa_endereco_cidade_to_string))
        {
            return $this->pessoa_endereco_cidade_to_string;
        }
    
        $values = PessoaEndereco::where('pessoa_id', '=', $this->id)->getIndexedArray('cidade_id','{cidade->nome}');
        return implode(', ', $values);
    }

    public function set_pessoa_especialidade_pessoa_to_string($pessoa_especialidade_pessoa_to_string)
    {
        if(is_array($pessoa_especialidade_pessoa_to_string))
        {
            $values = Pessoa::where('id', 'in', $pessoa_especialidade_pessoa_to_string)->getIndexedArray('nome', 'nome');
            $this->pessoa_especialidade_pessoa_to_string = implode(', ', $values);
        }
        else
        {
            $this->pessoa_especialidade_pessoa_to_string = $pessoa_especialidade_pessoa_to_string;
        }

        $this->vdata['pessoa_especialidade_pessoa_to_string'] = $this->pessoa_especialidade_pessoa_to_string;
    }

    public function get_pessoa_especialidade_pessoa_to_string()
    {
        if(!empty($this->pessoa_especialidade_pessoa_to_string))
        {
            return $this->pessoa_especialidade_pessoa_to_string;
        }
    
        $values = PessoaEspecialidade::where('pessoa_id', '=', $this->id)->getIndexedArray('pessoa_id','{pessoa->nome}');
        return implode(', ', $values);
    }

    public function set_pessoa_especialidade_especialidade_to_string($pessoa_especialidade_especialidade_to_string)
    {
        if(is_array($pessoa_especialidade_especialidade_to_string))
        {
            $values = Especialidade::where('id', 'in', $pessoa_especialidade_especialidade_to_string)->getIndexedArray('descricao', 'descricao');
            $this->pessoa_especialidade_especialidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->pessoa_especialidade_especialidade_to_string = $pessoa_especialidade_especialidade_to_string;
        }

        $this->vdata['pessoa_especialidade_especialidade_to_string'] = $this->pessoa_especialidade_especialidade_to_string;
    }

    public function get_pessoa_especialidade_especialidade_to_string()
    {
        if(!empty($this->pessoa_especialidade_especialidade_to_string))
        {
            return $this->pessoa_especialidade_especialidade_to_string;
        }
    
        $values = PessoaEspecialidade::where('pessoa_id', '=', $this->id)->getIndexedArray('especialidade_id','{especialidade->descricao}');
        return implode(', ', $values);
    }

    public function set_pessoa_grupo_pessoa_to_string($pessoa_grupo_pessoa_to_string)
    {
        if(is_array($pessoa_grupo_pessoa_to_string))
        {
            $values = Pessoa::where('id', 'in', $pessoa_grupo_pessoa_to_string)->getIndexedArray('nome', 'nome');
            $this->pessoa_grupo_pessoa_to_string = implode(', ', $values);
        }
        else
        {
            $this->pessoa_grupo_pessoa_to_string = $pessoa_grupo_pessoa_to_string;
        }

        $this->vdata['pessoa_grupo_pessoa_to_string'] = $this->pessoa_grupo_pessoa_to_string;
    }

    public function get_pessoa_grupo_pessoa_to_string()
    {
        if(!empty($this->pessoa_grupo_pessoa_to_string))
        {
            return $this->pessoa_grupo_pessoa_to_string;
        }
    
        $values = PessoaGrupo::where('pessoa_id', '=', $this->id)->getIndexedArray('pessoa_id','{pessoa->nome}');
        return implode(', ', $values);
    }

    public function set_pessoa_grupo_grupo_to_string($pessoa_grupo_grupo_to_string)
    {
        if(is_array($pessoa_grupo_grupo_to_string))
        {
            $values = Grupo::where('id', 'in', $pessoa_grupo_grupo_to_string)->getIndexedArray('nome', 'nome');
            $this->pessoa_grupo_grupo_to_string = implode(', ', $values);
        }
        else
        {
            $this->pessoa_grupo_grupo_to_string = $pessoa_grupo_grupo_to_string;
        }

        $this->vdata['pessoa_grupo_grupo_to_string'] = $this->pessoa_grupo_grupo_to_string;
    }

    public function get_pessoa_grupo_grupo_to_string()
    {
        if(!empty($this->pessoa_grupo_grupo_to_string))
        {
            return $this->pessoa_grupo_grupo_to_string;
        }
    
        $values = PessoaGrupo::where('pessoa_id', '=', $this->id)->getIndexedArray('grupo_id','{grupo->nome}');
        return implode(', ', $values);
    }

    public function get_nome_formatado()
    {
        $tratamento = $this->tratamento ? "{$this->tratamento} " : '';
        $nome = $this->nome_civel ? $this->nome_civel : $this->nome;
    
        return $tratamento . $nome;
    }

    public function get_cor()
    {
        $pessoasGrupos = $this->getPessoaGrupos();
    
        $cor = '#ffffff';
    
        if ($pessoasGrupos)
        {
            foreach($pessoasGrupos as $pessoaGrupo)
            {
                if($pessoaGrupo->grupo_id === Grupo::PROFISSIONAL)
                {
                    $cor = $pessoaGrupo->cor;
                }
            }
        }
    
        return $cor;
    }

    public function get_foto_icone()
    {
        if (empty($this->foto))
            return "app/images/favicon.png";
    
        return $this->foto;
    }

  
                
}

