<?php

class NotaFiscalServico extends TRecord
{
    const TABLENAME  = 'nota_fiscal_servico';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Cidade $municipio_prestacao_servico;
    private NotaFiscalStatus $nota_fiscal_status;
    private Clinica $clinica;
    private Pessoa $cliente;
    private Lancamento $lancamento;
    private Cidade $cidade_tomador;
    private Conta $conta;
    private Cidade $cidade_prestador;
    private Servico $servico;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByUnit');
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
                    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('cidade_tomador_id');
        parent::addAttribute('cidade_prestador_id');
        parent::addAttribute('municipio_prestacao_servico_id');
        parent::addAttribute('nota_fiscal_status_id');
        parent::addAttribute('clinica_id');
        parent::addAttribute('cliente_id');
        parent::addAttribute('conta_id');
        parent::addAttribute('lancamento_id');
        parent::addAttribute('natureza_operacao');
        parent::addAttribute('data_hora_emissao');
        parent::addAttribute('discriminacao');
        parent::addAttribute('numero');
        parent::addAttribute('codigo_verificacao');
        parent::addAttribute('id_gateway_externo');
        parent::addAttribute('dados_gateway_externo');
        parent::addAttribute('nome_tomador');
        parent::addAttribute('documento_tomador');
        parent::addAttribute('endereco_tomador');
        parent::addAttribute('email_tomador');
        parent::addAttribute('telefone_tomador');
        parent::addAttribute('numero_tomador');
        parent::addAttribute('bairro_tomador');
        parent::addAttribute('cep_tomador');
        parent::addAttribute('inscricao_municipal_tomador');
        parent::addAttribute('inscricao_municipal_prestador');
        parent::addAttribute('nome_prestador');
        parent::addAttribute('documento_prestador');
        parent::addAttribute('endereco_prestador');
        parent::addAttribute('email_prestador');
        parent::addAttribute('telefone_prestador');
        parent::addAttribute('numero_prestador');
        parent::addAttribute('bairro_prestador');
        parent::addAttribute('cep_prestador');
        parent::addAttribute('iss_retido');
        parent::addAttribute('desconto_incondicionado');
        parent::addAttribute('desconto_condicionado');
        parent::addAttribute('base_calculo_iss');
        parent::addAttribute('aliquota_iss');
        parent::addAttribute('aliquota_pis');
        parent::addAttribute('aliquota_cofins');
        parent::addAttribute('aliquota_csll');
        parent::addAttribute('aliquota_irrf');
        parent::addAttribute('aliquota_inss');
        parent::addAttribute('valor_deducoes');
        parent::addAttribute('valor_retencoes');
        parent::addAttribute('valor_outras_retencoes');
        parent::addAttribute('valor_liquido');
        parent::addAttribute('valor_servicos');
        parent::addAttribute('valor_iss');
        parent::addAttribute('valor_pis');
        parent::addAttribute('valor_inss');
        parent::addAttribute('valor_cofins');
        parent::addAttribute('valor_csll');
        parent::addAttribute('valor_irrf');
        parent::addAttribute('incentivador_cultural');
        parent::addAttribute('optante_simples_nacional');
        parent::addAttribute('nfse_status');
        parent::addAttribute('ano');
        parent::addAttribute('mes');
        parent::addAttribute('ano_mes');
        parent::addAttribute('pdf');
        parent::addAttribute('xml');
        parent::addAttribute('link_pdf_prefeitura');
        parent::addAttribute('regime_tributario_municipal');
        parent::addAttribute('numero_rps');
        parent::addAttribute('mensagem_erro');
        parent::addAttribute('email_enviado');
        parent::addAttribute('servico_id');
        parent::addAttribute('serie_rps');
    
    }

    /**
     * Method set_cidade
     * Sample of usage: $var->cidade = $object;
     * @param $object Instance of Cidade
     */
    public function set_municipio_prestacao_servico(Cidade $object)
    {
        $this->municipio_prestacao_servico = $object;
        $this->municipio_prestacao_servico_id = $object->id;
    }

    /**
     * Method get_municipio_prestacao_servico
     * Sample of usage: $var->municipio_prestacao_servico->attribute;
     * @returns Cidade instance
     */
    public function get_municipio_prestacao_servico()
    {
    
        // loads the associated object
        if (empty($this->municipio_prestacao_servico))
            $this->municipio_prestacao_servico = new Cidade($this->municipio_prestacao_servico_id);
    
        // returns the associated object
        return $this->municipio_prestacao_servico;
    }
    /**
     * Method set_nota_fiscal_status
     * Sample of usage: $var->nota_fiscal_status = $object;
     * @param $object Instance of NotaFiscalStatus
     */
    public function set_nota_fiscal_status(NotaFiscalStatus $object)
    {
        $this->nota_fiscal_status = $object;
        $this->nota_fiscal_status_id = $object->id;
    }

    /**
     * Method get_nota_fiscal_status
     * Sample of usage: $var->nota_fiscal_status->attribute;
     * @returns NotaFiscalStatus instance
     */
    public function get_nota_fiscal_status()
    {
    
        // loads the associated object
        if (empty($this->nota_fiscal_status))
            $this->nota_fiscal_status = new NotaFiscalStatus($this->nota_fiscal_status_id);
    
        // returns the associated object
        return $this->nota_fiscal_status;
    }
    /**
     * Method set_clinica
     * Sample of usage: $var->clinica = $object;
     * @param $object Instance of Clinica
     */
    public function set_clinica(Clinica $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns Clinica instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new Clinica($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }
    /**
     * Method set_pessoa
     * Sample of usage: $var->pessoa = $object;
     * @param $object Instance of Pessoa
     */
    public function set_cliente(Pessoa $object)
    {
        $this->cliente = $object;
        $this->cliente_id = $object->id;
    }

    /**
     * Method get_cliente
     * Sample of usage: $var->cliente->attribute;
     * @returns Pessoa instance
     */
    public function get_cliente()
    {
    
        // loads the associated object
        if (empty($this->cliente))
            $this->cliente = new Pessoa($this->cliente_id);
    
        // returns the associated object
        return $this->cliente;
    }
    /**
     * Method set_lancamento
     * Sample of usage: $var->lancamento = $object;
     * @param $object Instance of Lancamento
     */
    public function set_lancamento(Lancamento $object)
    {
        $this->lancamento = $object;
        $this->lancamento_id = $object->id;
    }

    /**
     * Method get_lancamento
     * Sample of usage: $var->lancamento->attribute;
     * @returns Lancamento instance
     */
    public function get_lancamento()
    {
    
        // loads the associated object
        if (empty($this->lancamento))
            $this->lancamento = new Lancamento($this->lancamento_id);
    
        // returns the associated object
        return $this->lancamento;
    }
    /**
     * Method set_cidade
     * Sample of usage: $var->cidade = $object;
     * @param $object Instance of Cidade
     */
    public function set_cidade_tomador(Cidade $object)
    {
        $this->cidade_tomador = $object;
        $this->cidade_tomador_id = $object->id;
    }

    /**
     * Method get_cidade_tomador
     * Sample of usage: $var->cidade_tomador->attribute;
     * @returns Cidade instance
     */
    public function get_cidade_tomador()
    {
    
        // loads the associated object
        if (empty($this->cidade_tomador))
            $this->cidade_tomador = new Cidade($this->cidade_tomador_id);
    
        // returns the associated object
        return $this->cidade_tomador;
    }
    /**
     * Method set_conta
     * Sample of usage: $var->conta = $object;
     * @param $object Instance of Conta
     */
    public function set_conta(Conta $object)
    {
        $this->conta = $object;
        $this->conta_id = $object->id;
    }

    /**
     * Method get_conta
     * Sample of usage: $var->conta->attribute;
     * @returns Conta instance
     */
    public function get_conta()
    {
    
        // loads the associated object
        if (empty($this->conta))
            $this->conta = new Conta($this->conta_id);
    
        // returns the associated object
        return $this->conta;
    }
    /**
     * Method set_cidade
     * Sample of usage: $var->cidade = $object;
     * @param $object Instance of Cidade
     */
    public function set_cidade_prestador(Cidade $object)
    {
        $this->cidade_prestador = $object;
        $this->cidade_prestador_id = $object->id;
    }

    /**
     * Method get_cidade_prestador
     * Sample of usage: $var->cidade_prestador->attribute;
     * @returns Cidade instance
     */
    public function get_cidade_prestador()
    {
    
        // loads the associated object
        if (empty($this->cidade_prestador))
            $this->cidade_prestador = new Cidade($this->cidade_prestador_id);
    
        // returns the associated object
        return $this->cidade_prestador;
    }
    /**
     * Method set_servico
     * Sample of usage: $var->servico = $object;
     * @param $object Instance of Servico
     */
    public function set_servico(Servico $object)
    {
        $this->servico = $object;
        $this->servico_id = $object->id;
    }

    /**
     * Method get_servico
     * Sample of usage: $var->servico->attribute;
     * @returns Servico instance
     */
    public function get_servico()
    {
    
        // loads the associated object
        if (empty($this->servico))
            $this->servico = new Servico($this->servico_id);
    
        // returns the associated object
        return $this->servico;
    }

    /**
     * Method getLancamentos
     */
    public function getLancamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('nota_fiscal_servico_id', '=', $this->id));
        return Lancamento::getObjects( $criteria );
    }

    public function set_lancamento_conta_to_string($lancamento_conta_to_string)
    {
        if(is_array($lancamento_conta_to_string))
        {
            $values = Conta::where('id', 'in', $lancamento_conta_to_string)->getIndexedArray('descricao', 'descricao');
            $this->lancamento_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_conta_to_string = $lancamento_conta_to_string;
        }

        $this->vdata['lancamento_conta_to_string'] = $this->lancamento_conta_to_string;
    }

    public function get_lancamento_conta_to_string()
    {
        if(!empty($this->lancamento_conta_to_string))
        {
            return $this->lancamento_conta_to_string;
        }
    
        $values = Lancamento::where('nota_fiscal_servico_id', '=', $this->id)->getIndexedArray('conta_id','{conta->descricao}');
        return implode(', ', $values);
    }

    public function set_lancamento_clinica_to_string($lancamento_clinica_to_string)
    {
        if(is_array($lancamento_clinica_to_string))
        {
            $values = SystemUnit::where('id', 'in', $lancamento_clinica_to_string)->getIndexedArray('name', 'name');
            $this->lancamento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_clinica_to_string = $lancamento_clinica_to_string;
        }

        $this->vdata['lancamento_clinica_to_string'] = $this->lancamento_clinica_to_string;
    }

    public function get_lancamento_clinica_to_string()
    {
        if(!empty($this->lancamento_clinica_to_string))
        {
            return $this->lancamento_clinica_to_string;
        }
    
        $values = Lancamento::where('nota_fiscal_servico_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->name}');
        return implode(', ', $values);
    }

    public function set_lancamento_tipo_pagamento_to_string($lancamento_tipo_pagamento_to_string)
    {
        if(is_array($lancamento_tipo_pagamento_to_string))
        {
            $values = TipoPagamento::where('id', 'in', $lancamento_tipo_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->lancamento_tipo_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_tipo_pagamento_to_string = $lancamento_tipo_pagamento_to_string;
        }

        $this->vdata['lancamento_tipo_pagamento_to_string'] = $this->lancamento_tipo_pagamento_to_string;
    }

    public function get_lancamento_tipo_pagamento_to_string()
    {
        if(!empty($this->lancamento_tipo_pagamento_to_string))
        {
            return $this->lancamento_tipo_pagamento_to_string;
        }
    
        $values = Lancamento::where('nota_fiscal_servico_id', '=', $this->id)->getIndexedArray('tipo_pagamento_id','{tipo_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_lancamento_nota_fiscal_servico_to_string($lancamento_nota_fiscal_servico_to_string)
    {
        if(is_array($lancamento_nota_fiscal_servico_to_string))
        {
            $values = NotaFiscalServico::where('id', 'in', $lancamento_nota_fiscal_servico_to_string)->getIndexedArray('id', 'id');
            $this->lancamento_nota_fiscal_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_nota_fiscal_servico_to_string = $lancamento_nota_fiscal_servico_to_string;
        }

        $this->vdata['lancamento_nota_fiscal_servico_to_string'] = $this->lancamento_nota_fiscal_servico_to_string;
    }

    public function get_lancamento_nota_fiscal_servico_to_string()
    {
        if(!empty($this->lancamento_nota_fiscal_servico_to_string))
        {
            return $this->lancamento_nota_fiscal_servico_to_string;
        }
    
        $values = Lancamento::where('nota_fiscal_servico_id', '=', $this->id)->getIndexedArray('nota_fiscal_servico_id','{nota_fiscal_servico->id}');
        return implode(', ', $values);
    }

    public function podeTransmitir()
    {
        return (in_array($this->nota_fiscal_status_id, NotaFiscalStatus::getStatusTransmissao()));
    }
    public function getDadosGatewayFormatado()
    {
        if ($this->dados_gateway_externo)
        {
            $dados = json_decode($this->dados_gateway_externo);

            $result = [];

            if (! empty($dados->erros))
            {
                $dados->erros = is_string($dados->erros) ? $dados->erros : json_encode($dados->erros);
                $result[] = "Erros: <div><b>{$dados->erros}</b></div>";
            }
        
            if (! empty($dados->justificativa))
            {
                $dados->justificativa = nl2br($dados->justificativa);
                $result[] = "Justificativa: <div><b>{$dados->justificativa}</b></div>";
            }
        
            if (! empty($dados->documento))
            {
                $result[] = "<div><a target='_blank' href='{$dados->documento}'><i class='fa fa-file-pdf red'></i> Visualizar documento</a></div>";
            }
        
            if (! empty($dados->xml))
            {
                $result[] = "<div><a target='_blank' href='{$dados->xml}'><i class='fa fa-file-code orange'></i> Visualizar XML</a></div>";
            }
        
            return implode('', $result);
        }
    
        return null;
    }

    public function onBeforeStore($object)
    {
        if (! empty($object->data_hora_emissao))
        {
            $object->ano = date('Y', strtotime($object->data_hora_emissao));
            $object->mes = date('m', strtotime($object->data_hora_emissao));
        
            $object->ano_mes = $object->ano.$object->mes;
        }
    }
            
}

