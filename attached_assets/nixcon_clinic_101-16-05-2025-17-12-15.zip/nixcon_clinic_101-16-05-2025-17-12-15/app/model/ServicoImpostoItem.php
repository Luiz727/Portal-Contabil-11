<?php

class ServicoImpostoItem extends TRecord
{
    const TABLENAME  = 'servico_imposto_item';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Servico $servico;
    private Imposto $imposto;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('servico_id');
        parent::addAttribute('imposto_id');
        parent::addAttribute('aliquota');
            
    }

    /**
     * Method set_servico
     * Sample of usage: $var->servico = $object;
     * @param $object Instance of Servico
     */
    public function set_servico(Servico $object)
    {
        $this->servico = $object;
        $this->servico_id = $object->id;
    }

    /**
     * Method get_servico
     * Sample of usage: $var->servico->attribute;
     * @returns Servico instance
     */
    public function get_servico()
    {
    
        // loads the associated object
        if (empty($this->servico))
            $this->servico = new Servico($this->servico_id);
    
        // returns the associated object
        return $this->servico;
    }
    /**
     * Method set_imposto
     * Sample of usage: $var->imposto = $object;
     * @param $object Instance of Imposto
     */
    public function set_imposto(Imposto $object)
    {
        $this->imposto = $object;
        $this->imposto_id = $object->id;
    }

    /**
     * Method get_imposto
     * Sample of usage: $var->imposto->attribute;
     * @returns Imposto instance
     */
    public function get_imposto()
    {
    
        // loads the associated object
        if (empty($this->imposto))
            $this->imposto = new Imposto($this->imposto_id);
    
        // returns the associated object
        return $this->imposto;
    }

    
}

