<?php

class Lancamento extends TRecord
{
    const TABLENAME  = 'lancamento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private NotaFiscalServico $nota_fiscal_servico;
    private Conta $conta;
    private TipoPagamento $tipo_pagamento;
    private SystemUnit $clinica;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByUnit');
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
            
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('conta_id');
        parent::addAttribute('clinica_id');
        parent::addAttribute('tipo_pagamento_id');
        parent::addAttribute('nota_fiscal_servico_id');
        parent::addAttribute('parcela');
        parent::addAttribute('dt_vencimento');
        parent::addAttribute('valor');
        parent::addAttribute('dt_pagamento');
        parent::addAttribute('ano_pagamento');
        parent::addAttribute('mes_pagamento');
        parent::addAttribute('ano_mes_pagamento');
        parent::addAttribute('ano_vencimento');
        parent::addAttribute('mes_vencimento');
        parent::addAttribute('ano_mes_vencimento');
    
    }

    /**
     * Method set_nota_fiscal_servico
     * Sample of usage: $var->nota_fiscal_servico = $object;
     * @param $object Instance of NotaFiscalServico
     */
    public function set_nota_fiscal_servico(NotaFiscalServico $object)
    {
        $this->nota_fiscal_servico = $object;
        $this->nota_fiscal_servico_id = $object->id;
    }

    /**
     * Method get_nota_fiscal_servico
     * Sample of usage: $var->nota_fiscal_servico->attribute;
     * @returns NotaFiscalServico instance
     */
    public function get_nota_fiscal_servico()
    {
    
        // loads the associated object
        if (empty($this->nota_fiscal_servico))
            $this->nota_fiscal_servico = new NotaFiscalServico($this->nota_fiscal_servico_id);
    
        // returns the associated object
        return $this->nota_fiscal_servico;
    }
    /**
     * Method set_conta
     * Sample of usage: $var->conta = $object;
     * @param $object Instance of Conta
     */
    public function set_conta(Conta $object)
    {
        $this->conta = $object;
        $this->conta_id = $object->id;
    }

    /**
     * Method get_conta
     * Sample of usage: $var->conta->attribute;
     * @returns Conta instance
     */
    public function get_conta()
    {
    
        // loads the associated object
        if (empty($this->conta))
            $this->conta = new Conta($this->conta_id);
    
        // returns the associated object
        return $this->conta;
    }
    /**
     * Method set_tipo_pagamento
     * Sample of usage: $var->tipo_pagamento = $object;
     * @param $object Instance of TipoPagamento
     */
    public function set_tipo_pagamento(TipoPagamento $object)
    {
        $this->tipo_pagamento = $object;
        $this->tipo_pagamento_id = $object->id;
    }

    /**
     * Method get_tipo_pagamento
     * Sample of usage: $var->tipo_pagamento->attribute;
     * @returns TipoPagamento instance
     */
    public function get_tipo_pagamento()
    {
    
        // loads the associated object
        if (empty($this->tipo_pagamento))
            $this->tipo_pagamento = new TipoPagamento($this->tipo_pagamento_id);
    
        // returns the associated object
        return $this->tipo_pagamento;
    }
    /**
     * Method set_system_unit
     * Sample of usage: $var->system_unit = $object;
     * @param $object Instance of SystemUnit
     */
    public function set_clinica(SystemUnit $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns SystemUnit instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new SystemUnit($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }

    /**
     * Method getNotaFiscalServicos
     */
    public function getNotaFiscalServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('lancamento_id', '=', $this->id));
        return NotaFiscalServico::getObjects( $criteria );
    }

    public function set_nota_fiscal_servico_cidade_tomador_to_string($nota_fiscal_servico_cidade_tomador_to_string)
    {
        if(is_array($nota_fiscal_servico_cidade_tomador_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_cidade_tomador_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cidade_tomador_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cidade_tomador_to_string = $nota_fiscal_servico_cidade_tomador_to_string;
        }

        $this->vdata['nota_fiscal_servico_cidade_tomador_to_string'] = $this->nota_fiscal_servico_cidade_tomador_to_string;
    }

    public function get_nota_fiscal_servico_cidade_tomador_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cidade_tomador_to_string))
        {
            return $this->nota_fiscal_servico_cidade_tomador_to_string;
        }
    
        $values = NotaFiscalServico::where('lancamento_id', '=', $this->id)->getIndexedArray('cidade_tomador_id','{cidade_tomador->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cidade_prestador_to_string($nota_fiscal_servico_cidade_prestador_to_string)
    {
        if(is_array($nota_fiscal_servico_cidade_prestador_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_cidade_prestador_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cidade_prestador_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cidade_prestador_to_string = $nota_fiscal_servico_cidade_prestador_to_string;
        }

        $this->vdata['nota_fiscal_servico_cidade_prestador_to_string'] = $this->nota_fiscal_servico_cidade_prestador_to_string;
    }

    public function get_nota_fiscal_servico_cidade_prestador_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cidade_prestador_to_string))
        {
            return $this->nota_fiscal_servico_cidade_prestador_to_string;
        }
    
        $values = NotaFiscalServico::where('lancamento_id', '=', $this->id)->getIndexedArray('cidade_prestador_id','{cidade_prestador->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_municipio_prestacao_servico_to_string($nota_fiscal_servico_municipio_prestacao_servico_to_string)
    {
        if(is_array($nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_municipio_prestacao_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_municipio_prestacao_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_municipio_prestacao_servico_to_string = $nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }

        $this->vdata['nota_fiscal_servico_municipio_prestacao_servico_to_string'] = $this->nota_fiscal_servico_municipio_prestacao_servico_to_string;
    }

    public function get_nota_fiscal_servico_municipio_prestacao_servico_to_string()
    {
        if(!empty($this->nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            return $this->nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }
    
        $values = NotaFiscalServico::where('lancamento_id', '=', $this->id)->getIndexedArray('municipio_prestacao_servico_id','{municipio_prestacao_servico->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_nota_fiscal_status_to_string($nota_fiscal_servico_nota_fiscal_status_to_string)
    {
        if(is_array($nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            $values = NotaFiscalStatus::where('id', 'in', $nota_fiscal_servico_nota_fiscal_status_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_nota_fiscal_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_nota_fiscal_status_to_string = $nota_fiscal_servico_nota_fiscal_status_to_string;
        }

        $this->vdata['nota_fiscal_servico_nota_fiscal_status_to_string'] = $this->nota_fiscal_servico_nota_fiscal_status_to_string;
    }

    public function get_nota_fiscal_servico_nota_fiscal_status_to_string()
    {
        if(!empty($this->nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            return $this->nota_fiscal_servico_nota_fiscal_status_to_string;
        }
    
        $values = NotaFiscalServico::where('lancamento_id', '=', $this->id)->getIndexedArray('nota_fiscal_status_id','{nota_fiscal_status->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_clinica_to_string($nota_fiscal_servico_clinica_to_string)
    {
        if(is_array($nota_fiscal_servico_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $nota_fiscal_servico_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_clinica_to_string = $nota_fiscal_servico_clinica_to_string;
        }

        $this->vdata['nota_fiscal_servico_clinica_to_string'] = $this->nota_fiscal_servico_clinica_to_string;
    }

    public function get_nota_fiscal_servico_clinica_to_string()
    {
        if(!empty($this->nota_fiscal_servico_clinica_to_string))
        {
            return $this->nota_fiscal_servico_clinica_to_string;
        }
    
        $values = NotaFiscalServico::where('lancamento_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cliente_to_string($nota_fiscal_servico_cliente_to_string)
    {
        if(is_array($nota_fiscal_servico_cliente_to_string))
        {
            $values = Pessoa::where('id', 'in', $nota_fiscal_servico_cliente_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cliente_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cliente_to_string = $nota_fiscal_servico_cliente_to_string;
        }

        $this->vdata['nota_fiscal_servico_cliente_to_string'] = $this->nota_fiscal_servico_cliente_to_string;
    }

    public function get_nota_fiscal_servico_cliente_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cliente_to_string))
        {
            return $this->nota_fiscal_servico_cliente_to_string;
        }
    
        $values = NotaFiscalServico::where('lancamento_id', '=', $this->id)->getIndexedArray('cliente_id','{cliente->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_conta_to_string($nota_fiscal_servico_conta_to_string)
    {
        if(is_array($nota_fiscal_servico_conta_to_string))
        {
            $values = Conta::where('id', 'in', $nota_fiscal_servico_conta_to_string)->getIndexedArray('descricao', 'descricao');
            $this->nota_fiscal_servico_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_conta_to_string = $nota_fiscal_servico_conta_to_string;
        }

        $this->vdata['nota_fiscal_servico_conta_to_string'] = $this->nota_fiscal_servico_conta_to_string;
    }

    public function get_nota_fiscal_servico_conta_to_string()
    {
        if(!empty($this->nota_fiscal_servico_conta_to_string))
        {
            return $this->nota_fiscal_servico_conta_to_string;
        }
    
        $values = NotaFiscalServico::where('lancamento_id', '=', $this->id)->getIndexedArray('conta_id','{conta->descricao}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_lancamento_to_string($nota_fiscal_servico_lancamento_to_string)
    {
        if(is_array($nota_fiscal_servico_lancamento_to_string))
        {
            $values = Lancamento::where('id', 'in', $nota_fiscal_servico_lancamento_to_string)->getIndexedArray('id', 'id');
            $this->nota_fiscal_servico_lancamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_lancamento_to_string = $nota_fiscal_servico_lancamento_to_string;
        }

        $this->vdata['nota_fiscal_servico_lancamento_to_string'] = $this->nota_fiscal_servico_lancamento_to_string;
    }

    public function get_nota_fiscal_servico_lancamento_to_string()
    {
        if(!empty($this->nota_fiscal_servico_lancamento_to_string))
        {
            return $this->nota_fiscal_servico_lancamento_to_string;
        }
    
        $values = NotaFiscalServico::where('lancamento_id', '=', $this->id)->getIndexedArray('lancamento_id','{lancamento->id}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_servico_to_string($nota_fiscal_servico_servico_to_string)
    {
        if(is_array($nota_fiscal_servico_servico_to_string))
        {
            $values = Servico::where('id', 'in', $nota_fiscal_servico_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_servico_to_string = $nota_fiscal_servico_servico_to_string;
        }

        $this->vdata['nota_fiscal_servico_servico_to_string'] = $this->nota_fiscal_servico_servico_to_string;
    }

    public function get_nota_fiscal_servico_servico_to_string()
    {
        if(!empty($this->nota_fiscal_servico_servico_to_string))
        {
            return $this->nota_fiscal_servico_servico_to_string;
        }
    
        $values = NotaFiscalServico::where('lancamento_id', '=', $this->id)->getIndexedArray('servico_id','{servico->nome}');
        return implode(', ', $values);
    }

    public function onBeforeStore($object)
    {
        if (! empty($object->dt_pagamento))
        {
            $object->ano_pagamento = date('Y', strtotime($object->dt_pagamento));
            $object->mes_pagamento = date('m', strtotime($object->dt_pagamento));
            $object->ano_mes_pagamento = date('Ym', strtotime($object->dt_pagamento));
        }
    
        if (! empty($object->dt_vencimento))
        {
            $object->ano_vencimento = date('Y', strtotime($object->dt_vencimento));
            $object->mes_vencimento = date('m', strtotime($object->dt_vencimento));
            $object->ano_mes_vencimento = date('Ym', strtotime($object->dt_vencimento));
        }
    }

    public function gerarNotaFiscal()
    {
    
        if(NotaFiscalServico::where('lancamento_id', '=', $this->id)->where('conta_id', '=', $this->conta_id)->where('nota_fiscal_status_id', 'not in', [NotaFiscalStatus::CANCELADA, NotaFiscalStatus::REJEITADA])->first())
        {
            throw new Exception('Já existe uma nota fiscal gerada para essa conta');
        }
    
        // configs da empresa dona do saas
        $configuracao = SaasConfiguracao::getDefaults();
    
    
        $notaFiscal = new SaasNotaFiscalServico();

        $notaFiscal->saas_pagamento_id = $this->id;
    
        if($this->saas_contrato_id)
        {
            $contrato = $this->get_saas_contrato();
            $notaFiscal->saas_plano_valor_id = $contrato->saas_plano_valor_id;
            $notaFiscal->saas_servico_id = $contrato->saas_plano_valor->saas_plano->saas_servico_id;
            $notaFiscal->discriminacao = $contrato->saas_plano_valor->saas_plano->discriminacao;
        
            $servico = $contrato->saas_plano_valor->saas_plano->saas_servico;
        
            $notaFiscal->iss_retido = $servico->servico_grupo_imposto->iss_retido;
        }
        elseif($this->saas_servico_id)
        {
            $notaFiscal->saas_servico_id = $this->saas_servico_id;
        
            $servico = $this->get_saas_servico();
        
            $notaFiscal->discriminacao = $servico->descricao;
            $notaFiscal->iss_retido = $servico->servico_grupo_imposto->iss_retido;
        }
   
        $notaFiscal->valor_servicos = $this->valor; 
        $notaFiscal->cidade_tomador_id = $account->cidade_id;
        $notaFiscal->cidade_prestador_id = $configuracao->cidade_id;
        $notaFiscal->municipio_prestacao_servico_id = $configuracao->cidade_id;
        $notaFiscal->nota_fiscal_status_id = NotaFiscalStatus::PENDENTE;
        $notaFiscal->account_id = $account->id;
    
        $notaFiscal->natureza_operacao = $configuracao->natureza_operacao;
        $notaFiscal->data_hora_emissao = date('Y-m-d H:i:s');
    
        //substr($campo,0,60);
    
        $notaFiscal->nome_tomador = $account->razao_social;
        $notaFiscal->documento_tomador = $account->documento;
        $notaFiscal->endereco_tomador = substr($account->rua,0,19);
        $notaFiscal->email_tomador = $account->email;
        $notaFiscal->telefone_tomador = $account->telefone;
        $notaFiscal->numero_tomador = $account->numero;
        $notaFiscal->bairro_tomador = substr($account->bairro,0,24);
        $notaFiscal->cep_tomador = $account->cep;
        $notaFiscal->inscricao_municipal_tomador = '';
        $notaFiscal->inscricao_municipal_prestador = $configuracao->inscricao_municipal;
        $notaFiscal->nome_prestador = $configuracao->razao_social;
        $notaFiscal->documento_prestador = $configuracao->cnpj;
        $notaFiscal->endereco_prestador = substr($configuracao->rua,0,19);
        $notaFiscal->email_prestador = $configuracao->email;
        $notaFiscal->telefone_prestador = $configuracao->telefone;
        $notaFiscal->numero_prestador = $configuracao->numero;
        $notaFiscal->bairro_prestador = substr($configuracao->bairro,0,24);
        $notaFiscal->cep_prestador = $configuracao->cep;
    
        // echo '<pre>';
        // var_dump($notaFiscal);
        // die;
    
        $notaFiscal = SaasNotaFiscalServicoService::calculaImpostos($notaFiscal);
    
        $notaFiscal->ano = date('Y');
        $notaFiscal->mes = date('m');
        $notaFiscal->ano_mes = date('Y/m');
    
        $notaFiscal->store();
    
        $this->saas_nota_fiscal_servico_id = $notaFiscal->id;
        $this->store();
    
        return $notaFiscal;
    }
                
}

