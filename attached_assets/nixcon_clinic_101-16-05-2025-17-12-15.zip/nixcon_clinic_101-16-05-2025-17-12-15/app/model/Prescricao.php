<?php

class Prescricao extends TRecord
{
    const TABLENAME  = 'prescricao';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Atendimento $atendimento;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('atendimento_id');
        parent::addAttribute('controle_especial');
        parent::addAttribute('dt_prescricao');
    
    }

    /**
     * Method set_atendimento
     * Sample of usage: $var->atendimento = $object;
     * @param $object Instance of Atendimento
     */
    public function set_atendimento(Atendimento $object)
    {
        $this->atendimento = $object;
        $this->atendimento_id = $object->id;
    }

    /**
     * Method get_atendimento
     * Sample of usage: $var->atendimento->attribute;
     * @returns Atendimento instance
     */
    public function get_atendimento()
    {
    
        // loads the associated object
        if (empty($this->atendimento))
            $this->atendimento = new Atendimento($this->atendimento_id);
    
        // returns the associated object
        return $this->atendimento;
    }

    /**
     * Method getMedicamentos
     */
    public function getMedicamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('prescricao_id', '=', $this->id));
        return Medicamento::getObjects( $criteria );
    }

    public function set_medicamento_prescricao_to_string($medicamento_prescricao_to_string)
    {
        if(is_array($medicamento_prescricao_to_string))
        {
            $values = Prescricao::where('id', 'in', $medicamento_prescricao_to_string)->getIndexedArray('id', 'id');
            $this->medicamento_prescricao_to_string = implode(', ', $values);
        }
        else
        {
            $this->medicamento_prescricao_to_string = $medicamento_prescricao_to_string;
        }

        $this->vdata['medicamento_prescricao_to_string'] = $this->medicamento_prescricao_to_string;
    }

    public function get_medicamento_prescricao_to_string()
    {
        if(!empty($this->medicamento_prescricao_to_string))
        {
            return $this->medicamento_prescricao_to_string;
        }
    
        $values = Medicamento::where('prescricao_id', '=', $this->id)->getIndexedArray('prescricao_id','{prescricao->id}');
        return implode(', ', $values);
    }

    public function dt_prescricao_formatada()
    {
        return TDate::date2br($this->dt_prescricao);
    }
    
}

