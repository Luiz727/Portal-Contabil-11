<?php

class ExameAtendimento extends TRecord
{
    const TABLENAME  = 'exame_atendimento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Exame $exame;
    private Atendimento $atendimento;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('atendimento_id');
        parent::addAttribute('exame_id');
        parent::addAttribute('indicacao_clinica');
        parent::addAttribute('dt_exames');
        parent::addAttribute('quantidade');
    
    }

    /**
     * Method set_exame
     * Sample of usage: $var->exame = $object;
     * @param $object Instance of Exame
     */
    public function set_exame(Exame $object)
    {
        $this->exame = $object;
        $this->exame_id = $object->id;
    }

    /**
     * Method get_exame
     * Sample of usage: $var->exame->attribute;
     * @returns Exame instance
     */
    public function get_exame()
    {
    
        // loads the associated object
        if (empty($this->exame))
            $this->exame = new Exame($this->exame_id);
    
        // returns the associated object
        return $this->exame;
    }
    /**
     * Method set_atendimento
     * Sample of usage: $var->atendimento = $object;
     * @param $object Instance of Atendimento
     */
    public function set_atendimento(Atendimento $object)
    {
        $this->atendimento = $object;
        $this->atendimento_id = $object->id;
    }

    /**
     * Method get_atendimento
     * Sample of usage: $var->atendimento->attribute;
     * @returns Atendimento instance
     */
    public function get_atendimento()
    {
    
        // loads the associated object
        if (empty($this->atendimento))
            $this->atendimento = new Atendimento($this->atendimento_id);
    
        // returns the associated object
        return $this->atendimento;
    }

}

