<?php

class Formulario extends TRecord
{
    const TABLENAME  = 'formulario';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SystemUnit $clinica;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByUnit');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('clinica_id');
        parent::addAttribute('nome');
        parent::addAttribute('ativo');
        parent::addAttribute('ordem');
    
    }

    /**
     * Method set_system_unit
     * Sample of usage: $var->system_unit = $object;
     * @param $object Instance of SystemUnit
     */
    public function set_clinica(SystemUnit $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns SystemUnit instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new SystemUnit($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }

    /**
     * Method getQuestaos
     */
    public function getQuestaos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('formulario_id', '=', $this->id));
        return Questao::getObjects( $criteria );
    }
    /**
     * Method getRespostaFormularios
     */
    public function getRespostaFormularios()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('formulario_id', '=', $this->id));
        return RespostaFormulario::getObjects( $criteria );
    }

    public function set_questao_formulario_to_string($questao_formulario_to_string)
    {
        if(is_array($questao_formulario_to_string))
        {
            $values = Formulario::where('id', 'in', $questao_formulario_to_string)->getIndexedArray('nome', 'nome');
            $this->questao_formulario_to_string = implode(', ', $values);
        }
        else
        {
            $this->questao_formulario_to_string = $questao_formulario_to_string;
        }

        $this->vdata['questao_formulario_to_string'] = $this->questao_formulario_to_string;
    }

    public function get_questao_formulario_to_string()
    {
        if(!empty($this->questao_formulario_to_string))
        {
            return $this->questao_formulario_to_string;
        }
    
        $values = Questao::where('formulario_id', '=', $this->id)->getIndexedArray('formulario_id','{formulario->nome}');
        return implode(', ', $values);
    }

    public function set_resposta_formulario_formulario_to_string($resposta_formulario_formulario_to_string)
    {
        if(is_array($resposta_formulario_formulario_to_string))
        {
            $values = Formulario::where('id', 'in', $resposta_formulario_formulario_to_string)->getIndexedArray('nome', 'nome');
            $this->resposta_formulario_formulario_to_string = implode(', ', $values);
        }
        else
        {
            $this->resposta_formulario_formulario_to_string = $resposta_formulario_formulario_to_string;
        }

        $this->vdata['resposta_formulario_formulario_to_string'] = $this->resposta_formulario_formulario_to_string;
    }

    public function get_resposta_formulario_formulario_to_string()
    {
        if(!empty($this->resposta_formulario_formulario_to_string))
        {
            return $this->resposta_formulario_formulario_to_string;
        }
    
        $values = RespostaFormulario::where('formulario_id', '=', $this->id)->getIndexedArray('formulario_id','{formulario->nome}');
        return implode(', ', $values);
    }

    public function set_resposta_formulario_atendimento_to_string($resposta_formulario_atendimento_to_string)
    {
        if(is_array($resposta_formulario_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $resposta_formulario_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->resposta_formulario_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->resposta_formulario_atendimento_to_string = $resposta_formulario_atendimento_to_string;
        }

        $this->vdata['resposta_formulario_atendimento_to_string'] = $this->resposta_formulario_atendimento_to_string;
    }

    public function get_resposta_formulario_atendimento_to_string()
    {
        if(!empty($this->resposta_formulario_atendimento_to_string))
        {
            return $this->resposta_formulario_atendimento_to_string;
        }
    
        $values = RespostaFormulario::where('formulario_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

}

