<?php

class CategoriaConta extends TRecord
{
    const TABLENAME  = 'categoria_conta';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Account $account;
    private TipoConta $tipo_conta;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByAccount');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('tipo_conta_id');
        parent::addAttribute('account_id');
        parent::addAttribute('nome');
    
    }

    /**
     * Method set_account
     * Sample of usage: $var->account = $object;
     * @param $object Instance of Account
     */
    public function set_account(Account $object)
    {
        $this->account = $object;
        $this->account_id = $object->id;
    }

    /**
     * Method get_account
     * Sample of usage: $var->account->attribute;
     * @returns Account instance
     */
    public function get_account()
    {
    
        // loads the associated object
        if (empty($this->account))
            $this->account = new Account($this->account_id);
    
        // returns the associated object
        return $this->account;
    }
    /**
     * Method set_tipo_conta
     * Sample of usage: $var->tipo_conta = $object;
     * @param $object Instance of TipoConta
     */
    public function set_tipo_conta(TipoConta $object)
    {
        $this->tipo_conta = $object;
        $this->tipo_conta_id = $object->id;
    }

    /**
     * Method get_tipo_conta
     * Sample of usage: $var->tipo_conta->attribute;
     * @returns TipoConta instance
     */
    public function get_tipo_conta()
    {
    
        // loads the associated object
        if (empty($this->tipo_conta))
            $this->tipo_conta = new TipoConta($this->tipo_conta_id);
    
        // returns the associated object
        return $this->tipo_conta;
    }

    /**
     * Method getClinicas
     */
    public function getClinicas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('atendimento_categoria_conta_id', '=', $this->id));
        return Clinica::getObjects( $criteria );
    }
    /**
     * Method getContas
     */
    public function getContas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('categoria_conta_id', '=', $this->id));
        return Conta::getObjects( $criteria );
    }

    public function set_clinica_system_unit_to_string($clinica_system_unit_to_string)
    {
        if(is_array($clinica_system_unit_to_string))
        {
            $values = SystemUnit::where('id', 'in', $clinica_system_unit_to_string)->getIndexedArray('name', 'name');
            $this->clinica_system_unit_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_system_unit_to_string = $clinica_system_unit_to_string;
        }

        $this->vdata['clinica_system_unit_to_string'] = $this->clinica_system_unit_to_string;
    }

    public function get_clinica_system_unit_to_string()
    {
        if(!empty($this->clinica_system_unit_to_string))
        {
            return $this->clinica_system_unit_to_string;
        }
    
        $values = Clinica::where('atendimento_categoria_conta_id', '=', $this->id)->getIndexedArray('system_unit_id','{system_unit->name}');
        return implode(', ', $values);
    }

    public function set_clinica_atendimento_categoria_conta_to_string($clinica_atendimento_categoria_conta_to_string)
    {
        if(is_array($clinica_atendimento_categoria_conta_to_string))
        {
            $values = CategoriaConta::where('id', 'in', $clinica_atendimento_categoria_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->clinica_atendimento_categoria_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_atendimento_categoria_conta_to_string = $clinica_atendimento_categoria_conta_to_string;
        }

        $this->vdata['clinica_atendimento_categoria_conta_to_string'] = $this->clinica_atendimento_categoria_conta_to_string;
    }

    public function get_clinica_atendimento_categoria_conta_to_string()
    {
        if(!empty($this->clinica_atendimento_categoria_conta_to_string))
        {
            return $this->clinica_atendimento_categoria_conta_to_string;
        }
    
        $values = Clinica::where('atendimento_categoria_conta_id', '=', $this->id)->getIndexedArray('atendimento_categoria_conta_id','{atendimento_categoria_conta->nome}');
        return implode(', ', $values);
    }

    public function set_clinica_cidade_to_string($clinica_cidade_to_string)
    {
        if(is_array($clinica_cidade_to_string))
        {
            $values = Cidade::where('id', 'in', $clinica_cidade_to_string)->getIndexedArray('nome', 'nome');
            $this->clinica_cidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_cidade_to_string = $clinica_cidade_to_string;
        }

        $this->vdata['clinica_cidade_to_string'] = $this->clinica_cidade_to_string;
    }

    public function get_clinica_cidade_to_string()
    {
        if(!empty($this->clinica_cidade_to_string))
        {
            return $this->clinica_cidade_to_string;
        }
    
        $values = Clinica::where('atendimento_categoria_conta_id', '=', $this->id)->getIndexedArray('cidade_id','{cidade->nome}');
        return implode(', ', $values);
    }

    public function set_clinica_account_to_string($clinica_account_to_string)
    {
        if(is_array($clinica_account_to_string))
        {
            $values = Account::where('id', 'in', $clinica_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->clinica_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_account_to_string = $clinica_account_to_string;
        }

        $this->vdata['clinica_account_to_string'] = $this->clinica_account_to_string;
    }

    public function get_clinica_account_to_string()
    {
        if(!empty($this->clinica_account_to_string))
        {
            return $this->clinica_account_to_string;
        }
    
        $values = Clinica::where('atendimento_categoria_conta_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_conta_pessoa_to_string($conta_pessoa_to_string)
    {
        if(is_array($conta_pessoa_to_string))
        {
            $values = Pessoa::where('id', 'in', $conta_pessoa_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_pessoa_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_pessoa_to_string = $conta_pessoa_to_string;
        }

        $this->vdata['conta_pessoa_to_string'] = $this->conta_pessoa_to_string;
    }

    public function get_conta_pessoa_to_string()
    {
        if(!empty($this->conta_pessoa_to_string))
        {
            return $this->conta_pessoa_to_string;
        }
    
        $values = Conta::where('categoria_conta_id', '=', $this->id)->getIndexedArray('pessoa_id','{pessoa->nome}');
        return implode(', ', $values);
    }

    public function set_conta_categoria_conta_to_string($conta_categoria_conta_to_string)
    {
        if(is_array($conta_categoria_conta_to_string))
        {
            $values = CategoriaConta::where('id', 'in', $conta_categoria_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_categoria_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_categoria_conta_to_string = $conta_categoria_conta_to_string;
        }

        $this->vdata['conta_categoria_conta_to_string'] = $this->conta_categoria_conta_to_string;
    }

    public function get_conta_categoria_conta_to_string()
    {
        if(!empty($this->conta_categoria_conta_to_string))
        {
            return $this->conta_categoria_conta_to_string;
        }
    
        $values = Conta::where('categoria_conta_id', '=', $this->id)->getIndexedArray('categoria_conta_id','{categoria_conta->nome}');
        return implode(', ', $values);
    }

    public function set_conta_tipo_conta_to_string($conta_tipo_conta_to_string)
    {
        if(is_array($conta_tipo_conta_to_string))
        {
            $values = TipoConta::where('id', 'in', $conta_tipo_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_tipo_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_tipo_conta_to_string = $conta_tipo_conta_to_string;
        }

        $this->vdata['conta_tipo_conta_to_string'] = $this->conta_tipo_conta_to_string;
    }

    public function get_conta_tipo_conta_to_string()
    {
        if(!empty($this->conta_tipo_conta_to_string))
        {
            return $this->conta_tipo_conta_to_string;
        }
    
        $values = Conta::where('categoria_conta_id', '=', $this->id)->getIndexedArray('tipo_conta_id','{tipo_conta->nome}');
        return implode(', ', $values);
    }

    public function set_conta_clinica_to_string($conta_clinica_to_string)
    {
        if(is_array($conta_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $conta_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_clinica_to_string = $conta_clinica_to_string;
        }

        $this->vdata['conta_clinica_to_string'] = $this->conta_clinica_to_string;
    }

    public function get_conta_clinica_to_string()
    {
        if(!empty($this->conta_clinica_to_string))
        {
            return $this->conta_clinica_to_string;
        }
    
        $values = Conta::where('categoria_conta_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_conta_atendimento_to_string($conta_atendimento_to_string)
    {
        if(is_array($conta_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $conta_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->conta_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_atendimento_to_string = $conta_atendimento_to_string;
        }

        $this->vdata['conta_atendimento_to_string'] = $this->conta_atendimento_to_string;
    }

    public function get_conta_atendimento_to_string()
    {
        if(!empty($this->conta_atendimento_to_string))
        {
            return $this->conta_atendimento_to_string;
        }
    
        $values = Conta::where('categoria_conta_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

}

