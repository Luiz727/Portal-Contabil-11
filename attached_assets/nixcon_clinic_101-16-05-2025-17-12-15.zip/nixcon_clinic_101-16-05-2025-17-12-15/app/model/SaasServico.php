<?php

class SaasServico extends TRecord
{
    const TABLENAME  = 'saas_servico';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SaasServicoGrupoImposto $servico_grupo_imposto;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByAccount');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('servico_grupo_imposto_id');
        parent::addAttribute('nome');
        parent::addAttribute('preco');
        parent::addAttribute('descricao');
        parent::addAttribute('ativo');
    
    }

    /**
     * Method set_saas_servico_grupo_imposto
     * Sample of usage: $var->saas_servico_grupo_imposto = $object;
     * @param $object Instance of SaasServicoGrupoImposto
     */
    public function set_servico_grupo_imposto(SaasServicoGrupoImposto $object)
    {
        $this->servico_grupo_imposto = $object;
        $this->servico_grupo_imposto_id = $object->id;
    }

    /**
     * Method get_servico_grupo_imposto
     * Sample of usage: $var->servico_grupo_imposto->attribute;
     * @returns SaasServicoGrupoImposto instance
     */
    public function get_servico_grupo_imposto()
    {
    
        // loads the associated object
        if (empty($this->servico_grupo_imposto))
            $this->servico_grupo_imposto = new SaasServicoGrupoImposto($this->servico_grupo_imposto_id);
    
        // returns the associated object
        return $this->servico_grupo_imposto;
    }

    /**
     * Method getSaasNotaFiscalServicos
     */
    public function getSaasNotaFiscalServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_servico_id', '=', $this->id));
        return SaasNotaFiscalServico::getObjects( $criteria );
    }
    /**
     * Method getSaasPagamentos
     */
    public function getSaasPagamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_servico_id', '=', $this->id));
        return SaasPagamento::getObjects( $criteria );
    }
    /**
     * Method getSaasPlanos
     */
    public function getSaasPlanos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_servico_id', '=', $this->id));
        return SaasPlano::getObjects( $criteria );
    }

    public function set_saas_nota_fiscal_servico_saas_pagamento_to_string($saas_nota_fiscal_servico_saas_pagamento_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_pagamento_to_string))
        {
            $values = SaasPagamento::where('id', 'in', $saas_nota_fiscal_servico_saas_pagamento_to_string)->getIndexedArray('id', 'id');
            $this->saas_nota_fiscal_servico_saas_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_pagamento_to_string = $saas_nota_fiscal_servico_saas_pagamento_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_pagamento_to_string'] = $this->saas_nota_fiscal_servico_saas_pagamento_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_pagamento_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_pagamento_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_pagamento_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_servico_id', '=', $this->id)->getIndexedArray('saas_pagamento_id','{saas_pagamento->id}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_plano_valor_to_string($saas_nota_fiscal_servico_saas_plano_valor_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_plano_valor_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_nota_fiscal_servico_saas_plano_valor_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_saas_plano_valor_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_plano_valor_to_string = $saas_nota_fiscal_servico_saas_plano_valor_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_plano_valor_to_string'] = $this->saas_nota_fiscal_servico_saas_plano_valor_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_plano_valor_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_plano_valor_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_plano_valor_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_servico_id', '=', $this->id)->getIndexedArray('saas_plano_valor_id','{saas_plano_valor->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_servico_to_string($saas_nota_fiscal_servico_saas_servico_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_nota_fiscal_servico_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_servico_to_string = $saas_nota_fiscal_servico_saas_servico_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_servico_to_string'] = $this->saas_nota_fiscal_servico_saas_servico_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_servico_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_servico_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_servico_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_servico_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_cidade_tomador_to_string($saas_nota_fiscal_servico_cidade_tomador_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_cidade_tomador_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_cidade_tomador_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_cidade_tomador_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_cidade_tomador_to_string = $saas_nota_fiscal_servico_cidade_tomador_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_cidade_tomador_to_string'] = $this->saas_nota_fiscal_servico_cidade_tomador_to_string;
    }

    public function get_saas_nota_fiscal_servico_cidade_tomador_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_cidade_tomador_to_string))
        {
            return $this->saas_nota_fiscal_servico_cidade_tomador_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_servico_id', '=', $this->id)->getIndexedArray('cidade_tomador_id','{cidade_tomador->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_cidade_prestador_to_string($saas_nota_fiscal_servico_cidade_prestador_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_cidade_prestador_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_cidade_prestador_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_cidade_prestador_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_cidade_prestador_to_string = $saas_nota_fiscal_servico_cidade_prestador_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_cidade_prestador_to_string'] = $this->saas_nota_fiscal_servico_cidade_prestador_to_string;
    }

    public function get_saas_nota_fiscal_servico_cidade_prestador_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_cidade_prestador_to_string))
        {
            return $this->saas_nota_fiscal_servico_cidade_prestador_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_servico_id', '=', $this->id)->getIndexedArray('cidade_prestador_id','{cidade_prestador->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_municipio_prestacao_servico_to_string($saas_nota_fiscal_servico_municipio_prestacao_servico_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_municipio_prestacao_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string = $saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_municipio_prestacao_servico_to_string'] = $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
    }

    public function get_saas_nota_fiscal_servico_municipio_prestacao_servico_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            return $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_servico_id', '=', $this->id)->getIndexedArray('municipio_prestacao_servico_id','{municipio_prestacao_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_nota_fiscal_status_to_string($saas_nota_fiscal_servico_nota_fiscal_status_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            $values = NotaFiscalStatus::where('id', 'in', $saas_nota_fiscal_servico_nota_fiscal_status_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string = $saas_nota_fiscal_servico_nota_fiscal_status_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_nota_fiscal_status_to_string'] = $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string;
    }

    public function get_saas_nota_fiscal_servico_nota_fiscal_status_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            return $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_servico_id', '=', $this->id)->getIndexedArray('nota_fiscal_status_id','{nota_fiscal_status->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_account_to_string($saas_pagamento_account_to_string)
    {
        if(is_array($saas_pagamento_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_pagamento_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_pagamento_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_account_to_string = $saas_pagamento_account_to_string;
        }

        $this->vdata['saas_pagamento_account_to_string'] = $this->saas_pagamento_account_to_string;
    }

    public function get_saas_pagamento_account_to_string()
    {
        if(!empty($this->saas_pagamento_account_to_string))
        {
            return $this->saas_pagamento_account_to_string;
        }
    
        $values = SaasPagamento::where('saas_servico_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_status_pagamento_to_string($saas_pagamento_saas_status_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_status_pagamento_to_string))
        {
            $values = SaasStatusPagamento::where('id', 'in', $saas_pagamento_saas_status_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_status_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_status_pagamento_to_string = $saas_pagamento_saas_status_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_status_pagamento_to_string'] = $this->saas_pagamento_saas_status_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_status_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_status_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_status_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_servico_id', '=', $this->id)->getIndexedArray('saas_status_pagamento_id','{saas_status_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_contrato_to_string($saas_pagamento_saas_contrato_to_string)
    {
        if(is_array($saas_pagamento_saas_contrato_to_string))
        {
            $values = SaasContrato::where('id', 'in', $saas_pagamento_saas_contrato_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_contrato_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_contrato_to_string = $saas_pagamento_saas_contrato_to_string;
        }

        $this->vdata['saas_pagamento_saas_contrato_to_string'] = $this->saas_pagamento_saas_contrato_to_string;
    }

    public function get_saas_pagamento_saas_contrato_to_string()
    {
        if(!empty($this->saas_pagamento_saas_contrato_to_string))
        {
            return $this->saas_pagamento_saas_contrato_to_string;
        }
    
        $values = SaasPagamento::where('saas_servico_id', '=', $this->id)->getIndexedArray('saas_contrato_id','{saas_contrato->id}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_servico_to_string($saas_pagamento_saas_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_pagamento_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_servico_to_string = $saas_pagamento_saas_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_servico_to_string'] = $this->saas_pagamento_saas_servico_to_string;
    }

    public function get_saas_pagamento_saas_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_servico_to_string))
        {
            return $this->saas_pagamento_saas_servico_to_string;
        }
    
        $values = SaasPagamento::where('saas_servico_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_forma_pagamento_to_string($saas_pagamento_saas_forma_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_forma_pagamento_to_string))
        {
            $values = SaasFormaPagamento::where('id', 'in', $saas_pagamento_saas_forma_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_forma_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_forma_pagamento_to_string = $saas_pagamento_saas_forma_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_forma_pagamento_to_string'] = $this->saas_pagamento_saas_forma_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_forma_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_forma_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_forma_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_servico_id', '=', $this->id)->getIndexedArray('saas_forma_pagamento_id','{saas_forma_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_gateway_pagamento_to_string($saas_pagamento_saas_gateway_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_gateway_pagamento_to_string))
        {
            $values = SaasGatewayPagamento::where('id', 'in', $saas_pagamento_saas_gateway_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_gateway_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_gateway_pagamento_to_string = $saas_pagamento_saas_gateway_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_gateway_pagamento_to_string'] = $this->saas_pagamento_saas_gateway_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_gateway_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_gateway_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_gateway_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_servico_id', '=', $this->id)->getIndexedArray('saas_gateway_pagamento_id','{saas_gateway_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_nota_fiscal_servico_to_string($saas_pagamento_saas_nota_fiscal_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            $values = SaasNotaFiscalServico::where('id', 'in', $saas_pagamento_saas_nota_fiscal_servico_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = $saas_pagamento_saas_nota_fiscal_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_nota_fiscal_servico_to_string'] = $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
    }

    public function get_saas_pagamento_saas_nota_fiscal_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            return $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
        }
    
        $values = SaasPagamento::where('saas_servico_id', '=', $this->id)->getIndexedArray('saas_nota_fiscal_servico_id','{saas_nota_fiscal_servico->id}');
        return implode(', ', $values);
    }

    public function set_saas_plano_saas_servico_to_string($saas_plano_saas_servico_to_string)
    {
        if(is_array($saas_plano_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_plano_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_plano_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_plano_saas_servico_to_string = $saas_plano_saas_servico_to_string;
        }

        $this->vdata['saas_plano_saas_servico_to_string'] = $this->saas_plano_saas_servico_to_string;
    }

    public function get_saas_plano_saas_servico_to_string()
    {
        if(!empty($this->saas_plano_saas_servico_to_string))
        {
            return $this->saas_plano_saas_servico_to_string;
        }
    
        $values = SaasPlano::where('saas_servico_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

}

