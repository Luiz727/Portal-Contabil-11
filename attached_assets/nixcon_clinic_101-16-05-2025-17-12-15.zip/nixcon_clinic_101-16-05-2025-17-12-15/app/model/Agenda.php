<?php

class Agenda extends TRecord
{
    const TABLENAME  = 'agenda';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Clinica $clinica;
    private Pessoa $profissional;
    private Procedimento $procedimento;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
        
        $this->addManagePermission('PermissaoService::canManageRecordByUnit');
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
            
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('clinica_id');
        parent::addAttribute('profissional_id');
        parent::addAttribute('nome');
        parent::addAttribute('horario_inicial');
        parent::addAttribute('horario_final');
        parent::addAttribute('visualizacao_inicial');
        parent::addAttribute('horario_inicio_intervalo');
        parent::addAttribute('horario_fim_intervalo');
        parent::addAttribute('duracao');
        parent::addAttribute('dias');
        parent::addAttribute('procedimento_id');
        parent::addAttribute('cor');
        parent::addAttribute('aceita_agendamento_online');
        parent::addAttribute('publica');
        parent::addAttribute('fl_permite_choque_horario');
    
    }

    /**
     * Method set_clinica
     * Sample of usage: $var->clinica = $object;
     * @param $object Instance of Clinica
     */
    public function set_clinica(Clinica $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns Clinica instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new Clinica($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }
    /**
     * Method set_pessoa
     * Sample of usage: $var->pessoa = $object;
     * @param $object Instance of Pessoa
     */
    public function set_profissional(Pessoa $object)
    {
        $this->profissional = $object;
        $this->profissional_id = $object->id;
    }

    /**
     * Method get_profissional
     * Sample of usage: $var->profissional->attribute;
     * @returns Pessoa instance
     */
    public function get_profissional()
    {
    
        // loads the associated object
        if (empty($this->profissional))
            $this->profissional = new Pessoa($this->profissional_id);
    
        // returns the associated object
        return $this->profissional;
    }
    /**
     * Method set_procedimento
     * Sample of usage: $var->procedimento = $object;
     * @param $object Instance of Procedimento
     */
    public function set_procedimento(Procedimento $object)
    {
        $this->procedimento = $object;
        $this->procedimento_id = $object->id;
    }

    /**
     * Method get_procedimento
     * Sample of usage: $var->procedimento->attribute;
     * @returns Procedimento instance
     */
    public function get_procedimento()
    {
    
        // loads the associated object
        if (empty($this->procedimento))
            $this->procedimento = new Procedimento($this->procedimento_id);
    
        // returns the associated object
        return $this->procedimento;
    }

    /**
     * Method getAgendamentos
     */
    public function getAgendamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('agenda_id', '=', $this->id));
        return Agendamento::getObjects( $criteria );
    }
    /**
     * Method getAgendaProfissionals
     */
    public function getAgendaProfissionals()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('agenda_id', '=', $this->id));
        return AgendaProfissional::getObjects( $criteria );
    }
    /**
     * Method getBloqueios
     */
    public function getBloqueios()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('agenda_id', '=', $this->id));
        return Bloqueio::getObjects( $criteria );
    }

    public function set_agendamento_paciente_to_string($agendamento_paciente_to_string)
    {
        if(is_array($agendamento_paciente_to_string))
        {
            $values = Pessoa::where('id', 'in', $agendamento_paciente_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_paciente_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_paciente_to_string = $agendamento_paciente_to_string;
        }

        $this->vdata['agendamento_paciente_to_string'] = $this->agendamento_paciente_to_string;
    }

    public function get_agendamento_paciente_to_string()
    {
        if(!empty($this->agendamento_paciente_to_string))
        {
            return $this->agendamento_paciente_to_string;
        }
    
        $values = Agendamento::where('agenda_id', '=', $this->id)->getIndexedArray('paciente_id','{paciente->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_estado_agenda_to_string($agendamento_estado_agenda_to_string)
    {
        if(is_array($agendamento_estado_agenda_to_string))
        {
            $values = EstadoAgenda::where('id', 'in', $agendamento_estado_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_estado_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_estado_agenda_to_string = $agendamento_estado_agenda_to_string;
        }

        $this->vdata['agendamento_estado_agenda_to_string'] = $this->agendamento_estado_agenda_to_string;
    }

    public function get_agendamento_estado_agenda_to_string()
    {
        if(!empty($this->agendamento_estado_agenda_to_string))
        {
            return $this->agendamento_estado_agenda_to_string;
        }
    
        $values = Agendamento::where('agenda_id', '=', $this->id)->getIndexedArray('estado_agenda_id','{estado_agenda->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_agenda_to_string($agendamento_agenda_to_string)
    {
        if(is_array($agendamento_agenda_to_string))
        {
            $values = Agenda::where('id', 'in', $agendamento_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_agenda_to_string = $agendamento_agenda_to_string;
        }

        $this->vdata['agendamento_agenda_to_string'] = $this->agendamento_agenda_to_string;
    }

    public function get_agendamento_agenda_to_string()
    {
        if(!empty($this->agendamento_agenda_to_string))
        {
            return $this->agendamento_agenda_to_string;
        }
    
        $values = Agendamento::where('agenda_id', '=', $this->id)->getIndexedArray('agenda_id','{agenda->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_clinica_to_string($agendamento_clinica_to_string)
    {
        if(is_array($agendamento_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $agendamento_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_clinica_to_string = $agendamento_clinica_to_string;
        }

        $this->vdata['agendamento_clinica_to_string'] = $this->agendamento_clinica_to_string;
    }

    public function get_agendamento_clinica_to_string()
    {
        if(!empty($this->agendamento_clinica_to_string))
        {
            return $this->agendamento_clinica_to_string;
        }
    
        $values = Agendamento::where('agenda_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_especialidade_to_string($agendamento_especialidade_to_string)
    {
        if(is_array($agendamento_especialidade_to_string))
        {
            $values = Especialidade::where('id', 'in', $agendamento_especialidade_to_string)->getIndexedArray('descricao', 'descricao');
            $this->agendamento_especialidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_especialidade_to_string = $agendamento_especialidade_to_string;
        }

        $this->vdata['agendamento_especialidade_to_string'] = $this->agendamento_especialidade_to_string;
    }

    public function get_agendamento_especialidade_to_string()
    {
        if(!empty($this->agendamento_especialidade_to_string))
        {
            return $this->agendamento_especialidade_to_string;
        }
    
        $values = Agendamento::where('agenda_id', '=', $this->id)->getIndexedArray('especialidade_id','{especialidade->descricao}');
        return implode(', ', $values);
    }

    public function set_agenda_profissional_profissional_to_string($agenda_profissional_profissional_to_string)
    {
        if(is_array($agenda_profissional_profissional_to_string))
        {
            $values = Pessoa::where('id', 'in', $agenda_profissional_profissional_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_profissional_profissional_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_profissional_profissional_to_string = $agenda_profissional_profissional_to_string;
        }

        $this->vdata['agenda_profissional_profissional_to_string'] = $this->agenda_profissional_profissional_to_string;
    }

    public function get_agenda_profissional_profissional_to_string()
    {
        if(!empty($this->agenda_profissional_profissional_to_string))
        {
            return $this->agenda_profissional_profissional_to_string;
        }
    
        $values = AgendaProfissional::where('agenda_id', '=', $this->id)->getIndexedArray('profissional_id','{profissional->nome}');
        return implode(', ', $values);
    }

    public function set_agenda_profissional_clinica_to_string($agenda_profissional_clinica_to_string)
    {
        if(is_array($agenda_profissional_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $agenda_profissional_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_profissional_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_profissional_clinica_to_string = $agenda_profissional_clinica_to_string;
        }

        $this->vdata['agenda_profissional_clinica_to_string'] = $this->agenda_profissional_clinica_to_string;
    }

    public function get_agenda_profissional_clinica_to_string()
    {
        if(!empty($this->agenda_profissional_clinica_to_string))
        {
            return $this->agenda_profissional_clinica_to_string;
        }
    
        $values = AgendaProfissional::where('agenda_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_agenda_profissional_agenda_to_string($agenda_profissional_agenda_to_string)
    {
        if(is_array($agenda_profissional_agenda_to_string))
        {
            $values = Agenda::where('id', 'in', $agenda_profissional_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_profissional_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_profissional_agenda_to_string = $agenda_profissional_agenda_to_string;
        }

        $this->vdata['agenda_profissional_agenda_to_string'] = $this->agenda_profissional_agenda_to_string;
    }

    public function get_agenda_profissional_agenda_to_string()
    {
        if(!empty($this->agenda_profissional_agenda_to_string))
        {
            return $this->agenda_profissional_agenda_to_string;
        }
    
        $values = AgendaProfissional::where('agenda_id', '=', $this->id)->getIndexedArray('agenda_id','{agenda->nome}');
        return implode(', ', $values);
    }

    public function set_bloqueio_agenda_to_string($bloqueio_agenda_to_string)
    {
        if(is_array($bloqueio_agenda_to_string))
        {
            $values = Agenda::where('id', 'in', $bloqueio_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->bloqueio_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->bloqueio_agenda_to_string = $bloqueio_agenda_to_string;
        }

        $this->vdata['bloqueio_agenda_to_string'] = $this->bloqueio_agenda_to_string;
    }

    public function get_bloqueio_agenda_to_string()
    {
        if(!empty($this->bloqueio_agenda_to_string))
        {
            return $this->bloqueio_agenda_to_string;
        }
    
        $values = Bloqueio::where('agenda_id', '=', $this->id)->getIndexedArray('agenda_id','{agenda->nome}');
        return implode(', ', $values);
    }

    public function set_bloqueio_clinica_to_string($bloqueio_clinica_to_string)
    {
        if(is_array($bloqueio_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $bloqueio_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->bloqueio_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->bloqueio_clinica_to_string = $bloqueio_clinica_to_string;
        }

        $this->vdata['bloqueio_clinica_to_string'] = $this->bloqueio_clinica_to_string;
    }

    public function get_bloqueio_clinica_to_string()
    {
        if(!empty($this->bloqueio_clinica_to_string))
        {
            return $this->bloqueio_clinica_to_string;
        }
    
        $values = Bloqueio::where('agenda_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function get_cor_agenda()
    {
        if ($this->cor)
        {
            return $this->cor;
        }
    
        return $this->get_profissional()->cor;
    }
        
}

