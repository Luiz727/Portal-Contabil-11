<?php

class Questao extends TRecord
{
    const TABLENAME  = 'questao';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Formulario $formulario;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('formulario_id');
        parent::addAttribute('nome');
        parent::addAttribute('tipo_campo');
        parent::addAttribute('fl_obrigatorio');
        parent::addAttribute('ativo');
        parent::addAttribute('opcoes');
    
    }

    /**
     * Method set_formulario
     * Sample of usage: $var->formulario = $object;
     * @param $object Instance of Formulario
     */
    public function set_formulario(Formulario $object)
    {
        $this->formulario = $object;
        $this->formulario_id = $object->id;
    }

    /**
     * Method get_formulario
     * Sample of usage: $var->formulario->attribute;
     * @returns Formulario instance
     */
    public function get_formulario()
    {
    
        // loads the associated object
        if (empty($this->formulario))
            $this->formulario = new Formulario($this->formulario_id);
    
        // returns the associated object
        return $this->formulario;
    }

    /**
     * Method getRespostas
     */
    public function getRespostas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('questao_id', '=', $this->id));
        return Resposta::getObjects( $criteria );
    }

    public function set_resposta_resposta_formulario_to_string($resposta_resposta_formulario_to_string)
    {
        if(is_array($resposta_resposta_formulario_to_string))
        {
            $values = RespostaFormulario::where('id', 'in', $resposta_resposta_formulario_to_string)->getIndexedArray('id', 'id');
            $this->resposta_resposta_formulario_to_string = implode(', ', $values);
        }
        else
        {
            $this->resposta_resposta_formulario_to_string = $resposta_resposta_formulario_to_string;
        }

        $this->vdata['resposta_resposta_formulario_to_string'] = $this->resposta_resposta_formulario_to_string;
    }

    public function get_resposta_resposta_formulario_to_string()
    {
        if(!empty($this->resposta_resposta_formulario_to_string))
        {
            return $this->resposta_resposta_formulario_to_string;
        }
    
        $values = Resposta::where('questao_id', '=', $this->id)->getIndexedArray('resposta_formulario_id','{resposta_formulario->id}');
        return implode(', ', $values);
    }

    public function set_resposta_questao_to_string($resposta_questao_to_string)
    {
        if(is_array($resposta_questao_to_string))
        {
            $values = Questao::where('id', 'in', $resposta_questao_to_string)->getIndexedArray('nome', 'nome');
            $this->resposta_questao_to_string = implode(', ', $values);
        }
        else
        {
            $this->resposta_questao_to_string = $resposta_questao_to_string;
        }

        $this->vdata['resposta_questao_to_string'] = $this->resposta_questao_to_string;
    }

    public function get_resposta_questao_to_string()
    {
        if(!empty($this->resposta_questao_to_string))
        {
            return $this->resposta_questao_to_string;
        }
    
        $values = Resposta::where('questao_id', '=', $this->id)->getIndexedArray('questao_id','{questao->nome}');
        return implode(', ', $values);
    }

}

