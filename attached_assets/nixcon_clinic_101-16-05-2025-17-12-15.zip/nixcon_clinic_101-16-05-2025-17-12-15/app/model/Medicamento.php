<?php

class Medicamento extends TRecord
{
    const TABLENAME  = 'medicamento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Prescricao $prescricao;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('prescricao_id');
        parent::addAttribute('medicamento');
        parent::addAttribute('quantidade');
        parent::addAttribute('posologia');
    
    }

    /**
     * Method set_prescricao
     * Sample of usage: $var->prescricao = $object;
     * @param $object Instance of Prescricao
     */
    public function set_prescricao(Prescricao $object)
    {
        $this->prescricao = $object;
        $this->prescricao_id = $object->id;
    }

    /**
     * Method get_prescricao
     * Sample of usage: $var->prescricao->attribute;
     * @returns Prescricao instance
     */
    public function get_prescricao()
    {
    
        // loads the associated object
        if (empty($this->prescricao))
            $this->prescricao = new Prescricao($this->prescricao_id);
    
        // returns the associated object
        return $this->prescricao;
    }

}

