<?php

class RespostaFormulario extends TRecord
{
    const TABLENAME  = 'resposta_formulario';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Formulario $formulario;
    private Atendimento $atendimento;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('formulario_id');
        parent::addAttribute('atendimento_id');
        parent::addAttribute('dt_resposta');
    
    }

    /**
     * Method set_formulario
     * Sample of usage: $var->formulario = $object;
     * @param $object Instance of Formulario
     */
    public function set_formulario(Formulario $object)
    {
        $this->formulario = $object;
        $this->formulario_id = $object->id;
    }

    /**
     * Method get_formulario
     * Sample of usage: $var->formulario->attribute;
     * @returns Formulario instance
     */
    public function get_formulario()
    {
    
        // loads the associated object
        if (empty($this->formulario))
            $this->formulario = new Formulario($this->formulario_id);
    
        // returns the associated object
        return $this->formulario;
    }
    /**
     * Method set_atendimento
     * Sample of usage: $var->atendimento = $object;
     * @param $object Instance of Atendimento
     */
    public function set_atendimento(Atendimento $object)
    {
        $this->atendimento = $object;
        $this->atendimento_id = $object->id;
    }

    /**
     * Method get_atendimento
     * Sample of usage: $var->atendimento->attribute;
     * @returns Atendimento instance
     */
    public function get_atendimento()
    {
    
        // loads the associated object
        if (empty($this->atendimento))
            $this->atendimento = new Atendimento($this->atendimento_id);
    
        // returns the associated object
        return $this->atendimento;
    }

    /**
     * Method getRespostas
     */
    public function getRespostas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('resposta_formulario_id', '=', $this->id));
        return Resposta::getObjects( $criteria );
    }

    public function set_resposta_resposta_formulario_to_string($resposta_resposta_formulario_to_string)
    {
        if(is_array($resposta_resposta_formulario_to_string))
        {
            $values = RespostaFormulario::where('id', 'in', $resposta_resposta_formulario_to_string)->getIndexedArray('id', 'id');
            $this->resposta_resposta_formulario_to_string = implode(', ', $values);
        }
        else
        {
            $this->resposta_resposta_formulario_to_string = $resposta_resposta_formulario_to_string;
        }

        $this->vdata['resposta_resposta_formulario_to_string'] = $this->resposta_resposta_formulario_to_string;
    }

    public function get_resposta_resposta_formulario_to_string()
    {
        if(!empty($this->resposta_resposta_formulario_to_string))
        {
            return $this->resposta_resposta_formulario_to_string;
        }
    
        $values = Resposta::where('resposta_formulario_id', '=', $this->id)->getIndexedArray('resposta_formulario_id','{resposta_formulario->id}');
        return implode(', ', $values);
    }

    public function set_resposta_questao_to_string($resposta_questao_to_string)
    {
        if(is_array($resposta_questao_to_string))
        {
            $values = Questao::where('id', 'in', $resposta_questao_to_string)->getIndexedArray('nome', 'nome');
            $this->resposta_questao_to_string = implode(', ', $values);
        }
        else
        {
            $this->resposta_questao_to_string = $resposta_questao_to_string;
        }

        $this->vdata['resposta_questao_to_string'] = $this->resposta_questao_to_string;
    }

    public function get_resposta_questao_to_string()
    {
        if(!empty($this->resposta_questao_to_string))
        {
            return $this->resposta_questao_to_string;
        }
    
        $values = Resposta::where('resposta_formulario_id', '=', $this->id)->getIndexedArray('questao_id','{questao->nome}');
        return implode(', ', $values);
    }

}

