<?php

class Exame extends TRecord
{
    const TABLENAME  = 'exame';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Clinica $clinica;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByUnit');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('ativo');
        parent::addAttribute('nome');
        parent::addAttribute('codigo_referencia');
        parent::addAttribute('clinica_id');
    
    }

    /**
     * Method set_clinica
     * Sample of usage: $var->clinica = $object;
     * @param $object Instance of Clinica
     */
    public function set_clinica(Clinica $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns Clinica instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new Clinica($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }

    /**
     * Method getExameAtendimentos
     */
    public function getExameAtendimentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('exame_id', '=', $this->id));
        return ExameAtendimento::getObjects( $criteria );
    }

    public function set_exame_atendimento_atendimento_to_string($exame_atendimento_atendimento_to_string)
    {
        if(is_array($exame_atendimento_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $exame_atendimento_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->exame_atendimento_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->exame_atendimento_atendimento_to_string = $exame_atendimento_atendimento_to_string;
        }

        $this->vdata['exame_atendimento_atendimento_to_string'] = $this->exame_atendimento_atendimento_to_string;
    }

    public function get_exame_atendimento_atendimento_to_string()
    {
        if(!empty($this->exame_atendimento_atendimento_to_string))
        {
            return $this->exame_atendimento_atendimento_to_string;
        }
    
        $values = ExameAtendimento::where('exame_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_exame_atendimento_exame_to_string($exame_atendimento_exame_to_string)
    {
        if(is_array($exame_atendimento_exame_to_string))
        {
            $values = Exame::where('id', 'in', $exame_atendimento_exame_to_string)->getIndexedArray('nome', 'nome');
            $this->exame_atendimento_exame_to_string = implode(', ', $values);
        }
        else
        {
            $this->exame_atendimento_exame_to_string = $exame_atendimento_exame_to_string;
        }

        $this->vdata['exame_atendimento_exame_to_string'] = $this->exame_atendimento_exame_to_string;
    }

    public function get_exame_atendimento_exame_to_string()
    {
        if(!empty($this->exame_atendimento_exame_to_string))
        {
            return $this->exame_atendimento_exame_to_string;
        }
    
        $values = ExameAtendimento::where('exame_id', '=', $this->id)->getIndexedArray('exame_id','{exame->nome}');
        return implode(', ', $values);
    }

}

