<?php

class Cidade extends TRecord
{
    const TABLENAME  = 'cidade';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Estado $estado;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('estado_id');
        parent::addAttribute('nome');
        parent::addAttribute('codigo_ibge');
    
    }

    /**
     * Method set_estado
     * Sample of usage: $var->estado = $object;
     * @param $object Instance of Estado
     */
    public function set_estado(Estado $object)
    {
        $this->estado = $object;
        $this->estado_id = $object->id;
    }

    /**
     * Method get_estado
     * Sample of usage: $var->estado->attribute;
     * @returns Estado instance
     */
    public function get_estado()
    {
    
        // loads the associated object
        if (empty($this->estado))
            $this->estado = new Estado($this->estado_id);
    
        // returns the associated object
        return $this->estado;
    }

    /**
     * Method getAccounts
     */
    public function getAccounts()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('cidade_id', '=', $this->id));
        return Account::getObjects( $criteria );
    }
    /**
     * Method getClinicas
     */
    public function getClinicas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('cidade_id', '=', $this->id));
        return Clinica::getObjects( $criteria );
    }
    /**
     * Method getNotaFiscalServicos
     */
    public function getNotaFiscalServicosByMunicipioPrestacaoServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('municipio_prestacao_servico_id', '=', $this->id));
        return NotaFiscalServico::getObjects( $criteria );
    }
    /**
     * Method getNotaFiscalServicos
     */
    public function getNotaFiscalServicosByCidadeTomadors()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('cidade_tomador_id', '=', $this->id));
        return NotaFiscalServico::getObjects( $criteria );
    }
    /**
     * Method getNotaFiscalServicos
     */
    public function getNotaFiscalServicosByCidadePrestadors()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('cidade_prestador_id', '=', $this->id));
        return NotaFiscalServico::getObjects( $criteria );
    }
    /**
     * Method getPessoaEnderecos
     */
    public function getPessoaEnderecos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('cidade_id', '=', $this->id));
        return PessoaEndereco::getObjects( $criteria );
    }
    /**
     * Method getSaasConfiguracaos
     */
    public function getSaasConfiguracaos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('cidade_id', '=', $this->id));
        return SaasConfiguracao::getObjects( $criteria );
    }
    /**
     * Method getSaasNotaFiscalServicos
     */
    public function getSaasNotaFiscalServicosByCidadePrestadors()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('cidade_prestador_id', '=', $this->id));
        return SaasNotaFiscalServico::getObjects( $criteria );
    }
    /**
     * Method getSaasNotaFiscalServicos
     */
    public function getSaasNotaFiscalServicosByMunicipioPrestacaoServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('municipio_prestacao_servico_id', '=', $this->id));
        return SaasNotaFiscalServico::getObjects( $criteria );
    }
    /**
     * Method getSaasNotaFiscalServicos
     */
    public function getSaasNotaFiscalServicosByCidadeTomadors()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('cidade_tomador_id', '=', $this->id));
        return SaasNotaFiscalServico::getObjects( $criteria );
    }

    public function set_account_cidade_to_string($account_cidade_to_string)
    {
        if(is_array($account_cidade_to_string))
        {
            $values = Cidade::where('id', 'in', $account_cidade_to_string)->getIndexedArray('nome', 'nome');
            $this->account_cidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->account_cidade_to_string = $account_cidade_to_string;
        }

        $this->vdata['account_cidade_to_string'] = $this->account_cidade_to_string;
    }

    public function get_account_cidade_to_string()
    {
        if(!empty($this->account_cidade_to_string))
        {
            return $this->account_cidade_to_string;
        }
    
        $values = Account::where('cidade_id', '=', $this->id)->getIndexedArray('cidade_id','{cidade->nome}');
        return implode(', ', $values);
    }

    public function set_account_system_user_to_string($account_system_user_to_string)
    {
        if(is_array($account_system_user_to_string))
        {
            $values = SystemUsers::where('id', 'in', $account_system_user_to_string)->getIndexedArray('name', 'name');
            $this->account_system_user_to_string = implode(', ', $values);
        }
        else
        {
            $this->account_system_user_to_string = $account_system_user_to_string;
        }

        $this->vdata['account_system_user_to_string'] = $this->account_system_user_to_string;
    }

    public function get_account_system_user_to_string()
    {
        if(!empty($this->account_system_user_to_string))
        {
            return $this->account_system_user_to_string;
        }
    
        $values = Account::where('cidade_id', '=', $this->id)->getIndexedArray('system_user_id','{system_user->name}');
        return implode(', ', $values);
    }

    public function set_clinica_system_unit_to_string($clinica_system_unit_to_string)
    {
        if(is_array($clinica_system_unit_to_string))
        {
            $values = SystemUnit::where('id', 'in', $clinica_system_unit_to_string)->getIndexedArray('name', 'name');
            $this->clinica_system_unit_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_system_unit_to_string = $clinica_system_unit_to_string;
        }

        $this->vdata['clinica_system_unit_to_string'] = $this->clinica_system_unit_to_string;
    }

    public function get_clinica_system_unit_to_string()
    {
        if(!empty($this->clinica_system_unit_to_string))
        {
            return $this->clinica_system_unit_to_string;
        }
    
        $values = Clinica::where('cidade_id', '=', $this->id)->getIndexedArray('system_unit_id','{system_unit->name}');
        return implode(', ', $values);
    }

    public function set_clinica_atendimento_categoria_conta_to_string($clinica_atendimento_categoria_conta_to_string)
    {
        if(is_array($clinica_atendimento_categoria_conta_to_string))
        {
            $values = CategoriaConta::where('id', 'in', $clinica_atendimento_categoria_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->clinica_atendimento_categoria_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_atendimento_categoria_conta_to_string = $clinica_atendimento_categoria_conta_to_string;
        }

        $this->vdata['clinica_atendimento_categoria_conta_to_string'] = $this->clinica_atendimento_categoria_conta_to_string;
    }

    public function get_clinica_atendimento_categoria_conta_to_string()
    {
        if(!empty($this->clinica_atendimento_categoria_conta_to_string))
        {
            return $this->clinica_atendimento_categoria_conta_to_string;
        }
    
        $values = Clinica::where('cidade_id', '=', $this->id)->getIndexedArray('atendimento_categoria_conta_id','{atendimento_categoria_conta->nome}');
        return implode(', ', $values);
    }

    public function set_clinica_cidade_to_string($clinica_cidade_to_string)
    {
        if(is_array($clinica_cidade_to_string))
        {
            $values = Cidade::where('id', 'in', $clinica_cidade_to_string)->getIndexedArray('nome', 'nome');
            $this->clinica_cidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_cidade_to_string = $clinica_cidade_to_string;
        }

        $this->vdata['clinica_cidade_to_string'] = $this->clinica_cidade_to_string;
    }

    public function get_clinica_cidade_to_string()
    {
        if(!empty($this->clinica_cidade_to_string))
        {
            return $this->clinica_cidade_to_string;
        }
    
        $values = Clinica::where('cidade_id', '=', $this->id)->getIndexedArray('cidade_id','{cidade->nome}');
        return implode(', ', $values);
    }

    public function set_clinica_account_to_string($clinica_account_to_string)
    {
        if(is_array($clinica_account_to_string))
        {
            $values = Account::where('id', 'in', $clinica_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->clinica_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_account_to_string = $clinica_account_to_string;
        }

        $this->vdata['clinica_account_to_string'] = $this->clinica_account_to_string;
    }

    public function get_clinica_account_to_string()
    {
        if(!empty($this->clinica_account_to_string))
        {
            return $this->clinica_account_to_string;
        }
    
        $values = Clinica::where('cidade_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cidade_tomador_to_string($nota_fiscal_servico_cidade_tomador_to_string)
    {
        if(is_array($nota_fiscal_servico_cidade_tomador_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_cidade_tomador_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cidade_tomador_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cidade_tomador_to_string = $nota_fiscal_servico_cidade_tomador_to_string;
        }

        $this->vdata['nota_fiscal_servico_cidade_tomador_to_string'] = $this->nota_fiscal_servico_cidade_tomador_to_string;
    }

    public function get_nota_fiscal_servico_cidade_tomador_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cidade_tomador_to_string))
        {
            return $this->nota_fiscal_servico_cidade_tomador_to_string;
        }
    
        $values = NotaFiscalServico::where('cidade_prestador_id', '=', $this->id)->getIndexedArray('cidade_tomador_id','{cidade_tomador->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cidade_prestador_to_string($nota_fiscal_servico_cidade_prestador_to_string)
    {
        if(is_array($nota_fiscal_servico_cidade_prestador_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_cidade_prestador_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cidade_prestador_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cidade_prestador_to_string = $nota_fiscal_servico_cidade_prestador_to_string;
        }

        $this->vdata['nota_fiscal_servico_cidade_prestador_to_string'] = $this->nota_fiscal_servico_cidade_prestador_to_string;
    }

    public function get_nota_fiscal_servico_cidade_prestador_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cidade_prestador_to_string))
        {
            return $this->nota_fiscal_servico_cidade_prestador_to_string;
        }
    
        $values = NotaFiscalServico::where('cidade_prestador_id', '=', $this->id)->getIndexedArray('cidade_prestador_id','{cidade_prestador->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_municipio_prestacao_servico_to_string($nota_fiscal_servico_municipio_prestacao_servico_to_string)
    {
        if(is_array($nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_municipio_prestacao_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_municipio_prestacao_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_municipio_prestacao_servico_to_string = $nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }

        $this->vdata['nota_fiscal_servico_municipio_prestacao_servico_to_string'] = $this->nota_fiscal_servico_municipio_prestacao_servico_to_string;
    }

    public function get_nota_fiscal_servico_municipio_prestacao_servico_to_string()
    {
        if(!empty($this->nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            return $this->nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }
    
        $values = NotaFiscalServico::where('cidade_prestador_id', '=', $this->id)->getIndexedArray('municipio_prestacao_servico_id','{municipio_prestacao_servico->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_nota_fiscal_status_to_string($nota_fiscal_servico_nota_fiscal_status_to_string)
    {
        if(is_array($nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            $values = NotaFiscalStatus::where('id', 'in', $nota_fiscal_servico_nota_fiscal_status_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_nota_fiscal_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_nota_fiscal_status_to_string = $nota_fiscal_servico_nota_fiscal_status_to_string;
        }

        $this->vdata['nota_fiscal_servico_nota_fiscal_status_to_string'] = $this->nota_fiscal_servico_nota_fiscal_status_to_string;
    }

    public function get_nota_fiscal_servico_nota_fiscal_status_to_string()
    {
        if(!empty($this->nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            return $this->nota_fiscal_servico_nota_fiscal_status_to_string;
        }
    
        $values = NotaFiscalServico::where('cidade_prestador_id', '=', $this->id)->getIndexedArray('nota_fiscal_status_id','{nota_fiscal_status->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_clinica_to_string($nota_fiscal_servico_clinica_to_string)
    {
        if(is_array($nota_fiscal_servico_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $nota_fiscal_servico_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_clinica_to_string = $nota_fiscal_servico_clinica_to_string;
        }

        $this->vdata['nota_fiscal_servico_clinica_to_string'] = $this->nota_fiscal_servico_clinica_to_string;
    }

    public function get_nota_fiscal_servico_clinica_to_string()
    {
        if(!empty($this->nota_fiscal_servico_clinica_to_string))
        {
            return $this->nota_fiscal_servico_clinica_to_string;
        }
    
        $values = NotaFiscalServico::where('cidade_prestador_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cliente_to_string($nota_fiscal_servico_cliente_to_string)
    {
        if(is_array($nota_fiscal_servico_cliente_to_string))
        {
            $values = Pessoa::where('id', 'in', $nota_fiscal_servico_cliente_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cliente_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cliente_to_string = $nota_fiscal_servico_cliente_to_string;
        }

        $this->vdata['nota_fiscal_servico_cliente_to_string'] = $this->nota_fiscal_servico_cliente_to_string;
    }

    public function get_nota_fiscal_servico_cliente_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cliente_to_string))
        {
            return $this->nota_fiscal_servico_cliente_to_string;
        }
    
        $values = NotaFiscalServico::where('cidade_prestador_id', '=', $this->id)->getIndexedArray('cliente_id','{cliente->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_conta_to_string($nota_fiscal_servico_conta_to_string)
    {
        if(is_array($nota_fiscal_servico_conta_to_string))
        {
            $values = Conta::where('id', 'in', $nota_fiscal_servico_conta_to_string)->getIndexedArray('descricao', 'descricao');
            $this->nota_fiscal_servico_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_conta_to_string = $nota_fiscal_servico_conta_to_string;
        }

        $this->vdata['nota_fiscal_servico_conta_to_string'] = $this->nota_fiscal_servico_conta_to_string;
    }

    public function get_nota_fiscal_servico_conta_to_string()
    {
        if(!empty($this->nota_fiscal_servico_conta_to_string))
        {
            return $this->nota_fiscal_servico_conta_to_string;
        }
    
        $values = NotaFiscalServico::where('cidade_prestador_id', '=', $this->id)->getIndexedArray('conta_id','{conta->descricao}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_lancamento_to_string($nota_fiscal_servico_lancamento_to_string)
    {
        if(is_array($nota_fiscal_servico_lancamento_to_string))
        {
            $values = Lancamento::where('id', 'in', $nota_fiscal_servico_lancamento_to_string)->getIndexedArray('id', 'id');
            $this->nota_fiscal_servico_lancamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_lancamento_to_string = $nota_fiscal_servico_lancamento_to_string;
        }

        $this->vdata['nota_fiscal_servico_lancamento_to_string'] = $this->nota_fiscal_servico_lancamento_to_string;
    }

    public function get_nota_fiscal_servico_lancamento_to_string()
    {
        if(!empty($this->nota_fiscal_servico_lancamento_to_string))
        {
            return $this->nota_fiscal_servico_lancamento_to_string;
        }
    
        $values = NotaFiscalServico::where('cidade_prestador_id', '=', $this->id)->getIndexedArray('lancamento_id','{lancamento->id}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_servico_to_string($nota_fiscal_servico_servico_to_string)
    {
        if(is_array($nota_fiscal_servico_servico_to_string))
        {
            $values = Servico::where('id', 'in', $nota_fiscal_servico_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_servico_to_string = $nota_fiscal_servico_servico_to_string;
        }

        $this->vdata['nota_fiscal_servico_servico_to_string'] = $this->nota_fiscal_servico_servico_to_string;
    }

    public function get_nota_fiscal_servico_servico_to_string()
    {
        if(!empty($this->nota_fiscal_servico_servico_to_string))
        {
            return $this->nota_fiscal_servico_servico_to_string;
        }
    
        $values = NotaFiscalServico::where('cidade_prestador_id', '=', $this->id)->getIndexedArray('servico_id','{servico->nome}');
        return implode(', ', $values);
    }

    public function set_pessoa_endereco_pessoa_to_string($pessoa_endereco_pessoa_to_string)
    {
        if(is_array($pessoa_endereco_pessoa_to_string))
        {
            $values = Pessoa::where('id', 'in', $pessoa_endereco_pessoa_to_string)->getIndexedArray('nome', 'nome');
            $this->pessoa_endereco_pessoa_to_string = implode(', ', $values);
        }
        else
        {
            $this->pessoa_endereco_pessoa_to_string = $pessoa_endereco_pessoa_to_string;
        }

        $this->vdata['pessoa_endereco_pessoa_to_string'] = $this->pessoa_endereco_pessoa_to_string;
    }

    public function get_pessoa_endereco_pessoa_to_string()
    {
        if(!empty($this->pessoa_endereco_pessoa_to_string))
        {
            return $this->pessoa_endereco_pessoa_to_string;
        }
    
        $values = PessoaEndereco::where('cidade_id', '=', $this->id)->getIndexedArray('pessoa_id','{pessoa->nome}');
        return implode(', ', $values);
    }

    public function set_pessoa_endereco_cidade_to_string($pessoa_endereco_cidade_to_string)
    {
        if(is_array($pessoa_endereco_cidade_to_string))
        {
            $values = Cidade::where('id', 'in', $pessoa_endereco_cidade_to_string)->getIndexedArray('nome', 'nome');
            $this->pessoa_endereco_cidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->pessoa_endereco_cidade_to_string = $pessoa_endereco_cidade_to_string;
        }

        $this->vdata['pessoa_endereco_cidade_to_string'] = $this->pessoa_endereco_cidade_to_string;
    }

    public function get_pessoa_endereco_cidade_to_string()
    {
        if(!empty($this->pessoa_endereco_cidade_to_string))
        {
            return $this->pessoa_endereco_cidade_to_string;
        }
    
        $values = PessoaEndereco::where('cidade_id', '=', $this->id)->getIndexedArray('cidade_id','{cidade->nome}');
        return implode(', ', $values);
    }

    public function set_saas_configuracao_cidade_to_string($saas_configuracao_cidade_to_string)
    {
        if(is_array($saas_configuracao_cidade_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_configuracao_cidade_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_configuracao_cidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_configuracao_cidade_to_string = $saas_configuracao_cidade_to_string;
        }

        $this->vdata['saas_configuracao_cidade_to_string'] = $this->saas_configuracao_cidade_to_string;
    }

    public function get_saas_configuracao_cidade_to_string()
    {
        if(!empty($this->saas_configuracao_cidade_to_string))
        {
            return $this->saas_configuracao_cidade_to_string;
        }
    
        $values = SaasConfiguracao::where('cidade_id', '=', $this->id)->getIndexedArray('cidade_id','{cidade->nome}');
        return implode(', ', $values);
    }

    public function set_saas_configuracao_saas_plano_valor_trial_to_string($saas_configuracao_saas_plano_valor_trial_to_string)
    {
        if(is_array($saas_configuracao_saas_plano_valor_trial_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_configuracao_saas_plano_valor_trial_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_configuracao_saas_plano_valor_trial_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_configuracao_saas_plano_valor_trial_to_string = $saas_configuracao_saas_plano_valor_trial_to_string;
        }

        $this->vdata['saas_configuracao_saas_plano_valor_trial_to_string'] = $this->saas_configuracao_saas_plano_valor_trial_to_string;
    }

    public function get_saas_configuracao_saas_plano_valor_trial_to_string()
    {
        if(!empty($this->saas_configuracao_saas_plano_valor_trial_to_string))
        {
            return $this->saas_configuracao_saas_plano_valor_trial_to_string;
        }
    
        $values = SaasConfiguracao::where('cidade_id', '=', $this->id)->getIndexedArray('saas_plano_valor_trial_id','{saas_plano_valor_trial->nome}');
        return implode(', ', $values);
    }

    public function set_saas_configuracao_contrato_inativo_system_group_to_string($saas_configuracao_contrato_inativo_system_group_to_string)
    {
        if(is_array($saas_configuracao_contrato_inativo_system_group_to_string))
        {
            $values = SystemGroup::where('id', 'in', $saas_configuracao_contrato_inativo_system_group_to_string)->getIndexedArray('name', 'name');
            $this->saas_configuracao_contrato_inativo_system_group_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_configuracao_contrato_inativo_system_group_to_string = $saas_configuracao_contrato_inativo_system_group_to_string;
        }

        $this->vdata['saas_configuracao_contrato_inativo_system_group_to_string'] = $this->saas_configuracao_contrato_inativo_system_group_to_string;
    }

    public function get_saas_configuracao_contrato_inativo_system_group_to_string()
    {
        if(!empty($this->saas_configuracao_contrato_inativo_system_group_to_string))
        {
            return $this->saas_configuracao_contrato_inativo_system_group_to_string;
        }
    
        $values = SaasConfiguracao::where('cidade_id', '=', $this->id)->getIndexedArray('contrato_inativo_system_group_id','{contrato_inativo_system_group->name}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_pagamento_to_string($saas_nota_fiscal_servico_saas_pagamento_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_pagamento_to_string))
        {
            $values = SaasPagamento::where('id', 'in', $saas_nota_fiscal_servico_saas_pagamento_to_string)->getIndexedArray('id', 'id');
            $this->saas_nota_fiscal_servico_saas_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_pagamento_to_string = $saas_nota_fiscal_servico_saas_pagamento_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_pagamento_to_string'] = $this->saas_nota_fiscal_servico_saas_pagamento_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_pagamento_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_pagamento_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_pagamento_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('cidade_tomador_id', '=', $this->id)->getIndexedArray('saas_pagamento_id','{saas_pagamento->id}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_plano_valor_to_string($saas_nota_fiscal_servico_saas_plano_valor_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_plano_valor_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_nota_fiscal_servico_saas_plano_valor_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_saas_plano_valor_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_plano_valor_to_string = $saas_nota_fiscal_servico_saas_plano_valor_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_plano_valor_to_string'] = $this->saas_nota_fiscal_servico_saas_plano_valor_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_plano_valor_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_plano_valor_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_plano_valor_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('cidade_tomador_id', '=', $this->id)->getIndexedArray('saas_plano_valor_id','{saas_plano_valor->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_servico_to_string($saas_nota_fiscal_servico_saas_servico_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_nota_fiscal_servico_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_servico_to_string = $saas_nota_fiscal_servico_saas_servico_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_servico_to_string'] = $this->saas_nota_fiscal_servico_saas_servico_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_servico_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_servico_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_servico_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('cidade_tomador_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_cidade_tomador_to_string($saas_nota_fiscal_servico_cidade_tomador_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_cidade_tomador_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_cidade_tomador_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_cidade_tomador_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_cidade_tomador_to_string = $saas_nota_fiscal_servico_cidade_tomador_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_cidade_tomador_to_string'] = $this->saas_nota_fiscal_servico_cidade_tomador_to_string;
    }

    public function get_saas_nota_fiscal_servico_cidade_tomador_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_cidade_tomador_to_string))
        {
            return $this->saas_nota_fiscal_servico_cidade_tomador_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('cidade_tomador_id', '=', $this->id)->getIndexedArray('cidade_tomador_id','{cidade_tomador->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_cidade_prestador_to_string($saas_nota_fiscal_servico_cidade_prestador_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_cidade_prestador_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_cidade_prestador_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_cidade_prestador_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_cidade_prestador_to_string = $saas_nota_fiscal_servico_cidade_prestador_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_cidade_prestador_to_string'] = $this->saas_nota_fiscal_servico_cidade_prestador_to_string;
    }

    public function get_saas_nota_fiscal_servico_cidade_prestador_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_cidade_prestador_to_string))
        {
            return $this->saas_nota_fiscal_servico_cidade_prestador_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('cidade_tomador_id', '=', $this->id)->getIndexedArray('cidade_prestador_id','{cidade_prestador->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_municipio_prestacao_servico_to_string($saas_nota_fiscal_servico_municipio_prestacao_servico_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_municipio_prestacao_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string = $saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_municipio_prestacao_servico_to_string'] = $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
    }

    public function get_saas_nota_fiscal_servico_municipio_prestacao_servico_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            return $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('cidade_tomador_id', '=', $this->id)->getIndexedArray('municipio_prestacao_servico_id','{municipio_prestacao_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_nota_fiscal_status_to_string($saas_nota_fiscal_servico_nota_fiscal_status_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            $values = NotaFiscalStatus::where('id', 'in', $saas_nota_fiscal_servico_nota_fiscal_status_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string = $saas_nota_fiscal_servico_nota_fiscal_status_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_nota_fiscal_status_to_string'] = $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string;
    }

    public function get_saas_nota_fiscal_servico_nota_fiscal_status_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            return $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('cidade_tomador_id', '=', $this->id)->getIndexedArray('nota_fiscal_status_id','{nota_fiscal_status->nome}');
        return implode(', ', $values);
    }

    public static function fromIBGE($codigo)
    {
        return self::where('codigo_ibge', '=', $codigo)->first();
    }

    
}

