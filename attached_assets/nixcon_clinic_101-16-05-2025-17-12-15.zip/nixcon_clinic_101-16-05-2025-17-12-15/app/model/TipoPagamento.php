<?php

class TipoPagamento extends TRecord
{
    const TABLENAME  = 'tipo_pagamento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Account $account;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByAccount');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('account_id');
        parent::addAttribute('nome');
        parent::addAttribute('ativo');
    
    }

    /**
     * Method set_account
     * Sample of usage: $var->account = $object;
     * @param $object Instance of Account
     */
    public function set_account(Account $object)
    {
        $this->account = $object;
        $this->account_id = $object->id;
    }

    /**
     * Method get_account
     * Sample of usage: $var->account->attribute;
     * @returns Account instance
     */
    public function get_account()
    {
    
        // loads the associated object
        if (empty($this->account))
            $this->account = new Account($this->account_id);
    
        // returns the associated object
        return $this->account;
    }

    /**
     * Method getLancamentos
     */
    public function getLancamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('tipo_pagamento_id', '=', $this->id));
        return Lancamento::getObjects( $criteria );
    }

    public function set_lancamento_conta_to_string($lancamento_conta_to_string)
    {
        if(is_array($lancamento_conta_to_string))
        {
            $values = Conta::where('id', 'in', $lancamento_conta_to_string)->getIndexedArray('descricao', 'descricao');
            $this->lancamento_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_conta_to_string = $lancamento_conta_to_string;
        }

        $this->vdata['lancamento_conta_to_string'] = $this->lancamento_conta_to_string;
    }

    public function get_lancamento_conta_to_string()
    {
        if(!empty($this->lancamento_conta_to_string))
        {
            return $this->lancamento_conta_to_string;
        }
    
        $values = Lancamento::where('tipo_pagamento_id', '=', $this->id)->getIndexedArray('conta_id','{conta->descricao}');
        return implode(', ', $values);
    }

    public function set_lancamento_clinica_to_string($lancamento_clinica_to_string)
    {
        if(is_array($lancamento_clinica_to_string))
        {
            $values = SystemUnit::where('id', 'in', $lancamento_clinica_to_string)->getIndexedArray('name', 'name');
            $this->lancamento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_clinica_to_string = $lancamento_clinica_to_string;
        }

        $this->vdata['lancamento_clinica_to_string'] = $this->lancamento_clinica_to_string;
    }

    public function get_lancamento_clinica_to_string()
    {
        if(!empty($this->lancamento_clinica_to_string))
        {
            return $this->lancamento_clinica_to_string;
        }
    
        $values = Lancamento::where('tipo_pagamento_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->name}');
        return implode(', ', $values);
    }

    public function set_lancamento_tipo_pagamento_to_string($lancamento_tipo_pagamento_to_string)
    {
        if(is_array($lancamento_tipo_pagamento_to_string))
        {
            $values = TipoPagamento::where('id', 'in', $lancamento_tipo_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->lancamento_tipo_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_tipo_pagamento_to_string = $lancamento_tipo_pagamento_to_string;
        }

        $this->vdata['lancamento_tipo_pagamento_to_string'] = $this->lancamento_tipo_pagamento_to_string;
    }

    public function get_lancamento_tipo_pagamento_to_string()
    {
        if(!empty($this->lancamento_tipo_pagamento_to_string))
        {
            return $this->lancamento_tipo_pagamento_to_string;
        }
    
        $values = Lancamento::where('tipo_pagamento_id', '=', $this->id)->getIndexedArray('tipo_pagamento_id','{tipo_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_lancamento_nota_fiscal_servico_to_string($lancamento_nota_fiscal_servico_to_string)
    {
        if(is_array($lancamento_nota_fiscal_servico_to_string))
        {
            $values = NotaFiscalServico::where('id', 'in', $lancamento_nota_fiscal_servico_to_string)->getIndexedArray('id', 'id');
            $this->lancamento_nota_fiscal_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_nota_fiscal_servico_to_string = $lancamento_nota_fiscal_servico_to_string;
        }

        $this->vdata['lancamento_nota_fiscal_servico_to_string'] = $this->lancamento_nota_fiscal_servico_to_string;
    }

    public function get_lancamento_nota_fiscal_servico_to_string()
    {
        if(!empty($this->lancamento_nota_fiscal_servico_to_string))
        {
            return $this->lancamento_nota_fiscal_servico_to_string;
        }
    
        $values = Lancamento::where('tipo_pagamento_id', '=', $this->id)->getIndexedArray('nota_fiscal_servico_id','{nota_fiscal_servico->id}');
        return implode(', ', $values);
    }

}

