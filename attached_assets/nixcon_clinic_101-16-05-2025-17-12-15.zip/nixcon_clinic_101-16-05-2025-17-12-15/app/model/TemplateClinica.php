<?php

class TemplateClinica extends TRecord
{
    const TABLENAME  = 'template_clinica';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Clinica $clinica;

    const EMAIL = 'EMAIL';
    const WHATSAPP = 'WHATSAPP';
                                        

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByUnit');
    
            
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('clinica_id');
        parent::addAttribute('chave');
        parent::addAttribute('descricao');
        parent::addAttribute('habilitado');
        parent::addAttribute('template');
        parent::addAttribute('titulo');
        parent::addAttribute('tipo_template');
        parent::addAttribute('readonly');
    
    }

    /**
     * Method set_clinica
     * Sample of usage: $var->clinica = $object;
     * @param $object Instance of Clinica
     */
    public function set_clinica(Clinica $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns Clinica instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new Clinica($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }

    /**
     * Method getMensagems
     */
    public function getMensagems()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('template_clinica_id', '=', $this->id));
        return Mensagem::getObjects( $criteria );
    }
    /**
     * Method getTemplateAcaos
     */
    public function getTemplateAcaos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('template_clinica_id', '=', $this->id));
        return TemplateAcao::getObjects( $criteria );
    }

    public function set_mensagem_agendamento_to_string($mensagem_agendamento_to_string)
    {
        if(is_array($mensagem_agendamento_to_string))
        {
            $values = Agendamento::where('id', 'in', $mensagem_agendamento_to_string)->getIndexedArray('id', 'id');
            $this->mensagem_agendamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->mensagem_agendamento_to_string = $mensagem_agendamento_to_string;
        }

        $this->vdata['mensagem_agendamento_to_string'] = $this->mensagem_agendamento_to_string;
    }

    public function get_mensagem_agendamento_to_string()
    {
        if(!empty($this->mensagem_agendamento_to_string))
        {
            return $this->mensagem_agendamento_to_string;
        }
    
        $values = Mensagem::where('template_clinica_id', '=', $this->id)->getIndexedArray('agendamento_id','{agendamento->id}');
        return implode(', ', $values);
    }

    public function set_mensagem_template_clinica_to_string($mensagem_template_clinica_to_string)
    {
        if(is_array($mensagem_template_clinica_to_string))
        {
            $values = TemplateClinica::where('id', 'in', $mensagem_template_clinica_to_string)->getIndexedArray('chave', 'chave');
            $this->mensagem_template_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->mensagem_template_clinica_to_string = $mensagem_template_clinica_to_string;
        }

        $this->vdata['mensagem_template_clinica_to_string'] = $this->mensagem_template_clinica_to_string;
    }

    public function get_mensagem_template_clinica_to_string()
    {
        if(!empty($this->mensagem_template_clinica_to_string))
        {
            return $this->mensagem_template_clinica_to_string;
        }
    
        $values = Mensagem::where('template_clinica_id', '=', $this->id)->getIndexedArray('template_clinica_id','{template_clinica->chave}');
        return implode(', ', $values);
    }

    public function set_mensagem_system_user_to_string($mensagem_system_user_to_string)
    {
        if(is_array($mensagem_system_user_to_string))
        {
            $values = SystemUsers::where('id', 'in', $mensagem_system_user_to_string)->getIndexedArray('name', 'name');
            $this->mensagem_system_user_to_string = implode(', ', $values);
        }
        else
        {
            $this->mensagem_system_user_to_string = $mensagem_system_user_to_string;
        }

        $this->vdata['mensagem_system_user_to_string'] = $this->mensagem_system_user_to_string;
    }

    public function get_mensagem_system_user_to_string()
    {
        if(!empty($this->mensagem_system_user_to_string))
        {
            return $this->mensagem_system_user_to_string;
        }
    
        $values = Mensagem::where('template_clinica_id', '=', $this->id)->getIndexedArray('system_user_id','{system_user->name}');
        return implode(', ', $values);
    }

    public function set_template_acao_template_clinica_to_string($template_acao_template_clinica_to_string)
    {
        if(is_array($template_acao_template_clinica_to_string))
        {
            $values = TemplateClinica::where('id', 'in', $template_acao_template_clinica_to_string)->getIndexedArray('chave', 'chave');
            $this->template_acao_template_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->template_acao_template_clinica_to_string = $template_acao_template_clinica_to_string;
        }

        $this->vdata['template_acao_template_clinica_to_string'] = $this->template_acao_template_clinica_to_string;
    }

    public function get_template_acao_template_clinica_to_string()
    {
        if(!empty($this->template_acao_template_clinica_to_string))
        {
            return $this->template_acao_template_clinica_to_string;
        }
    
        $values = TemplateAcao::where('template_clinica_id', '=', $this->id)->getIndexedArray('template_clinica_id','{template_clinica->chave}');
        return implode(', ', $values);
    }

    public static function getTemplate($chave, $unitId)
    {
        $clinica = Clinica::findByUnitId($unitId);
    
        return self::where('chave', '=', $chave)->where('clinica_id', '=', $clinica->id)->first();
    }

    public function parserTitulo($agendamento)
    {
        return self::replace($agendamento, $this->titulo);
    }

    public function parserTemplate($agendamento)
    {
        return self::replace($agendamento, $this->template);
    }

    public static function replace($object, $content, $clinica = null)
    {
        if ($object instanceof Agendamento)
        {
            return self::replaceAgendamento($object, $content);
        }
    
        return self::replacePessoa($object, $content, $clinica);
    }

    public static function replacePessoa($pessoa, $content, $clinica)
    {
        $content = str_replace('{$nome}', $pessoa->nome, $content);
        $content = str_replace('{$clinica}', $clinica->nome, $content);
        $content = str_replace('{$endereco_clinica}', $clinica->endereco_formatado, $content);
        $content = str_replace('{$telefone_clinica}', $clinica->telefone, $content);
        $content = str_replace('{$email_clinica}', $clinica->email, $content);
        $content = str_replace('{$usuario}', $pessoa->usuario , $content);
        $content = str_replace('{$senha}', $pessoa->senha , $content);
    
        return $content;
    }

    public static function replaceNotaFiscal($nfse, $content, $clinica)
    {
        $content = str_replace('{$nome}', $nfse->nome_tomador, $content);
        $content = str_replace('{$clinica}', $clinica->nome, $content);
        $content = str_replace('{$endereco_clinica}', $clinica->endereco_formatado, $content);
        $content = str_replace('{$telefone_clinica}', $clinica->telefone, $content);
        $content = str_replace('{$email_clinica}', $clinica->email, $content);
    
        return $content;
    }

    public static function replaceAgendamento($agendamento, $content)
    {
        $token = AgendamentoService::getToken($agendamento->id);
    
        $content = str_replace('{$id}', $agendamento->id, $content);
        $content = str_replace('{$estado}', $agendamento->estado_agenda->nome, $content);
        $content = str_replace('{$observacao}', $agendamento->observacao, $content);
    
        $content = str_replace('{$profissional_foto}', $agendamento->agenda->profissional->foto, $content);
        $content = str_replace('{$profissional}', $agendamento->agenda->profissional->nome, $content);
        $content = str_replace('{$data_inicial}', date('d/m/Y H:i', strtotime($agendamento->dt_inicial)), $content);
        $content = str_replace('{$data_consulta}', date('d/m/Y H:i', strtotime($agendamento->dt_inicial)), $content);
    
        $content = str_replace('{$paciente}', $agendamento->paciente->nome, $content);
        $content = str_replace('{$agenda_nome}', $agendamento->agenda->nome, $content);
    
        if ($agendamento->link_atendimento_online)
        {
            $content = str_replace('{$link_atendimento_online}', "{$agendamento->agenda->clinica->url_sistema}/atendimento/{$agendamento->link_atendimento_online}" , $content);
        }
    
        $content = str_replace('{$link_detalhe}', "{$agendamento->agenda->clinica->url_sistema}/agendamento-{$agendamento->id}-{$token}", $content);
        $content = str_replace('{$link_cancelamento}', "{$agendamento->agenda->clinica->url_sistema}/cancelar-agendamento-{$agendamento->id}-{$token}", $content);
        $content = str_replace('{$link_confirmacao}', "{$agendamento->agenda->clinica->url_sistema}/confirmar-agendamento-{$agendamento->id}-{$token}", $content);
    
    
        $content = str_replace('{$clinica}', $agendamento->agenda->clinica->nome, $content);
        $content = str_replace('{$endereco_clinica}', $agendamento->agenda->clinica->endereco_formatado, $content);
        $content = str_replace('{$telefone_clinica}', $agendamento->agenda->clinica->telefone, $content);
        $content = str_replace('{$email_clinica}', $agendamento->agenda->clinica->email, $content);
    
    
        $content = str_replace('{$usuario}', $agendamento->paciente->usuario , $content);
        $content = str_replace('{$senha}', $agendamento->paciente->senha , $content);
    
        return $content;
    }
                                                
}

