<?php

class Servico extends TRecord
{
    const TABLENAME  = 'servico';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Account $account;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByAccount');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('account_id');
        parent::addAttribute('nome');
        parent::addAttribute('descricao');
        parent::addAttribute('codigo_cnae');
        parent::addAttribute('codigo_tributacao_municipio');
        parent::addAttribute('codigo_nbs');
        parent::addAttribute('codigo');
        parent::addAttribute('descricao_servico_municipio');
        parent::addAttribute('iss_retido');
        parent::addAttribute('natureza_operacao');
    
    }

    /**
     * Method set_account
     * Sample of usage: $var->account = $object;
     * @param $object Instance of Account
     */
    public function set_account(Account $object)
    {
        $this->account = $object;
        $this->account_id = $object->id;
    }

    /**
     * Method get_account
     * Sample of usage: $var->account->attribute;
     * @returns Account instance
     */
    public function get_account()
    {
    
        // loads the associated object
        if (empty($this->account))
            $this->account = new Account($this->account_id);
    
        // returns the associated object
        return $this->account;
    }

    /**
     * Method getNotaFiscalServicos
     */
    public function getNotaFiscalServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('servico_id', '=', $this->id));
        return NotaFiscalServico::getObjects( $criteria );
    }
    /**
     * Method getServicoImpostoItems
     */
    public function getServicoImpostoItems()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('servico_id', '=', $this->id));
        return ServicoImpostoItem::getObjects( $criteria );
    }

    public function set_nota_fiscal_servico_cidade_tomador_to_string($nota_fiscal_servico_cidade_tomador_to_string)
    {
        if(is_array($nota_fiscal_servico_cidade_tomador_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_cidade_tomador_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cidade_tomador_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cidade_tomador_to_string = $nota_fiscal_servico_cidade_tomador_to_string;
        }

        $this->vdata['nota_fiscal_servico_cidade_tomador_to_string'] = $this->nota_fiscal_servico_cidade_tomador_to_string;
    }

    public function get_nota_fiscal_servico_cidade_tomador_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cidade_tomador_to_string))
        {
            return $this->nota_fiscal_servico_cidade_tomador_to_string;
        }
    
        $values = NotaFiscalServico::where('servico_id', '=', $this->id)->getIndexedArray('cidade_tomador_id','{cidade_tomador->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cidade_prestador_to_string($nota_fiscal_servico_cidade_prestador_to_string)
    {
        if(is_array($nota_fiscal_servico_cidade_prestador_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_cidade_prestador_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cidade_prestador_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cidade_prestador_to_string = $nota_fiscal_servico_cidade_prestador_to_string;
        }

        $this->vdata['nota_fiscal_servico_cidade_prestador_to_string'] = $this->nota_fiscal_servico_cidade_prestador_to_string;
    }

    public function get_nota_fiscal_servico_cidade_prestador_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cidade_prestador_to_string))
        {
            return $this->nota_fiscal_servico_cidade_prestador_to_string;
        }
    
        $values = NotaFiscalServico::where('servico_id', '=', $this->id)->getIndexedArray('cidade_prestador_id','{cidade_prestador->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_municipio_prestacao_servico_to_string($nota_fiscal_servico_municipio_prestacao_servico_to_string)
    {
        if(is_array($nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_municipio_prestacao_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_municipio_prestacao_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_municipio_prestacao_servico_to_string = $nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }

        $this->vdata['nota_fiscal_servico_municipio_prestacao_servico_to_string'] = $this->nota_fiscal_servico_municipio_prestacao_servico_to_string;
    }

    public function get_nota_fiscal_servico_municipio_prestacao_servico_to_string()
    {
        if(!empty($this->nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            return $this->nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }
    
        $values = NotaFiscalServico::where('servico_id', '=', $this->id)->getIndexedArray('municipio_prestacao_servico_id','{municipio_prestacao_servico->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_nota_fiscal_status_to_string($nota_fiscal_servico_nota_fiscal_status_to_string)
    {
        if(is_array($nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            $values = NotaFiscalStatus::where('id', 'in', $nota_fiscal_servico_nota_fiscal_status_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_nota_fiscal_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_nota_fiscal_status_to_string = $nota_fiscal_servico_nota_fiscal_status_to_string;
        }

        $this->vdata['nota_fiscal_servico_nota_fiscal_status_to_string'] = $this->nota_fiscal_servico_nota_fiscal_status_to_string;
    }

    public function get_nota_fiscal_servico_nota_fiscal_status_to_string()
    {
        if(!empty($this->nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            return $this->nota_fiscal_servico_nota_fiscal_status_to_string;
        }
    
        $values = NotaFiscalServico::where('servico_id', '=', $this->id)->getIndexedArray('nota_fiscal_status_id','{nota_fiscal_status->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_clinica_to_string($nota_fiscal_servico_clinica_to_string)
    {
        if(is_array($nota_fiscal_servico_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $nota_fiscal_servico_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_clinica_to_string = $nota_fiscal_servico_clinica_to_string;
        }

        $this->vdata['nota_fiscal_servico_clinica_to_string'] = $this->nota_fiscal_servico_clinica_to_string;
    }

    public function get_nota_fiscal_servico_clinica_to_string()
    {
        if(!empty($this->nota_fiscal_servico_clinica_to_string))
        {
            return $this->nota_fiscal_servico_clinica_to_string;
        }
    
        $values = NotaFiscalServico::where('servico_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cliente_to_string($nota_fiscal_servico_cliente_to_string)
    {
        if(is_array($nota_fiscal_servico_cliente_to_string))
        {
            $values = Pessoa::where('id', 'in', $nota_fiscal_servico_cliente_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cliente_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cliente_to_string = $nota_fiscal_servico_cliente_to_string;
        }

        $this->vdata['nota_fiscal_servico_cliente_to_string'] = $this->nota_fiscal_servico_cliente_to_string;
    }

    public function get_nota_fiscal_servico_cliente_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cliente_to_string))
        {
            return $this->nota_fiscal_servico_cliente_to_string;
        }
    
        $values = NotaFiscalServico::where('servico_id', '=', $this->id)->getIndexedArray('cliente_id','{cliente->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_conta_to_string($nota_fiscal_servico_conta_to_string)
    {
        if(is_array($nota_fiscal_servico_conta_to_string))
        {
            $values = Conta::where('id', 'in', $nota_fiscal_servico_conta_to_string)->getIndexedArray('descricao', 'descricao');
            $this->nota_fiscal_servico_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_conta_to_string = $nota_fiscal_servico_conta_to_string;
        }

        $this->vdata['nota_fiscal_servico_conta_to_string'] = $this->nota_fiscal_servico_conta_to_string;
    }

    public function get_nota_fiscal_servico_conta_to_string()
    {
        if(!empty($this->nota_fiscal_servico_conta_to_string))
        {
            return $this->nota_fiscal_servico_conta_to_string;
        }
    
        $values = NotaFiscalServico::where('servico_id', '=', $this->id)->getIndexedArray('conta_id','{conta->descricao}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_lancamento_to_string($nota_fiscal_servico_lancamento_to_string)
    {
        if(is_array($nota_fiscal_servico_lancamento_to_string))
        {
            $values = Lancamento::where('id', 'in', $nota_fiscal_servico_lancamento_to_string)->getIndexedArray('id', 'id');
            $this->nota_fiscal_servico_lancamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_lancamento_to_string = $nota_fiscal_servico_lancamento_to_string;
        }

        $this->vdata['nota_fiscal_servico_lancamento_to_string'] = $this->nota_fiscal_servico_lancamento_to_string;
    }

    public function get_nota_fiscal_servico_lancamento_to_string()
    {
        if(!empty($this->nota_fiscal_servico_lancamento_to_string))
        {
            return $this->nota_fiscal_servico_lancamento_to_string;
        }
    
        $values = NotaFiscalServico::where('servico_id', '=', $this->id)->getIndexedArray('lancamento_id','{lancamento->id}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_servico_to_string($nota_fiscal_servico_servico_to_string)
    {
        if(is_array($nota_fiscal_servico_servico_to_string))
        {
            $values = Servico::where('id', 'in', $nota_fiscal_servico_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_servico_to_string = $nota_fiscal_servico_servico_to_string;
        }

        $this->vdata['nota_fiscal_servico_servico_to_string'] = $this->nota_fiscal_servico_servico_to_string;
    }

    public function get_nota_fiscal_servico_servico_to_string()
    {
        if(!empty($this->nota_fiscal_servico_servico_to_string))
        {
            return $this->nota_fiscal_servico_servico_to_string;
        }
    
        $values = NotaFiscalServico::where('servico_id', '=', $this->id)->getIndexedArray('servico_id','{servico->nome}');
        return implode(', ', $values);
    }

    public function set_servico_imposto_item_servico_to_string($servico_imposto_item_servico_to_string)
    {
        if(is_array($servico_imposto_item_servico_to_string))
        {
            $values = Servico::where('id', 'in', $servico_imposto_item_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->servico_imposto_item_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->servico_imposto_item_servico_to_string = $servico_imposto_item_servico_to_string;
        }

        $this->vdata['servico_imposto_item_servico_to_string'] = $this->servico_imposto_item_servico_to_string;
    }

    public function get_servico_imposto_item_servico_to_string()
    {
        if(!empty($this->servico_imposto_item_servico_to_string))
        {
            return $this->servico_imposto_item_servico_to_string;
        }
    
        $values = ServicoImpostoItem::where('servico_id', '=', $this->id)->getIndexedArray('servico_id','{servico->nome}');
        return implode(', ', $values);
    }

    public function set_servico_imposto_item_imposto_to_string($servico_imposto_item_imposto_to_string)
    {
        if(is_array($servico_imposto_item_imposto_to_string))
        {
            $values = Imposto::where('id', 'in', $servico_imposto_item_imposto_to_string)->getIndexedArray('nome', 'nome');
            $this->servico_imposto_item_imposto_to_string = implode(', ', $values);
        }
        else
        {
            $this->servico_imposto_item_imposto_to_string = $servico_imposto_item_imposto_to_string;
        }

        $this->vdata['servico_imposto_item_imposto_to_string'] = $this->servico_imposto_item_imposto_to_string;
    }

    public function get_servico_imposto_item_imposto_to_string()
    {
        if(!empty($this->servico_imposto_item_imposto_to_string))
        {
            return $this->servico_imposto_item_imposto_to_string;
        }
    
        $values = ServicoImpostoItem::where('servico_id', '=', $this->id)->getIndexedArray('imposto_id','{imposto->nome}');
        return implode(', ', $values);
    }

}

