<?php

class SaasPlanoValor extends TRecord
{
    const TABLENAME  = 'saas_plano_valor';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SaasPlano $saas_plano;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('saas_plano_id');
        parent::addAttribute('valor');
        parent::addAttribute('nome');
        parent::addAttribute('duracao');
        parent::addAttribute('ativo');
        parent::addAttribute('desativado_em');
        parent::addAttribute('recorrencia');
    
    }

    /**
     * Method set_saas_plano
     * Sample of usage: $var->saas_plano = $object;
     * @param $object Instance of SaasPlano
     */
    public function set_saas_plano(SaasPlano $object)
    {
        $this->saas_plano = $object;
        $this->saas_plano_id = $object->id;
    }

    /**
     * Method get_saas_plano
     * Sample of usage: $var->saas_plano->attribute;
     * @returns SaasPlano instance
     */
    public function get_saas_plano()
    {
    
        // loads the associated object
        if (empty($this->saas_plano))
            $this->saas_plano = new SaasPlano($this->saas_plano_id);
    
        // returns the associated object
        return $this->saas_plano;
    }

    /**
     * Method getSaasConfiguracaos
     */
    public function getSaasConfiguracaos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_plano_valor_trial_id', '=', $this->id));
        return SaasConfiguracao::getObjects( $criteria );
    }
    /**
     * Method getSaasContratos
     */
    public function getSaasContratos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_plano_valor_id', '=', $this->id));
        return SaasContrato::getObjects( $criteria );
    }
    /**
     * Method getSaasNotaFiscalServicos
     */
    public function getSaasNotaFiscalServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_plano_valor_id', '=', $this->id));
        return SaasNotaFiscalServico::getObjects( $criteria );
    }

    public function set_saas_configuracao_cidade_to_string($saas_configuracao_cidade_to_string)
    {
        if(is_array($saas_configuracao_cidade_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_configuracao_cidade_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_configuracao_cidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_configuracao_cidade_to_string = $saas_configuracao_cidade_to_string;
        }

        $this->vdata['saas_configuracao_cidade_to_string'] = $this->saas_configuracao_cidade_to_string;
    }

    public function get_saas_configuracao_cidade_to_string()
    {
        if(!empty($this->saas_configuracao_cidade_to_string))
        {
            return $this->saas_configuracao_cidade_to_string;
        }
    
        $values = SaasConfiguracao::where('saas_plano_valor_trial_id', '=', $this->id)->getIndexedArray('cidade_id','{cidade->nome}');
        return implode(', ', $values);
    }

    public function set_saas_configuracao_saas_plano_valor_trial_to_string($saas_configuracao_saas_plano_valor_trial_to_string)
    {
        if(is_array($saas_configuracao_saas_plano_valor_trial_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_configuracao_saas_plano_valor_trial_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_configuracao_saas_plano_valor_trial_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_configuracao_saas_plano_valor_trial_to_string = $saas_configuracao_saas_plano_valor_trial_to_string;
        }

        $this->vdata['saas_configuracao_saas_plano_valor_trial_to_string'] = $this->saas_configuracao_saas_plano_valor_trial_to_string;
    }

    public function get_saas_configuracao_saas_plano_valor_trial_to_string()
    {
        if(!empty($this->saas_configuracao_saas_plano_valor_trial_to_string))
        {
            return $this->saas_configuracao_saas_plano_valor_trial_to_string;
        }
    
        $values = SaasConfiguracao::where('saas_plano_valor_trial_id', '=', $this->id)->getIndexedArray('saas_plano_valor_trial_id','{saas_plano_valor_trial->nome}');
        return implode(', ', $values);
    }

    public function set_saas_configuracao_contrato_inativo_system_group_to_string($saas_configuracao_contrato_inativo_system_group_to_string)
    {
        if(is_array($saas_configuracao_contrato_inativo_system_group_to_string))
        {
            $values = SystemGroup::where('id', 'in', $saas_configuracao_contrato_inativo_system_group_to_string)->getIndexedArray('name', 'name');
            $this->saas_configuracao_contrato_inativo_system_group_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_configuracao_contrato_inativo_system_group_to_string = $saas_configuracao_contrato_inativo_system_group_to_string;
        }

        $this->vdata['saas_configuracao_contrato_inativo_system_group_to_string'] = $this->saas_configuracao_contrato_inativo_system_group_to_string;
    }

    public function get_saas_configuracao_contrato_inativo_system_group_to_string()
    {
        if(!empty($this->saas_configuracao_contrato_inativo_system_group_to_string))
        {
            return $this->saas_configuracao_contrato_inativo_system_group_to_string;
        }
    
        $values = SaasConfiguracao::where('saas_plano_valor_trial_id', '=', $this->id)->getIndexedArray('contrato_inativo_system_group_id','{contrato_inativo_system_group->name}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_saas_plano_valor_to_string($saas_contrato_saas_plano_valor_to_string)
    {
        if(is_array($saas_contrato_saas_plano_valor_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_contrato_saas_plano_valor_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_contrato_saas_plano_valor_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_saas_plano_valor_to_string = $saas_contrato_saas_plano_valor_to_string;
        }

        $this->vdata['saas_contrato_saas_plano_valor_to_string'] = $this->saas_contrato_saas_plano_valor_to_string;
    }

    public function get_saas_contrato_saas_plano_valor_to_string()
    {
        if(!empty($this->saas_contrato_saas_plano_valor_to_string))
        {
            return $this->saas_contrato_saas_plano_valor_to_string;
        }
    
        $values = SaasContrato::where('saas_plano_valor_id', '=', $this->id)->getIndexedArray('saas_plano_valor_id','{saas_plano_valor->nome}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_account_to_string($saas_contrato_account_to_string)
    {
        if(is_array($saas_contrato_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_contrato_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_contrato_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_account_to_string = $saas_contrato_account_to_string;
        }

        $this->vdata['saas_contrato_account_to_string'] = $this->saas_contrato_account_to_string;
    }

    public function get_saas_contrato_account_to_string()
    {
        if(!empty($this->saas_contrato_account_to_string))
        {
            return $this->saas_contrato_account_to_string;
        }
    
        $values = SaasContrato::where('saas_plano_valor_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_saas_contrato_status_to_string($saas_contrato_saas_contrato_status_to_string)
    {
        if(is_array($saas_contrato_saas_contrato_status_to_string))
        {
            $values = SaasContratoStatus::where('id', 'in', $saas_contrato_saas_contrato_status_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_contrato_saas_contrato_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_saas_contrato_status_to_string = $saas_contrato_saas_contrato_status_to_string;
        }

        $this->vdata['saas_contrato_saas_contrato_status_to_string'] = $this->saas_contrato_saas_contrato_status_to_string;
    }

    public function get_saas_contrato_saas_contrato_status_to_string()
    {
        if(!empty($this->saas_contrato_saas_contrato_status_to_string))
        {
            return $this->saas_contrato_saas_contrato_status_to_string;
        }
    
        $values = SaasContrato::where('saas_plano_valor_id', '=', $this->id)->getIndexedArray('saas_contrato_status_id','{saas_contrato_status->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_pagamento_to_string($saas_nota_fiscal_servico_saas_pagamento_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_pagamento_to_string))
        {
            $values = SaasPagamento::where('id', 'in', $saas_nota_fiscal_servico_saas_pagamento_to_string)->getIndexedArray('id', 'id');
            $this->saas_nota_fiscal_servico_saas_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_pagamento_to_string = $saas_nota_fiscal_servico_saas_pagamento_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_pagamento_to_string'] = $this->saas_nota_fiscal_servico_saas_pagamento_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_pagamento_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_pagamento_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_pagamento_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_plano_valor_id', '=', $this->id)->getIndexedArray('saas_pagamento_id','{saas_pagamento->id}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_plano_valor_to_string($saas_nota_fiscal_servico_saas_plano_valor_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_plano_valor_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_nota_fiscal_servico_saas_plano_valor_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_saas_plano_valor_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_plano_valor_to_string = $saas_nota_fiscal_servico_saas_plano_valor_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_plano_valor_to_string'] = $this->saas_nota_fiscal_servico_saas_plano_valor_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_plano_valor_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_plano_valor_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_plano_valor_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_plano_valor_id', '=', $this->id)->getIndexedArray('saas_plano_valor_id','{saas_plano_valor->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_servico_to_string($saas_nota_fiscal_servico_saas_servico_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_nota_fiscal_servico_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_servico_to_string = $saas_nota_fiscal_servico_saas_servico_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_servico_to_string'] = $this->saas_nota_fiscal_servico_saas_servico_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_servico_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_servico_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_servico_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_plano_valor_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_cidade_tomador_to_string($saas_nota_fiscal_servico_cidade_tomador_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_cidade_tomador_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_cidade_tomador_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_cidade_tomador_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_cidade_tomador_to_string = $saas_nota_fiscal_servico_cidade_tomador_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_cidade_tomador_to_string'] = $this->saas_nota_fiscal_servico_cidade_tomador_to_string;
    }

    public function get_saas_nota_fiscal_servico_cidade_tomador_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_cidade_tomador_to_string))
        {
            return $this->saas_nota_fiscal_servico_cidade_tomador_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_plano_valor_id', '=', $this->id)->getIndexedArray('cidade_tomador_id','{cidade_tomador->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_cidade_prestador_to_string($saas_nota_fiscal_servico_cidade_prestador_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_cidade_prestador_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_cidade_prestador_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_cidade_prestador_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_cidade_prestador_to_string = $saas_nota_fiscal_servico_cidade_prestador_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_cidade_prestador_to_string'] = $this->saas_nota_fiscal_servico_cidade_prestador_to_string;
    }

    public function get_saas_nota_fiscal_servico_cidade_prestador_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_cidade_prestador_to_string))
        {
            return $this->saas_nota_fiscal_servico_cidade_prestador_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_plano_valor_id', '=', $this->id)->getIndexedArray('cidade_prestador_id','{cidade_prestador->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_municipio_prestacao_servico_to_string($saas_nota_fiscal_servico_municipio_prestacao_servico_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_municipio_prestacao_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string = $saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_municipio_prestacao_servico_to_string'] = $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
    }

    public function get_saas_nota_fiscal_servico_municipio_prestacao_servico_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            return $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_plano_valor_id', '=', $this->id)->getIndexedArray('municipio_prestacao_servico_id','{municipio_prestacao_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_nota_fiscal_status_to_string($saas_nota_fiscal_servico_nota_fiscal_status_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            $values = NotaFiscalStatus::where('id', 'in', $saas_nota_fiscal_servico_nota_fiscal_status_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string = $saas_nota_fiscal_servico_nota_fiscal_status_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_nota_fiscal_status_to_string'] = $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string;
    }

    public function get_saas_nota_fiscal_servico_nota_fiscal_status_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            return $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_plano_valor_id', '=', $this->id)->getIndexedArray('nota_fiscal_status_id','{nota_fiscal_status->nome}');
        return implode(', ', $values);
    }

    /**
     * Method onBeforeDelete
     */
    public function onBeforeDelete()
    {
    

        if(SaasConfiguracao::where('saas_plano_valor_trial_id', '=', $this->id)->first())
        {
            throw new Exception("Não é possível deletar este registro pois ele está sendo utilizado em outra parte do sistema");
        }
    
        if(SaasContrato::where('saas_plano_valor_id', '=', $this->id)->first())
        {
            throw new Exception("Não é possível deletar este registro pois ele está sendo utilizado em outra parte do sistema");
        }
    
        if(SaasNotaFiscalServico::where('saas_plano_valor_id', '=', $this->id)->first())
        {
            throw new Exception("Não é possível deletar este registro pois ele está sendo utilizado em outra parte do sistema");
        }
    
    }

    public function get_valor_f()
    {
        return 'R$ ' . number_format($this->valor, 2, ',', '.');
    }

    public function get_valor_formatado()
    {
        return 'R$ ' . number_format($this->valor, 2, ',', '.');
    }

    public function get_option_html()
    {
        $valor = number_format($this->valor, 2, ',', '.');
        $mes = $this->duracao > 1 ? 'meses' : 'mês';
    
        $div = new TElement('div');
        $div->class = 'option-valor';
        $div->add(TElement::tag('div', $this->nome, ['class' => 'valor-nome']));
        $div->add(TElement::tag('div', "Duração: {$this->duracao} {$mes}", ['class' => 'valor-duracao']));
        $div->add(TElement::tag('div', [TElement::tag('small', 'R$'), $valor], ['class' => 'valor-valor']));
    
        return $div;
    }

    public function get_descricao_html()
    {
        $valor = $this->get_valor_f();
        $plano = $this->get_saas_plano();
    
        return "Plano {$plano->nome}<br> {$this->nome} | Duração: {$this->duracao} meses | Valor: {$valor}";
    }
                    
}

