<?php

class SystemUnit extends TRecord
{
    const TABLENAME  = 'system_unit';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'max'; // {max, serial}

    private Account $account;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        //$this->addManagePermission('PermissaoService::canManageRecordByAccount');
    
                    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('account_id');
        parent::addAttribute('name');
        parent::addAttribute('connection_name');
        parent::addAttribute('active');
    
    }

    /**
     * Method set_account
     * Sample of usage: $var->account = $object;
     * @param $object Instance of Account
     */
    public function set_account(Account $object)
    {
        $this->account = $object;
        $this->account_id = $object->id;
    }

    /**
     * Method get_account
     * Sample of usage: $var->account->attribute;
     * @returns Account instance
     */
    public function get_account()
    {
    
        // loads the associated object
        if (empty($this->account))
            $this->account = new Account($this->account_id);
    
        // returns the associated object
        return $this->account;
    }

    /**
     * Method getAtendimentos
     */
    public function getAtendimentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Atendimento::getObjects( $criteria );
    }
    /**
     * Method getClinicas
     */
    public function getClinicas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('system_unit_id', '=', $this->id));
        return Clinica::getObjects( $criteria );
    }
    /**
     * Method getFormularios
     */
    public function getFormularios()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Formulario::getObjects( $criteria );
    }
    /**
     * Method getLancamentos
     */
    public function getLancamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Lancamento::getObjects( $criteria );
    }
    /**
     * Method getSaasErrorLogs
     */
    public function getSaasErrorLogs()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('system_unit_id', '=', $this->id));
        return SaasErrorLog::getObjects( $criteria );
    }

    public function set_atendimento_agendamento_to_string($atendimento_agendamento_to_string)
    {
        if(is_array($atendimento_agendamento_to_string))
        {
            $values = Agendamento::where('id', 'in', $atendimento_agendamento_to_string)->getIndexedArray('id', 'id');
            $this->atendimento_agendamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_agendamento_to_string = $atendimento_agendamento_to_string;
        }

        $this->vdata['atendimento_agendamento_to_string'] = $this->atendimento_agendamento_to_string;
    }

    public function get_atendimento_agendamento_to_string()
    {
        if(!empty($this->atendimento_agendamento_to_string))
        {
            return $this->atendimento_agendamento_to_string;
        }
    
        $values = Atendimento::where('clinica_id', '=', $this->id)->getIndexedArray('agendamento_id','{agendamento->id}');
        return implode(', ', $values);
    }

    public function set_atendimento_paciente_to_string($atendimento_paciente_to_string)
    {
        if(is_array($atendimento_paciente_to_string))
        {
            $values = Pessoa::where('id', 'in', $atendimento_paciente_to_string)->getIndexedArray('nome', 'nome');
            $this->atendimento_paciente_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_paciente_to_string = $atendimento_paciente_to_string;
        }

        $this->vdata['atendimento_paciente_to_string'] = $this->atendimento_paciente_to_string;
    }

    public function get_atendimento_paciente_to_string()
    {
        if(!empty($this->atendimento_paciente_to_string))
        {
            return $this->atendimento_paciente_to_string;
        }
    
        $values = Atendimento::where('clinica_id', '=', $this->id)->getIndexedArray('paciente_id','{paciente->nome}');
        return implode(', ', $values);
    }

    public function set_atendimento_profissional_to_string($atendimento_profissional_to_string)
    {
        if(is_array($atendimento_profissional_to_string))
        {
            $values = Pessoa::where('id', 'in', $atendimento_profissional_to_string)->getIndexedArray('nome', 'nome');
            $this->atendimento_profissional_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_profissional_to_string = $atendimento_profissional_to_string;
        }

        $this->vdata['atendimento_profissional_to_string'] = $this->atendimento_profissional_to_string;
    }

    public function get_atendimento_profissional_to_string()
    {
        if(!empty($this->atendimento_profissional_to_string))
        {
            return $this->atendimento_profissional_to_string;
        }
    
        $values = Atendimento::where('clinica_id', '=', $this->id)->getIndexedArray('profissional_id','{profissional->nome}');
        return implode(', ', $values);
    }

    public function set_atendimento_clinica_to_string($atendimento_clinica_to_string)
    {
        if(is_array($atendimento_clinica_to_string))
        {
            $values = SystemUnit::where('id', 'in', $atendimento_clinica_to_string)->getIndexedArray('name', 'name');
            $this->atendimento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_clinica_to_string = $atendimento_clinica_to_string;
        }

        $this->vdata['atendimento_clinica_to_string'] = $this->atendimento_clinica_to_string;
    }

    public function get_atendimento_clinica_to_string()
    {
        if(!empty($this->atendimento_clinica_to_string))
        {
            return $this->atendimento_clinica_to_string;
        }
    
        $values = Atendimento::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->name}');
        return implode(', ', $values);
    }

    public function set_clinica_system_unit_to_string($clinica_system_unit_to_string)
    {
        if(is_array($clinica_system_unit_to_string))
        {
            $values = SystemUnit::where('id', 'in', $clinica_system_unit_to_string)->getIndexedArray('name', 'name');
            $this->clinica_system_unit_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_system_unit_to_string = $clinica_system_unit_to_string;
        }

        $this->vdata['clinica_system_unit_to_string'] = $this->clinica_system_unit_to_string;
    }

    public function get_clinica_system_unit_to_string()
    {
        if(!empty($this->clinica_system_unit_to_string))
        {
            return $this->clinica_system_unit_to_string;
        }
    
        $values = Clinica::where('system_unit_id', '=', $this->id)->getIndexedArray('system_unit_id','{system_unit->name}');
        return implode(', ', $values);
    }

    public function set_clinica_atendimento_categoria_conta_to_string($clinica_atendimento_categoria_conta_to_string)
    {
        if(is_array($clinica_atendimento_categoria_conta_to_string))
        {
            $values = CategoriaConta::where('id', 'in', $clinica_atendimento_categoria_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->clinica_atendimento_categoria_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_atendimento_categoria_conta_to_string = $clinica_atendimento_categoria_conta_to_string;
        }

        $this->vdata['clinica_atendimento_categoria_conta_to_string'] = $this->clinica_atendimento_categoria_conta_to_string;
    }

    public function get_clinica_atendimento_categoria_conta_to_string()
    {
        if(!empty($this->clinica_atendimento_categoria_conta_to_string))
        {
            return $this->clinica_atendimento_categoria_conta_to_string;
        }
    
        $values = Clinica::where('system_unit_id', '=', $this->id)->getIndexedArray('atendimento_categoria_conta_id','{atendimento_categoria_conta->nome}');
        return implode(', ', $values);
    }

    public function set_clinica_cidade_to_string($clinica_cidade_to_string)
    {
        if(is_array($clinica_cidade_to_string))
        {
            $values = Cidade::where('id', 'in', $clinica_cidade_to_string)->getIndexedArray('nome', 'nome');
            $this->clinica_cidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_cidade_to_string = $clinica_cidade_to_string;
        }

        $this->vdata['clinica_cidade_to_string'] = $this->clinica_cidade_to_string;
    }

    public function get_clinica_cidade_to_string()
    {
        if(!empty($this->clinica_cidade_to_string))
        {
            return $this->clinica_cidade_to_string;
        }
    
        $values = Clinica::where('system_unit_id', '=', $this->id)->getIndexedArray('cidade_id','{cidade->nome}');
        return implode(', ', $values);
    }

    public function set_clinica_account_to_string($clinica_account_to_string)
    {
        if(is_array($clinica_account_to_string))
        {
            $values = Account::where('id', 'in', $clinica_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->clinica_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_account_to_string = $clinica_account_to_string;
        }

        $this->vdata['clinica_account_to_string'] = $this->clinica_account_to_string;
    }

    public function get_clinica_account_to_string()
    {
        if(!empty($this->clinica_account_to_string))
        {
            return $this->clinica_account_to_string;
        }
    
        $values = Clinica::where('system_unit_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_formulario_clinica_to_string($formulario_clinica_to_string)
    {
        if(is_array($formulario_clinica_to_string))
        {
            $values = SystemUnit::where('id', 'in', $formulario_clinica_to_string)->getIndexedArray('name', 'name');
            $this->formulario_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->formulario_clinica_to_string = $formulario_clinica_to_string;
        }

        $this->vdata['formulario_clinica_to_string'] = $this->formulario_clinica_to_string;
    }

    public function get_formulario_clinica_to_string()
    {
        if(!empty($this->formulario_clinica_to_string))
        {
            return $this->formulario_clinica_to_string;
        }
    
        $values = Formulario::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->name}');
        return implode(', ', $values);
    }

    public function set_lancamento_conta_to_string($lancamento_conta_to_string)
    {
        if(is_array($lancamento_conta_to_string))
        {
            $values = Conta::where('id', 'in', $lancamento_conta_to_string)->getIndexedArray('descricao', 'descricao');
            $this->lancamento_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_conta_to_string = $lancamento_conta_to_string;
        }

        $this->vdata['lancamento_conta_to_string'] = $this->lancamento_conta_to_string;
    }

    public function get_lancamento_conta_to_string()
    {
        if(!empty($this->lancamento_conta_to_string))
        {
            return $this->lancamento_conta_to_string;
        }
    
        $values = Lancamento::where('clinica_id', '=', $this->id)->getIndexedArray('conta_id','{conta->descricao}');
        return implode(', ', $values);
    }

    public function set_lancamento_clinica_to_string($lancamento_clinica_to_string)
    {
        if(is_array($lancamento_clinica_to_string))
        {
            $values = SystemUnit::where('id', 'in', $lancamento_clinica_to_string)->getIndexedArray('name', 'name');
            $this->lancamento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_clinica_to_string = $lancamento_clinica_to_string;
        }

        $this->vdata['lancamento_clinica_to_string'] = $this->lancamento_clinica_to_string;
    }

    public function get_lancamento_clinica_to_string()
    {
        if(!empty($this->lancamento_clinica_to_string))
        {
            return $this->lancamento_clinica_to_string;
        }
    
        $values = Lancamento::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->name}');
        return implode(', ', $values);
    }

    public function set_lancamento_tipo_pagamento_to_string($lancamento_tipo_pagamento_to_string)
    {
        if(is_array($lancamento_tipo_pagamento_to_string))
        {
            $values = TipoPagamento::where('id', 'in', $lancamento_tipo_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->lancamento_tipo_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_tipo_pagamento_to_string = $lancamento_tipo_pagamento_to_string;
        }

        $this->vdata['lancamento_tipo_pagamento_to_string'] = $this->lancamento_tipo_pagamento_to_string;
    }

    public function get_lancamento_tipo_pagamento_to_string()
    {
        if(!empty($this->lancamento_tipo_pagamento_to_string))
        {
            return $this->lancamento_tipo_pagamento_to_string;
        }
    
        $values = Lancamento::where('clinica_id', '=', $this->id)->getIndexedArray('tipo_pagamento_id','{tipo_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_lancamento_nota_fiscal_servico_to_string($lancamento_nota_fiscal_servico_to_string)
    {
        if(is_array($lancamento_nota_fiscal_servico_to_string))
        {
            $values = NotaFiscalServico::where('id', 'in', $lancamento_nota_fiscal_servico_to_string)->getIndexedArray('id', 'id');
            $this->lancamento_nota_fiscal_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_nota_fiscal_servico_to_string = $lancamento_nota_fiscal_servico_to_string;
        }

        $this->vdata['lancamento_nota_fiscal_servico_to_string'] = $this->lancamento_nota_fiscal_servico_to_string;
    }

    public function get_lancamento_nota_fiscal_servico_to_string()
    {
        if(!empty($this->lancamento_nota_fiscal_servico_to_string))
        {
            return $this->lancamento_nota_fiscal_servico_to_string;
        }
    
        $values = Lancamento::where('clinica_id', '=', $this->id)->getIndexedArray('nota_fiscal_servico_id','{nota_fiscal_servico->id}');
        return implode(', ', $values);
    }

    public function set_saas_error_log_system_unit_to_string($saas_error_log_system_unit_to_string)
    {
        if(is_array($saas_error_log_system_unit_to_string))
        {
            $values = SystemUnit::where('id', 'in', $saas_error_log_system_unit_to_string)->getIndexedArray('name', 'name');
            $this->saas_error_log_system_unit_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_error_log_system_unit_to_string = $saas_error_log_system_unit_to_string;
        }

        $this->vdata['saas_error_log_system_unit_to_string'] = $this->saas_error_log_system_unit_to_string;
    }

    public function get_saas_error_log_system_unit_to_string()
    {
        if(!empty($this->saas_error_log_system_unit_to_string))
        {
            return $this->saas_error_log_system_unit_to_string;
        }
    
        $values = SaasErrorLog::where('system_unit_id', '=', $this->id)->getIndexedArray('system_unit_id','{system_unit->name}');
        return implode(', ', $values);
    }

    public function set_saas_error_log_system_user_to_string($saas_error_log_system_user_to_string)
    {
        if(is_array($saas_error_log_system_user_to_string))
        {
            $values = SystemUsers::where('id', 'in', $saas_error_log_system_user_to_string)->getIndexedArray('name', 'name');
            $this->saas_error_log_system_user_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_error_log_system_user_to_string = $saas_error_log_system_user_to_string;
        }

        $this->vdata['saas_error_log_system_user_to_string'] = $this->saas_error_log_system_user_to_string;
    }

    public function get_saas_error_log_system_user_to_string()
    {
        if(!empty($this->saas_error_log_system_user_to_string))
        {
            return $this->saas_error_log_system_user_to_string;
        }
    
        $values = SaasErrorLog::where('system_unit_id', '=', $this->id)->getIndexedArray('system_user_id','{system_user->name}');
        return implode(', ', $values);
    }

}

