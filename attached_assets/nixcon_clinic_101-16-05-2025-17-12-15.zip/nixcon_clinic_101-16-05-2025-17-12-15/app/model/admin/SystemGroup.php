<?php

class SystemGroup extends TRecord
{
    const TABLENAME  = 'system_group';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'max'; // {max, serial}

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('name');
        parent::addAttribute('uuid');
    
    }

    /**
     * Method getSaasConfiguracaos
     */
    public function getSaasConfiguracaos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('contrato_inativo_system_group_id', '=', $this->id));
        return SaasConfiguracao::getObjects( $criteria );
    }
    /**
     * Method getSaasContratoGrupos
     */
    public function getSaasContratoGrupos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('system_group_id', '=', $this->id));
        return SaasContratoGrupo::getObjects( $criteria );
    }
    /**
     * Method getSaasPlanoGrupos
     */
    public function getSaasPlanoGrupos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('system_group_id', '=', $this->id));
        return SaasPlanoGrupo::getObjects( $criteria );
    }

    public function set_saas_configuracao_cidade_to_string($saas_configuracao_cidade_to_string)
    {
        if(is_array($saas_configuracao_cidade_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_configuracao_cidade_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_configuracao_cidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_configuracao_cidade_to_string = $saas_configuracao_cidade_to_string;
        }

        $this->vdata['saas_configuracao_cidade_to_string'] = $this->saas_configuracao_cidade_to_string;
    }

    public function get_saas_configuracao_cidade_to_string()
    {
        if(!empty($this->saas_configuracao_cidade_to_string))
        {
            return $this->saas_configuracao_cidade_to_string;
        }
    
        $values = SaasConfiguracao::where('contrato_inativo_system_group_id', '=', $this->id)->getIndexedArray('cidade_id','{cidade->nome}');
        return implode(', ', $values);
    }

    public function set_saas_configuracao_saas_plano_valor_trial_to_string($saas_configuracao_saas_plano_valor_trial_to_string)
    {
        if(is_array($saas_configuracao_saas_plano_valor_trial_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_configuracao_saas_plano_valor_trial_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_configuracao_saas_plano_valor_trial_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_configuracao_saas_plano_valor_trial_to_string = $saas_configuracao_saas_plano_valor_trial_to_string;
        }

        $this->vdata['saas_configuracao_saas_plano_valor_trial_to_string'] = $this->saas_configuracao_saas_plano_valor_trial_to_string;
    }

    public function get_saas_configuracao_saas_plano_valor_trial_to_string()
    {
        if(!empty($this->saas_configuracao_saas_plano_valor_trial_to_string))
        {
            return $this->saas_configuracao_saas_plano_valor_trial_to_string;
        }
    
        $values = SaasConfiguracao::where('contrato_inativo_system_group_id', '=', $this->id)->getIndexedArray('saas_plano_valor_trial_id','{saas_plano_valor_trial->nome}');
        return implode(', ', $values);
    }

    public function set_saas_configuracao_contrato_inativo_system_group_to_string($saas_configuracao_contrato_inativo_system_group_to_string)
    {
        if(is_array($saas_configuracao_contrato_inativo_system_group_to_string))
        {
            $values = SystemGroup::where('id', 'in', $saas_configuracao_contrato_inativo_system_group_to_string)->getIndexedArray('name', 'name');
            $this->saas_configuracao_contrato_inativo_system_group_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_configuracao_contrato_inativo_system_group_to_string = $saas_configuracao_contrato_inativo_system_group_to_string;
        }

        $this->vdata['saas_configuracao_contrato_inativo_system_group_to_string'] = $this->saas_configuracao_contrato_inativo_system_group_to_string;
    }

    public function get_saas_configuracao_contrato_inativo_system_group_to_string()
    {
        if(!empty($this->saas_configuracao_contrato_inativo_system_group_to_string))
        {
            return $this->saas_configuracao_contrato_inativo_system_group_to_string;
        }
    
        $values = SaasConfiguracao::where('contrato_inativo_system_group_id', '=', $this->id)->getIndexedArray('contrato_inativo_system_group_id','{contrato_inativo_system_group->name}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_grupo_saas_contrato_to_string($saas_contrato_grupo_saas_contrato_to_string)
    {
        if(is_array($saas_contrato_grupo_saas_contrato_to_string))
        {
            $values = SaasContrato::where('id', 'in', $saas_contrato_grupo_saas_contrato_to_string)->getIndexedArray('id', 'id');
            $this->saas_contrato_grupo_saas_contrato_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_grupo_saas_contrato_to_string = $saas_contrato_grupo_saas_contrato_to_string;
        }

        $this->vdata['saas_contrato_grupo_saas_contrato_to_string'] = $this->saas_contrato_grupo_saas_contrato_to_string;
    }

    public function get_saas_contrato_grupo_saas_contrato_to_string()
    {
        if(!empty($this->saas_contrato_grupo_saas_contrato_to_string))
        {
            return $this->saas_contrato_grupo_saas_contrato_to_string;
        }
    
        $values = SaasContratoGrupo::where('system_group_id', '=', $this->id)->getIndexedArray('saas_contrato_id','{saas_contrato->id}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_grupo_system_group_to_string($saas_contrato_grupo_system_group_to_string)
    {
        if(is_array($saas_contrato_grupo_system_group_to_string))
        {
            $values = SystemGroup::where('id', 'in', $saas_contrato_grupo_system_group_to_string)->getIndexedArray('name', 'name');
            $this->saas_contrato_grupo_system_group_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_grupo_system_group_to_string = $saas_contrato_grupo_system_group_to_string;
        }

        $this->vdata['saas_contrato_grupo_system_group_to_string'] = $this->saas_contrato_grupo_system_group_to_string;
    }

    public function get_saas_contrato_grupo_system_group_to_string()
    {
        if(!empty($this->saas_contrato_grupo_system_group_to_string))
        {
            return $this->saas_contrato_grupo_system_group_to_string;
        }
    
        $values = SaasContratoGrupo::where('system_group_id', '=', $this->id)->getIndexedArray('system_group_id','{system_group->name}');
        return implode(', ', $values);
    }

    public function set_saas_plano_grupo_saas_plano_to_string($saas_plano_grupo_saas_plano_to_string)
    {
        if(is_array($saas_plano_grupo_saas_plano_to_string))
        {
            $values = SaasPlano::where('id', 'in', $saas_plano_grupo_saas_plano_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_plano_grupo_saas_plano_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_plano_grupo_saas_plano_to_string = $saas_plano_grupo_saas_plano_to_string;
        }

        $this->vdata['saas_plano_grupo_saas_plano_to_string'] = $this->saas_plano_grupo_saas_plano_to_string;
    }

    public function get_saas_plano_grupo_saas_plano_to_string()
    {
        if(!empty($this->saas_plano_grupo_saas_plano_to_string))
        {
            return $this->saas_plano_grupo_saas_plano_to_string;
        }
    
        $values = SaasPlanoGrupo::where('system_group_id', '=', $this->id)->getIndexedArray('saas_plano_id','{saas_plano->nome}');
        return implode(', ', $values);
    }

    public function set_saas_plano_grupo_system_group_to_string($saas_plano_grupo_system_group_to_string)
    {
        if(is_array($saas_plano_grupo_system_group_to_string))
        {
            $values = SystemGroup::where('id', 'in', $saas_plano_grupo_system_group_to_string)->getIndexedArray('name', 'name');
            $this->saas_plano_grupo_system_group_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_plano_grupo_system_group_to_string = $saas_plano_grupo_system_group_to_string;
        }

        $this->vdata['saas_plano_grupo_system_group_to_string'] = $this->saas_plano_grupo_system_group_to_string;
    }

    public function get_saas_plano_grupo_system_group_to_string()
    {
        if(!empty($this->saas_plano_grupo_system_group_to_string))
        {
            return $this->saas_plano_grupo_system_group_to_string;
        }
    
        $values = SaasPlanoGrupo::where('system_group_id', '=', $this->id)->getIndexedArray('system_group_id','{system_group->name}');
        return implode(', ', $values);
    }

    /**
     * Add a SystemProgram to the SystemGroup
     * @param $object Instance of SystemProgram
     */
    public function addSystemProgram(SystemProgram $systemprogram)
    {
        if (SystemGroupProgram::where('system_program_id','=',$systemprogram->id)->where('system_group_id','=',$this->id)->count() == 0)
        {
            $object = new SystemGroupProgram;
            $object->system_program_id = $systemprogram->id;
            $object->system_group_id = $this->id;
            $object->store();
        }
    }

    /**
     * Return the SystemProgram's
     * @return Collection of SystemProgram
     */
    public function getSystemPrograms()
    {
        $system_programs = array();
        // load the related System_program objects
        $repository = new TRepository('SystemGroupProgram');
        $criteria = new TCriteria;
        $criteria->add(new TFilter('system_group_id', '=', $this->id));
        $system_group_system_programs = $repository->load($criteria);
        if ($system_group_system_programs)
        {
            foreach ($system_group_system_programs as $system_group_system_program)
            {
                $systemProgram = new SystemProgram( $system_group_system_program->system_program_id );
                $systemProgram->allowed_actions = json_encode([]);
                if($system_group_system_program->actions)
                {
                    $systemProgram->allowed_actions = $system_group_system_program->actions;
                }
                $system_programs[] = $systemProgram;
            }
        }
        return $system_programs;
    }

    /**
     * Reset aggregates
     */
    public function clearParts()
    {
        // delete the related objects
        SystemGroupProgram::where('system_group_id', '=', $this->id)->delete();
        SystemUserGroup::where('system_group_id', '=', $this->id)->delete();
    }

    /**
     * Delete the object and its aggregates
     * @param $id object ID
     */
    public function delete($id = NULL)
    {
        // delete the related System_groupSystem_program objects
        $id = isset($id) ? $id : $this->id;
    
        SystemGroupProgram::where('system_group_id', '=', $id)->delete();
        SystemUserGroup::where('system_group_id', '=', $id)->delete();
    
        // delete the object itself
        parent::delete($id);
    }

    /**
     * Clone the entire object and related ones
     */
    public function cloneGroup()
    {
        $programs = $this->getSystemPrograms();
        $users    = $this->getSystemUsers();
        unset($this->id);
        $this->name .= ' (clone)';
        $this->store();
        if ($programs)
        {
            foreach ($programs as $program)
            {
                $this->addSystemProgram( $program );
            }
        }
        if ($users)
        {
            foreach ($users as $user)
            {
                $this->addSystemUser( $user );
            }
        }
    }
    /**
     * Add a SystemUser to the SystemGroup
     * @param $object Instance of SystemUser
     */
    public function addSystemUser(SystemUsers $systemuser)
    {
        if (SystemUserGroup::where('system_user_id','=',$systemuser->id)->where('system_group_id','=',$this->id)->count() == 0)
        {
            $object = new SystemUserGroup;
            $object->system_user_id  = $systemuser->id;
            $object->system_group_id = $this->id;
            $object->store();
        }
    }
    /**
     * Return the SystemUser's
     * @return Collection of SystemUser
     */
    public function getSystemUsers()
    {
        $system_users = array();
        // load the related System_user objects
        $repository = new TRepository('SystemUserGroup');
        $criteria = new TCriteria;
        $criteria->add(new TFilter('system_group_id', '=', $this->id));
        $system_group_system_users = $repository->load($criteria);
        if ($system_group_system_users)
        {
            foreach ($system_group_system_users as $system_group_system_user)
            {
                $system_users[] = new SystemUsers( $system_group_system_user->system_user_id );
            }
        }
        return $system_users;
    }

    
}

