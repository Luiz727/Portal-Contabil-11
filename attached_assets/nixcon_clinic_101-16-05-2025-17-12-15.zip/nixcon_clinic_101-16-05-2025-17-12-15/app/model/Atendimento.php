<?php

class Atendimento extends TRecord
{
    const TABLENAME  = 'atendimento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SystemUnit $clinica;
    private Pessoa $paciente;
    private Pessoa $profissional;
    private Agendamento $agendamento;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByUnit');
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
            
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('agendamento_id');
        parent::addAttribute('paciente_id');
        parent::addAttribute('profissional_id');
        parent::addAttribute('clinica_id');
        parent::addAttribute('dt_inicio');
        parent::addAttribute('dt_final');
        parent::addAttribute('valor_total');
        parent::addAttribute('ano_inicial');
        parent::addAttribute('mes_inicial');
        parent::addAttribute('ano_mes_inicial');
        parent::addAttribute('mes_final');
        parent::addAttribute('ano_final');
        parent::addAttribute('ano_mes_final');
    
    }

    /**
     * Method set_system_unit
     * Sample of usage: $var->system_unit = $object;
     * @param $object Instance of SystemUnit
     */
    public function set_clinica(SystemUnit $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns SystemUnit instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new SystemUnit($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }
    /**
     * Method set_pessoa
     * Sample of usage: $var->pessoa = $object;
     * @param $object Instance of Pessoa
     */
    public function set_paciente(Pessoa $object)
    {
        $this->paciente = $object;
        $this->paciente_id = $object->id;
    }

    /**
     * Method get_paciente
     * Sample of usage: $var->paciente->attribute;
     * @returns Pessoa instance
     */
    public function get_paciente()
    {
    
        // loads the associated object
        if (empty($this->paciente))
            $this->paciente = new Pessoa($this->paciente_id);
    
        // returns the associated object
        return $this->paciente;
    }
    /**
     * Method set_pessoa
     * Sample of usage: $var->pessoa = $object;
     * @param $object Instance of Pessoa
     */
    public function set_profissional(Pessoa $object)
    {
        $this->profissional = $object;
        $this->profissional_id = $object->id;
    }

    /**
     * Method get_profissional
     * Sample of usage: $var->profissional->attribute;
     * @returns Pessoa instance
     */
    public function get_profissional()
    {
    
        // loads the associated object
        if (empty($this->profissional))
            $this->profissional = new Pessoa($this->profissional_id);
    
        // returns the associated object
        return $this->profissional;
    }
    /**
     * Method set_agendamento
     * Sample of usage: $var->agendamento = $object;
     * @param $object Instance of Agendamento
     */
    public function set_agendamento(Agendamento $object)
    {
        $this->agendamento = $object;
        $this->agendamento_id = $object->id;
    }

    /**
     * Method get_agendamento
     * Sample of usage: $var->agendamento->attribute;
     * @returns Agendamento instance
     */
    public function get_agendamento()
    {
    
        // loads the associated object
        if (empty($this->agendamento))
            $this->agendamento = new Agendamento($this->agendamento_id);
    
        // returns the associated object
        return $this->agendamento;
    }

    /**
     * Method getAnexos
     */
    public function getAnexos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('atendimento_id', '=', $this->id));
        return Anexo::getObjects( $criteria );
    }
    /**
     * Method getAtendimentoMaterials
     */
    public function getAtendimentoMaterials()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('atendimento_id', '=', $this->id));
        return AtendimentoMaterial::getObjects( $criteria );
    }
    /**
     * Method getAtendimentoProcedimentos
     */
    public function getAtendimentoProcedimentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('atendimento_id', '=', $this->id));
        return AtendimentoProcedimento::getObjects( $criteria );
    }
    /**
     * Method getContas
     */
    public function getContas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('atendimento_id', '=', $this->id));
        return Conta::getObjects( $criteria );
    }
    /**
     * Method getDocumentos
     */
    public function getDocumentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('atendimento_id', '=', $this->id));
        return Documento::getObjects( $criteria );
    }
    /**
     * Method getExameAtendimentos
     */
    public function getExameAtendimentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('atendimento_id', '=', $this->id));
        return ExameAtendimento::getObjects( $criteria );
    }
    /**
     * Method getPrescricaos
     */
    public function getPrescricaos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('atendimento_id', '=', $this->id));
        return Prescricao::getObjects( $criteria );
    }
    /**
     * Method getRespostaFormularios
     */
    public function getRespostaFormularios()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('atendimento_id', '=', $this->id));
        return RespostaFormulario::getObjects( $criteria );
    }

    public function set_anexo_atendimento_to_string($anexo_atendimento_to_string)
    {
        if(is_array($anexo_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $anexo_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->anexo_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->anexo_atendimento_to_string = $anexo_atendimento_to_string;
        }

        $this->vdata['anexo_atendimento_to_string'] = $this->anexo_atendimento_to_string;
    }

    public function get_anexo_atendimento_to_string()
    {
        if(!empty($this->anexo_atendimento_to_string))
        {
            return $this->anexo_atendimento_to_string;
        }
    
        $values = Anexo::where('atendimento_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_atendimento_material_material_to_string($atendimento_material_material_to_string)
    {
        if(is_array($atendimento_material_material_to_string))
        {
            $values = Material::where('id', 'in', $atendimento_material_material_to_string)->getIndexedArray('nome', 'nome');
            $this->atendimento_material_material_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_material_material_to_string = $atendimento_material_material_to_string;
        }

        $this->vdata['atendimento_material_material_to_string'] = $this->atendimento_material_material_to_string;
    }

    public function get_atendimento_material_material_to_string()
    {
        if(!empty($this->atendimento_material_material_to_string))
        {
            return $this->atendimento_material_material_to_string;
        }
    
        $values = AtendimentoMaterial::where('atendimento_id', '=', $this->id)->getIndexedArray('material_id','{material->nome}');
        return implode(', ', $values);
    }

    public function set_atendimento_material_atendimento_to_string($atendimento_material_atendimento_to_string)
    {
        if(is_array($atendimento_material_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $atendimento_material_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->atendimento_material_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_material_atendimento_to_string = $atendimento_material_atendimento_to_string;
        }

        $this->vdata['atendimento_material_atendimento_to_string'] = $this->atendimento_material_atendimento_to_string;
    }

    public function get_atendimento_material_atendimento_to_string()
    {
        if(!empty($this->atendimento_material_atendimento_to_string))
        {
            return $this->atendimento_material_atendimento_to_string;
        }
    
        $values = AtendimentoMaterial::where('atendimento_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_atendimento_procedimento_convenio_to_string($atendimento_procedimento_convenio_to_string)
    {
        if(is_array($atendimento_procedimento_convenio_to_string))
        {
            $values = Convenio::where('id', 'in', $atendimento_procedimento_convenio_to_string)->getIndexedArray('nome', 'nome');
            $this->atendimento_procedimento_convenio_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_procedimento_convenio_to_string = $atendimento_procedimento_convenio_to_string;
        }

        $this->vdata['atendimento_procedimento_convenio_to_string'] = $this->atendimento_procedimento_convenio_to_string;
    }

    public function get_atendimento_procedimento_convenio_to_string()
    {
        if(!empty($this->atendimento_procedimento_convenio_to_string))
        {
            return $this->atendimento_procedimento_convenio_to_string;
        }
    
        $values = AtendimentoProcedimento::where('atendimento_id', '=', $this->id)->getIndexedArray('convenio_id','{convenio->nome}');
        return implode(', ', $values);
    }

    public function set_atendimento_procedimento_atendimento_to_string($atendimento_procedimento_atendimento_to_string)
    {
        if(is_array($atendimento_procedimento_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $atendimento_procedimento_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->atendimento_procedimento_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_procedimento_atendimento_to_string = $atendimento_procedimento_atendimento_to_string;
        }

        $this->vdata['atendimento_procedimento_atendimento_to_string'] = $this->atendimento_procedimento_atendimento_to_string;
    }

    public function get_atendimento_procedimento_atendimento_to_string()
    {
        if(!empty($this->atendimento_procedimento_atendimento_to_string))
        {
            return $this->atendimento_procedimento_atendimento_to_string;
        }
    
        $values = AtendimentoProcedimento::where('atendimento_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_atendimento_procedimento_procedimento_to_string($atendimento_procedimento_procedimento_to_string)
    {
        if(is_array($atendimento_procedimento_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $atendimento_procedimento_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->atendimento_procedimento_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_procedimento_procedimento_to_string = $atendimento_procedimento_procedimento_to_string;
        }

        $this->vdata['atendimento_procedimento_procedimento_to_string'] = $this->atendimento_procedimento_procedimento_to_string;
    }

    public function get_atendimento_procedimento_procedimento_to_string()
    {
        if(!empty($this->atendimento_procedimento_procedimento_to_string))
        {
            return $this->atendimento_procedimento_procedimento_to_string;
        }
    
        $values = AtendimentoProcedimento::where('atendimento_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_conta_pessoa_to_string($conta_pessoa_to_string)
    {
        if(is_array($conta_pessoa_to_string))
        {
            $values = Pessoa::where('id', 'in', $conta_pessoa_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_pessoa_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_pessoa_to_string = $conta_pessoa_to_string;
        }

        $this->vdata['conta_pessoa_to_string'] = $this->conta_pessoa_to_string;
    }

    public function get_conta_pessoa_to_string()
    {
        if(!empty($this->conta_pessoa_to_string))
        {
            return $this->conta_pessoa_to_string;
        }
    
        $values = Conta::where('atendimento_id', '=', $this->id)->getIndexedArray('pessoa_id','{pessoa->nome}');
        return implode(', ', $values);
    }

    public function set_conta_categoria_conta_to_string($conta_categoria_conta_to_string)
    {
        if(is_array($conta_categoria_conta_to_string))
        {
            $values = CategoriaConta::where('id', 'in', $conta_categoria_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_categoria_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_categoria_conta_to_string = $conta_categoria_conta_to_string;
        }

        $this->vdata['conta_categoria_conta_to_string'] = $this->conta_categoria_conta_to_string;
    }

    public function get_conta_categoria_conta_to_string()
    {
        if(!empty($this->conta_categoria_conta_to_string))
        {
            return $this->conta_categoria_conta_to_string;
        }
    
        $values = Conta::where('atendimento_id', '=', $this->id)->getIndexedArray('categoria_conta_id','{categoria_conta->nome}');
        return implode(', ', $values);
    }

    public function set_conta_tipo_conta_to_string($conta_tipo_conta_to_string)
    {
        if(is_array($conta_tipo_conta_to_string))
        {
            $values = TipoConta::where('id', 'in', $conta_tipo_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_tipo_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_tipo_conta_to_string = $conta_tipo_conta_to_string;
        }

        $this->vdata['conta_tipo_conta_to_string'] = $this->conta_tipo_conta_to_string;
    }

    public function get_conta_tipo_conta_to_string()
    {
        if(!empty($this->conta_tipo_conta_to_string))
        {
            return $this->conta_tipo_conta_to_string;
        }
    
        $values = Conta::where('atendimento_id', '=', $this->id)->getIndexedArray('tipo_conta_id','{tipo_conta->nome}');
        return implode(', ', $values);
    }

    public function set_conta_clinica_to_string($conta_clinica_to_string)
    {
        if(is_array($conta_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $conta_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_clinica_to_string = $conta_clinica_to_string;
        }

        $this->vdata['conta_clinica_to_string'] = $this->conta_clinica_to_string;
    }

    public function get_conta_clinica_to_string()
    {
        if(!empty($this->conta_clinica_to_string))
        {
            return $this->conta_clinica_to_string;
        }
    
        $values = Conta::where('atendimento_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_conta_atendimento_to_string($conta_atendimento_to_string)
    {
        if(is_array($conta_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $conta_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->conta_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_atendimento_to_string = $conta_atendimento_to_string;
        }

        $this->vdata['conta_atendimento_to_string'] = $this->conta_atendimento_to_string;
    }

    public function get_conta_atendimento_to_string()
    {
        if(!empty($this->conta_atendimento_to_string))
        {
            return $this->conta_atendimento_to_string;
        }
    
        $values = Conta::where('atendimento_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_documento_atendimento_to_string($documento_atendimento_to_string)
    {
        if(is_array($documento_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $documento_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->documento_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_atendimento_to_string = $documento_atendimento_to_string;
        }

        $this->vdata['documento_atendimento_to_string'] = $this->documento_atendimento_to_string;
    }

    public function get_documento_atendimento_to_string()
    {
        if(!empty($this->documento_atendimento_to_string))
        {
            return $this->documento_atendimento_to_string;
        }
    
        $values = Documento::where('atendimento_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_documento_tipo_documento_to_string($documento_tipo_documento_to_string)
    {
        if(is_array($documento_tipo_documento_to_string))
        {
            $values = TipoDocumento::where('id', 'in', $documento_tipo_documento_to_string)->getIndexedArray('nome', 'nome');
            $this->documento_tipo_documento_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_tipo_documento_to_string = $documento_tipo_documento_to_string;
        }

        $this->vdata['documento_tipo_documento_to_string'] = $this->documento_tipo_documento_to_string;
    }

    public function get_documento_tipo_documento_to_string()
    {
        if(!empty($this->documento_tipo_documento_to_string))
        {
            return $this->documento_tipo_documento_to_string;
        }
    
        $values = Documento::where('atendimento_id', '=', $this->id)->getIndexedArray('tipo_documento_id','{tipo_documento->nome}');
        return implode(', ', $values);
    }

    public function set_documento_clinica_to_string($documento_clinica_to_string)
    {
        if(is_array($documento_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $documento_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->documento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_clinica_to_string = $documento_clinica_to_string;
        }

        $this->vdata['documento_clinica_to_string'] = $this->documento_clinica_to_string;
    }

    public function get_documento_clinica_to_string()
    {
        if(!empty($this->documento_clinica_to_string))
        {
            return $this->documento_clinica_to_string;
        }
    
        $values = Documento::where('atendimento_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_documento_procedimento_to_string($documento_procedimento_to_string)
    {
        if(is_array($documento_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $documento_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->documento_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_procedimento_to_string = $documento_procedimento_to_string;
        }

        $this->vdata['documento_procedimento_to_string'] = $this->documento_procedimento_to_string;
    }

    public function get_documento_procedimento_to_string()
    {
        if(!empty($this->documento_procedimento_to_string))
        {
            return $this->documento_procedimento_to_string;
        }
    
        $values = Documento::where('atendimento_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_exame_atendimento_atendimento_to_string($exame_atendimento_atendimento_to_string)
    {
        if(is_array($exame_atendimento_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $exame_atendimento_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->exame_atendimento_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->exame_atendimento_atendimento_to_string = $exame_atendimento_atendimento_to_string;
        }

        $this->vdata['exame_atendimento_atendimento_to_string'] = $this->exame_atendimento_atendimento_to_string;
    }

    public function get_exame_atendimento_atendimento_to_string()
    {
        if(!empty($this->exame_atendimento_atendimento_to_string))
        {
            return $this->exame_atendimento_atendimento_to_string;
        }
    
        $values = ExameAtendimento::where('atendimento_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_exame_atendimento_exame_to_string($exame_atendimento_exame_to_string)
    {
        if(is_array($exame_atendimento_exame_to_string))
        {
            $values = Exame::where('id', 'in', $exame_atendimento_exame_to_string)->getIndexedArray('nome', 'nome');
            $this->exame_atendimento_exame_to_string = implode(', ', $values);
        }
        else
        {
            $this->exame_atendimento_exame_to_string = $exame_atendimento_exame_to_string;
        }

        $this->vdata['exame_atendimento_exame_to_string'] = $this->exame_atendimento_exame_to_string;
    }

    public function get_exame_atendimento_exame_to_string()
    {
        if(!empty($this->exame_atendimento_exame_to_string))
        {
            return $this->exame_atendimento_exame_to_string;
        }
    
        $values = ExameAtendimento::where('atendimento_id', '=', $this->id)->getIndexedArray('exame_id','{exame->nome}');
        return implode(', ', $values);
    }

    public function set_prescricao_atendimento_to_string($prescricao_atendimento_to_string)
    {
        if(is_array($prescricao_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $prescricao_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->prescricao_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->prescricao_atendimento_to_string = $prescricao_atendimento_to_string;
        }

        $this->vdata['prescricao_atendimento_to_string'] = $this->prescricao_atendimento_to_string;
    }

    public function get_prescricao_atendimento_to_string()
    {
        if(!empty($this->prescricao_atendimento_to_string))
        {
            return $this->prescricao_atendimento_to_string;
        }
    
        $values = Prescricao::where('atendimento_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_resposta_formulario_formulario_to_string($resposta_formulario_formulario_to_string)
    {
        if(is_array($resposta_formulario_formulario_to_string))
        {
            $values = Formulario::where('id', 'in', $resposta_formulario_formulario_to_string)->getIndexedArray('nome', 'nome');
            $this->resposta_formulario_formulario_to_string = implode(', ', $values);
        }
        else
        {
            $this->resposta_formulario_formulario_to_string = $resposta_formulario_formulario_to_string;
        }

        $this->vdata['resposta_formulario_formulario_to_string'] = $this->resposta_formulario_formulario_to_string;
    }

    public function get_resposta_formulario_formulario_to_string()
    {
        if(!empty($this->resposta_formulario_formulario_to_string))
        {
            return $this->resposta_formulario_formulario_to_string;
        }
    
        $values = RespostaFormulario::where('atendimento_id', '=', $this->id)->getIndexedArray('formulario_id','{formulario->nome}');
        return implode(', ', $values);
    }

    public function set_resposta_formulario_atendimento_to_string($resposta_formulario_atendimento_to_string)
    {
        if(is_array($resposta_formulario_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $resposta_formulario_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->resposta_formulario_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->resposta_formulario_atendimento_to_string = $resposta_formulario_atendimento_to_string;
        }

        $this->vdata['resposta_formulario_atendimento_to_string'] = $this->resposta_formulario_atendimento_to_string;
    }

    public function get_resposta_formulario_atendimento_to_string()
    {
        if(!empty($this->resposta_formulario_atendimento_to_string))
        {
            return $this->resposta_formulario_atendimento_to_string;
        }
    
        $values = RespostaFormulario::where('atendimento_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function onBeforeStore($object)
    {
        if (! empty($object->dt_inicio))
        {
            $object->ano_inicial = date('Y', strtotime($object->dt_inicio));
            $object->mes_inicial = date('m', strtotime($object->dt_inicio));
            $object->ano_mes_inicial = date('Ym', strtotime($object->dt_inicio));
        }
    
        if (! empty($object->dt_final))
        {
            $object->ano_final = date('Y', strtotime($object->dt_final));
            $object->mes_final = date('m', strtotime($object->dt_final));
            $object->ano_mes_final = date('Ym', strtotime($object->dt_final));
        }
    }

    public function get_data_atendimento()
    {
        return TDate::date2br($this->dt_inicio);
    }

    public function get_inicio_atendimento()
    {
        return date('d/m/Y H:i', strtotime($this->dt_inicio));
    }
                        
}

