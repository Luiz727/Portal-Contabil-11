<?php

class Account extends TRecord
{
    const TABLENAME  = 'account';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Cidade $cidade;
    private SystemUsers $system_user;

    private $contrato;

                                            

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('cidade_id');
        parent::addAttribute('system_user_id');
        parent::addAttribute('nome_responsavel');
        parent::addAttribute('razao_social');
        parent::addAttribute('tipo_pessoa');
        parent::addAttribute('documento');
        parent::addAttribute('email');
        parent::addAttribute('telefone');
        parent::addAttribute('cep');
        parent::addAttribute('rua');
        parent::addAttribute('numero');
        parent::addAttribute('complemento');
        parent::addAttribute('bairro');
        parent::addAttribute('mes_criacao');
        parent::addAttribute('ano_criacao');
        parent::addAttribute('created_at');
    
    }

    /**
     * Method set_cidade
     * Sample of usage: $var->cidade = $object;
     * @param $object Instance of Cidade
     */
    public function set_cidade(Cidade $object)
    {
        $this->cidade = $object;
        $this->cidade_id = $object->id;
    }

    /**
     * Method get_cidade
     * Sample of usage: $var->cidade->attribute;
     * @returns Cidade instance
     */
    public function get_cidade()
    {
    
        // loads the associated object
        if (empty($this->cidade))
            $this->cidade = new Cidade($this->cidade_id);
    
        // returns the associated object
        return $this->cidade;
    }
    /**
     * Method set_system_users
     * Sample of usage: $var->system_users = $object;
     * @param $object Instance of SystemUsers
     */
    public function set_system_user(SystemUsers $object)
    {
        $this->system_user = $object;
        $this->system_user_id = $object->id;
    }

    /**
     * Method get_system_user
     * Sample of usage: $var->system_user->attribute;
     * @returns SystemUsers instance
     */
    public function get_system_user()
    {
    
        // loads the associated object
        if (empty($this->system_user))
            $this->system_user = new SystemUsers($this->system_user_id);
    
        // returns the associated object
        return $this->system_user;
    }

    /**
     * Method getCategoriaContas
     */
    public function getCategoriaContas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('account_id', '=', $this->id));
        return CategoriaConta::getObjects( $criteria );
    }
    /**
     * Method getClinicas
     */
    public function getClinicas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('account_id', '=', $this->id));
        return Clinica::getObjects( $criteria );
    }
    /**
     * Method getConvenios
     */
    public function getConvenios()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('account_id', '=', $this->id));
        return Convenio::getObjects( $criteria );
    }
    /**
     * Method getSaasContratos
     */
    public function getSaasContratos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('account_id', '=', $this->id));
        return SaasContrato::getObjects( $criteria );
    }
    /**
     * Method getSaasPagamentos
     */
    public function getSaasPagamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('account_id', '=', $this->id));
        return SaasPagamento::getObjects( $criteria );
    }
    /**
     * Method getServicos
     */
    public function getServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('account_id', '=', $this->id));
        return Servico::getObjects( $criteria );
    }
    /**
     * Method getTipoPagamentos
     */
    public function getTipoPagamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('account_id', '=', $this->id));
        return TipoPagamento::getObjects( $criteria );
    }

    public function set_categoria_conta_tipo_conta_to_string($categoria_conta_tipo_conta_to_string)
    {
        if(is_array($categoria_conta_tipo_conta_to_string))
        {
            $values = TipoConta::where('id', 'in', $categoria_conta_tipo_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->categoria_conta_tipo_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->categoria_conta_tipo_conta_to_string = $categoria_conta_tipo_conta_to_string;
        }

        $this->vdata['categoria_conta_tipo_conta_to_string'] = $this->categoria_conta_tipo_conta_to_string;
    }

    public function get_categoria_conta_tipo_conta_to_string()
    {
        if(!empty($this->categoria_conta_tipo_conta_to_string))
        {
            return $this->categoria_conta_tipo_conta_to_string;
        }
    
        $values = CategoriaConta::where('account_id', '=', $this->id)->getIndexedArray('tipo_conta_id','{tipo_conta->nome}');
        return implode(', ', $values);
    }

    public function set_categoria_conta_account_to_string($categoria_conta_account_to_string)
    {
        if(is_array($categoria_conta_account_to_string))
        {
            $values = Account::where('id', 'in', $categoria_conta_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->categoria_conta_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->categoria_conta_account_to_string = $categoria_conta_account_to_string;
        }

        $this->vdata['categoria_conta_account_to_string'] = $this->categoria_conta_account_to_string;
    }

    public function get_categoria_conta_account_to_string()
    {
        if(!empty($this->categoria_conta_account_to_string))
        {
            return $this->categoria_conta_account_to_string;
        }
    
        $values = CategoriaConta::where('account_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_clinica_system_unit_to_string($clinica_system_unit_to_string)
    {
        if(is_array($clinica_system_unit_to_string))
        {
            $values = SystemUnit::where('id', 'in', $clinica_system_unit_to_string)->getIndexedArray('name', 'name');
            $this->clinica_system_unit_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_system_unit_to_string = $clinica_system_unit_to_string;
        }

        $this->vdata['clinica_system_unit_to_string'] = $this->clinica_system_unit_to_string;
    }

    public function get_clinica_system_unit_to_string()
    {
        if(!empty($this->clinica_system_unit_to_string))
        {
            return $this->clinica_system_unit_to_string;
        }
    
        $values = Clinica::where('account_id', '=', $this->id)->getIndexedArray('system_unit_id','{system_unit->name}');
        return implode(', ', $values);
    }

    public function set_clinica_atendimento_categoria_conta_to_string($clinica_atendimento_categoria_conta_to_string)
    {
        if(is_array($clinica_atendimento_categoria_conta_to_string))
        {
            $values = CategoriaConta::where('id', 'in', $clinica_atendimento_categoria_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->clinica_atendimento_categoria_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_atendimento_categoria_conta_to_string = $clinica_atendimento_categoria_conta_to_string;
        }

        $this->vdata['clinica_atendimento_categoria_conta_to_string'] = $this->clinica_atendimento_categoria_conta_to_string;
    }

    public function get_clinica_atendimento_categoria_conta_to_string()
    {
        if(!empty($this->clinica_atendimento_categoria_conta_to_string))
        {
            return $this->clinica_atendimento_categoria_conta_to_string;
        }
    
        $values = Clinica::where('account_id', '=', $this->id)->getIndexedArray('atendimento_categoria_conta_id','{atendimento_categoria_conta->nome}');
        return implode(', ', $values);
    }

    public function set_clinica_cidade_to_string($clinica_cidade_to_string)
    {
        if(is_array($clinica_cidade_to_string))
        {
            $values = Cidade::where('id', 'in', $clinica_cidade_to_string)->getIndexedArray('nome', 'nome');
            $this->clinica_cidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_cidade_to_string = $clinica_cidade_to_string;
        }

        $this->vdata['clinica_cidade_to_string'] = $this->clinica_cidade_to_string;
    }

    public function get_clinica_cidade_to_string()
    {
        if(!empty($this->clinica_cidade_to_string))
        {
            return $this->clinica_cidade_to_string;
        }
    
        $values = Clinica::where('account_id', '=', $this->id)->getIndexedArray('cidade_id','{cidade->nome}');
        return implode(', ', $values);
    }

    public function set_clinica_account_to_string($clinica_account_to_string)
    {
        if(is_array($clinica_account_to_string))
        {
            $values = Account::where('id', 'in', $clinica_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->clinica_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_account_to_string = $clinica_account_to_string;
        }

        $this->vdata['clinica_account_to_string'] = $this->clinica_account_to_string;
    }

    public function get_clinica_account_to_string()
    {
        if(!empty($this->clinica_account_to_string))
        {
            return $this->clinica_account_to_string;
        }
    
        $values = Clinica::where('account_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_convenio_account_to_string($convenio_account_to_string)
    {
        if(is_array($convenio_account_to_string))
        {
            $values = Account::where('id', 'in', $convenio_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->convenio_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->convenio_account_to_string = $convenio_account_to_string;
        }

        $this->vdata['convenio_account_to_string'] = $this->convenio_account_to_string;
    }

    public function get_convenio_account_to_string()
    {
        if(!empty($this->convenio_account_to_string))
        {
            return $this->convenio_account_to_string;
        }
    
        $values = Convenio::where('account_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_saas_plano_valor_to_string($saas_contrato_saas_plano_valor_to_string)
    {
        if(is_array($saas_contrato_saas_plano_valor_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_contrato_saas_plano_valor_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_contrato_saas_plano_valor_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_saas_plano_valor_to_string = $saas_contrato_saas_plano_valor_to_string;
        }

        $this->vdata['saas_contrato_saas_plano_valor_to_string'] = $this->saas_contrato_saas_plano_valor_to_string;
    }

    public function get_saas_contrato_saas_plano_valor_to_string()
    {
        if(!empty($this->saas_contrato_saas_plano_valor_to_string))
        {
            return $this->saas_contrato_saas_plano_valor_to_string;
        }
    
        $values = SaasContrato::where('account_id', '=', $this->id)->getIndexedArray('saas_plano_valor_id','{saas_plano_valor->nome}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_account_to_string($saas_contrato_account_to_string)
    {
        if(is_array($saas_contrato_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_contrato_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_contrato_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_account_to_string = $saas_contrato_account_to_string;
        }

        $this->vdata['saas_contrato_account_to_string'] = $this->saas_contrato_account_to_string;
    }

    public function get_saas_contrato_account_to_string()
    {
        if(!empty($this->saas_contrato_account_to_string))
        {
            return $this->saas_contrato_account_to_string;
        }
    
        $values = SaasContrato::where('account_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_saas_contrato_status_to_string($saas_contrato_saas_contrato_status_to_string)
    {
        if(is_array($saas_contrato_saas_contrato_status_to_string))
        {
            $values = SaasContratoStatus::where('id', 'in', $saas_contrato_saas_contrato_status_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_contrato_saas_contrato_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_saas_contrato_status_to_string = $saas_contrato_saas_contrato_status_to_string;
        }

        $this->vdata['saas_contrato_saas_contrato_status_to_string'] = $this->saas_contrato_saas_contrato_status_to_string;
    }

    public function get_saas_contrato_saas_contrato_status_to_string()
    {
        if(!empty($this->saas_contrato_saas_contrato_status_to_string))
        {
            return $this->saas_contrato_saas_contrato_status_to_string;
        }
    
        $values = SaasContrato::where('account_id', '=', $this->id)->getIndexedArray('saas_contrato_status_id','{saas_contrato_status->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_account_to_string($saas_pagamento_account_to_string)
    {
        if(is_array($saas_pagamento_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_pagamento_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_pagamento_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_account_to_string = $saas_pagamento_account_to_string;
        }

        $this->vdata['saas_pagamento_account_to_string'] = $this->saas_pagamento_account_to_string;
    }

    public function get_saas_pagamento_account_to_string()
    {
        if(!empty($this->saas_pagamento_account_to_string))
        {
            return $this->saas_pagamento_account_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_status_pagamento_to_string($saas_pagamento_saas_status_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_status_pagamento_to_string))
        {
            $values = SaasStatusPagamento::where('id', 'in', $saas_pagamento_saas_status_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_status_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_status_pagamento_to_string = $saas_pagamento_saas_status_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_status_pagamento_to_string'] = $this->saas_pagamento_saas_status_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_status_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_status_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_status_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('saas_status_pagamento_id','{saas_status_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_contrato_to_string($saas_pagamento_saas_contrato_to_string)
    {
        if(is_array($saas_pagamento_saas_contrato_to_string))
        {
            $values = SaasContrato::where('id', 'in', $saas_pagamento_saas_contrato_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_contrato_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_contrato_to_string = $saas_pagamento_saas_contrato_to_string;
        }

        $this->vdata['saas_pagamento_saas_contrato_to_string'] = $this->saas_pagamento_saas_contrato_to_string;
    }

    public function get_saas_pagamento_saas_contrato_to_string()
    {
        if(!empty($this->saas_pagamento_saas_contrato_to_string))
        {
            return $this->saas_pagamento_saas_contrato_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('saas_contrato_id','{saas_contrato->id}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_servico_to_string($saas_pagamento_saas_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_pagamento_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_servico_to_string = $saas_pagamento_saas_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_servico_to_string'] = $this->saas_pagamento_saas_servico_to_string;
    }

    public function get_saas_pagamento_saas_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_servico_to_string))
        {
            return $this->saas_pagamento_saas_servico_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_forma_pagamento_to_string($saas_pagamento_saas_forma_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_forma_pagamento_to_string))
        {
            $values = SaasFormaPagamento::where('id', 'in', $saas_pagamento_saas_forma_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_forma_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_forma_pagamento_to_string = $saas_pagamento_saas_forma_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_forma_pagamento_to_string'] = $this->saas_pagamento_saas_forma_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_forma_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_forma_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_forma_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('saas_forma_pagamento_id','{saas_forma_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_gateway_pagamento_to_string($saas_pagamento_saas_gateway_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_gateway_pagamento_to_string))
        {
            $values = SaasGatewayPagamento::where('id', 'in', $saas_pagamento_saas_gateway_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_gateway_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_gateway_pagamento_to_string = $saas_pagamento_saas_gateway_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_gateway_pagamento_to_string'] = $this->saas_pagamento_saas_gateway_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_gateway_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_gateway_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_gateway_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('saas_gateway_pagamento_id','{saas_gateway_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_nota_fiscal_servico_to_string($saas_pagamento_saas_nota_fiscal_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            $values = SaasNotaFiscalServico::where('id', 'in', $saas_pagamento_saas_nota_fiscal_servico_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = $saas_pagamento_saas_nota_fiscal_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_nota_fiscal_servico_to_string'] = $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
    }

    public function get_saas_pagamento_saas_nota_fiscal_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            return $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('saas_nota_fiscal_servico_id','{saas_nota_fiscal_servico->id}');
        return implode(', ', $values);
    }

    public function set_servico_account_to_string($servico_account_to_string)
    {
        if(is_array($servico_account_to_string))
        {
            $values = Account::where('id', 'in', $servico_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->servico_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->servico_account_to_string = $servico_account_to_string;
        }

        $this->vdata['servico_account_to_string'] = $this->servico_account_to_string;
    }

    public function get_servico_account_to_string()
    {
        if(!empty($this->servico_account_to_string))
        {
            return $this->servico_account_to_string;
        }
    
        $values = Servico::where('account_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_tipo_pagamento_account_to_string($tipo_pagamento_account_to_string)
    {
        if(is_array($tipo_pagamento_account_to_string))
        {
            $values = Account::where('id', 'in', $tipo_pagamento_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->tipo_pagamento_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->tipo_pagamento_account_to_string = $tipo_pagamento_account_to_string;
        }

        $this->vdata['tipo_pagamento_account_to_string'] = $this->tipo_pagamento_account_to_string;
    }

    public function get_tipo_pagamento_account_to_string()
    {
        if(!empty($this->tipo_pagamento_account_to_string))
        {
            return $this->tipo_pagamento_account_to_string;
        }
    
        $values = TipoPagamento::where('account_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function get_contrato()
    {
        $configs = SaasConfiguracaoService::getConfiguracoes();
    
        $criteria = new TCriteria;
        $criteria->add(new TFilter('account_id', '=', $this->id));
        $criteria->add(new TFilter('saas_contrato_status_id', '=', SaasContratoStatus::ATIVO));
        $criteria->add(new TFilter('saas_plano_valor_id', '!=', $configs->saas_plano_valor_trial_id));
        $criteria->add(new TFilter('data_final', '>=', date('Y-m-d')));
        $criteria->setProperty('order', 'data_final desc');

        $contrato = new TRepository('SaasContrato');
        $contrato->setCriteria($criteria);
        $contrato = $contrato->first();
    
        if(!$contrato)
        {
            $criteria = new TCriteria;
            $criteria->add(new TFilter('account_id', '=', $this->id));
            $criteria->add(new TFilter('saas_contrato_status_id', '=', SaasContratoStatus::ATIVO));
            $criteria->add(new TFilter('saas_plano_valor_id', '=', $configs->saas_plano_valor_trial_id));
            $criteria->add(new TFilter('data_final', '>=', date('Y-m-d')));
            $criteria->setProperty('order', 'data_final desc');

            $contrato = new TRepository('SaasContrato');
            $contrato->setCriteria($criteria);
            $contrato = $contrato->first();
        }
    
        if(!$contrato)
        {
            $criteria = new TCriteria;
            $criteria->add(new TFilter('account_id', '=', $this->id));
            $criteria->add(new TFilter('saas_contrato_status_id', '!=', SaasContratoStatus::AGUARDANDO_PAGAMENTO));
            $criteria->setProperty('order', 'data_final desc');

            $contrato = new TRepository('SaasContrato');
            $contrato->setCriteria($criteria);
            $contrato = $contrato->first();
        }
    
        return $contrato;
    }
                                                        
}

