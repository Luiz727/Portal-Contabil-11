<?php

class SaasPlano extends TRecord
{
    const TABLENAME  = 'saas_plano';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SaasServico $saas_servico;

    private $ids_groups;
    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('saas_servico_id');
        parent::addAttribute('nome');
        parent::addAttribute('descricao');
        parent::addAttribute('ativo');
        parent::addAttribute('limite_usuarios');
        parent::addAttribute('limite_unidades');
        parent::addAttribute('discriminacao');
        parent::addAttribute('ordem');
    
    }

    /**
     * Method set_saas_servico
     * Sample of usage: $var->saas_servico = $object;
     * @param $object Instance of SaasServico
     */
    public function set_saas_servico(SaasServico $object)
    {
        $this->saas_servico = $object;
        $this->saas_servico_id = $object->id;
    }

    /**
     * Method get_saas_servico
     * Sample of usage: $var->saas_servico->attribute;
     * @returns SaasServico instance
     */
    public function get_saas_servico()
    {
    
        // loads the associated object
        if (empty($this->saas_servico))
            $this->saas_servico = new SaasServico($this->saas_servico_id);
    
        // returns the associated object
        return $this->saas_servico;
    }

    /**
     * Method getSaasPlanoGrupos
     */
    public function getSaasPlanoGrupos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_plano_id', '=', $this->id));
        return SaasPlanoGrupo::getObjects( $criteria );
    }
    /**
     * Method getSaasPlanoValors
     */
    public function getSaasPlanoValors()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_plano_id', '=', $this->id));
        return SaasPlanoValor::getObjects( $criteria );
    }

    public function set_saas_plano_grupo_saas_plano_to_string($saas_plano_grupo_saas_plano_to_string)
    {
        if(is_array($saas_plano_grupo_saas_plano_to_string))
        {
            $values = SaasPlano::where('id', 'in', $saas_plano_grupo_saas_plano_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_plano_grupo_saas_plano_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_plano_grupo_saas_plano_to_string = $saas_plano_grupo_saas_plano_to_string;
        }

        $this->vdata['saas_plano_grupo_saas_plano_to_string'] = $this->saas_plano_grupo_saas_plano_to_string;
    }

    public function get_saas_plano_grupo_saas_plano_to_string()
    {
        if(!empty($this->saas_plano_grupo_saas_plano_to_string))
        {
            return $this->saas_plano_grupo_saas_plano_to_string;
        }
    
        $values = SaasPlanoGrupo::where('saas_plano_id', '=', $this->id)->getIndexedArray('saas_plano_id','{saas_plano->nome}');
        return implode(', ', $values);
    }

    public function set_saas_plano_grupo_system_group_to_string($saas_plano_grupo_system_group_to_string)
    {
        if(is_array($saas_plano_grupo_system_group_to_string))
        {
            $values = SystemGroup::where('id', 'in', $saas_plano_grupo_system_group_to_string)->getIndexedArray('name', 'name');
            $this->saas_plano_grupo_system_group_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_plano_grupo_system_group_to_string = $saas_plano_grupo_system_group_to_string;
        }

        $this->vdata['saas_plano_grupo_system_group_to_string'] = $this->saas_plano_grupo_system_group_to_string;
    }

    public function get_saas_plano_grupo_system_group_to_string()
    {
        if(!empty($this->saas_plano_grupo_system_group_to_string))
        {
            return $this->saas_plano_grupo_system_group_to_string;
        }
    
        $values = SaasPlanoGrupo::where('saas_plano_id', '=', $this->id)->getIndexedArray('system_group_id','{system_group->name}');
        return implode(', ', $values);
    }

    public function set_saas_plano_valor_saas_plano_to_string($saas_plano_valor_saas_plano_to_string)
    {
        if(is_array($saas_plano_valor_saas_plano_to_string))
        {
            $values = SaasPlano::where('id', 'in', $saas_plano_valor_saas_plano_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_plano_valor_saas_plano_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_plano_valor_saas_plano_to_string = $saas_plano_valor_saas_plano_to_string;
        }

        $this->vdata['saas_plano_valor_saas_plano_to_string'] = $this->saas_plano_valor_saas_plano_to_string;
    }

    public function get_saas_plano_valor_saas_plano_to_string()
    {
        if(!empty($this->saas_plano_valor_saas_plano_to_string))
        {
            return $this->saas_plano_valor_saas_plano_to_string;
        }
    
        $values = SaasPlanoValor::where('saas_plano_id', '=', $this->id)->getIndexedArray('saas_plano_id','{saas_plano->nome}');
        return implode(', ', $values);
    }

    public function get_ids_groups()
    {
        if (empty($this->ids_groups))
        {
            $criteria = new TCriteria;
            $criteria->add(new TFilter('saas_plano_id', '=', $this->id));
            $plano_grupos = SaasPlanoGrupo::getObjects( $criteria );
    
            $this->ids_groups = array_column($plano_grupos, 'system_group_id');
        }
    
        return $this->ids_groups;
    }

    public function get_option_html()
    {
        $card = new TElement('div');
        $card->class = 'option-planos';
        $card->add(TElement::tag('div', $this->nome, ['class' => 'nome']));
        $card->add(TElement::tag('div', $this->descricao, ['class' => 'descricao']));
        $card->add(TElement::tag('div', 'Valores', ['class' => 'valores']));
        $valores = $this->getSaasPlanoValors();

        foreach($valores as $valor)
        {
            $card->add(TElement::tag('div', [TElement::tag('div', $valor->nome), TElement::tag('div', $valor->valor_f)], ['class' => 'valor']));
        }

        return $card;
    }
    
}

