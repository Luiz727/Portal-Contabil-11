<?php

class SaasTemplateEmail extends TRecord
{
    const TABLENAME  = 'saas_template_email';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    const NOVA_CONTA = '1';
    const NOTA_FISCAL_ENVIADA = '2';
    const AVISO_VENCIMENTO = '3';
    const RESETAR_SENHA = '4';
    const PLANO_ATIVADO = '5';

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('descricao');
        parent::addAttribute('titulo');
        parent::addAttribute('conteudo');
    
    }

}

