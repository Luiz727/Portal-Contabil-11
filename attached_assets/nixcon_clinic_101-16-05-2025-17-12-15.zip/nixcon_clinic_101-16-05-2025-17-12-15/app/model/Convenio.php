<?php

class Convenio extends TRecord
{
    const TABLENAME  = 'convenio';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Account $account;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByAccount');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('account_id');
        parent::addAttribute('nome');
    
    }

    /**
     * Method set_account
     * Sample of usage: $var->account = $object;
     * @param $object Instance of Account
     */
    public function set_account(Account $object)
    {
        $this->account = $object;
        $this->account_id = $object->id;
    }

    /**
     * Method get_account
     * Sample of usage: $var->account->attribute;
     * @returns Account instance
     */
    public function get_account()
    {
    
        // loads the associated object
        if (empty($this->account))
            $this->account = new Account($this->account_id);
    
        // returns the associated object
        return $this->account;
    }

    /**
     * Method getAgendamentoProcedimentos
     */
    public function getAgendamentoProcedimentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('convenio_id', '=', $this->id));
        return AgendamentoProcedimento::getObjects( $criteria );
    }
    /**
     * Method getAtendimentoProcedimentos
     */
    public function getAtendimentoProcedimentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('convenio_id', '=', $this->id));
        return AtendimentoProcedimento::getObjects( $criteria );
    }
    /**
     * Method getClinicaConvenios
     */
    public function getClinicaConvenios()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('convenio_id', '=', $this->id));
        return ClinicaConvenio::getObjects( $criteria );
    }
    /**
     * Method getProcedimentoPrecos
     */
    public function getProcedimentoPrecos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('convenio_id', '=', $this->id));
        return ProcedimentoPreco::getObjects( $criteria );
    }

    public function set_agendamento_procedimento_agendamento_to_string($agendamento_procedimento_agendamento_to_string)
    {
        if(is_array($agendamento_procedimento_agendamento_to_string))
        {
            $values = Agendamento::where('id', 'in', $agendamento_procedimento_agendamento_to_string)->getIndexedArray('id', 'id');
            $this->agendamento_procedimento_agendamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_procedimento_agendamento_to_string = $agendamento_procedimento_agendamento_to_string;
        }

        $this->vdata['agendamento_procedimento_agendamento_to_string'] = $this->agendamento_procedimento_agendamento_to_string;
    }

    public function get_agendamento_procedimento_agendamento_to_string()
    {
        if(!empty($this->agendamento_procedimento_agendamento_to_string))
        {
            return $this->agendamento_procedimento_agendamento_to_string;
        }
    
        $values = AgendamentoProcedimento::where('convenio_id', '=', $this->id)->getIndexedArray('agendamento_id','{agendamento->id}');
        return implode(', ', $values);
    }

    public function set_agendamento_procedimento_procedimento_to_string($agendamento_procedimento_procedimento_to_string)
    {
        if(is_array($agendamento_procedimento_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $agendamento_procedimento_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_procedimento_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_procedimento_procedimento_to_string = $agendamento_procedimento_procedimento_to_string;
        }

        $this->vdata['agendamento_procedimento_procedimento_to_string'] = $this->agendamento_procedimento_procedimento_to_string;
    }

    public function get_agendamento_procedimento_procedimento_to_string()
    {
        if(!empty($this->agendamento_procedimento_procedimento_to_string))
        {
            return $this->agendamento_procedimento_procedimento_to_string;
        }
    
        $values = AgendamentoProcedimento::where('convenio_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_procedimento_convenio_to_string($agendamento_procedimento_convenio_to_string)
    {
        if(is_array($agendamento_procedimento_convenio_to_string))
        {
            $values = Convenio::where('id', 'in', $agendamento_procedimento_convenio_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_procedimento_convenio_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_procedimento_convenio_to_string = $agendamento_procedimento_convenio_to_string;
        }

        $this->vdata['agendamento_procedimento_convenio_to_string'] = $this->agendamento_procedimento_convenio_to_string;
    }

    public function get_agendamento_procedimento_convenio_to_string()
    {
        if(!empty($this->agendamento_procedimento_convenio_to_string))
        {
            return $this->agendamento_procedimento_convenio_to_string;
        }
    
        $values = AgendamentoProcedimento::where('convenio_id', '=', $this->id)->getIndexedArray('convenio_id','{convenio->nome}');
        return implode(', ', $values);
    }

    public function set_atendimento_procedimento_convenio_to_string($atendimento_procedimento_convenio_to_string)
    {
        if(is_array($atendimento_procedimento_convenio_to_string))
        {
            $values = Convenio::where('id', 'in', $atendimento_procedimento_convenio_to_string)->getIndexedArray('nome', 'nome');
            $this->atendimento_procedimento_convenio_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_procedimento_convenio_to_string = $atendimento_procedimento_convenio_to_string;
        }

        $this->vdata['atendimento_procedimento_convenio_to_string'] = $this->atendimento_procedimento_convenio_to_string;
    }

    public function get_atendimento_procedimento_convenio_to_string()
    {
        if(!empty($this->atendimento_procedimento_convenio_to_string))
        {
            return $this->atendimento_procedimento_convenio_to_string;
        }
    
        $values = AtendimentoProcedimento::where('convenio_id', '=', $this->id)->getIndexedArray('convenio_id','{convenio->nome}');
        return implode(', ', $values);
    }

    public function set_atendimento_procedimento_atendimento_to_string($atendimento_procedimento_atendimento_to_string)
    {
        if(is_array($atendimento_procedimento_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $atendimento_procedimento_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->atendimento_procedimento_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_procedimento_atendimento_to_string = $atendimento_procedimento_atendimento_to_string;
        }

        $this->vdata['atendimento_procedimento_atendimento_to_string'] = $this->atendimento_procedimento_atendimento_to_string;
    }

    public function get_atendimento_procedimento_atendimento_to_string()
    {
        if(!empty($this->atendimento_procedimento_atendimento_to_string))
        {
            return $this->atendimento_procedimento_atendimento_to_string;
        }
    
        $values = AtendimentoProcedimento::where('convenio_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_atendimento_procedimento_procedimento_to_string($atendimento_procedimento_procedimento_to_string)
    {
        if(is_array($atendimento_procedimento_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $atendimento_procedimento_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->atendimento_procedimento_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_procedimento_procedimento_to_string = $atendimento_procedimento_procedimento_to_string;
        }

        $this->vdata['atendimento_procedimento_procedimento_to_string'] = $this->atendimento_procedimento_procedimento_to_string;
    }

    public function get_atendimento_procedimento_procedimento_to_string()
    {
        if(!empty($this->atendimento_procedimento_procedimento_to_string))
        {
            return $this->atendimento_procedimento_procedimento_to_string;
        }
    
        $values = AtendimentoProcedimento::where('convenio_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_clinica_convenio_convenio_to_string($clinica_convenio_convenio_to_string)
    {
        if(is_array($clinica_convenio_convenio_to_string))
        {
            $values = Convenio::where('id', 'in', $clinica_convenio_convenio_to_string)->getIndexedArray('nome', 'nome');
            $this->clinica_convenio_convenio_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_convenio_convenio_to_string = $clinica_convenio_convenio_to_string;
        }

        $this->vdata['clinica_convenio_convenio_to_string'] = $this->clinica_convenio_convenio_to_string;
    }

    public function get_clinica_convenio_convenio_to_string()
    {
        if(!empty($this->clinica_convenio_convenio_to_string))
        {
            return $this->clinica_convenio_convenio_to_string;
        }
    
        $values = ClinicaConvenio::where('convenio_id', '=', $this->id)->getIndexedArray('convenio_id','{convenio->nome}');
        return implode(', ', $values);
    }

    public function set_clinica_convenio_clinica_to_string($clinica_convenio_clinica_to_string)
    {
        if(is_array($clinica_convenio_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $clinica_convenio_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->clinica_convenio_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_convenio_clinica_to_string = $clinica_convenio_clinica_to_string;
        }

        $this->vdata['clinica_convenio_clinica_to_string'] = $this->clinica_convenio_clinica_to_string;
    }

    public function get_clinica_convenio_clinica_to_string()
    {
        if(!empty($this->clinica_convenio_clinica_to_string))
        {
            return $this->clinica_convenio_clinica_to_string;
        }
    
        $values = ClinicaConvenio::where('convenio_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_procedimento_preco_procedimento_to_string($procedimento_preco_procedimento_to_string)
    {
        if(is_array($procedimento_preco_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $procedimento_preco_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->procedimento_preco_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->procedimento_preco_procedimento_to_string = $procedimento_preco_procedimento_to_string;
        }

        $this->vdata['procedimento_preco_procedimento_to_string'] = $this->procedimento_preco_procedimento_to_string;
    }

    public function get_procedimento_preco_procedimento_to_string()
    {
        if(!empty($this->procedimento_preco_procedimento_to_string))
        {
            return $this->procedimento_preco_procedimento_to_string;
        }
    
        $values = ProcedimentoPreco::where('convenio_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_procedimento_preco_convenio_to_string($procedimento_preco_convenio_to_string)
    {
        if(is_array($procedimento_preco_convenio_to_string))
        {
            $values = Convenio::where('id', 'in', $procedimento_preco_convenio_to_string)->getIndexedArray('nome', 'nome');
            $this->procedimento_preco_convenio_to_string = implode(', ', $values);
        }
        else
        {
            $this->procedimento_preco_convenio_to_string = $procedimento_preco_convenio_to_string;
        }

        $this->vdata['procedimento_preco_convenio_to_string'] = $this->procedimento_preco_convenio_to_string;
    }

    public function get_procedimento_preco_convenio_to_string()
    {
        if(!empty($this->procedimento_preco_convenio_to_string))
        {
            return $this->procedimento_preco_convenio_to_string;
        }
    
        $values = ProcedimentoPreco::where('convenio_id', '=', $this->id)->getIndexedArray('convenio_id','{convenio->nome}');
        return implode(', ', $values);
    }

}

