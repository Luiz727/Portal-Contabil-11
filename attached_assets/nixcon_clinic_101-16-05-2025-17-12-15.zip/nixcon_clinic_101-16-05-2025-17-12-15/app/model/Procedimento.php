<?php

class Procedimento extends TRecord
{
    const TABLENAME  = 'procedimento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'max'; // {max, serial}

    private Clinica $clinica;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByUnit');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('clinica_id');
        parent::addAttribute('nome');
        parent::addAttribute('cor');
        parent::addAttribute('duracao');
        parent::addAttribute('codigo_referencia');
        parent::addAttribute('ativo');
    
    }

    /**
     * Method set_clinica
     * Sample of usage: $var->clinica = $object;
     * @param $object Instance of Clinica
     */
    public function set_clinica(Clinica $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns Clinica instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new Clinica($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }

    /**
     * Method getAgendas
     */
    public function getAgendas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('procedimento_id', '=', $this->id));
        return Agenda::getObjects( $criteria );
    }
    /**
     * Method getAgendamentoProcedimentos
     */
    public function getAgendamentoProcedimentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('procedimento_id', '=', $this->id));
        return AgendamentoProcedimento::getObjects( $criteria );
    }
    /**
     * Method getAtendimentoProcedimentos
     */
    public function getAtendimentoProcedimentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('procedimento_id', '=', $this->id));
        return AtendimentoProcedimento::getObjects( $criteria );
    }
    /**
     * Method getDocumentos
     */
    public function getDocumentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('procedimento_id', '=', $this->id));
        return Documento::getObjects( $criteria );
    }
    /**
     * Method getProcedimentoMaterials
     */
    public function getProcedimentoMaterials()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('procedimento_id', '=', $this->id));
        return ProcedimentoMaterial::getObjects( $criteria );
    }
    /**
     * Method getProcedimentoPrecos
     */
    public function getProcedimentoPrecos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('procedimento_id', '=', $this->id));
        return ProcedimentoPreco::getObjects( $criteria );
    }

    public function set_agenda_clinica_to_string($agenda_clinica_to_string)
    {
        if(is_array($agenda_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $agenda_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_clinica_to_string = $agenda_clinica_to_string;
        }

        $this->vdata['agenda_clinica_to_string'] = $this->agenda_clinica_to_string;
    }

    public function get_agenda_clinica_to_string()
    {
        if(!empty($this->agenda_clinica_to_string))
        {
            return $this->agenda_clinica_to_string;
        }
    
        $values = Agenda::where('procedimento_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_agenda_profissional_to_string($agenda_profissional_to_string)
    {
        if(is_array($agenda_profissional_to_string))
        {
            $values = Pessoa::where('id', 'in', $agenda_profissional_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_profissional_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_profissional_to_string = $agenda_profissional_to_string;
        }

        $this->vdata['agenda_profissional_to_string'] = $this->agenda_profissional_to_string;
    }

    public function get_agenda_profissional_to_string()
    {
        if(!empty($this->agenda_profissional_to_string))
        {
            return $this->agenda_profissional_to_string;
        }
    
        $values = Agenda::where('procedimento_id', '=', $this->id)->getIndexedArray('profissional_id','{profissional->nome}');
        return implode(', ', $values);
    }

    public function set_agenda_procedimento_to_string($agenda_procedimento_to_string)
    {
        if(is_array($agenda_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $agenda_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_procedimento_to_string = $agenda_procedimento_to_string;
        }

        $this->vdata['agenda_procedimento_to_string'] = $this->agenda_procedimento_to_string;
    }

    public function get_agenda_procedimento_to_string()
    {
        if(!empty($this->agenda_procedimento_to_string))
        {
            return $this->agenda_procedimento_to_string;
        }
    
        $values = Agenda::where('procedimento_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_procedimento_agendamento_to_string($agendamento_procedimento_agendamento_to_string)
    {
        if(is_array($agendamento_procedimento_agendamento_to_string))
        {
            $values = Agendamento::where('id', 'in', $agendamento_procedimento_agendamento_to_string)->getIndexedArray('id', 'id');
            $this->agendamento_procedimento_agendamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_procedimento_agendamento_to_string = $agendamento_procedimento_agendamento_to_string;
        }

        $this->vdata['agendamento_procedimento_agendamento_to_string'] = $this->agendamento_procedimento_agendamento_to_string;
    }

    public function get_agendamento_procedimento_agendamento_to_string()
    {
        if(!empty($this->agendamento_procedimento_agendamento_to_string))
        {
            return $this->agendamento_procedimento_agendamento_to_string;
        }
    
        $values = AgendamentoProcedimento::where('procedimento_id', '=', $this->id)->getIndexedArray('agendamento_id','{agendamento->id}');
        return implode(', ', $values);
    }

    public function set_agendamento_procedimento_procedimento_to_string($agendamento_procedimento_procedimento_to_string)
    {
        if(is_array($agendamento_procedimento_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $agendamento_procedimento_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_procedimento_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_procedimento_procedimento_to_string = $agendamento_procedimento_procedimento_to_string;
        }

        $this->vdata['agendamento_procedimento_procedimento_to_string'] = $this->agendamento_procedimento_procedimento_to_string;
    }

    public function get_agendamento_procedimento_procedimento_to_string()
    {
        if(!empty($this->agendamento_procedimento_procedimento_to_string))
        {
            return $this->agendamento_procedimento_procedimento_to_string;
        }
    
        $values = AgendamentoProcedimento::where('procedimento_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_procedimento_convenio_to_string($agendamento_procedimento_convenio_to_string)
    {
        if(is_array($agendamento_procedimento_convenio_to_string))
        {
            $values = Convenio::where('id', 'in', $agendamento_procedimento_convenio_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_procedimento_convenio_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_procedimento_convenio_to_string = $agendamento_procedimento_convenio_to_string;
        }

        $this->vdata['agendamento_procedimento_convenio_to_string'] = $this->agendamento_procedimento_convenio_to_string;
    }

    public function get_agendamento_procedimento_convenio_to_string()
    {
        if(!empty($this->agendamento_procedimento_convenio_to_string))
        {
            return $this->agendamento_procedimento_convenio_to_string;
        }
    
        $values = AgendamentoProcedimento::where('procedimento_id', '=', $this->id)->getIndexedArray('convenio_id','{convenio->nome}');
        return implode(', ', $values);
    }

    public function set_atendimento_procedimento_convenio_to_string($atendimento_procedimento_convenio_to_string)
    {
        if(is_array($atendimento_procedimento_convenio_to_string))
        {
            $values = Convenio::where('id', 'in', $atendimento_procedimento_convenio_to_string)->getIndexedArray('nome', 'nome');
            $this->atendimento_procedimento_convenio_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_procedimento_convenio_to_string = $atendimento_procedimento_convenio_to_string;
        }

        $this->vdata['atendimento_procedimento_convenio_to_string'] = $this->atendimento_procedimento_convenio_to_string;
    }

    public function get_atendimento_procedimento_convenio_to_string()
    {
        if(!empty($this->atendimento_procedimento_convenio_to_string))
        {
            return $this->atendimento_procedimento_convenio_to_string;
        }
    
        $values = AtendimentoProcedimento::where('procedimento_id', '=', $this->id)->getIndexedArray('convenio_id','{convenio->nome}');
        return implode(', ', $values);
    }

    public function set_atendimento_procedimento_atendimento_to_string($atendimento_procedimento_atendimento_to_string)
    {
        if(is_array($atendimento_procedimento_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $atendimento_procedimento_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->atendimento_procedimento_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_procedimento_atendimento_to_string = $atendimento_procedimento_atendimento_to_string;
        }

        $this->vdata['atendimento_procedimento_atendimento_to_string'] = $this->atendimento_procedimento_atendimento_to_string;
    }

    public function get_atendimento_procedimento_atendimento_to_string()
    {
        if(!empty($this->atendimento_procedimento_atendimento_to_string))
        {
            return $this->atendimento_procedimento_atendimento_to_string;
        }
    
        $values = AtendimentoProcedimento::where('procedimento_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_atendimento_procedimento_procedimento_to_string($atendimento_procedimento_procedimento_to_string)
    {
        if(is_array($atendimento_procedimento_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $atendimento_procedimento_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->atendimento_procedimento_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimento_procedimento_procedimento_to_string = $atendimento_procedimento_procedimento_to_string;
        }

        $this->vdata['atendimento_procedimento_procedimento_to_string'] = $this->atendimento_procedimento_procedimento_to_string;
    }

    public function get_atendimento_procedimento_procedimento_to_string()
    {
        if(!empty($this->atendimento_procedimento_procedimento_to_string))
        {
            return $this->atendimento_procedimento_procedimento_to_string;
        }
    
        $values = AtendimentoProcedimento::where('procedimento_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_documento_atendimento_to_string($documento_atendimento_to_string)
    {
        if(is_array($documento_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $documento_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->documento_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_atendimento_to_string = $documento_atendimento_to_string;
        }

        $this->vdata['documento_atendimento_to_string'] = $this->documento_atendimento_to_string;
    }

    public function get_documento_atendimento_to_string()
    {
        if(!empty($this->documento_atendimento_to_string))
        {
            return $this->documento_atendimento_to_string;
        }
    
        $values = Documento::where('procedimento_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_documento_tipo_documento_to_string($documento_tipo_documento_to_string)
    {
        if(is_array($documento_tipo_documento_to_string))
        {
            $values = TipoDocumento::where('id', 'in', $documento_tipo_documento_to_string)->getIndexedArray('nome', 'nome');
            $this->documento_tipo_documento_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_tipo_documento_to_string = $documento_tipo_documento_to_string;
        }

        $this->vdata['documento_tipo_documento_to_string'] = $this->documento_tipo_documento_to_string;
    }

    public function get_documento_tipo_documento_to_string()
    {
        if(!empty($this->documento_tipo_documento_to_string))
        {
            return $this->documento_tipo_documento_to_string;
        }
    
        $values = Documento::where('procedimento_id', '=', $this->id)->getIndexedArray('tipo_documento_id','{tipo_documento->nome}');
        return implode(', ', $values);
    }

    public function set_documento_clinica_to_string($documento_clinica_to_string)
    {
        if(is_array($documento_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $documento_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->documento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_clinica_to_string = $documento_clinica_to_string;
        }

        $this->vdata['documento_clinica_to_string'] = $this->documento_clinica_to_string;
    }

    public function get_documento_clinica_to_string()
    {
        if(!empty($this->documento_clinica_to_string))
        {
            return $this->documento_clinica_to_string;
        }
    
        $values = Documento::where('procedimento_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_documento_procedimento_to_string($documento_procedimento_to_string)
    {
        if(is_array($documento_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $documento_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->documento_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_procedimento_to_string = $documento_procedimento_to_string;
        }

        $this->vdata['documento_procedimento_to_string'] = $this->documento_procedimento_to_string;
    }

    public function get_documento_procedimento_to_string()
    {
        if(!empty($this->documento_procedimento_to_string))
        {
            return $this->documento_procedimento_to_string;
        }
    
        $values = Documento::where('procedimento_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_procedimento_material_procedimento_to_string($procedimento_material_procedimento_to_string)
    {
        if(is_array($procedimento_material_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $procedimento_material_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->procedimento_material_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->procedimento_material_procedimento_to_string = $procedimento_material_procedimento_to_string;
        }

        $this->vdata['procedimento_material_procedimento_to_string'] = $this->procedimento_material_procedimento_to_string;
    }

    public function get_procedimento_material_procedimento_to_string()
    {
        if(!empty($this->procedimento_material_procedimento_to_string))
        {
            return $this->procedimento_material_procedimento_to_string;
        }
    
        $values = ProcedimentoMaterial::where('procedimento_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_procedimento_material_material_to_string($procedimento_material_material_to_string)
    {
        if(is_array($procedimento_material_material_to_string))
        {
            $values = Material::where('id', 'in', $procedimento_material_material_to_string)->getIndexedArray('nome', 'nome');
            $this->procedimento_material_material_to_string = implode(', ', $values);
        }
        else
        {
            $this->procedimento_material_material_to_string = $procedimento_material_material_to_string;
        }

        $this->vdata['procedimento_material_material_to_string'] = $this->procedimento_material_material_to_string;
    }

    public function get_procedimento_material_material_to_string()
    {
        if(!empty($this->procedimento_material_material_to_string))
        {
            return $this->procedimento_material_material_to_string;
        }
    
        $values = ProcedimentoMaterial::where('procedimento_id', '=', $this->id)->getIndexedArray('material_id','{material->nome}');
        return implode(', ', $values);
    }

    public function set_procedimento_preco_procedimento_to_string($procedimento_preco_procedimento_to_string)
    {
        if(is_array($procedimento_preco_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $procedimento_preco_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->procedimento_preco_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->procedimento_preco_procedimento_to_string = $procedimento_preco_procedimento_to_string;
        }

        $this->vdata['procedimento_preco_procedimento_to_string'] = $this->procedimento_preco_procedimento_to_string;
    }

    public function get_procedimento_preco_procedimento_to_string()
    {
        if(!empty($this->procedimento_preco_procedimento_to_string))
        {
            return $this->procedimento_preco_procedimento_to_string;
        }
    
        $values = ProcedimentoPreco::where('procedimento_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_procedimento_preco_convenio_to_string($procedimento_preco_convenio_to_string)
    {
        if(is_array($procedimento_preco_convenio_to_string))
        {
            $values = Convenio::where('id', 'in', $procedimento_preco_convenio_to_string)->getIndexedArray('nome', 'nome');
            $this->procedimento_preco_convenio_to_string = implode(', ', $values);
        }
        else
        {
            $this->procedimento_preco_convenio_to_string = $procedimento_preco_convenio_to_string;
        }

        $this->vdata['procedimento_preco_convenio_to_string'] = $this->procedimento_preco_convenio_to_string;
    }

    public function get_procedimento_preco_convenio_to_string()
    {
        if(!empty($this->procedimento_preco_convenio_to_string))
        {
            return $this->procedimento_preco_convenio_to_string;
        }
    
        $values = ProcedimentoPreco::where('procedimento_id', '=', $this->id)->getIndexedArray('convenio_id','{convenio->nome}');
        return implode(', ', $values);
    }

    public function get_count_materiais()
    {
        return count($this->getProcedimentoMaterials());
    }
  
    
}

