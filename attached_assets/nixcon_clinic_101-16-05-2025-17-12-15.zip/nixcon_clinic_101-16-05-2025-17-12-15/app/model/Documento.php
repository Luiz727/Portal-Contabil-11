<?php

class Documento extends TRecord
{
    const TABLENAME  = 'documento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private TipoDocumento $tipo_documento;
    private Atendimento $atendimento;
    private Procedimento $procedimento;
    private Clinica $clinica;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByUnit');
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
            
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('atendimento_id');
        parent::addAttribute('tipo_documento_id');
        parent::addAttribute('clinica_id');
        parent::addAttribute('procedimento_id');
        parent::addAttribute('texto');
        parent::addAttribute('dt_preenchimento');
        parent::addAttribute('autenticador');
        parent::addAttribute('dt_validade');
        parent::addAttribute('medico_assistente');
    
    }

    /**
     * Method set_tipo_documento
     * Sample of usage: $var->tipo_documento = $object;
     * @param $object Instance of TipoDocumento
     */
    public function set_tipo_documento(TipoDocumento $object)
    {
        $this->tipo_documento = $object;
        $this->tipo_documento_id = $object->id;
    }

    /**
     * Method get_tipo_documento
     * Sample of usage: $var->tipo_documento->attribute;
     * @returns TipoDocumento instance
     */
    public function get_tipo_documento()
    {
    
        // loads the associated object
        if (empty($this->tipo_documento))
            $this->tipo_documento = new TipoDocumento($this->tipo_documento_id);
    
        // returns the associated object
        return $this->tipo_documento;
    }
    /**
     * Method set_atendimento
     * Sample of usage: $var->atendimento = $object;
     * @param $object Instance of Atendimento
     */
    public function set_atendimento(Atendimento $object)
    {
        $this->atendimento = $object;
        $this->atendimento_id = $object->id;
    }

    /**
     * Method get_atendimento
     * Sample of usage: $var->atendimento->attribute;
     * @returns Atendimento instance
     */
    public function get_atendimento()
    {
    
        // loads the associated object
        if (empty($this->atendimento))
            $this->atendimento = new Atendimento($this->atendimento_id);
    
        // returns the associated object
        return $this->atendimento;
    }
    /**
     * Method set_procedimento
     * Sample of usage: $var->procedimento = $object;
     * @param $object Instance of Procedimento
     */
    public function set_procedimento(Procedimento $object)
    {
        $this->procedimento = $object;
        $this->procedimento_id = $object->id;
    }

    /**
     * Method get_procedimento
     * Sample of usage: $var->procedimento->attribute;
     * @returns Procedimento instance
     */
    public function get_procedimento()
    {
    
        // loads the associated object
        if (empty($this->procedimento))
            $this->procedimento = new Procedimento($this->procedimento_id);
    
        // returns the associated object
        return $this->procedimento;
    }
    /**
     * Method set_clinica
     * Sample of usage: $var->clinica = $object;
     * @param $object Instance of Clinica
     */
    public function set_clinica(Clinica $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns Clinica instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new Clinica($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }

    public function get_texto_formatado()
    {
        $variaveis = TipoDocumento::VARIAVEIS;
    
        $text = $this->texto;
        $atendimento = $this->get_atendimento();
    
        foreach($variaveis as $chave => $atendimento_variavel)
        {
            $text = str_replace($chave, $atendimento->render("{{$atendimento_variavel}}"), $text);
        }
    
        return $text;
    }

    public function get_preenchimento()
    {
        return date('d/m/Y H:i', strtotime($this->dt_preenchimento));
    }
            
}

