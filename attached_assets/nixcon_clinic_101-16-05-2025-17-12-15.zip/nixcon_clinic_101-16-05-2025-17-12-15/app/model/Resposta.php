<?php

class Resposta extends TRecord
{
    const TABLENAME  = 'resposta';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private RespostaFormulario $resposta_formulario;
    private Questao $questao;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('resposta_formulario_id');
        parent::addAttribute('questao_id');
        parent::addAttribute('resposta');
    
    }

    /**
     * Method set_resposta_formulario
     * Sample of usage: $var->resposta_formulario = $object;
     * @param $object Instance of RespostaFormulario
     */
    public function set_resposta_formulario(RespostaFormulario $object)
    {
        $this->resposta_formulario = $object;
        $this->resposta_formulario_id = $object->id;
    }

    /**
     * Method get_resposta_formulario
     * Sample of usage: $var->resposta_formulario->attribute;
     * @returns RespostaFormulario instance
     */
    public function get_resposta_formulario()
    {
    
        // loads the associated object
        if (empty($this->resposta_formulario))
            $this->resposta_formulario = new RespostaFormulario($this->resposta_formulario_id);
    
        // returns the associated object
        return $this->resposta_formulario;
    }
    /**
     * Method set_questao
     * Sample of usage: $var->questao = $object;
     * @param $object Instance of Questao
     */
    public function set_questao(Questao $object)
    {
        $this->questao = $object;
        $this->questao_id = $object->id;
    }

    /**
     * Method get_questao
     * Sample of usage: $var->questao->attribute;
     * @returns Questao instance
     */
    public function get_questao()
    {
    
        // loads the associated object
        if (empty($this->questao))
            $this->questao = new Questao($this->questao_id);
    
        // returns the associated object
        return $this->questao;
    }

}

