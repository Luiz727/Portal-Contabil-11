<?php

class TipoConta extends TRecord
{
    const TABLENAME  = 'tipo_conta';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    const RECEBER = '1';
    const PAGAR = '2';

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('nome');
            
    }

    /**
     * Method getCategoriaContas
     */
    public function getCategoriaContas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('tipo_conta_id', '=', $this->id));
        return CategoriaConta::getObjects( $criteria );
    }
    /**
     * Method getContas
     */
    public function getContas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('tipo_conta_id', '=', $this->id));
        return Conta::getObjects( $criteria );
    }

    public function set_categoria_conta_tipo_conta_to_string($categoria_conta_tipo_conta_to_string)
    {
        if(is_array($categoria_conta_tipo_conta_to_string))
        {
            $values = TipoConta::where('id', 'in', $categoria_conta_tipo_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->categoria_conta_tipo_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->categoria_conta_tipo_conta_to_string = $categoria_conta_tipo_conta_to_string;
        }

        $this->vdata['categoria_conta_tipo_conta_to_string'] = $this->categoria_conta_tipo_conta_to_string;
    }

    public function get_categoria_conta_tipo_conta_to_string()
    {
        if(!empty($this->categoria_conta_tipo_conta_to_string))
        {
            return $this->categoria_conta_tipo_conta_to_string;
        }
    
        $values = CategoriaConta::where('tipo_conta_id', '=', $this->id)->getIndexedArray('tipo_conta_id','{tipo_conta->nome}');
        return implode(', ', $values);
    }

    public function set_categoria_conta_account_to_string($categoria_conta_account_to_string)
    {
        if(is_array($categoria_conta_account_to_string))
        {
            $values = Account::where('id', 'in', $categoria_conta_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->categoria_conta_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->categoria_conta_account_to_string = $categoria_conta_account_to_string;
        }

        $this->vdata['categoria_conta_account_to_string'] = $this->categoria_conta_account_to_string;
    }

    public function get_categoria_conta_account_to_string()
    {
        if(!empty($this->categoria_conta_account_to_string))
        {
            return $this->categoria_conta_account_to_string;
        }
    
        $values = CategoriaConta::where('tipo_conta_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_conta_pessoa_to_string($conta_pessoa_to_string)
    {
        if(is_array($conta_pessoa_to_string))
        {
            $values = Pessoa::where('id', 'in', $conta_pessoa_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_pessoa_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_pessoa_to_string = $conta_pessoa_to_string;
        }

        $this->vdata['conta_pessoa_to_string'] = $this->conta_pessoa_to_string;
    }

    public function get_conta_pessoa_to_string()
    {
        if(!empty($this->conta_pessoa_to_string))
        {
            return $this->conta_pessoa_to_string;
        }
    
        $values = Conta::where('tipo_conta_id', '=', $this->id)->getIndexedArray('pessoa_id','{pessoa->nome}');
        return implode(', ', $values);
    }

    public function set_conta_categoria_conta_to_string($conta_categoria_conta_to_string)
    {
        if(is_array($conta_categoria_conta_to_string))
        {
            $values = CategoriaConta::where('id', 'in', $conta_categoria_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_categoria_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_categoria_conta_to_string = $conta_categoria_conta_to_string;
        }

        $this->vdata['conta_categoria_conta_to_string'] = $this->conta_categoria_conta_to_string;
    }

    public function get_conta_categoria_conta_to_string()
    {
        if(!empty($this->conta_categoria_conta_to_string))
        {
            return $this->conta_categoria_conta_to_string;
        }
    
        $values = Conta::where('tipo_conta_id', '=', $this->id)->getIndexedArray('categoria_conta_id','{categoria_conta->nome}');
        return implode(', ', $values);
    }

    public function set_conta_tipo_conta_to_string($conta_tipo_conta_to_string)
    {
        if(is_array($conta_tipo_conta_to_string))
        {
            $values = TipoConta::where('id', 'in', $conta_tipo_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_tipo_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_tipo_conta_to_string = $conta_tipo_conta_to_string;
        }

        $this->vdata['conta_tipo_conta_to_string'] = $this->conta_tipo_conta_to_string;
    }

    public function get_conta_tipo_conta_to_string()
    {
        if(!empty($this->conta_tipo_conta_to_string))
        {
            return $this->conta_tipo_conta_to_string;
        }
    
        $values = Conta::where('tipo_conta_id', '=', $this->id)->getIndexedArray('tipo_conta_id','{tipo_conta->nome}');
        return implode(', ', $values);
    }

    public function set_conta_clinica_to_string($conta_clinica_to_string)
    {
        if(is_array($conta_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $conta_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_clinica_to_string = $conta_clinica_to_string;
        }

        $this->vdata['conta_clinica_to_string'] = $this->conta_clinica_to_string;
    }

    public function get_conta_clinica_to_string()
    {
        if(!empty($this->conta_clinica_to_string))
        {
            return $this->conta_clinica_to_string;
        }
    
        $values = Conta::where('tipo_conta_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_conta_atendimento_to_string($conta_atendimento_to_string)
    {
        if(is_array($conta_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $conta_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->conta_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_atendimento_to_string = $conta_atendimento_to_string;
        }

        $this->vdata['conta_atendimento_to_string'] = $this->conta_atendimento_to_string;
    }

    public function get_conta_atendimento_to_string()
    {
        if(!empty($this->conta_atendimento_to_string))
        {
            return $this->conta_atendimento_to_string;
        }
    
        $values = Conta::where('tipo_conta_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    
}

