<?php

class Conta extends TRecord
{
    const TABLENAME  = 'conta';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Pessoa $pessoa;
    private Atendimento $atendimento;
    private Clinica $clinica;
    private TipoConta $tipo_conta;
    private CategoriaConta $categoria_conta;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByUnit');
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
                    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('pessoa_id');
        parent::addAttribute('categoria_conta_id');
        parent::addAttribute('tipo_conta_id');
        parent::addAttribute('clinica_id');
        parent::addAttribute('atendimento_id');
        parent::addAttribute('data_emissao');
        parent::addAttribute('total_parcelas');
        parent::addAttribute('quitada');
        parent::addAttribute('descricao');
        parent::addAttribute('conta_origem_id');
        parent::addAttribute('total_conta');
        parent::addAttribute('mes');
        parent::addAttribute('ano');
        parent::addAttribute('ano_mes');
    
    }

    /**
     * Method set_pessoa
     * Sample of usage: $var->pessoa = $object;
     * @param $object Instance of Pessoa
     */
    public function set_pessoa(Pessoa $object)
    {
        $this->pessoa = $object;
        $this->pessoa_id = $object->id;
    }

    /**
     * Method get_pessoa
     * Sample of usage: $var->pessoa->attribute;
     * @returns Pessoa instance
     */
    public function get_pessoa()
    {
    
        // loads the associated object
        if (empty($this->pessoa))
            $this->pessoa = new Pessoa($this->pessoa_id);
    
        // returns the associated object
        return $this->pessoa;
    }
    /**
     * Method set_atendimento
     * Sample of usage: $var->atendimento = $object;
     * @param $object Instance of Atendimento
     */
    public function set_atendimento(Atendimento $object)
    {
        $this->atendimento = $object;
        $this->atendimento_id = $object->id;
    }

    /**
     * Method get_atendimento
     * Sample of usage: $var->atendimento->attribute;
     * @returns Atendimento instance
     */
    public function get_atendimento()
    {
    
        // loads the associated object
        if (empty($this->atendimento))
            $this->atendimento = new Atendimento($this->atendimento_id);
    
        // returns the associated object
        return $this->atendimento;
    }
    /**
     * Method set_clinica
     * Sample of usage: $var->clinica = $object;
     * @param $object Instance of Clinica
     */
    public function set_clinica(Clinica $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns Clinica instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new Clinica($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }
    /**
     * Method set_tipo_conta
     * Sample of usage: $var->tipo_conta = $object;
     * @param $object Instance of TipoConta
     */
    public function set_tipo_conta(TipoConta $object)
    {
        $this->tipo_conta = $object;
        $this->tipo_conta_id = $object->id;
    }

    /**
     * Method get_tipo_conta
     * Sample of usage: $var->tipo_conta->attribute;
     * @returns TipoConta instance
     */
    public function get_tipo_conta()
    {
    
        // loads the associated object
        if (empty($this->tipo_conta))
            $this->tipo_conta = new TipoConta($this->tipo_conta_id);
    
        // returns the associated object
        return $this->tipo_conta;
    }
    /**
     * Method set_categoria_conta
     * Sample of usage: $var->categoria_conta = $object;
     * @param $object Instance of CategoriaConta
     */
    public function set_categoria_conta(CategoriaConta $object)
    {
        $this->categoria_conta = $object;
        $this->categoria_conta_id = $object->id;
    }

    /**
     * Method get_categoria_conta
     * Sample of usage: $var->categoria_conta->attribute;
     * @returns CategoriaConta instance
     */
    public function get_categoria_conta()
    {
    
        // loads the associated object
        if (empty($this->categoria_conta))
            $this->categoria_conta = new CategoriaConta($this->categoria_conta_id);
    
        // returns the associated object
        return $this->categoria_conta;
    }

    /**
     * Method getLancamentos
     */
    public function getLancamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('conta_id', '=', $this->id));
        return Lancamento::getObjects( $criteria );
    }
    /**
     * Method getNotaFiscalServicos
     */
    public function getNotaFiscalServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('conta_id', '=', $this->id));
        return NotaFiscalServico::getObjects( $criteria );
    }

    public function set_lancamento_conta_to_string($lancamento_conta_to_string)
    {
        if(is_array($lancamento_conta_to_string))
        {
            $values = Conta::where('id', 'in', $lancamento_conta_to_string)->getIndexedArray('descricao', 'descricao');
            $this->lancamento_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_conta_to_string = $lancamento_conta_to_string;
        }

        $this->vdata['lancamento_conta_to_string'] = $this->lancamento_conta_to_string;
    }

    public function get_lancamento_conta_to_string()
    {
        if(!empty($this->lancamento_conta_to_string))
        {
            return $this->lancamento_conta_to_string;
        }
    
        $values = Lancamento::where('conta_id', '=', $this->id)->getIndexedArray('conta_id','{conta->descricao}');
        return implode(', ', $values);
    }

    public function set_lancamento_clinica_to_string($lancamento_clinica_to_string)
    {
        if(is_array($lancamento_clinica_to_string))
        {
            $values = SystemUnit::where('id', 'in', $lancamento_clinica_to_string)->getIndexedArray('name', 'name');
            $this->lancamento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_clinica_to_string = $lancamento_clinica_to_string;
        }

        $this->vdata['lancamento_clinica_to_string'] = $this->lancamento_clinica_to_string;
    }

    public function get_lancamento_clinica_to_string()
    {
        if(!empty($this->lancamento_clinica_to_string))
        {
            return $this->lancamento_clinica_to_string;
        }
    
        $values = Lancamento::where('conta_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->name}');
        return implode(', ', $values);
    }

    public function set_lancamento_tipo_pagamento_to_string($lancamento_tipo_pagamento_to_string)
    {
        if(is_array($lancamento_tipo_pagamento_to_string))
        {
            $values = TipoPagamento::where('id', 'in', $lancamento_tipo_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->lancamento_tipo_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_tipo_pagamento_to_string = $lancamento_tipo_pagamento_to_string;
        }

        $this->vdata['lancamento_tipo_pagamento_to_string'] = $this->lancamento_tipo_pagamento_to_string;
    }

    public function get_lancamento_tipo_pagamento_to_string()
    {
        if(!empty($this->lancamento_tipo_pagamento_to_string))
        {
            return $this->lancamento_tipo_pagamento_to_string;
        }
    
        $values = Lancamento::where('conta_id', '=', $this->id)->getIndexedArray('tipo_pagamento_id','{tipo_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_lancamento_nota_fiscal_servico_to_string($lancamento_nota_fiscal_servico_to_string)
    {
        if(is_array($lancamento_nota_fiscal_servico_to_string))
        {
            $values = NotaFiscalServico::where('id', 'in', $lancamento_nota_fiscal_servico_to_string)->getIndexedArray('id', 'id');
            $this->lancamento_nota_fiscal_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->lancamento_nota_fiscal_servico_to_string = $lancamento_nota_fiscal_servico_to_string;
        }

        $this->vdata['lancamento_nota_fiscal_servico_to_string'] = $this->lancamento_nota_fiscal_servico_to_string;
    }

    public function get_lancamento_nota_fiscal_servico_to_string()
    {
        if(!empty($this->lancamento_nota_fiscal_servico_to_string))
        {
            return $this->lancamento_nota_fiscal_servico_to_string;
        }
    
        $values = Lancamento::where('conta_id', '=', $this->id)->getIndexedArray('nota_fiscal_servico_id','{nota_fiscal_servico->id}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cidade_tomador_to_string($nota_fiscal_servico_cidade_tomador_to_string)
    {
        if(is_array($nota_fiscal_servico_cidade_tomador_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_cidade_tomador_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cidade_tomador_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cidade_tomador_to_string = $nota_fiscal_servico_cidade_tomador_to_string;
        }

        $this->vdata['nota_fiscal_servico_cidade_tomador_to_string'] = $this->nota_fiscal_servico_cidade_tomador_to_string;
    }

    public function get_nota_fiscal_servico_cidade_tomador_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cidade_tomador_to_string))
        {
            return $this->nota_fiscal_servico_cidade_tomador_to_string;
        }
    
        $values = NotaFiscalServico::where('conta_id', '=', $this->id)->getIndexedArray('cidade_tomador_id','{cidade_tomador->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cidade_prestador_to_string($nota_fiscal_servico_cidade_prestador_to_string)
    {
        if(is_array($nota_fiscal_servico_cidade_prestador_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_cidade_prestador_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cidade_prestador_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cidade_prestador_to_string = $nota_fiscal_servico_cidade_prestador_to_string;
        }

        $this->vdata['nota_fiscal_servico_cidade_prestador_to_string'] = $this->nota_fiscal_servico_cidade_prestador_to_string;
    }

    public function get_nota_fiscal_servico_cidade_prestador_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cidade_prestador_to_string))
        {
            return $this->nota_fiscal_servico_cidade_prestador_to_string;
        }
    
        $values = NotaFiscalServico::where('conta_id', '=', $this->id)->getIndexedArray('cidade_prestador_id','{cidade_prestador->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_municipio_prestacao_servico_to_string($nota_fiscal_servico_municipio_prestacao_servico_to_string)
    {
        if(is_array($nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_municipio_prestacao_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_municipio_prestacao_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_municipio_prestacao_servico_to_string = $nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }

        $this->vdata['nota_fiscal_servico_municipio_prestacao_servico_to_string'] = $this->nota_fiscal_servico_municipio_prestacao_servico_to_string;
    }

    public function get_nota_fiscal_servico_municipio_prestacao_servico_to_string()
    {
        if(!empty($this->nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            return $this->nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }
    
        $values = NotaFiscalServico::where('conta_id', '=', $this->id)->getIndexedArray('municipio_prestacao_servico_id','{municipio_prestacao_servico->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_nota_fiscal_status_to_string($nota_fiscal_servico_nota_fiscal_status_to_string)
    {
        if(is_array($nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            $values = NotaFiscalStatus::where('id', 'in', $nota_fiscal_servico_nota_fiscal_status_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_nota_fiscal_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_nota_fiscal_status_to_string = $nota_fiscal_servico_nota_fiscal_status_to_string;
        }

        $this->vdata['nota_fiscal_servico_nota_fiscal_status_to_string'] = $this->nota_fiscal_servico_nota_fiscal_status_to_string;
    }

    public function get_nota_fiscal_servico_nota_fiscal_status_to_string()
    {
        if(!empty($this->nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            return $this->nota_fiscal_servico_nota_fiscal_status_to_string;
        }
    
        $values = NotaFiscalServico::where('conta_id', '=', $this->id)->getIndexedArray('nota_fiscal_status_id','{nota_fiscal_status->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_clinica_to_string($nota_fiscal_servico_clinica_to_string)
    {
        if(is_array($nota_fiscal_servico_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $nota_fiscal_servico_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_clinica_to_string = $nota_fiscal_servico_clinica_to_string;
        }

        $this->vdata['nota_fiscal_servico_clinica_to_string'] = $this->nota_fiscal_servico_clinica_to_string;
    }

    public function get_nota_fiscal_servico_clinica_to_string()
    {
        if(!empty($this->nota_fiscal_servico_clinica_to_string))
        {
            return $this->nota_fiscal_servico_clinica_to_string;
        }
    
        $values = NotaFiscalServico::where('conta_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cliente_to_string($nota_fiscal_servico_cliente_to_string)
    {
        if(is_array($nota_fiscal_servico_cliente_to_string))
        {
            $values = Pessoa::where('id', 'in', $nota_fiscal_servico_cliente_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cliente_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cliente_to_string = $nota_fiscal_servico_cliente_to_string;
        }

        $this->vdata['nota_fiscal_servico_cliente_to_string'] = $this->nota_fiscal_servico_cliente_to_string;
    }

    public function get_nota_fiscal_servico_cliente_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cliente_to_string))
        {
            return $this->nota_fiscal_servico_cliente_to_string;
        }
    
        $values = NotaFiscalServico::where('conta_id', '=', $this->id)->getIndexedArray('cliente_id','{cliente->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_conta_to_string($nota_fiscal_servico_conta_to_string)
    {
        if(is_array($nota_fiscal_servico_conta_to_string))
        {
            $values = Conta::where('id', 'in', $nota_fiscal_servico_conta_to_string)->getIndexedArray('descricao', 'descricao');
            $this->nota_fiscal_servico_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_conta_to_string = $nota_fiscal_servico_conta_to_string;
        }

        $this->vdata['nota_fiscal_servico_conta_to_string'] = $this->nota_fiscal_servico_conta_to_string;
    }

    public function get_nota_fiscal_servico_conta_to_string()
    {
        if(!empty($this->nota_fiscal_servico_conta_to_string))
        {
            return $this->nota_fiscal_servico_conta_to_string;
        }
    
        $values = NotaFiscalServico::where('conta_id', '=', $this->id)->getIndexedArray('conta_id','{conta->descricao}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_lancamento_to_string($nota_fiscal_servico_lancamento_to_string)
    {
        if(is_array($nota_fiscal_servico_lancamento_to_string))
        {
            $values = Lancamento::where('id', 'in', $nota_fiscal_servico_lancamento_to_string)->getIndexedArray('id', 'id');
            $this->nota_fiscal_servico_lancamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_lancamento_to_string = $nota_fiscal_servico_lancamento_to_string;
        }

        $this->vdata['nota_fiscal_servico_lancamento_to_string'] = $this->nota_fiscal_servico_lancamento_to_string;
    }

    public function get_nota_fiscal_servico_lancamento_to_string()
    {
        if(!empty($this->nota_fiscal_servico_lancamento_to_string))
        {
            return $this->nota_fiscal_servico_lancamento_to_string;
        }
    
        $values = NotaFiscalServico::where('conta_id', '=', $this->id)->getIndexedArray('lancamento_id','{lancamento->id}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_servico_to_string($nota_fiscal_servico_servico_to_string)
    {
        if(is_array($nota_fiscal_servico_servico_to_string))
        {
            $values = Servico::where('id', 'in', $nota_fiscal_servico_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_servico_to_string = $nota_fiscal_servico_servico_to_string;
        }

        $this->vdata['nota_fiscal_servico_servico_to_string'] = $this->nota_fiscal_servico_servico_to_string;
    }

    public function get_nota_fiscal_servico_servico_to_string()
    {
        if(!empty($this->nota_fiscal_servico_servico_to_string))
        {
            return $this->nota_fiscal_servico_servico_to_string;
        }
    
        $values = NotaFiscalServico::where('conta_id', '=', $this->id)->getIndexedArray('servico_id','{servico->nome}');
        return implode(', ', $values);
    }

    public function onBeforeStore($object)
    {
        if (!empty($object->data_emissao)) {
            $object->ano = date('Y', strtotime($object->data_emissao));
            $object->mes = date('m', strtotime($object->data_emissao));
            $object->ano_mes = date('Ym', strtotime($object->data_emissao));
        }
    }

    public function gerarNotaFiscal($lancamentos, $servico_id, $observacoes)
    {
        $total = 0;
    
        if($lancamentos)
        {
            foreach($lancamentos as $lancamento_id)
            {
                $lancamento = new Lancamento($lancamento_id);
            
                $total += $lancamento->valor;
            }
        }
    
        $configuracao = Clinica::find($this->clinica_id);
        $pessoa = new Pessoa($this->pessoa_id);
    
        $notaFiscal = new NotaFiscalServico();
        $notaFiscal->conta_id = $this->id;
        $notaFiscal->servico_id = $servico_id;
        $notaFiscal->clinica_id = $this->clinica_id;
        $notaFiscal->cliente_id = $this->pessoa_id;
    
        $notaFiscal->discriminacao = $observacoes;
    
        $notaFiscal->valor_servicos = $total;
        $notaFiscal->cidade_tomador_id = $configuracao->cidade_id;
        $notaFiscal->cidade_prestador_id = $configuracao->cidade_id;
        $notaFiscal->municipio_prestacao_servico_id = $configuracao->cidade_id;
        $notaFiscal->nota_fiscal_status_id = NotaFiscalStatus::PENDENTE;
    
        $notaFiscal->natureza_operacao = $configuracao->natureza_operacao;
        $notaFiscal->data_hora_emissao = date('Y-m-d H:i:s');
    
        $endereco = PessoaEndereco::where('pessoa_id', '=', $pessoa->id)->first();
    
    
        if(!$endereco)
        {
            throw new Exception("O endereço do cliente: {$pessoa->nome} não foi preenchido! ");
        }
    
    
    
        $notaFiscal->nome_tomador = $pessoa->nome;
        $notaFiscal->documento_tomador = $pessoa->documento;
        $notaFiscal->endereco_tomador = substr($endereco->rua,0,19);
        $notaFiscal->email_tomador = $pessoa->email;
        $notaFiscal->telefone_tomador = $pessoa->telefone;
        $notaFiscal->numero_tomador = $endereco->numero;
        $notaFiscal->bairro_tomador = substr($endereco->bairro,0,24);
        $notaFiscal->cep_tomador = $endereco->cep;
        $notaFiscal->inscricao_municipal_tomador = '';
        $notaFiscal->inscricao_municipal_prestador = $configuracao->inscricao_municipal;
        $notaFiscal->nome_prestador = $configuracao->razao_social;
        $notaFiscal->documento_prestador = $configuracao->cnpj;
        $notaFiscal->endereco_prestador = substr($configuracao->endereco,0,19);
        $notaFiscal->email_prestador = $configuracao->email;
        $notaFiscal->telefone_prestador = $configuracao->telefone;
        $notaFiscal->numero_prestador = $configuracao->numero;
        $notaFiscal->bairro_prestador = substr($configuracao->bairro,0,24);
        $notaFiscal->cep_prestador = $configuracao->cep;
        $notaFiscal = ClinicaNotaFiscalServicoService::calculaImpostos($notaFiscal);
    
        $notaFiscal->ano = date('Y');
        $notaFiscal->mes = date('m');
        $notaFiscal->ano_mes = date('Y/m');
    
        $notaFiscal->store();
    
        if($lancamentos)
        {
            foreach($lancamentos as $lancamento_id)
            {
                $lancamento = new Lancamento($lancamento_id);
                $lancamento->nota_fiscal_servico_id = $notaFiscal->id;
            
                $total += $lancamento->valor;
                $lancamento->store();
            }
        }
    
        $this->store();
    
        return $notaFiscal;
    }
                                            
}

