<?php

class TipoDocumento extends TRecord
{
    const TABLENAME  = 'tipo_documento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Clinica $clinica;

    const VARIAVEIS = [
        "[nome_paciente]" => "paciente->nome_formatado",
        "[nome_profissional]" => "profissional->nome_formatado",
        "[nome_clinica]" => "agendamento->agenda->clinica->nome",
        "[data_atendimento]" => "data_atendimento",
        "[inicio_atendimento]" => "inicio_atendimento"
    ];

    private static $LAUDO = 1;

            

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('clinica_id');
        parent::addAttribute('nome');
        parent::addAttribute('texto_padrao');
        parent::addAttribute('ativo');
    
    }

    /**
     * Method set_clinica
     * Sample of usage: $var->clinica = $object;
     * @param $object Instance of Clinica
     */
    public function set_clinica(Clinica $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns Clinica instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new Clinica($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }

    /**
     * Method getDocumentos
     */
    public function getDocumentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('tipo_documento_id', '=', $this->id));
        return Documento::getObjects( $criteria );
    }

    public function set_documento_atendimento_to_string($documento_atendimento_to_string)
    {
        if(is_array($documento_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $documento_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->documento_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_atendimento_to_string = $documento_atendimento_to_string;
        }

        $this->vdata['documento_atendimento_to_string'] = $this->documento_atendimento_to_string;
    }

    public function get_documento_atendimento_to_string()
    {
        if(!empty($this->documento_atendimento_to_string))
        {
            return $this->documento_atendimento_to_string;
        }
    
        $values = Documento::where('tipo_documento_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_documento_tipo_documento_to_string($documento_tipo_documento_to_string)
    {
        if(is_array($documento_tipo_documento_to_string))
        {
            $values = TipoDocumento::where('id', 'in', $documento_tipo_documento_to_string)->getIndexedArray('nome', 'nome');
            $this->documento_tipo_documento_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_tipo_documento_to_string = $documento_tipo_documento_to_string;
        }

        $this->vdata['documento_tipo_documento_to_string'] = $this->documento_tipo_documento_to_string;
    }

    public function get_documento_tipo_documento_to_string()
    {
        if(!empty($this->documento_tipo_documento_to_string))
        {
            return $this->documento_tipo_documento_to_string;
        }
    
        $values = Documento::where('tipo_documento_id', '=', $this->id)->getIndexedArray('tipo_documento_id','{tipo_documento->nome}');
        return implode(', ', $values);
    }

    public function set_documento_clinica_to_string($documento_clinica_to_string)
    {
        if(is_array($documento_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $documento_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->documento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_clinica_to_string = $documento_clinica_to_string;
        }

        $this->vdata['documento_clinica_to_string'] = $this->documento_clinica_to_string;
    }

    public function get_documento_clinica_to_string()
    {
        if(!empty($this->documento_clinica_to_string))
        {
            return $this->documento_clinica_to_string;
        }
    
        $values = Documento::where('tipo_documento_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_documento_procedimento_to_string($documento_procedimento_to_string)
    {
        if(is_array($documento_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $documento_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->documento_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_procedimento_to_string = $documento_procedimento_to_string;
        }

        $this->vdata['documento_procedimento_to_string'] = $this->documento_procedimento_to_string;
    }

    public function get_documento_procedimento_to_string()
    {
        if(!empty($this->documento_procedimento_to_string))
        {
            return $this->documento_procedimento_to_string;
        }
    
        $values = Documento::where('tipo_documento_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

}

