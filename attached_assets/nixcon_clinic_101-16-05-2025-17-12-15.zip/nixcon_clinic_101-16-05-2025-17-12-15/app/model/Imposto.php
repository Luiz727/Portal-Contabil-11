<?php

class Imposto extends TRecord
{
    const TABLENAME  = 'imposto';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    const ISS = '1';
    const PIS = '2';
    const COFINS = '3';
    const INSS = '4';
    const IRRF = '5';
    const CSLL = '6';

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('nome');
        parent::addAttribute('codigo');
            
    }

    /**
     * Method getServicoImpostoItems
     */
    public function getServicoImpostoItems()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('imposto_id', '=', $this->id));
        return ServicoImpostoItem::getObjects( $criteria );
    }

    public function set_servico_imposto_item_servico_to_string($servico_imposto_item_servico_to_string)
    {
        if(is_array($servico_imposto_item_servico_to_string))
        {
            $values = Servico::where('id', 'in', $servico_imposto_item_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->servico_imposto_item_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->servico_imposto_item_servico_to_string = $servico_imposto_item_servico_to_string;
        }

        $this->vdata['servico_imposto_item_servico_to_string'] = $this->servico_imposto_item_servico_to_string;
    }

    public function get_servico_imposto_item_servico_to_string()
    {
        if(!empty($this->servico_imposto_item_servico_to_string))
        {
            return $this->servico_imposto_item_servico_to_string;
        }
    
        $values = ServicoImpostoItem::where('imposto_id', '=', $this->id)->getIndexedArray('servico_id','{servico->nome}');
        return implode(', ', $values);
    }

    public function set_servico_imposto_item_imposto_to_string($servico_imposto_item_imposto_to_string)
    {
        if(is_array($servico_imposto_item_imposto_to_string))
        {
            $values = Imposto::where('id', 'in', $servico_imposto_item_imposto_to_string)->getIndexedArray('nome', 'nome');
            $this->servico_imposto_item_imposto_to_string = implode(', ', $values);
        }
        else
        {
            $this->servico_imposto_item_imposto_to_string = $servico_imposto_item_imposto_to_string;
        }

        $this->vdata['servico_imposto_item_imposto_to_string'] = $this->servico_imposto_item_imposto_to_string;
    }

    public function get_servico_imposto_item_imposto_to_string()
    {
        if(!empty($this->servico_imposto_item_imposto_to_string))
        {
            return $this->servico_imposto_item_imposto_to_string;
        }
    
        $values = ServicoImpostoItem::where('imposto_id', '=', $this->id)->getIndexedArray('imposto_id','{imposto->nome}');
        return implode(', ', $values);
    }

    
}

