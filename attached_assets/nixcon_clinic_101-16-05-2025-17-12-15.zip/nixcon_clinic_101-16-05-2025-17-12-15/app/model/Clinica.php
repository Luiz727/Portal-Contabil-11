<?php

class Clinica extends TRecord
{
    const TABLENAME  = 'clinica';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SystemUnit $system_unit;
    private Cidade $cidade;
    private CategoriaConta $atendimento_categoria_conta;
    private Account $account;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByAccount');
        $this->addManagePermission('PermissaoService::verifyAttributes');
    
    
                    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('system_unit_id');
        parent::addAttribute('atendimento_categoria_conta_id');
        parent::addAttribute('cidade_id');
        parent::addAttribute('account_id');
        parent::addAttribute('token');
        parent::addAttribute('nome');
        parent::addAttribute('cnpj');
        parent::addAttribute('telefone');
        parent::addAttribute('email');
        parent::addAttribute('endereco');
        parent::addAttribute('bairro');
        parent::addAttribute('cep');
        parent::addAttribute('numero');
        parent::addAttribute('complemento');
        parent::addAttribute('logo_documento');
        parent::addAttribute('nfse_serie');
        parent::addAttribute('razao_social');
        parent::addAttribute('nfse_info');
        parent::addAttribute('nfse_numero');
        parent::addAttribute('regime_tributacao');
        parent::addAttribute('token_integra_notas');
        parent::addAttribute('token_integra_notas_homologacao');
        parent::addAttribute('nfse_emissao_producao');
        parent::addAttribute('certificado_a1_conteudo');
        parent::addAttribute('senha_certificado_a1');
        parent::addAttribute('certificado_a1_nome');
        parent::addAttribute('emitente_configurado');
        parent::addAttribute('validade_certificado');
        parent::addAttribute('logo_horizontal_grande');
    
    }

    /**
     * Method set_system_unit
     * Sample of usage: $var->system_unit = $object;
     * @param $object Instance of SystemUnit
     */
    public function set_system_unit(SystemUnit $object)
    {
        $this->system_unit = $object;
        $this->system_unit_id = $object->id;
    }

    /**
     * Method get_system_unit
     * Sample of usage: $var->system_unit->attribute;
     * @returns SystemUnit instance
     */
    public function get_system_unit()
    {
    
        // loads the associated object
        if (empty($this->system_unit))
            $this->system_unit = new SystemUnit($this->system_unit_id);
    
        // returns the associated object
        return $this->system_unit;
    }
    /**
     * Method set_cidade
     * Sample of usage: $var->cidade = $object;
     * @param $object Instance of Cidade
     */
    public function set_cidade(Cidade $object)
    {
        $this->cidade = $object;
        $this->cidade_id = $object->id;
    }

    /**
     * Method get_cidade
     * Sample of usage: $var->cidade->attribute;
     * @returns Cidade instance
     */
    public function get_cidade()
    {
    
        // loads the associated object
        if (empty($this->cidade))
            $this->cidade = new Cidade($this->cidade_id);
    
        // returns the associated object
        return $this->cidade;
    }
    /**
     * Method set_categoria_conta
     * Sample of usage: $var->categoria_conta = $object;
     * @param $object Instance of CategoriaConta
     */
    public function set_atendimento_categoria_conta(CategoriaConta $object)
    {
        $this->atendimento_categoria_conta = $object;
        $this->atendimento_categoria_conta_id = $object->id;
    }

    /**
     * Method get_atendimento_categoria_conta
     * Sample of usage: $var->atendimento_categoria_conta->attribute;
     * @returns CategoriaConta instance
     */
    public function get_atendimento_categoria_conta()
    {
    
        // loads the associated object
        if (empty($this->atendimento_categoria_conta))
            $this->atendimento_categoria_conta = new CategoriaConta($this->atendimento_categoria_conta_id);
    
        // returns the associated object
        return $this->atendimento_categoria_conta;
    }
    /**
     * Method set_account
     * Sample of usage: $var->account = $object;
     * @param $object Instance of Account
     */
    public function set_account(Account $object)
    {
        $this->account = $object;
        $this->account_id = $object->id;
    }

    /**
     * Method get_account
     * Sample of usage: $var->account->attribute;
     * @returns Account instance
     */
    public function get_account()
    {
    
        // loads the associated object
        if (empty($this->account))
            $this->account = new Account($this->account_id);
    
        // returns the associated object
        return $this->account;
    }

    /**
     * Method getAgendas
     */
    public function getAgendas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Agenda::getObjects( $criteria );
    }
    /**
     * Method getAgendamentos
     */
    public function getAgendamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Agendamento::getObjects( $criteria );
    }
    /**
     * Method getAgendaProfissionals
     */
    public function getAgendaProfissionals()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return AgendaProfissional::getObjects( $criteria );
    }
    /**
     * Method getBloqueios
     */
    public function getBloqueios()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Bloqueio::getObjects( $criteria );
    }
    /**
     * Method getClinicaConvenios
     */
    public function getClinicaConvenios()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return ClinicaConvenio::getObjects( $criteria );
    }
    /**
     * Method getContas
     */
    public function getContas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Conta::getObjects( $criteria );
    }
    /**
     * Method getDocumentos
     */
    public function getDocumentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Documento::getObjects( $criteria );
    }
    /**
     * Method getEmailConfigs
     */
    public function getEmailConfigs()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return EmailConfig::getObjects( $criteria );
    }
    /**
     * Method getEspecialidades
     */
    public function getEspecialidades()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Especialidade::getObjects( $criteria );
    }
    /**
     * Method getExames
     */
    public function getExames()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Exame::getObjects( $criteria );
    }
    /**
     * Method getMaterials
     */
    public function getMaterials()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Material::getObjects( $criteria );
    }
    /**
     * Method getMovimentacaos
     */
    public function getMovimentacaos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Movimentacao::getObjects( $criteria );
    }
    /**
     * Method getNotaFiscalServicos
     */
    public function getNotaFiscalServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return NotaFiscalServico::getObjects( $criteria );
    }
    /**
     * Method getPessoas
     */
    public function getPessoas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Pessoa::getObjects( $criteria );
    }
    /**
     * Method getProcedimentos
     */
    public function getProcedimentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return Procedimento::getObjects( $criteria );
    }
    /**
     * Method getTemplateClinicas
     */
    public function getTemplateClinicas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return TemplateClinica::getObjects( $criteria );
    }
    /**
     * Method getTipoDocumentos
     */
    public function getTipoDocumentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return TipoDocumento::getObjects( $criteria );
    }
    /**
     * Method getWhatsappConfigs
     */
    public function getWhatsappConfigs()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('clinica_id', '=', $this->id));
        return WhatsappConfig::getObjects( $criteria );
    }

    public function set_agenda_clinica_to_string($agenda_clinica_to_string)
    {
        if(is_array($agenda_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $agenda_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_clinica_to_string = $agenda_clinica_to_string;
        }

        $this->vdata['agenda_clinica_to_string'] = $this->agenda_clinica_to_string;
    }

    public function get_agenda_clinica_to_string()
    {
        if(!empty($this->agenda_clinica_to_string))
        {
            return $this->agenda_clinica_to_string;
        }
    
        $values = Agenda::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_agenda_profissional_to_string($agenda_profissional_to_string)
    {
        if(is_array($agenda_profissional_to_string))
        {
            $values = Pessoa::where('id', 'in', $agenda_profissional_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_profissional_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_profissional_to_string = $agenda_profissional_to_string;
        }

        $this->vdata['agenda_profissional_to_string'] = $this->agenda_profissional_to_string;
    }

    public function get_agenda_profissional_to_string()
    {
        if(!empty($this->agenda_profissional_to_string))
        {
            return $this->agenda_profissional_to_string;
        }
    
        $values = Agenda::where('clinica_id', '=', $this->id)->getIndexedArray('profissional_id','{profissional->nome}');
        return implode(', ', $values);
    }

    public function set_agenda_procedimento_to_string($agenda_procedimento_to_string)
    {
        if(is_array($agenda_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $agenda_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_procedimento_to_string = $agenda_procedimento_to_string;
        }

        $this->vdata['agenda_procedimento_to_string'] = $this->agenda_procedimento_to_string;
    }

    public function get_agenda_procedimento_to_string()
    {
        if(!empty($this->agenda_procedimento_to_string))
        {
            return $this->agenda_procedimento_to_string;
        }
    
        $values = Agenda::where('clinica_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_paciente_to_string($agendamento_paciente_to_string)
    {
        if(is_array($agendamento_paciente_to_string))
        {
            $values = Pessoa::where('id', 'in', $agendamento_paciente_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_paciente_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_paciente_to_string = $agendamento_paciente_to_string;
        }

        $this->vdata['agendamento_paciente_to_string'] = $this->agendamento_paciente_to_string;
    }

    public function get_agendamento_paciente_to_string()
    {
        if(!empty($this->agendamento_paciente_to_string))
        {
            return $this->agendamento_paciente_to_string;
        }
    
        $values = Agendamento::where('clinica_id', '=', $this->id)->getIndexedArray('paciente_id','{paciente->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_estado_agenda_to_string($agendamento_estado_agenda_to_string)
    {
        if(is_array($agendamento_estado_agenda_to_string))
        {
            $values = EstadoAgenda::where('id', 'in', $agendamento_estado_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_estado_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_estado_agenda_to_string = $agendamento_estado_agenda_to_string;
        }

        $this->vdata['agendamento_estado_agenda_to_string'] = $this->agendamento_estado_agenda_to_string;
    }

    public function get_agendamento_estado_agenda_to_string()
    {
        if(!empty($this->agendamento_estado_agenda_to_string))
        {
            return $this->agendamento_estado_agenda_to_string;
        }
    
        $values = Agendamento::where('clinica_id', '=', $this->id)->getIndexedArray('estado_agenda_id','{estado_agenda->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_agenda_to_string($agendamento_agenda_to_string)
    {
        if(is_array($agendamento_agenda_to_string))
        {
            $values = Agenda::where('id', 'in', $agendamento_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_agenda_to_string = $agendamento_agenda_to_string;
        }

        $this->vdata['agendamento_agenda_to_string'] = $this->agendamento_agenda_to_string;
    }

    public function get_agendamento_agenda_to_string()
    {
        if(!empty($this->agendamento_agenda_to_string))
        {
            return $this->agendamento_agenda_to_string;
        }
    
        $values = Agendamento::where('clinica_id', '=', $this->id)->getIndexedArray('agenda_id','{agenda->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_clinica_to_string($agendamento_clinica_to_string)
    {
        if(is_array($agendamento_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $agendamento_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_clinica_to_string = $agendamento_clinica_to_string;
        }

        $this->vdata['agendamento_clinica_to_string'] = $this->agendamento_clinica_to_string;
    }

    public function get_agendamento_clinica_to_string()
    {
        if(!empty($this->agendamento_clinica_to_string))
        {
            return $this->agendamento_clinica_to_string;
        }
    
        $values = Agendamento::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_especialidade_to_string($agendamento_especialidade_to_string)
    {
        if(is_array($agendamento_especialidade_to_string))
        {
            $values = Especialidade::where('id', 'in', $agendamento_especialidade_to_string)->getIndexedArray('descricao', 'descricao');
            $this->agendamento_especialidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_especialidade_to_string = $agendamento_especialidade_to_string;
        }

        $this->vdata['agendamento_especialidade_to_string'] = $this->agendamento_especialidade_to_string;
    }

    public function get_agendamento_especialidade_to_string()
    {
        if(!empty($this->agendamento_especialidade_to_string))
        {
            return $this->agendamento_especialidade_to_string;
        }
    
        $values = Agendamento::where('clinica_id', '=', $this->id)->getIndexedArray('especialidade_id','{especialidade->descricao}');
        return implode(', ', $values);
    }

    public function set_agenda_profissional_profissional_to_string($agenda_profissional_profissional_to_string)
    {
        if(is_array($agenda_profissional_profissional_to_string))
        {
            $values = Pessoa::where('id', 'in', $agenda_profissional_profissional_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_profissional_profissional_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_profissional_profissional_to_string = $agenda_profissional_profissional_to_string;
        }

        $this->vdata['agenda_profissional_profissional_to_string'] = $this->agenda_profissional_profissional_to_string;
    }

    public function get_agenda_profissional_profissional_to_string()
    {
        if(!empty($this->agenda_profissional_profissional_to_string))
        {
            return $this->agenda_profissional_profissional_to_string;
        }
    
        $values = AgendaProfissional::where('clinica_id', '=', $this->id)->getIndexedArray('profissional_id','{profissional->nome}');
        return implode(', ', $values);
    }

    public function set_agenda_profissional_clinica_to_string($agenda_profissional_clinica_to_string)
    {
        if(is_array($agenda_profissional_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $agenda_profissional_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_profissional_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_profissional_clinica_to_string = $agenda_profissional_clinica_to_string;
        }

        $this->vdata['agenda_profissional_clinica_to_string'] = $this->agenda_profissional_clinica_to_string;
    }

    public function get_agenda_profissional_clinica_to_string()
    {
        if(!empty($this->agenda_profissional_clinica_to_string))
        {
            return $this->agenda_profissional_clinica_to_string;
        }
    
        $values = AgendaProfissional::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_agenda_profissional_agenda_to_string($agenda_profissional_agenda_to_string)
    {
        if(is_array($agenda_profissional_agenda_to_string))
        {
            $values = Agenda::where('id', 'in', $agenda_profissional_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->agenda_profissional_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->agenda_profissional_agenda_to_string = $agenda_profissional_agenda_to_string;
        }

        $this->vdata['agenda_profissional_agenda_to_string'] = $this->agenda_profissional_agenda_to_string;
    }

    public function get_agenda_profissional_agenda_to_string()
    {
        if(!empty($this->agenda_profissional_agenda_to_string))
        {
            return $this->agenda_profissional_agenda_to_string;
        }
    
        $values = AgendaProfissional::where('clinica_id', '=', $this->id)->getIndexedArray('agenda_id','{agenda->nome}');
        return implode(', ', $values);
    }

    public function set_bloqueio_agenda_to_string($bloqueio_agenda_to_string)
    {
        if(is_array($bloqueio_agenda_to_string))
        {
            $values = Agenda::where('id', 'in', $bloqueio_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->bloqueio_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->bloqueio_agenda_to_string = $bloqueio_agenda_to_string;
        }

        $this->vdata['bloqueio_agenda_to_string'] = $this->bloqueio_agenda_to_string;
    }

    public function get_bloqueio_agenda_to_string()
    {
        if(!empty($this->bloqueio_agenda_to_string))
        {
            return $this->bloqueio_agenda_to_string;
        }
    
        $values = Bloqueio::where('clinica_id', '=', $this->id)->getIndexedArray('agenda_id','{agenda->nome}');
        return implode(', ', $values);
    }

    public function set_bloqueio_clinica_to_string($bloqueio_clinica_to_string)
    {
        if(is_array($bloqueio_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $bloqueio_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->bloqueio_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->bloqueio_clinica_to_string = $bloqueio_clinica_to_string;
        }

        $this->vdata['bloqueio_clinica_to_string'] = $this->bloqueio_clinica_to_string;
    }

    public function get_bloqueio_clinica_to_string()
    {
        if(!empty($this->bloqueio_clinica_to_string))
        {
            return $this->bloqueio_clinica_to_string;
        }
    
        $values = Bloqueio::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_clinica_convenio_convenio_to_string($clinica_convenio_convenio_to_string)
    {
        if(is_array($clinica_convenio_convenio_to_string))
        {
            $values = Convenio::where('id', 'in', $clinica_convenio_convenio_to_string)->getIndexedArray('nome', 'nome');
            $this->clinica_convenio_convenio_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_convenio_convenio_to_string = $clinica_convenio_convenio_to_string;
        }

        $this->vdata['clinica_convenio_convenio_to_string'] = $this->clinica_convenio_convenio_to_string;
    }

    public function get_clinica_convenio_convenio_to_string()
    {
        if(!empty($this->clinica_convenio_convenio_to_string))
        {
            return $this->clinica_convenio_convenio_to_string;
        }
    
        $values = ClinicaConvenio::where('clinica_id', '=', $this->id)->getIndexedArray('convenio_id','{convenio->nome}');
        return implode(', ', $values);
    }

    public function set_clinica_convenio_clinica_to_string($clinica_convenio_clinica_to_string)
    {
        if(is_array($clinica_convenio_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $clinica_convenio_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->clinica_convenio_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->clinica_convenio_clinica_to_string = $clinica_convenio_clinica_to_string;
        }

        $this->vdata['clinica_convenio_clinica_to_string'] = $this->clinica_convenio_clinica_to_string;
    }

    public function get_clinica_convenio_clinica_to_string()
    {
        if(!empty($this->clinica_convenio_clinica_to_string))
        {
            return $this->clinica_convenio_clinica_to_string;
        }
    
        $values = ClinicaConvenio::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_conta_pessoa_to_string($conta_pessoa_to_string)
    {
        if(is_array($conta_pessoa_to_string))
        {
            $values = Pessoa::where('id', 'in', $conta_pessoa_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_pessoa_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_pessoa_to_string = $conta_pessoa_to_string;
        }

        $this->vdata['conta_pessoa_to_string'] = $this->conta_pessoa_to_string;
    }

    public function get_conta_pessoa_to_string()
    {
        if(!empty($this->conta_pessoa_to_string))
        {
            return $this->conta_pessoa_to_string;
        }
    
        $values = Conta::where('clinica_id', '=', $this->id)->getIndexedArray('pessoa_id','{pessoa->nome}');
        return implode(', ', $values);
    }

    public function set_conta_categoria_conta_to_string($conta_categoria_conta_to_string)
    {
        if(is_array($conta_categoria_conta_to_string))
        {
            $values = CategoriaConta::where('id', 'in', $conta_categoria_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_categoria_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_categoria_conta_to_string = $conta_categoria_conta_to_string;
        }

        $this->vdata['conta_categoria_conta_to_string'] = $this->conta_categoria_conta_to_string;
    }

    public function get_conta_categoria_conta_to_string()
    {
        if(!empty($this->conta_categoria_conta_to_string))
        {
            return $this->conta_categoria_conta_to_string;
        }
    
        $values = Conta::where('clinica_id', '=', $this->id)->getIndexedArray('categoria_conta_id','{categoria_conta->nome}');
        return implode(', ', $values);
    }

    public function set_conta_tipo_conta_to_string($conta_tipo_conta_to_string)
    {
        if(is_array($conta_tipo_conta_to_string))
        {
            $values = TipoConta::where('id', 'in', $conta_tipo_conta_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_tipo_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_tipo_conta_to_string = $conta_tipo_conta_to_string;
        }

        $this->vdata['conta_tipo_conta_to_string'] = $this->conta_tipo_conta_to_string;
    }

    public function get_conta_tipo_conta_to_string()
    {
        if(!empty($this->conta_tipo_conta_to_string))
        {
            return $this->conta_tipo_conta_to_string;
        }
    
        $values = Conta::where('clinica_id', '=', $this->id)->getIndexedArray('tipo_conta_id','{tipo_conta->nome}');
        return implode(', ', $values);
    }

    public function set_conta_clinica_to_string($conta_clinica_to_string)
    {
        if(is_array($conta_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $conta_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->conta_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_clinica_to_string = $conta_clinica_to_string;
        }

        $this->vdata['conta_clinica_to_string'] = $this->conta_clinica_to_string;
    }

    public function get_conta_clinica_to_string()
    {
        if(!empty($this->conta_clinica_to_string))
        {
            return $this->conta_clinica_to_string;
        }
    
        $values = Conta::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_conta_atendimento_to_string($conta_atendimento_to_string)
    {
        if(is_array($conta_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $conta_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->conta_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->conta_atendimento_to_string = $conta_atendimento_to_string;
        }

        $this->vdata['conta_atendimento_to_string'] = $this->conta_atendimento_to_string;
    }

    public function get_conta_atendimento_to_string()
    {
        if(!empty($this->conta_atendimento_to_string))
        {
            return $this->conta_atendimento_to_string;
        }
    
        $values = Conta::where('clinica_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_documento_atendimento_to_string($documento_atendimento_to_string)
    {
        if(is_array($documento_atendimento_to_string))
        {
            $values = Atendimento::where('id', 'in', $documento_atendimento_to_string)->getIndexedArray('id', 'id');
            $this->documento_atendimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_atendimento_to_string = $documento_atendimento_to_string;
        }

        $this->vdata['documento_atendimento_to_string'] = $this->documento_atendimento_to_string;
    }

    public function get_documento_atendimento_to_string()
    {
        if(!empty($this->documento_atendimento_to_string))
        {
            return $this->documento_atendimento_to_string;
        }
    
        $values = Documento::where('clinica_id', '=', $this->id)->getIndexedArray('atendimento_id','{atendimento->id}');
        return implode(', ', $values);
    }

    public function set_documento_tipo_documento_to_string($documento_tipo_documento_to_string)
    {
        if(is_array($documento_tipo_documento_to_string))
        {
            $values = TipoDocumento::where('id', 'in', $documento_tipo_documento_to_string)->getIndexedArray('nome', 'nome');
            $this->documento_tipo_documento_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_tipo_documento_to_string = $documento_tipo_documento_to_string;
        }

        $this->vdata['documento_tipo_documento_to_string'] = $this->documento_tipo_documento_to_string;
    }

    public function get_documento_tipo_documento_to_string()
    {
        if(!empty($this->documento_tipo_documento_to_string))
        {
            return $this->documento_tipo_documento_to_string;
        }
    
        $values = Documento::where('clinica_id', '=', $this->id)->getIndexedArray('tipo_documento_id','{tipo_documento->nome}');
        return implode(', ', $values);
    }

    public function set_documento_clinica_to_string($documento_clinica_to_string)
    {
        if(is_array($documento_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $documento_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->documento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_clinica_to_string = $documento_clinica_to_string;
        }

        $this->vdata['documento_clinica_to_string'] = $this->documento_clinica_to_string;
    }

    public function get_documento_clinica_to_string()
    {
        if(!empty($this->documento_clinica_to_string))
        {
            return $this->documento_clinica_to_string;
        }
    
        $values = Documento::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_documento_procedimento_to_string($documento_procedimento_to_string)
    {
        if(is_array($documento_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $documento_procedimento_to_string)->getIndexedArray('nome', 'nome');
            $this->documento_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->documento_procedimento_to_string = $documento_procedimento_to_string;
        }

        $this->vdata['documento_procedimento_to_string'] = $this->documento_procedimento_to_string;
    }

    public function get_documento_procedimento_to_string()
    {
        if(!empty($this->documento_procedimento_to_string))
        {
            return $this->documento_procedimento_to_string;
        }
    
        $values = Documento::where('clinica_id', '=', $this->id)->getIndexedArray('procedimento_id','{procedimento->nome}');
        return implode(', ', $values);
    }

    public function set_email_config_clinica_to_string($email_config_clinica_to_string)
    {
        if(is_array($email_config_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $email_config_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->email_config_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->email_config_clinica_to_string = $email_config_clinica_to_string;
        }

        $this->vdata['email_config_clinica_to_string'] = $this->email_config_clinica_to_string;
    }

    public function get_email_config_clinica_to_string()
    {
        if(!empty($this->email_config_clinica_to_string))
        {
            return $this->email_config_clinica_to_string;
        }
    
        $values = EmailConfig::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_especialidade_clinica_to_string($especialidade_clinica_to_string)
    {
        if(is_array($especialidade_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $especialidade_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->especialidade_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->especialidade_clinica_to_string = $especialidade_clinica_to_string;
        }

        $this->vdata['especialidade_clinica_to_string'] = $this->especialidade_clinica_to_string;
    }

    public function get_especialidade_clinica_to_string()
    {
        if(!empty($this->especialidade_clinica_to_string))
        {
            return $this->especialidade_clinica_to_string;
        }
    
        $values = Especialidade::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_exame_clinica_to_string($exame_clinica_to_string)
    {
        if(is_array($exame_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $exame_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->exame_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->exame_clinica_to_string = $exame_clinica_to_string;
        }

        $this->vdata['exame_clinica_to_string'] = $this->exame_clinica_to_string;
    }

    public function get_exame_clinica_to_string()
    {
        if(!empty($this->exame_clinica_to_string))
        {
            return $this->exame_clinica_to_string;
        }
    
        $values = Exame::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_material_unidade_medida_to_string($material_unidade_medida_to_string)
    {
        if(is_array($material_unidade_medida_to_string))
        {
            $values = UnidadeMedida::where('id', 'in', $material_unidade_medida_to_string)->getIndexedArray('nome', 'nome');
            $this->material_unidade_medida_to_string = implode(', ', $values);
        }
        else
        {
            $this->material_unidade_medida_to_string = $material_unidade_medida_to_string;
        }

        $this->vdata['material_unidade_medida_to_string'] = $this->material_unidade_medida_to_string;
    }

    public function get_material_unidade_medida_to_string()
    {
        if(!empty($this->material_unidade_medida_to_string))
        {
            return $this->material_unidade_medida_to_string;
        }
    
        $values = Material::where('clinica_id', '=', $this->id)->getIndexedArray('unidade_medida_id','{unidade_medida->nome}');
        return implode(', ', $values);
    }

    public function set_material_clinica_to_string($material_clinica_to_string)
    {
        if(is_array($material_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $material_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->material_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->material_clinica_to_string = $material_clinica_to_string;
        }

        $this->vdata['material_clinica_to_string'] = $this->material_clinica_to_string;
    }

    public function get_material_clinica_to_string()
    {
        if(!empty($this->material_clinica_to_string))
        {
            return $this->material_clinica_to_string;
        }
    
        $values = Material::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_movimentacao_material_to_string($movimentacao_material_to_string)
    {
        if(is_array($movimentacao_material_to_string))
        {
            $values = Material::where('id', 'in', $movimentacao_material_to_string)->getIndexedArray('nome', 'nome');
            $this->movimentacao_material_to_string = implode(', ', $values);
        }
        else
        {
            $this->movimentacao_material_to_string = $movimentacao_material_to_string;
        }

        $this->vdata['movimentacao_material_to_string'] = $this->movimentacao_material_to_string;
    }

    public function get_movimentacao_material_to_string()
    {
        if(!empty($this->movimentacao_material_to_string))
        {
            return $this->movimentacao_material_to_string;
        }
    
        $values = Movimentacao::where('clinica_id', '=', $this->id)->getIndexedArray('material_id','{material->nome}');
        return implode(', ', $values);
    }

    public function set_movimentacao_system_user_to_string($movimentacao_system_user_to_string)
    {
        if(is_array($movimentacao_system_user_to_string))
        {
            $values = SystemUsers::where('id', 'in', $movimentacao_system_user_to_string)->getIndexedArray('name', 'name');
            $this->movimentacao_system_user_to_string = implode(', ', $values);
        }
        else
        {
            $this->movimentacao_system_user_to_string = $movimentacao_system_user_to_string;
        }

        $this->vdata['movimentacao_system_user_to_string'] = $this->movimentacao_system_user_to_string;
    }

    public function get_movimentacao_system_user_to_string()
    {
        if(!empty($this->movimentacao_system_user_to_string))
        {
            return $this->movimentacao_system_user_to_string;
        }
    
        $values = Movimentacao::where('clinica_id', '=', $this->id)->getIndexedArray('system_user_id','{system_user->name}');
        return implode(', ', $values);
    }

    public function set_movimentacao_clinica_to_string($movimentacao_clinica_to_string)
    {
        if(is_array($movimentacao_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $movimentacao_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->movimentacao_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->movimentacao_clinica_to_string = $movimentacao_clinica_to_string;
        }

        $this->vdata['movimentacao_clinica_to_string'] = $this->movimentacao_clinica_to_string;
    }

    public function get_movimentacao_clinica_to_string()
    {
        if(!empty($this->movimentacao_clinica_to_string))
        {
            return $this->movimentacao_clinica_to_string;
        }
    
        $values = Movimentacao::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cidade_tomador_to_string($nota_fiscal_servico_cidade_tomador_to_string)
    {
        if(is_array($nota_fiscal_servico_cidade_tomador_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_cidade_tomador_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cidade_tomador_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cidade_tomador_to_string = $nota_fiscal_servico_cidade_tomador_to_string;
        }

        $this->vdata['nota_fiscal_servico_cidade_tomador_to_string'] = $this->nota_fiscal_servico_cidade_tomador_to_string;
    }

    public function get_nota_fiscal_servico_cidade_tomador_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cidade_tomador_to_string))
        {
            return $this->nota_fiscal_servico_cidade_tomador_to_string;
        }
    
        $values = NotaFiscalServico::where('clinica_id', '=', $this->id)->getIndexedArray('cidade_tomador_id','{cidade_tomador->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cidade_prestador_to_string($nota_fiscal_servico_cidade_prestador_to_string)
    {
        if(is_array($nota_fiscal_servico_cidade_prestador_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_cidade_prestador_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cidade_prestador_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cidade_prestador_to_string = $nota_fiscal_servico_cidade_prestador_to_string;
        }

        $this->vdata['nota_fiscal_servico_cidade_prestador_to_string'] = $this->nota_fiscal_servico_cidade_prestador_to_string;
    }

    public function get_nota_fiscal_servico_cidade_prestador_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cidade_prestador_to_string))
        {
            return $this->nota_fiscal_servico_cidade_prestador_to_string;
        }
    
        $values = NotaFiscalServico::where('clinica_id', '=', $this->id)->getIndexedArray('cidade_prestador_id','{cidade_prestador->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_municipio_prestacao_servico_to_string($nota_fiscal_servico_municipio_prestacao_servico_to_string)
    {
        if(is_array($nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            $values = Cidade::where('id', 'in', $nota_fiscal_servico_municipio_prestacao_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_municipio_prestacao_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_municipio_prestacao_servico_to_string = $nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }

        $this->vdata['nota_fiscal_servico_municipio_prestacao_servico_to_string'] = $this->nota_fiscal_servico_municipio_prestacao_servico_to_string;
    }

    public function get_nota_fiscal_servico_municipio_prestacao_servico_to_string()
    {
        if(!empty($this->nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            return $this->nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }
    
        $values = NotaFiscalServico::where('clinica_id', '=', $this->id)->getIndexedArray('municipio_prestacao_servico_id','{municipio_prestacao_servico->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_nota_fiscal_status_to_string($nota_fiscal_servico_nota_fiscal_status_to_string)
    {
        if(is_array($nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            $values = NotaFiscalStatus::where('id', 'in', $nota_fiscal_servico_nota_fiscal_status_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_nota_fiscal_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_nota_fiscal_status_to_string = $nota_fiscal_servico_nota_fiscal_status_to_string;
        }

        $this->vdata['nota_fiscal_servico_nota_fiscal_status_to_string'] = $this->nota_fiscal_servico_nota_fiscal_status_to_string;
    }

    public function get_nota_fiscal_servico_nota_fiscal_status_to_string()
    {
        if(!empty($this->nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            return $this->nota_fiscal_servico_nota_fiscal_status_to_string;
        }
    
        $values = NotaFiscalServico::where('clinica_id', '=', $this->id)->getIndexedArray('nota_fiscal_status_id','{nota_fiscal_status->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_clinica_to_string($nota_fiscal_servico_clinica_to_string)
    {
        if(is_array($nota_fiscal_servico_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $nota_fiscal_servico_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_clinica_to_string = $nota_fiscal_servico_clinica_to_string;
        }

        $this->vdata['nota_fiscal_servico_clinica_to_string'] = $this->nota_fiscal_servico_clinica_to_string;
    }

    public function get_nota_fiscal_servico_clinica_to_string()
    {
        if(!empty($this->nota_fiscal_servico_clinica_to_string))
        {
            return $this->nota_fiscal_servico_clinica_to_string;
        }
    
        $values = NotaFiscalServico::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_cliente_to_string($nota_fiscal_servico_cliente_to_string)
    {
        if(is_array($nota_fiscal_servico_cliente_to_string))
        {
            $values = Pessoa::where('id', 'in', $nota_fiscal_servico_cliente_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_cliente_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_cliente_to_string = $nota_fiscal_servico_cliente_to_string;
        }

        $this->vdata['nota_fiscal_servico_cliente_to_string'] = $this->nota_fiscal_servico_cliente_to_string;
    }

    public function get_nota_fiscal_servico_cliente_to_string()
    {
        if(!empty($this->nota_fiscal_servico_cliente_to_string))
        {
            return $this->nota_fiscal_servico_cliente_to_string;
        }
    
        $values = NotaFiscalServico::where('clinica_id', '=', $this->id)->getIndexedArray('cliente_id','{cliente->nome}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_conta_to_string($nota_fiscal_servico_conta_to_string)
    {
        if(is_array($nota_fiscal_servico_conta_to_string))
        {
            $values = Conta::where('id', 'in', $nota_fiscal_servico_conta_to_string)->getIndexedArray('descricao', 'descricao');
            $this->nota_fiscal_servico_conta_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_conta_to_string = $nota_fiscal_servico_conta_to_string;
        }

        $this->vdata['nota_fiscal_servico_conta_to_string'] = $this->nota_fiscal_servico_conta_to_string;
    }

    public function get_nota_fiscal_servico_conta_to_string()
    {
        if(!empty($this->nota_fiscal_servico_conta_to_string))
        {
            return $this->nota_fiscal_servico_conta_to_string;
        }
    
        $values = NotaFiscalServico::where('clinica_id', '=', $this->id)->getIndexedArray('conta_id','{conta->descricao}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_lancamento_to_string($nota_fiscal_servico_lancamento_to_string)
    {
        if(is_array($nota_fiscal_servico_lancamento_to_string))
        {
            $values = Lancamento::where('id', 'in', $nota_fiscal_servico_lancamento_to_string)->getIndexedArray('id', 'id');
            $this->nota_fiscal_servico_lancamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_lancamento_to_string = $nota_fiscal_servico_lancamento_to_string;
        }

        $this->vdata['nota_fiscal_servico_lancamento_to_string'] = $this->nota_fiscal_servico_lancamento_to_string;
    }

    public function get_nota_fiscal_servico_lancamento_to_string()
    {
        if(!empty($this->nota_fiscal_servico_lancamento_to_string))
        {
            return $this->nota_fiscal_servico_lancamento_to_string;
        }
    
        $values = NotaFiscalServico::where('clinica_id', '=', $this->id)->getIndexedArray('lancamento_id','{lancamento->id}');
        return implode(', ', $values);
    }

    public function set_nota_fiscal_servico_servico_to_string($nota_fiscal_servico_servico_to_string)
    {
        if(is_array($nota_fiscal_servico_servico_to_string))
        {
            $values = Servico::where('id', 'in', $nota_fiscal_servico_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->nota_fiscal_servico_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->nota_fiscal_servico_servico_to_string = $nota_fiscal_servico_servico_to_string;
        }

        $this->vdata['nota_fiscal_servico_servico_to_string'] = $this->nota_fiscal_servico_servico_to_string;
    }

    public function get_nota_fiscal_servico_servico_to_string()
    {
        if(!empty($this->nota_fiscal_servico_servico_to_string))
        {
            return $this->nota_fiscal_servico_servico_to_string;
        }
    
        $values = NotaFiscalServico::where('clinica_id', '=', $this->id)->getIndexedArray('servico_id','{servico->nome}');
        return implode(', ', $values);
    }

    public function set_pessoa_clinica_to_string($pessoa_clinica_to_string)
    {
        if(is_array($pessoa_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $pessoa_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->pessoa_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->pessoa_clinica_to_string = $pessoa_clinica_to_string;
        }

        $this->vdata['pessoa_clinica_to_string'] = $this->pessoa_clinica_to_string;
    }

    public function get_pessoa_clinica_to_string()
    {
        if(!empty($this->pessoa_clinica_to_string))
        {
            return $this->pessoa_clinica_to_string;
        }
    
        $values = Pessoa::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_pessoa_system_users_to_string($pessoa_system_users_to_string)
    {
        if(is_array($pessoa_system_users_to_string))
        {
            $values = SystemUsers::where('id', 'in', $pessoa_system_users_to_string)->getIndexedArray('name', 'name');
            $this->pessoa_system_users_to_string = implode(', ', $values);
        }
        else
        {
            $this->pessoa_system_users_to_string = $pessoa_system_users_to_string;
        }

        $this->vdata['pessoa_system_users_to_string'] = $this->pessoa_system_users_to_string;
    }

    public function get_pessoa_system_users_to_string()
    {
        if(!empty($this->pessoa_system_users_to_string))
        {
            return $this->pessoa_system_users_to_string;
        }
    
        $values = Pessoa::where('clinica_id', '=', $this->id)->getIndexedArray('system_users_id','{system_users->name}');
        return implode(', ', $values);
    }

    public function set_procedimento_clinica_to_string($procedimento_clinica_to_string)
    {
        if(is_array($procedimento_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $procedimento_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->procedimento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->procedimento_clinica_to_string = $procedimento_clinica_to_string;
        }

        $this->vdata['procedimento_clinica_to_string'] = $this->procedimento_clinica_to_string;
    }

    public function get_procedimento_clinica_to_string()
    {
        if(!empty($this->procedimento_clinica_to_string))
        {
            return $this->procedimento_clinica_to_string;
        }
    
        $values = Procedimento::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_template_clinica_clinica_to_string($template_clinica_clinica_to_string)
    {
        if(is_array($template_clinica_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $template_clinica_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->template_clinica_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->template_clinica_clinica_to_string = $template_clinica_clinica_to_string;
        }

        $this->vdata['template_clinica_clinica_to_string'] = $this->template_clinica_clinica_to_string;
    }

    public function get_template_clinica_clinica_to_string()
    {
        if(!empty($this->template_clinica_clinica_to_string))
        {
            return $this->template_clinica_clinica_to_string;
        }
    
        $values = TemplateClinica::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_tipo_documento_clinica_to_string($tipo_documento_clinica_to_string)
    {
        if(is_array($tipo_documento_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $tipo_documento_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->tipo_documento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->tipo_documento_clinica_to_string = $tipo_documento_clinica_to_string;
        }

        $this->vdata['tipo_documento_clinica_to_string'] = $this->tipo_documento_clinica_to_string;
    }

    public function get_tipo_documento_clinica_to_string()
    {
        if(!empty($this->tipo_documento_clinica_to_string))
        {
            return $this->tipo_documento_clinica_to_string;
        }
    
        $values = TipoDocumento::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_whatsapp_config_clinica_to_string($whatsapp_config_clinica_to_string)
    {
        if(is_array($whatsapp_config_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $whatsapp_config_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->whatsapp_config_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->whatsapp_config_clinica_to_string = $whatsapp_config_clinica_to_string;
        }

        $this->vdata['whatsapp_config_clinica_to_string'] = $this->whatsapp_config_clinica_to_string;
    }

    public function get_whatsapp_config_clinica_to_string()
    {
        if(!empty($this->whatsapp_config_clinica_to_string))
        {
            return $this->whatsapp_config_clinica_to_string;
        }
    
        $values = WhatsappConfig::where('clinica_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public static function findByUnitId($unitId)
    {
        return self::where('system_unit_id', '=', $unitId)->first();
    }

    public function get_endereco_formatado()
    {
        $endereco = $this->endereco;
    
        if ($this->complemento)
        {
            $endereco .= " {$this->complemento}";
        }
    
        $endereco .= ', ' . $this->numero .  ' - ' . $this->bairro . ' ' . $this->cep;
    
        $endereco .= " {$this->get_cidade()->nome} ({$this->get_cidade()->get_estado()->sigla})";
    
        return $endereco;
    }

    public function get_url_sistema()
    {
        $object = SaasConfiguracao::first();
    
        return $object->url_sistema;
    }

                            
}

