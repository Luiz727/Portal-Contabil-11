<?php

class TemplateAcao extends TRecord
{
    const TABLENAME  = 'template_acao';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private TemplateClinica $template_clinica;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('template_clinica_id');
        parent::addAttribute('url');
        parent::addAttribute('label');
            
    }

    /**
     * Method set_template_clinica
     * Sample of usage: $var->template_clinica = $object;
     * @param $object Instance of TemplateClinica
     */
    public function set_template_clinica(TemplateClinica $object)
    {
        $this->template_clinica = $object;
        $this->template_clinica_id = $object->id;
    }

    /**
     * Method get_template_clinica
     * Sample of usage: $var->template_clinica->attribute;
     * @returns TemplateClinica instance
     */
    public function get_template_clinica()
    {
    
        // loads the associated object
        if (empty($this->template_clinica))
            $this->template_clinica = new TemplateClinica($this->template_clinica_id);
    
        // returns the associated object
        return $this->template_clinica;
    }

    
}

