<?php

class SaasGatewayFormaPagamento extends TRecord
{
    const TABLENAME  = 'saas_gateway_forma_pagamento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SaasFormaPagamento $saas_forma_pagamento;
    private SaasGatewayPagamento $saas_gateway_pagamento;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('saas_forma_pagamento_id');
        parent::addAttribute('saas_gateway_pagamento_id');
        parent::addAttribute('codigo');
    
    }

    /**
     * Method set_saas_forma_pagamento
     * Sample of usage: $var->saas_forma_pagamento = $object;
     * @param $object Instance of SaasFormaPagamento
     */
    public function set_saas_forma_pagamento(SaasFormaPagamento $object)
    {
        $this->saas_forma_pagamento = $object;
        $this->saas_forma_pagamento_id = $object->id;
    }

    /**
     * Method get_saas_forma_pagamento
     * Sample of usage: $var->saas_forma_pagamento->attribute;
     * @returns SaasFormaPagamento instance
     */
    public function get_saas_forma_pagamento()
    {
    
        // loads the associated object
        if (empty($this->saas_forma_pagamento))
            $this->saas_forma_pagamento = new SaasFormaPagamento($this->saas_forma_pagamento_id);
    
        // returns the associated object
        return $this->saas_forma_pagamento;
    }
    /**
     * Method set_saas_gateway_pagamento
     * Sample of usage: $var->saas_gateway_pagamento = $object;
     * @param $object Instance of SaasGatewayPagamento
     */
    public function set_saas_gateway_pagamento(SaasGatewayPagamento $object)
    {
        $this->saas_gateway_pagamento = $object;
        $this->saas_gateway_pagamento_id = $object->id;
    }

    /**
     * Method get_saas_gateway_pagamento
     * Sample of usage: $var->saas_gateway_pagamento->attribute;
     * @returns SaasGatewayPagamento instance
     */
    public function get_saas_gateway_pagamento()
    {
    
        // loads the associated object
        if (empty($this->saas_gateway_pagamento))
            $this->saas_gateway_pagamento = new SaasGatewayPagamento($this->saas_gateway_pagamento_id);
    
        // returns the associated object
        return $this->saas_gateway_pagamento;
    }

    public static function getSaasFormaPagamento($gateway_id, $forma)
    {
        $fs = self::where('saas_gateway_pagamento_id', '=', $gateway_id)->where('codigo', '=', $forma)->first();
    
        if ($fs)
        {
            return $fs->get_saas_forma_pagamento();
        }
    
        return null;
    }
    
}

