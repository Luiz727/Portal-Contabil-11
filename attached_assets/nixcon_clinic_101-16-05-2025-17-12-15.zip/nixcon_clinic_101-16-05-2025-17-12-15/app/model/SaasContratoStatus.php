<?php

class SaasContratoStatus extends TRecord
{
    const TABLENAME  = 'saas_contrato_status';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    const AGUARDANDO_PAGAMENTO = '1';
    const ATIVO = '2';
    const PAGAMENTO_ATRAZADO = '3';
    const INATIVO = '4';

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('nome');
        parent::addAttribute('cor');
            
    }

    /**
     * Method getSaasContratos
     */
    public function getSaasContratos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_contrato_status_id', '=', $this->id));
        return SaasContrato::getObjects( $criteria );
    }

    public function set_saas_contrato_saas_plano_valor_to_string($saas_contrato_saas_plano_valor_to_string)
    {
        if(is_array($saas_contrato_saas_plano_valor_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_contrato_saas_plano_valor_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_contrato_saas_plano_valor_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_saas_plano_valor_to_string = $saas_contrato_saas_plano_valor_to_string;
        }

        $this->vdata['saas_contrato_saas_plano_valor_to_string'] = $this->saas_contrato_saas_plano_valor_to_string;
    }

    public function get_saas_contrato_saas_plano_valor_to_string()
    {
        if(!empty($this->saas_contrato_saas_plano_valor_to_string))
        {
            return $this->saas_contrato_saas_plano_valor_to_string;
        }
    
        $values = SaasContrato::where('saas_contrato_status_id', '=', $this->id)->getIndexedArray('saas_plano_valor_id','{saas_plano_valor->nome}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_account_to_string($saas_contrato_account_to_string)
    {
        if(is_array($saas_contrato_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_contrato_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_contrato_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_account_to_string = $saas_contrato_account_to_string;
        }

        $this->vdata['saas_contrato_account_to_string'] = $this->saas_contrato_account_to_string;
    }

    public function get_saas_contrato_account_to_string()
    {
        if(!empty($this->saas_contrato_account_to_string))
        {
            return $this->saas_contrato_account_to_string;
        }
    
        $values = SaasContrato::where('saas_contrato_status_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_saas_contrato_status_to_string($saas_contrato_saas_contrato_status_to_string)
    {
        if(is_array($saas_contrato_saas_contrato_status_to_string))
        {
            $values = SaasContratoStatus::where('id', 'in', $saas_contrato_saas_contrato_status_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_contrato_saas_contrato_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_saas_contrato_status_to_string = $saas_contrato_saas_contrato_status_to_string;
        }

        $this->vdata['saas_contrato_saas_contrato_status_to_string'] = $this->saas_contrato_saas_contrato_status_to_string;
    }

    public function get_saas_contrato_saas_contrato_status_to_string()
    {
        if(!empty($this->saas_contrato_saas_contrato_status_to_string))
        {
            return $this->saas_contrato_saas_contrato_status_to_string;
        }
    
        $values = SaasContrato::where('saas_contrato_status_id', '=', $this->id)->getIndexedArray('saas_contrato_status_id','{saas_contrato_status->nome}');
        return implode(', ', $values);
    }

    
}

