<?php

class Especialidade extends TRecord
{
    const TABLENAME  = 'especialidade';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Clinica $clinica;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByUnit');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('clinica_id');
        parent::addAttribute('descricao');
    
    }

    /**
     * Method set_clinica
     * Sample of usage: $var->clinica = $object;
     * @param $object Instance of Clinica
     */
    public function set_clinica(Clinica $object)
    {
        $this->clinica = $object;
        $this->clinica_id = $object->id;
    }

    /**
     * Method get_clinica
     * Sample of usage: $var->clinica->attribute;
     * @returns Clinica instance
     */
    public function get_clinica()
    {
    
        // loads the associated object
        if (empty($this->clinica))
            $this->clinica = new Clinica($this->clinica_id);
    
        // returns the associated object
        return $this->clinica;
    }

    /**
     * Method getAgendamentos
     */
    public function getAgendamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('especialidade_id', '=', $this->id));
        return Agendamento::getObjects( $criteria );
    }
    /**
     * Method getPessoaEspecialidades
     */
    public function getPessoaEspecialidades()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('especialidade_id', '=', $this->id));
        return PessoaEspecialidade::getObjects( $criteria );
    }

    public function set_agendamento_paciente_to_string($agendamento_paciente_to_string)
    {
        if(is_array($agendamento_paciente_to_string))
        {
            $values = Pessoa::where('id', 'in', $agendamento_paciente_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_paciente_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_paciente_to_string = $agendamento_paciente_to_string;
        }

        $this->vdata['agendamento_paciente_to_string'] = $this->agendamento_paciente_to_string;
    }

    public function get_agendamento_paciente_to_string()
    {
        if(!empty($this->agendamento_paciente_to_string))
        {
            return $this->agendamento_paciente_to_string;
        }
    
        $values = Agendamento::where('especialidade_id', '=', $this->id)->getIndexedArray('paciente_id','{paciente->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_estado_agenda_to_string($agendamento_estado_agenda_to_string)
    {
        if(is_array($agendamento_estado_agenda_to_string))
        {
            $values = EstadoAgenda::where('id', 'in', $agendamento_estado_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_estado_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_estado_agenda_to_string = $agendamento_estado_agenda_to_string;
        }

        $this->vdata['agendamento_estado_agenda_to_string'] = $this->agendamento_estado_agenda_to_string;
    }

    public function get_agendamento_estado_agenda_to_string()
    {
        if(!empty($this->agendamento_estado_agenda_to_string))
        {
            return $this->agendamento_estado_agenda_to_string;
        }
    
        $values = Agendamento::where('especialidade_id', '=', $this->id)->getIndexedArray('estado_agenda_id','{estado_agenda->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_agenda_to_string($agendamento_agenda_to_string)
    {
        if(is_array($agendamento_agenda_to_string))
        {
            $values = Agenda::where('id', 'in', $agendamento_agenda_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_agenda_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_agenda_to_string = $agendamento_agenda_to_string;
        }

        $this->vdata['agendamento_agenda_to_string'] = $this->agendamento_agenda_to_string;
    }

    public function get_agendamento_agenda_to_string()
    {
        if(!empty($this->agendamento_agenda_to_string))
        {
            return $this->agendamento_agenda_to_string;
        }
    
        $values = Agendamento::where('especialidade_id', '=', $this->id)->getIndexedArray('agenda_id','{agenda->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_clinica_to_string($agendamento_clinica_to_string)
    {
        if(is_array($agendamento_clinica_to_string))
        {
            $values = Clinica::where('id', 'in', $agendamento_clinica_to_string)->getIndexedArray('nome', 'nome');
            $this->agendamento_clinica_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_clinica_to_string = $agendamento_clinica_to_string;
        }

        $this->vdata['agendamento_clinica_to_string'] = $this->agendamento_clinica_to_string;
    }

    public function get_agendamento_clinica_to_string()
    {
        if(!empty($this->agendamento_clinica_to_string))
        {
            return $this->agendamento_clinica_to_string;
        }
    
        $values = Agendamento::where('especialidade_id', '=', $this->id)->getIndexedArray('clinica_id','{clinica->nome}');
        return implode(', ', $values);
    }

    public function set_agendamento_especialidade_to_string($agendamento_especialidade_to_string)
    {
        if(is_array($agendamento_especialidade_to_string))
        {
            $values = Especialidade::where('id', 'in', $agendamento_especialidade_to_string)->getIndexedArray('descricao', 'descricao');
            $this->agendamento_especialidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->agendamento_especialidade_to_string = $agendamento_especialidade_to_string;
        }

        $this->vdata['agendamento_especialidade_to_string'] = $this->agendamento_especialidade_to_string;
    }

    public function get_agendamento_especialidade_to_string()
    {
        if(!empty($this->agendamento_especialidade_to_string))
        {
            return $this->agendamento_especialidade_to_string;
        }
    
        $values = Agendamento::where('especialidade_id', '=', $this->id)->getIndexedArray('especialidade_id','{especialidade->descricao}');
        return implode(', ', $values);
    }

    public function set_pessoa_especialidade_pessoa_to_string($pessoa_especialidade_pessoa_to_string)
    {
        if(is_array($pessoa_especialidade_pessoa_to_string))
        {
            $values = Pessoa::where('id', 'in', $pessoa_especialidade_pessoa_to_string)->getIndexedArray('nome', 'nome');
            $this->pessoa_especialidade_pessoa_to_string = implode(', ', $values);
        }
        else
        {
            $this->pessoa_especialidade_pessoa_to_string = $pessoa_especialidade_pessoa_to_string;
        }

        $this->vdata['pessoa_especialidade_pessoa_to_string'] = $this->pessoa_especialidade_pessoa_to_string;
    }

    public function get_pessoa_especialidade_pessoa_to_string()
    {
        if(!empty($this->pessoa_especialidade_pessoa_to_string))
        {
            return $this->pessoa_especialidade_pessoa_to_string;
        }
    
        $values = PessoaEspecialidade::where('especialidade_id', '=', $this->id)->getIndexedArray('pessoa_id','{pessoa->nome}');
        return implode(', ', $values);
    }

    public function set_pessoa_especialidade_especialidade_to_string($pessoa_especialidade_especialidade_to_string)
    {
        if(is_array($pessoa_especialidade_especialidade_to_string))
        {
            $values = Especialidade::where('id', 'in', $pessoa_especialidade_especialidade_to_string)->getIndexedArray('descricao', 'descricao');
            $this->pessoa_especialidade_especialidade_to_string = implode(', ', $values);
        }
        else
        {
            $this->pessoa_especialidade_especialidade_to_string = $pessoa_especialidade_especialidade_to_string;
        }

        $this->vdata['pessoa_especialidade_especialidade_to_string'] = $this->pessoa_especialidade_especialidade_to_string;
    }

    public function get_pessoa_especialidade_especialidade_to_string()
    {
        if(!empty($this->pessoa_especialidade_especialidade_to_string))
        {
            return $this->pessoa_especialidade_especialidade_to_string;
        }
    
        $values = PessoaEspecialidade::where('especialidade_id', '=', $this->id)->getIndexedArray('especialidade_id','{especialidade->descricao}');
        return implode(', ', $values);
    }

}

