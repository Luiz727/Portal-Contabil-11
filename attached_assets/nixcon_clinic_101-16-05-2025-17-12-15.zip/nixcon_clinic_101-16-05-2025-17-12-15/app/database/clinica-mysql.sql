CREATE TABLE account( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `cidade_id` int   , 
      `system_user_id` int   , 
      `nome_responsavel` text   NOT NULL  , 
      `razao_social` text   NOT NULL  , 
      `tipo_pessoa` char  (1)     DEFAULT 'J', 
      `documento` text   , 
      `email` text   , 
      `telefone` text   , 
      `cep` text   , 
      `rua` text   , 
      `numero` text   , 
      `complemento` text   , 
      `bairro` text   , 
      `mes_criacao` int   , 
      `ano_criacao` int   , 
      `created_at` datetime   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE agenda( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `profissional_id` int   NOT NULL  , 
      `nome` text   NOT NULL  , 
      `horario_inicial` time   NOT NULL  , 
      `horario_final` time   NOT NULL  , 
      `visualizacao_inicial` varchar  (30)   NOT NULL    DEFAULT 'agendaWeek', 
      `horario_inicio_intervalo` time   , 
      `horario_fim_intervalo` time   , 
      `duracao` int   NOT NULL    DEFAULT 30, 
      `dias` text   NOT NULL  , 
      `procedimento_id` int   , 
      `cor` varchar  (10)   , 
      `aceita_agendamento_online` char  (1)     DEFAULT 'F', 
      `publica` char  (1)     DEFAULT 'F', 
      `fl_permite_choque_horario` char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE agendamento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `paciente_id` int   NOT NULL  , 
      `estado_agenda_id` int   NOT NULL  , 
      `agenda_id` int   NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `especialidade_id` int   , 
      `dt_inicial` datetime   NOT NULL  , 
      `dt_final` datetime   NOT NULL  , 
      `agendamento_original_id` int   , 
      `observacao` text   , 
      `ativo` char  (1)     DEFAULT 'T', 
      `ano_inicial` text   , 
      `mes_inicial` text   , 
      `ano_mes_inicial` text   , 
      `ano_final` text   , 
      `mes_final` text   , 
      `ano_mes_final` text   , 
      `online` char  (1)     DEFAULT 'F', 
      `link_atendimento_online` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE agendamento_procedimento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `agendamento_id` int   NOT NULL  , 
      `procedimento_id` int   NOT NULL  , 
      `convenio_id` int   NOT NULL  , 
      `quantidade` double   NOT NULL  , 
      `valor` double   , 
      `valor_total` double   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE agenda_profissional( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `profissional_id` int   NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `agenda_id` int   NOT NULL  , 
      `fl_manipula_atendimento` char  (1)   NOT NULL    DEFAULT 'N', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE anexo( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `atendimento_id` int   NOT NULL  , 
      `arquivo` text   NOT NULL  , 
      `observacao` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE atendimento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `agendamento_id` int   NOT NULL  , 
      `paciente_id` int   NOT NULL  , 
      `profissional_id` int   NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `dt_inicio` datetime   NOT NULL  , 
      `dt_final` datetime   , 
      `valor_total` double   , 
      `ano_inicial` text   , 
      `mes_inicial` text   , 
      `ano_mes_inicial` text   , 
      `mes_final` text   , 
      `ano_final` text   , 
      `ano_mes_final` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE atendimento_material( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `material_id` int   NOT NULL  , 
      `atendimento_id` int   NOT NULL  , 
      `quantidade` double   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE atendimento_procedimento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `convenio_id` int   NOT NULL  , 
      `atendimento_id` int   NOT NULL  , 
      `procedimento_id` int   NOT NULL  , 
      `quantidade` double   NOT NULL  , 
      `valor` double   , 
      `valor_total` double   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE bloqueio( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `agenda_id` int   NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `dt_inicio` datetime   NOT NULL  , 
      `dt_final` datetime   NOT NULL  , 
      `observacao` text   , 
      `horario_bloqueio_original` int   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE categoria_conta( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `tipo_conta_id` int   NOT NULL  , 
      `account_id` int   NOT NULL  , 
      `nome` text   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE cep_cache( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `cep` varchar  (12)   NOT NULL  , 
      `codigo_ibge` text   , 
      `rua` text   , 
      `cidade` text   , 
      `uf` text   , 
      `cidade_id` int   , 
      `bairro` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE cidade( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `estado_id` int   NOT NULL  , 
      `nome` text   NOT NULL  , 
      `codigo_ibge` text   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE clinica( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `system_unit_id` int   , 
      `atendimento_categoria_conta_id` int   , 
      `cidade_id` int   , 
      `account_id` int   , 
      `token` text   , 
      `nome` text   NOT NULL  , 
      `cnpj` text   , 
      `telefone` text   , 
      `email` text   NOT NULL  , 
      `endereco` text   , 
      `bairro` text   , 
      `cep` text   , 
      `numero` text   , 
      `complemento` text   , 
      `logo_documento` text   , 
      `nfse_serie` text   , 
      `razao_social` varchar  (255)   , 
      `nfse_info` text   , 
      `nfse_numero` text   , 
      `regime_tributacao` text   , 
      `token_integra_notas` text   , 
      `token_integra_notas_homologacao` text   , 
      `nfse_emissao_producao` char  (1)     DEFAULT 'F', 
      `certificado_a1_conteudo` text   , 
      `senha_certificado_a1` text   , 
      `certificado_a1_nome` text   , 
      `emitente_configurado` char  (1)     DEFAULT 'F', 
      `validade_certificado` date   , 
      `logo_horizontal_grande` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE clinica_convenio( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `convenio_id` int   NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE conta( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `pessoa_id` int   NOT NULL  , 
      `categoria_conta_id` int   , 
      `tipo_conta_id` int   NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `atendimento_id` int   , 
      `data_emissao` date   NOT NULL  , 
      `total_parcelas` int   NOT NULL    DEFAULT 1, 
      `quitada` char  (1)   NOT NULL    DEFAULT 'F', 
      `descricao` text   NOT NULL  , 
      `conta_origem_id` int   , 
      `total_conta` double   NOT NULL  , 
      `mes` text   , 
      `ano` text   , 
      `ano_mes` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE convenio( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `account_id` int   NOT NULL  , 
      `nome` text   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE documento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `atendimento_id` int   NOT NULL  , 
      `tipo_documento_id` int   NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `procedimento_id` int   , 
      `texto` text   NOT NULL  , 
      `dt_preenchimento` datetime   NOT NULL  , 
      `autenticador` text   , 
      `dt_validade` date   NOT NULL  , 
      `medico_assistente` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE email_config( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `port` text   , 
      `username` text   , 
      `password` text   , 
      `host` text   , 
      `from_email` text   , 
      `from_name` text   , 
      `smtp_auth` char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE especialidade( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `descricao` text   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE estado( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
      `sigla` char  (2)   NOT NULL  , 
      `codigo_ibge` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE estado_agenda( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
      `estado_inicial` char  (1)   NOT NULL    DEFAULT 'N', 
      `estado_final` char  (1)   NOT NULL    DEFAULT 'N', 
      `cor` varchar  (10)   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE estado_agendamento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `agendamento_id` int   NOT NULL  , 
      `estado_agenda_id` int   NOT NULL  , 
      `system_users_id` int   , 
      `atribuido_em` datetime   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE exame( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `ativo` char  (1)   NOT NULL    DEFAULT 'T', 
      `nome` text   NOT NULL  , 
      `codigo_referencia` text   , 
      `clinica_id` int   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE exame_atendimento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `atendimento_id` int   NOT NULL  , 
      `exame_id` int   NOT NULL  , 
      `indicacao_clinica` text   NOT NULL  , 
      `dt_exames` date   NOT NULL  , 
      `quantidade` int   NOT NULL    DEFAULT 1, 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE formulario( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `nome` text   NOT NULL  , 
      `ativo` char  (1)   NOT NULL    DEFAULT 'T', 
      `ordem` int   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE grupo( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
      `cor` varchar  (10)   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE imposto( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
      `codigo` text   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE lancamento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `conta_id` int   NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `tipo_pagamento_id` int   , 
      `nota_fiscal_servico_id` int   , 
      `parcela` int   NOT NULL    DEFAULT 1, 
      `dt_vencimento` date   NOT NULL  , 
      `valor` double   NOT NULL  , 
      `dt_pagamento` date   , 
      `ano_pagamento` text   , 
      `mes_pagamento` text   , 
      `ano_mes_pagamento` text   , 
      `ano_vencimento` text   , 
      `mes_vencimento` text   , 
      `ano_mes_vencimento` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE material( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `unidade_medida_id` int   NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `nome` text   NOT NULL  , 
      `estoque_minimo` double   , 
      `dt_vencimento` date   , 
      `estoque_atualizado` double   , 
      `lote` text   , 
      `ativo` char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE medicamento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `prescricao_id` int   NOT NULL  , 
      `medicamento` text   NOT NULL  , 
      `quantidade` text   NOT NULL  , 
      `posologia` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE mensagem( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `agendamento_id` int   NOT NULL  , 
      `template_clinica_id` int   , 
      `system_user_id` int   NOT NULL  , 
      `titulo` text   , 
      `template` text   , 
      `enviado_em` datetime   , 
      `tipo_mensagem` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE mensagem_acao( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `mensagem_id` int   NOT NULL  , 
      `url` text   , 
      `label` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE movimentacao( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `material_id` int   NOT NULL  , 
      `system_user_id` int   NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `dt_movimentacao` text   , 
      `quantidade` double   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE nota_fiscal_servico( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `cidade_tomador_id` int   NOT NULL  , 
      `cidade_prestador_id` int   NOT NULL  , 
      `municipio_prestacao_servico_id` int   NOT NULL  , 
      `nota_fiscal_status_id` int   NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `cliente_id` int   NOT NULL  , 
      `conta_id` int   , 
      `lancamento_id` int   , 
      `natureza_operacao` text   , 
      `data_hora_emissao` datetime   NOT NULL  , 
      `discriminacao` text   NOT NULL  , 
      `numero` text   , 
      `codigo_verificacao` text   , 
      `id_gateway_externo` text   , 
      `dados_gateway_externo` text   , 
      `nome_tomador` text   NOT NULL  , 
      `documento_tomador` text   NOT NULL  , 
      `endereco_tomador` text   NOT NULL  , 
      `email_tomador` text   NOT NULL  , 
      `telefone_tomador` text   , 
      `numero_tomador` text   NOT NULL  , 
      `bairro_tomador` text   NOT NULL  , 
      `cep_tomador` text   NOT NULL  , 
      `inscricao_municipal_tomador` text   , 
      `inscricao_municipal_prestador` text   , 
      `nome_prestador` text   NOT NULL  , 
      `documento_prestador` text   NOT NULL  , 
      `endereco_prestador` text   NOT NULL  , 
      `email_prestador` text   NOT NULL  , 
      `telefone_prestador` text   , 
      `numero_prestador` text   NOT NULL  , 
      `bairro_prestador` text   NOT NULL  , 
      `cep_prestador` text   NOT NULL  , 
      `iss_retido` char  (1)     DEFAULT 'F', 
      `desconto_incondicionado` double     DEFAULT 0.00, 
      `desconto_condicionado` double     DEFAULT 0.00, 
      `base_calculo_iss` double   , 
      `aliquota_iss` double   , 
      `aliquota_pis` double   , 
      `aliquota_cofins` double   , 
      `aliquota_csll` double   , 
      `aliquota_irrf` double   , 
      `aliquota_inss` double   , 
      `valor_deducoes` double   , 
      `valor_retencoes` double   , 
      `valor_outras_retencoes` double   , 
      `valor_liquido` double   , 
      `valor_servicos` double   , 
      `valor_iss` double   , 
      `valor_pis` double     DEFAULT 0.00, 
      `valor_inss` double     DEFAULT 0.00, 
      `valor_cofins` double     DEFAULT 0.00, 
      `valor_csll` double   , 
      `valor_irrf` double     DEFAULT 0.00, 
      `incentivador_cultural` char  (1)     DEFAULT 'F', 
      `optante_simples_nacional` char  (1)     DEFAULT 'F', 
      `nfse_status` text   , 
      `ano` text   , 
      `mes` text   , 
      `ano_mes` text   , 
      `pdf` text   , 
      `xml` text   , 
      `link_pdf_prefeitura` text   , 
      `regime_tributario_municipal` text   , 
      `numero_rps` text   , 
      `mensagem_erro` text   , 
      `email_enviado` char  (1)     DEFAULT 'F', 
      `servico_id` int   NOT NULL  , 
      `serie_rps` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE nota_fiscal_status( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
      `cor` text   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE pessoa( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `nome` varchar  (255)   NOT NULL  , 
      `documento` text   , 
      `email` varchar  (255)   , 
      `telefone` varchar  (20)   , 
      `system_users_id` int   , 
      `sexo` char  (1)   , 
      `nome_civel` varchar  (255)   , 
      `rg` text   , 
      `dt_nascimento` date   , 
      `profissao` text   , 
      `tratamento` text   , 
      `observacao` text   , 
      `assinatura` text   , 
      `usuario` varchar  (255)   , 
      `senha` varchar  (255)   , 
      `foto` text   , 
      `aceita_receber_mensagen_whatsapp` char  (1)   NOT NULL    DEFAULT 'F', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE pessoa_endereco( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `pessoa_id` int   NOT NULL  , 
      `cidade_id` int   NOT NULL  , 
      `cep` varchar  (10)   NOT NULL  , 
      `rua` varchar  (500)   NOT NULL  , 
      `bairro` varchar  (500)   NOT NULL  , 
      `numero` varchar  (100)   NOT NULL  , 
      `complemento` varchar  (500)   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE pessoa_especialidade( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `pessoa_id` int   NOT NULL  , 
      `especialidade_id` int   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE pessoa_grupo( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `pessoa_id` int   NOT NULL  , 
      `grupo_id` int   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE prescricao( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `atendimento_id` int   NOT NULL  , 
      `controle_especial` char  (1)   NOT NULL    DEFAULT 'N', 
      `dt_prescricao` date   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE procedimento( 
      `id` int   NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `nome` text   NOT NULL  , 
      `cor` varchar  (10)   NOT NULL  , 
      `duracao` time   , 
      `codigo_referencia` text   , 
      `ativo` char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE procedimento_material( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `procedimento_id` int   NOT NULL  , 
      `material_id` int   NOT NULL  , 
      `quantidade` double   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE procedimento_preco( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `procedimento_id` int   NOT NULL  , 
      `convenio_id` int   NOT NULL  , 
      `valor` double   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE questao( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `formulario_id` int   NOT NULL  , 
      `nome` text   NOT NULL  , 
      `tipo_campo` text   NOT NULL  , 
      `fl_obrigatorio` char  (1)   NOT NULL    DEFAULT 'F', 
      `ativo` char  (1)   NOT NULL    DEFAULT 'T', 
      `opcoes` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE resposta( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `resposta_formulario_id` int   NOT NULL  , 
      `questao_id` int   NOT NULL  , 
      `resposta` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE resposta_formulario( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `formulario_id` int   NOT NULL  , 
      `atendimento_id` int   NOT NULL  , 
      `dt_resposta` date   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_configuracao( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `cidade_id` int   , 
      `saas_plano_valor_trial_id` int   , 
      `contrato_inativo_system_group_id` int   , 
      `parametro_fiscal_id` int   , 
      `razao_social` text   , 
      `nome_fantasia` text   , 
      `cnpj` text   , 
      `inscricao_estadual` text   , 
      `inscricao_municipal` text   , 
      `cep` text   , 
      `rua` text   , 
      `bairro` text   , 
      `numero` text   , 
      `complemento` text   , 
      `email` text   NOT NULL  , 
      `telefone` text   NOT NULL  , 
      `dias_trial` int   , 
      `contrato` text   , 
      `regime_tributacao` text   , 
      `token_integra_notas` text   , 
      `token_integra_notas_homologacao` text   , 
      `nfse_emissao_producao` char  (1)   NOT NULL    DEFAULT 'F', 
      `nfse_numero` text   , 
      `nfse_serie` text   , 
      `nfse_info` text   , 
      `termo_uso` text   , 
      `email_port` text   , 
      `email_username` text   , 
      `email_password` text   , 
      `email_host` text   , 
      `email_from` text   , 
      `email_from_name` text   , 
      `email_smtp_auth` char  (1)     DEFAULT 'F', 
      `dias_renovacao_contrato` int   , 
      `dias_vencimento_pagamento` int   , 
      `token_integra_notas_software_house` text   , 
      `url_sistema` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_contrato( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `saas_plano_valor_id` int   NOT NULL  , 
      `account_id` int   NOT NULL  , 
      `saas_contrato_status_id` int   NOT NULL  , 
      `valor_total` double   , 
      `data_inicial` date   NOT NULL  , 
      `data_final` date   , 
      `criado_em` datetime   , 
      `renovacao` char  (1)     DEFAULT 'F', 
      `total_usuarios` int   , 
      `total_unidades` int   , 
      `gateway_assinatura_id` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_contrato_grupo( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `saas_contrato_id` int   NOT NULL  , 
      `system_group_id` int   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_contrato_status( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
      `cor` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_email_log( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `titulo` text   , 
      `conteudo` text   , 
      `destinatario` text   , 
      `created_at` datetime   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_error_log( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `system_unit_id` int   , 
      `system_user_id` int   , 
      `error_class` varchar  (255)   , 
      `error_method` varchar  (255)   , 
      `message` text   , 
      `payload` text   , 
      `created_at` datetime   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_forma_pagamento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_gateway_forma_pagamento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `saas_forma_pagamento_id` int   NOT NULL  , 
      `saas_gateway_pagamento_id` int   NOT NULL  , 
      `codigo` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_gateway_pagamento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
      `ativo` char  (1)   NOT NULL    DEFAULT 'T', 
      `public_key` text   , 
      `access_token` text   , 
      `client_secret` text   , 
      `client_id` text   , 
      `oauth_token` text   , 
      `oauth_token_created_at` datetime   , 
      `certificado_crt` text   , 
      `certificado_key` text   , 
      `webhook_url` text   , 
      `webhook_certificado_cert` text   , 
      `fl_homologacao` char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_gateway_pagamento_status( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `saas_gateway_pagamento_id` int   NOT NULL  , 
      `saas_status_pagamento_id` int   NOT NULL  , 
      `codigo` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_imposto( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
      `codigo` text   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_nota_fiscal_servico( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `saas_pagamento_id` int   , 
      `saas_plano_valor_id` int   , 
      `saas_servico_id` int   , 
      `cidade_tomador_id` int   NOT NULL  , 
      `cidade_prestador_id` int   NOT NULL  , 
      `municipio_prestacao_servico_id` int   NOT NULL  , 
      `nota_fiscal_status_id` int   NOT NULL  , 
      `account_id` int   NOT NULL  , 
      `natureza_operacao` text   , 
      `data_hora_emissao` datetime   NOT NULL  , 
      `discriminacao` text   NOT NULL  , 
      `numero` text   , 
      `codigo_verificacao` text   , 
      `id_gateway_externo` text   , 
      `dados_gateway_externo` text   , 
      `nome_tomador` text   NOT NULL  , 
      `documento_tomador` text   NOT NULL  , 
      `endereco_tomador` text   NOT NULL  , 
      `email_tomador` text   NOT NULL  , 
      `telefone_tomador` text   , 
      `numero_tomador` text   NOT NULL  , 
      `bairro_tomador` text   NOT NULL  , 
      `cep_tomador` text   NOT NULL  , 
      `inscricao_municipal_tomador` text   , 
      `inscricao_municipal_prestador` text   , 
      `nome_prestador` text   NOT NULL  , 
      `documento_prestador` text   NOT NULL  , 
      `endereco_prestador` text   NOT NULL  , 
      `email_prestador` text   NOT NULL  , 
      `telefone_prestador` text   , 
      `numero_prestador` text   NOT NULL  , 
      `bairro_prestador` text   NOT NULL  , 
      `cep_prestador` text   NOT NULL  , 
      `iss_retido` char  (1)     DEFAULT 'F', 
      `desconto_incondicionado` double     DEFAULT 0.00, 
      `desconto_condicionado` double     DEFAULT 0.00, 
      `base_calculo_iss` double   , 
      `aliquota_iss` double   , 
      `aliquota_pis` double   , 
      `aliquota_cofins` double   , 
      `aliquota_csll` double   , 
      `aliquota_irrf` double   , 
      `aliquota_inss` double   , 
      `valor_deducoes` double   , 
      `valor_retencoes` double   , 
      `valor_outras_retencoes` double   , 
      `valor_liquido` double   , 
      `valor_servicos` double   , 
      `valor_iss` double   , 
      `valor_pis` double     DEFAULT 0.00, 
      `valor_inss` double     DEFAULT 0.00, 
      `valor_cofins` double     DEFAULT 0.00, 
      `valor_csll` double   , 
      `valor_irrf` double     DEFAULT 0.00, 
      `incentivador_cultural` char  (1)     DEFAULT 'F', 
      `optante_simples_nacional` char  (1)     DEFAULT 'F', 
      `nfse_status` text   , 
      `ano` text   , 
      `mes` text   , 
      `ano_mes` text   , 
      `pdf` text   , 
      `xml` text   , 
      `link_pdf_prefeitura` text   , 
      `regime_tributario_municipal` text   , 
      `numero_rps` text   , 
      `mensagem_erro` text   , 
      `email_enviado` char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_pagamento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `account_id` int   NOT NULL  , 
      `saas_status_pagamento_id` int   NOT NULL  , 
      `saas_contrato_id` int   , 
      `saas_servico_id` int   , 
      `saas_forma_pagamento_id` int   NOT NULL  , 
      `saas_gateway_pagamento_id` int   NOT NULL  , 
      `saas_nota_fiscal_servico_id` int   , 
      `valor` double   NOT NULL  , 
      `data_compra` datetime   NOT NULL  , 
      `data_vencimento` date   , 
      `data_pagamento` date   , 
      `dados_gateway` text   , 
      `id_gateway` text   , 
      `payment_id` text   , 
      `link_gateway` text   , 
      `mes_compra` int   , 
      `ano_compra` int   , 
      `ano_pagamento` int   , 
      `mes_pagamento` int   , 
      `mes_ano_pagamento` text   , 
      `mes_ano_compra` text   , 
      `renovacao` char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_plano( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `saas_servico_id` int   , 
      `nome` text   NOT NULL  , 
      `descricao` text   NOT NULL  , 
      `ativo` char  (1)   NOT NULL    DEFAULT 'T', 
      `limite_usuarios` int   , 
      `limite_unidades` int   , 
      `discriminacao` text   , 
      `ordem` int   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_plano_grupo( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `saas_plano_id` int   NOT NULL  , 
      `system_group_id` int   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_plano_valor( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `saas_plano_id` int   NOT NULL  , 
      `valor` double   NOT NULL  , 
      `nome` text   NOT NULL  , 
      `duracao` int   , 
      `ativo` char  (1)     DEFAULT 'T', 
      `desativado_em` datetime   , 
      `recorrencia` char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_servico( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `servico_grupo_imposto_id` int   , 
      `nome` text   NOT NULL  , 
      `preco` double   , 
      `descricao` text   NOT NULL  , 
      `ativo` char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_servico_grupo_imposto( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
      `codigo_cnae` text   , 
      `codigo_tributacao_municipio` text   , 
      `codigo_nbs` text   , 
      `codigo` text   , 
      `descricao_servico_municipio` text   , 
      `iss_retido` text   , 
      `natureza_operacao` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_servico_grupo_imposto_item( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `saas_servico_grupo_imposto_id` int   NOT NULL  , 
      `saas_imposto_id` int   NOT NULL  , 
      `aliquota` double   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_status_pagamento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
      `cor` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE saas_template_email( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `descricao` text   , 
      `titulo` text   , 
      `conteudo` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE servico( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `account_id` int   NOT NULL  , 
      `nome` text   NOT NULL  , 
      `descricao` text   , 
      `codigo_cnae` text   , 
      `codigo_tributacao_municipio` text   , 
      `codigo_nbs` text   , 
      `codigo` text   , 
      `descricao_servico_municipio` text   , 
      `iss_retido` text   , 
      `natureza_operacao` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE servico_imposto_item( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `servico_id` int   NOT NULL  , 
      `imposto_id` int   NOT NULL  , 
      `aliquota` double   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_document( 
      `id` int   NOT NULL  , 
      `category_id` int   NOT NULL  , 
      `system_user_id` int   , 
      `title` text   NOT NULL  , 
      `description` text   , 
      `submission_date` date   , 
      `archive_date` date   , 
      `filename` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_document_category( 
      `id` int   NOT NULL  , 
      `name` text   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_document_group( 
      `id` int   NOT NULL  , 
      `document_id` int   NOT NULL  , 
      `system_group_id` int   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_document_user( 
      `id` int   NOT NULL  , 
      `document_id` int   NOT NULL  , 
      `system_user_id` int   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_group( 
      `id` int   NOT NULL  , 
      `name` text   NOT NULL  , 
      `uuid` varchar  (36)   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_group_program( 
      `id` int   NOT NULL  , 
      `system_group_id` int   NOT NULL  , 
      `system_program_id` int   NOT NULL  , 
      `actions` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_message( 
      `id` int   NOT NULL  , 
      `system_user_id` int   NOT NULL  , 
      `system_user_to_id` int   NOT NULL  , 
      `subject` text   NOT NULL  , 
      `message` text   , 
      `dt_message` datetime   , 
      `checked` char  (1)   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_notification( 
      `id` int   NOT NULL  , 
      `system_user_id` int   NOT NULL  , 
      `system_user_to_id` int   NOT NULL  , 
      `subject` text   , 
      `message` text   , 
      `dt_message` datetime   , 
      `action_url` text   , 
      `action_label` text   , 
      `icon` text   , 
      `checked` char  (1)   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_preference( 
      `id` varchar  (255)   NOT NULL  , 
      `preference` text   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_program( 
      `id` int   NOT NULL  , 
      `name` text   NOT NULL  , 
      `controller` text   NOT NULL  , 
      `actions` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_unit( 
      `id` int   NOT NULL  , 
      `account_id` int   , 
      `name` text   NOT NULL  , 
      `connection_name` text   , 
      `active` char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_user_group( 
      `id` int   NOT NULL  , 
      `system_user_id` int   NOT NULL  , 
      `system_group_id` int   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_user_program( 
      `id` int   NOT NULL  , 
      `system_user_id` int   NOT NULL  , 
      `system_program_id` int   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_users( 
      `id` int   NOT NULL  , 
      `name` text   NOT NULL  , 
      `login` text   NOT NULL  , 
      `password` text   NOT NULL  , 
      `email` text   , 
      `frontpage_id` int   , 
      `system_unit_id` int   , 
      `account_id` int   , 
      `active` char  (1)   , 
      `accepted_term_policy` char  (1)   , 
      `accepted_term_policy_at` text   , 
      `two_factor_enabled` char  (1)     DEFAULT 'N', 
      `two_factor_type` varchar  (100)   , 
      `two_factor_secret` varchar  (255)   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE system_user_unit( 
      `id` int   NOT NULL  , 
      `system_user_id` int   NOT NULL  , 
      `system_unit_id` int   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE template_acao( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `template_clinica_id` int   NOT NULL  , 
      `url` text   , 
      `label` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE template_clinica( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `chave` text   NOT NULL  , 
      `descricao` text   NOT NULL  , 
      `habilitado` char  (1)   NOT NULL    DEFAULT 'T', 
      `template` text   , 
      `titulo` text   , 
      `tipo_template` text   , 
      `readonly` char  (1)   NOT NULL    DEFAULT 'F', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE tipo_conta( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE tipo_documento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `nome` text   NOT NULL  , 
      `texto_padrao` text   NOT NULL  , 
      `ativo` char  (1)   NOT NULL    DEFAULT 'S', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE tipo_pagamento( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `account_id` int   NOT NULL  , 
      `nome` text   NOT NULL  , 
      `ativo` char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE unidade_medida( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` text   NOT NULL  , 
      `sigla` text   NOT NULL  , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE webhook_log( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `gateway_pagamento_id` int   , 
      `payload` text   , 
      `created_at` datetime   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE whatsapp_config( 
      `id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `clinica_id` int   NOT NULL  , 
      `phone` text   , 
      `status` text   , 
      `api_token` text   , 
      `api_key` text   , 
      `api_client_token` text   , 
 PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

 
 ALTER TABLE cep_cache ADD UNIQUE (cep);
  
 ALTER TABLE account ADD CONSTRAINT fk_account_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE account ADD CONSTRAINT fk_account_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE agenda ADD CONSTRAINT fk_agenda_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE agenda ADD CONSTRAINT fk_agenda_2 FOREIGN KEY (profissional_id) references pessoa(id); 
ALTER TABLE agenda ADD CONSTRAINT fk_agenda_3 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_5 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_1 FOREIGN KEY (paciente_id) references pessoa(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_2 FOREIGN KEY (estado_agenda_id) references estado_agenda(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_3 FOREIGN KEY (agenda_id) references agenda(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_4 FOREIGN KEY (especialidade_id) references especialidade(id); 
ALTER TABLE agendamento_procedimento ADD CONSTRAINT fk_agendamento_procedimento_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE agendamento_procedimento ADD CONSTRAINT fk_agendamento_procedimento_2 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE agendamento_procedimento ADD CONSTRAINT fk_agendamento_procedimento_3 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE agenda_profissional ADD CONSTRAINT fk_agenda_profissional_3 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE agenda_profissional ADD CONSTRAINT fk_agenda_profissional_1 FOREIGN KEY (profissional_id) references pessoa(id); 
ALTER TABLE agenda_profissional ADD CONSTRAINT fk_agenda_profissional_2 FOREIGN KEY (agenda_id) references agenda(id); 
ALTER TABLE anexo ADD CONSTRAINT fk_anexo_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_4 FOREIGN KEY (clinica_id) references system_unit(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_2 FOREIGN KEY (paciente_id) references pessoa(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_3 FOREIGN KEY (profissional_id) references pessoa(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE atendimento_material ADD CONSTRAINT fk_atendimento_material_1 FOREIGN KEY (material_id) references material(id); 
ALTER TABLE atendimento_material ADD CONSTRAINT fk_atendimento_material_2 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE atendimento_procedimento ADD CONSTRAINT fk_atendimento_procedimento_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE atendimento_procedimento ADD CONSTRAINT fk_atendimento_procedimento_2 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE atendimento_procedimento ADD CONSTRAINT fk_atendimento_procedimento_3 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE bloqueio ADD CONSTRAINT fk_bloqueio_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE bloqueio ADD CONSTRAINT fk_bloqueio_1 FOREIGN KEY (agenda_id) references agenda(id); 
ALTER TABLE categoria_conta ADD CONSTRAINT fk_categoria_conta_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE categoria_conta ADD CONSTRAINT fk_categoria_conta_1 FOREIGN KEY (tipo_conta_id) references tipo_conta(id); 
ALTER TABLE cidade ADD CONSTRAINT fk_cidade_1 FOREIGN KEY (estado_id) references estado(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_3 FOREIGN KEY (atendimento_categoria_conta_id) references categoria_conta(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_4 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE clinica_convenio ADD CONSTRAINT fk_clinica_convenio_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE clinica_convenio ADD CONSTRAINT fk_clinica_convenio_1 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_3 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_4 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_5 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_2 FOREIGN KEY (tipo_conta_id) references tipo_conta(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_1 FOREIGN KEY (categoria_conta_id) references categoria_conta(id); 
ALTER TABLE convenio ADD CONSTRAINT fk_convenio_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_1 FOREIGN KEY (tipo_documento_id) references tipo_documento(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_2 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_3 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_4 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE email_config ADD CONSTRAINT fk_email_config_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE especialidade ADD CONSTRAINT fk_especialidade_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE estado_agendamento ADD CONSTRAINT fk_estado_agendamento_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE estado_agendamento ADD CONSTRAINT fk_estado_agendamento_2 FOREIGN KEY (estado_agenda_id) references estado_agenda(id); 
ALTER TABLE estado_agendamento ADD CONSTRAINT fk_estado_agendamento_3 FOREIGN KEY (system_users_id) references system_users(id); 
ALTER TABLE exame ADD CONSTRAINT fk_exame_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE exame_atendimento ADD CONSTRAINT fk_exame_atendimento_2 FOREIGN KEY (exame_id) references exame(id); 
ALTER TABLE exame_atendimento ADD CONSTRAINT fk_exame_atendimento_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE formulario ADD CONSTRAINT fk_formulario_1 FOREIGN KEY (clinica_id) references system_unit(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_4 FOREIGN KEY (nota_fiscal_servico_id) references nota_fiscal_servico(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_1 FOREIGN KEY (conta_id) references conta(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_2 FOREIGN KEY (tipo_pagamento_id) references tipo_pagamento(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_3 FOREIGN KEY (clinica_id) references system_unit(id); 
ALTER TABLE material ADD CONSTRAINT fk_material_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE material ADD CONSTRAINT fk_material_1 FOREIGN KEY (unidade_medida_id) references unidade_medida(id); 
ALTER TABLE medicamento ADD CONSTRAINT fk_medicamento_1 FOREIGN KEY (prescricao_id) references prescricao(id); 
ALTER TABLE mensagem ADD CONSTRAINT fk_message_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE mensagem ADD CONSTRAINT fk_message_2 FOREIGN KEY (template_clinica_id) references template_clinica(id); 
ALTER TABLE mensagem ADD CONSTRAINT fk_message_3 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE mensagem_acao ADD CONSTRAINT fk_mensagem_acao_1 FOREIGN KEY (mensagem_id) references mensagem(id); 
ALTER TABLE movimentacao ADD CONSTRAINT fk_movimentacao_3 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE movimentacao ADD CONSTRAINT fk_movimentacao_1 FOREIGN KEY (material_id) references material(id); 
ALTER TABLE movimentacao ADD CONSTRAINT fk_movimentacao_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_3 FOREIGN KEY (municipio_prestacao_servico_id) references cidade(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_4 FOREIGN KEY (nota_fiscal_status_id) references nota_fiscal_status(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_5 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_6 FOREIGN KEY (cliente_id) references pessoa(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_9 FOREIGN KEY (lancamento_id) references lancamento(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_7 FOREIGN KEY (cidade_tomador_id) references cidade(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_1 FOREIGN KEY (conta_id) references conta(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_2 FOREIGN KEY (cidade_prestador_id) references cidade(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_8 FOREIGN KEY (servico_id) references servico(id); 
ALTER TABLE pessoa ADD CONSTRAINT fk_pessoa_1 FOREIGN KEY (system_users_id) references system_users(id); 
ALTER TABLE pessoa ADD CONSTRAINT fk_pessoa_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE pessoa_endereco ADD CONSTRAINT fk_pessoa_endereco_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE pessoa_endereco ADD CONSTRAINT fk_pessoa_endereco_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_especialidade ADD CONSTRAINT fk_pessoa_especialidade_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_especialidade ADD CONSTRAINT fk_pessoa_especialidade_2 FOREIGN KEY (especialidade_id) references especialidade(id); 
ALTER TABLE pessoa_grupo ADD CONSTRAINT fk_pessoa_grupo_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_grupo ADD CONSTRAINT fk_pessoa_grupo_2 FOREIGN KEY (grupo_id) references grupo(id); 
ALTER TABLE prescricao ADD CONSTRAINT fk_prescricao_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE procedimento ADD CONSTRAINT fk_procedimento_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE procedimento_material ADD CONSTRAINT fk_procedimento_material_1 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE procedimento_material ADD CONSTRAINT fk_procedimento_material_2 FOREIGN KEY (material_id) references material(id); 
ALTER TABLE procedimento_preco ADD CONSTRAINT fk_procedimento_preco_1 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE procedimento_preco ADD CONSTRAINT fk_procedimento_preco_2 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE questao ADD CONSTRAINT fk_questao_1 FOREIGN KEY (formulario_id) references formulario(id); 
ALTER TABLE resposta ADD CONSTRAINT fk_resposta_2 FOREIGN KEY (resposta_formulario_id) references resposta_formulario(id); 
ALTER TABLE resposta ADD CONSTRAINT fk_resposta_1 FOREIGN KEY (questao_id) references questao(id); 
ALTER TABLE resposta_formulario ADD CONSTRAINT fk_resposta_formulario_1 FOREIGN KEY (formulario_id) references formulario(id); 
ALTER TABLE resposta_formulario ADD CONSTRAINT fk_resposta_formulario_2 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_1 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_2 FOREIGN KEY (saas_plano_valor_trial_id) references saas_plano_valor(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_4 FOREIGN KEY (contrato_inativo_system_group_id) references system_group(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_3 FOREIGN KEY (saas_contrato_status_id) references saas_contrato_status(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_4 FOREIGN KEY (saas_plano_valor_id) references saas_plano_valor(id); 
ALTER TABLE saas_contrato_grupo ADD CONSTRAINT fk_saas_contrato_grupo_2 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE saas_contrato_grupo ADD CONSTRAINT fk_saas_contrato_grupo_1 FOREIGN KEY (saas_contrato_id) references saas_contrato(id); 
ALTER TABLE saas_error_log ADD CONSTRAINT fk_saas_error_log_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE saas_error_log ADD CONSTRAINT fk_saas_error_log_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE saas_gateway_forma_pagamento ADD CONSTRAINT fk_saas_forma_pagamento_gateway_1 FOREIGN KEY (saas_forma_pagamento_id) references saas_forma_pagamento(id); 
ALTER TABLE saas_gateway_forma_pagamento ADD CONSTRAINT fk_saas_forma_pagamento_gateway_2 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_gateway_pagamento_status ADD CONSTRAINT fk_saas_gateway_pagamento_status_1 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_gateway_pagamento_status ADD CONSTRAINT fk_saas_gateway_pagamento_status_2 FOREIGN KEY (saas_status_pagamento_id) references saas_status_pagamento(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_6 FOREIGN KEY (saas_pagamento_id) references saas_pagamento(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_2 FOREIGN KEY (cidade_prestador_id) references cidade(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_3 FOREIGN KEY (municipio_prestacao_servico_id) references cidade(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_4 FOREIGN KEY (nota_fiscal_status_id) references nota_fiscal_status(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_5 FOREIGN KEY (saas_plano_valor_id) references saas_plano_valor(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_7 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_1 FOREIGN KEY (cidade_tomador_id) references cidade(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_1 FOREIGN KEY (saas_status_pagamento_id) references saas_status_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_2 FOREIGN KEY (saas_contrato_id) references saas_contrato(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_3 FOREIGN KEY (saas_forma_pagamento_id) references saas_forma_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_4 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_5 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_6 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_7 FOREIGN KEY (saas_nota_fiscal_servico_id) references saas_nota_fiscal_servico(id); 
ALTER TABLE saas_plano ADD CONSTRAINT fk_saas_plano_1 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_plano_grupo ADD CONSTRAINT fk_saas_plano_grupo_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE saas_plano_grupo ADD CONSTRAINT fk_saas_plano_grupo_2 FOREIGN KEY (saas_plano_id) references saas_plano(id); 
ALTER TABLE saas_plano_valor ADD CONSTRAINT fk_saas_plano_valor_1 FOREIGN KEY (saas_plano_id) references saas_plano(id); 
ALTER TABLE saas_servico ADD CONSTRAINT fk_saas_servico_2 FOREIGN KEY (servico_grupo_imposto_id) references saas_servico_grupo_imposto(id); 
ALTER TABLE saas_servico_grupo_imposto_item ADD CONSTRAINT fk_servico_grupo_imposto_item_1 FOREIGN KEY (saas_servico_grupo_imposto_id) references saas_servico_grupo_imposto(id); 
ALTER TABLE saas_servico_grupo_imposto_item ADD CONSTRAINT fk_servico_grupo_imposto_item_2 FOREIGN KEY (saas_imposto_id) references saas_imposto(id); 
ALTER TABLE servico ADD CONSTRAINT fk_servico_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE servico_imposto_item ADD CONSTRAINT fk_servico_imposto_item_1 FOREIGN KEY (servico_id) references servico(id); 
ALTER TABLE servico_imposto_item ADD CONSTRAINT fk_servico_imposto_item_2 FOREIGN KEY (imposto_id) references imposto(id); 
ALTER TABLE system_document ADD CONSTRAINT fk_system_document_2 FOREIGN KEY (category_id) references system_document_category(id); 
ALTER TABLE system_document ADD CONSTRAINT fk_system_document_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_document_group ADD CONSTRAINT fk_system_document_group_2 FOREIGN KEY (document_id) references system_document(id); 
ALTER TABLE system_document_group ADD CONSTRAINT fk_system_document_group_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_document_user ADD CONSTRAINT fk_system_document_user_2 FOREIGN KEY (document_id) references system_document(id); 
ALTER TABLE system_document_user ADD CONSTRAINT fk_system_document_user_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_group_program ADD CONSTRAINT fk_system_group_program_1 FOREIGN KEY (system_program_id) references system_program(id); 
ALTER TABLE system_group_program ADD CONSTRAINT fk_system_group_program_2 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_message ADD CONSTRAINT fk_system_message_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_message ADD CONSTRAINT fk_system_message_2 FOREIGN KEY (system_user_to_id) references system_users(id); 
ALTER TABLE system_notification ADD CONSTRAINT fk_system_notification_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_notification ADD CONSTRAINT fk_system_notification_2 FOREIGN KEY (system_user_to_id) references system_users(id); 
ALTER TABLE system_unit ADD CONSTRAINT fk_system_unit_1 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE system_user_group ADD CONSTRAINT fk_system_user_group_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_user_group ADD CONSTRAINT fk_system_user_group_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_user_program ADD CONSTRAINT fk_system_user_program_1 FOREIGN KEY (system_program_id) references system_program(id); 
ALTER TABLE system_user_program ADD CONSTRAINT fk_system_user_program_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_users_3 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_user_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_user_2 FOREIGN KEY (frontpage_id) references system_program(id); 
ALTER TABLE system_user_unit ADD CONSTRAINT fk_system_user_unit_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_user_unit ADD CONSTRAINT fk_system_user_unit_2 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE template_acao ADD CONSTRAINT fk_template_acao_1 FOREIGN KEY (template_clinica_id) references template_clinica(id); 
ALTER TABLE template_clinica ADD CONSTRAINT fk_template_clinica_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE tipo_documento ADD CONSTRAINT fk_tipo_documento_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE tipo_pagamento ADD CONSTRAINT fk_tipo_pagamento_1 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE webhook_log ADD CONSTRAINT fk_webhook_log_1 FOREIGN KEY (gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE whatsapp_config ADD CONSTRAINT fk_whatsapp_config_1 FOREIGN KEY (clinica_id) references clinica(id); 
