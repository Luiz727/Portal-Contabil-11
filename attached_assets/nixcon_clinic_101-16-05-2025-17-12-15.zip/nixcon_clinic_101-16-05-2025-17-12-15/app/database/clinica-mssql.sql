CREATE TABLE account( 
      id  INT IDENTITY    NOT NULL  , 
      cidade_id int   , 
      system_user_id int   , 
      nome_responsavel nvarchar(max)   NOT NULL  , 
      razao_social nvarchar(max)   NOT NULL  , 
      tipo_pessoa char  (1)     DEFAULT 'J', 
      documento nvarchar(max)   , 
      email nvarchar(max)   , 
      telefone nvarchar(max)   , 
      cep nvarchar(max)   , 
      rua nvarchar(max)   , 
      numero nvarchar(max)   , 
      complemento nvarchar(max)   , 
      bairro nvarchar(max)   , 
      mes_criacao int   , 
      ano_criacao int   , 
      created_at datetime2   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE agenda( 
      id  INT IDENTITY    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      profissional_id int   NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      horario_inicial time   NOT NULL  , 
      horario_final time   NOT NULL  , 
      visualizacao_inicial varchar  (30)   NOT NULL    DEFAULT 'agendaWeek', 
      horario_inicio_intervalo time   , 
      horario_fim_intervalo time   , 
      duracao int   NOT NULL    DEFAULT 30, 
      dias nvarchar(max)   NOT NULL  , 
      procedimento_id int   , 
      cor varchar  (10)   , 
      aceita_agendamento_online char  (1)     DEFAULT 'F', 
      publica char  (1)     DEFAULT 'F', 
      fl_permite_choque_horario char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE agendamento( 
      id  INT IDENTITY    NOT NULL  , 
      paciente_id int   NOT NULL  , 
      estado_agenda_id int   NOT NULL  , 
      agenda_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      especialidade_id int   , 
      dt_inicial datetime2   NOT NULL  , 
      dt_final datetime2   NOT NULL  , 
      agendamento_original_id int   , 
      observacao nvarchar(max)   , 
      ativo char  (1)     DEFAULT 'T', 
      ano_inicial nvarchar(max)   , 
      mes_inicial nvarchar(max)   , 
      ano_mes_inicial nvarchar(max)   , 
      ano_final nvarchar(max)   , 
      mes_final nvarchar(max)   , 
      ano_mes_final nvarchar(max)   , 
      online char  (1)     DEFAULT 'F', 
      link_atendimento_online nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE agendamento_procedimento( 
      id  INT IDENTITY    NOT NULL  , 
      agendamento_id int   NOT NULL  , 
      procedimento_id int   NOT NULL  , 
      convenio_id int   NOT NULL  , 
      quantidade float   NOT NULL  , 
      valor float   , 
      valor_total float   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE agenda_profissional( 
      id  INT IDENTITY    NOT NULL  , 
      profissional_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      agenda_id int   NOT NULL  , 
      fl_manipula_atendimento char  (1)   NOT NULL    DEFAULT 'N', 
 PRIMARY KEY (id)) ; 

CREATE TABLE anexo( 
      id  INT IDENTITY    NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      arquivo nvarchar(max)   NOT NULL  , 
      observacao nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE atendimento( 
      id  INT IDENTITY    NOT NULL  , 
      agendamento_id int   NOT NULL  , 
      paciente_id int   NOT NULL  , 
      profissional_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      dt_inicio datetime2   NOT NULL  , 
      dt_final datetime2   , 
      valor_total float   , 
      ano_inicial nvarchar(max)   , 
      mes_inicial nvarchar(max)   , 
      ano_mes_inicial nvarchar(max)   , 
      mes_final nvarchar(max)   , 
      ano_final nvarchar(max)   , 
      ano_mes_final nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE atendimento_material( 
      id  INT IDENTITY    NOT NULL  , 
      material_id int   NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      quantidade float   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE atendimento_procedimento( 
      id  INT IDENTITY    NOT NULL  , 
      convenio_id int   NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      procedimento_id int   NOT NULL  , 
      quantidade float   NOT NULL  , 
      valor float   , 
      valor_total float   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE bloqueio( 
      id  INT IDENTITY    NOT NULL  , 
      agenda_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      dt_inicio datetime2   NOT NULL  , 
      dt_final datetime2   NOT NULL  , 
      observacao nvarchar(max)   , 
      horario_bloqueio_original int   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE categoria_conta( 
      id  INT IDENTITY    NOT NULL  , 
      tipo_conta_id int   NOT NULL  , 
      account_id int   NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE cep_cache( 
      id  INT IDENTITY    NOT NULL  , 
      cep varchar  (12)   NOT NULL  , 
      codigo_ibge nvarchar(max)   , 
      rua nvarchar(max)   , 
      cidade nvarchar(max)   , 
      uf nvarchar(max)   , 
      cidade_id int   , 
      bairro nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE cidade( 
      id  INT IDENTITY    NOT NULL  , 
      estado_id int   NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      codigo_ibge nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE clinica( 
      id  INT IDENTITY    NOT NULL  , 
      system_unit_id int   , 
      atendimento_categoria_conta_id int   , 
      cidade_id int   , 
      account_id int   , 
      token nvarchar(max)   , 
      nome nvarchar(max)   NOT NULL  , 
      cnpj nvarchar(max)   , 
      telefone nvarchar(max)   , 
      email nvarchar(max)   NOT NULL  , 
      endereco nvarchar(max)   , 
      bairro nvarchar(max)   , 
      cep nvarchar(max)   , 
      numero nvarchar(max)   , 
      complemento nvarchar(max)   , 
      logo_documento nvarchar(max)   , 
      nfse_serie nvarchar(max)   , 
      razao_social varchar  (255)   , 
      nfse_info nvarchar(max)   , 
      nfse_numero nvarchar(max)   , 
      regime_tributacao nvarchar(max)   , 
      token_integra_notas nvarchar(max)   , 
      token_integra_notas_homologacao nvarchar(max)   , 
      nfse_emissao_producao char  (1)     DEFAULT 'F', 
      certificado_a1_conteudo nvarchar(max)   , 
      senha_certificado_a1 nvarchar(max)   , 
      certificado_a1_nome nvarchar(max)   , 
      emitente_configurado char  (1)     DEFAULT 'F', 
      validade_certificado date   , 
      logo_horizontal_grande nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE clinica_convenio( 
      id  INT IDENTITY    NOT NULL  , 
      convenio_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE conta( 
      id  INT IDENTITY    NOT NULL  , 
      pessoa_id int   NOT NULL  , 
      categoria_conta_id int   , 
      tipo_conta_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      atendimento_id int   , 
      data_emissao date   NOT NULL  , 
      total_parcelas int   NOT NULL    DEFAULT 1, 
      quitada char  (1)   NOT NULL    DEFAULT 'F', 
      descricao nvarchar(max)   NOT NULL  , 
      conta_origem_id int   , 
      total_conta float   NOT NULL  , 
      mes nvarchar(max)   , 
      ano nvarchar(max)   , 
      ano_mes nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE convenio( 
      id  INT IDENTITY    NOT NULL  , 
      account_id int   NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE documento( 
      id  INT IDENTITY    NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      tipo_documento_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      procedimento_id int   , 
      texto nvarchar(max)   NOT NULL  , 
      dt_preenchimento datetime2   NOT NULL  , 
      autenticador nvarchar(max)   , 
      dt_validade date   NOT NULL  , 
      medico_assistente nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE email_config( 
      id  INT IDENTITY    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      port nvarchar(max)   , 
      username nvarchar(max)   , 
      password nvarchar(max)   , 
      host nvarchar(max)   , 
      from_email nvarchar(max)   , 
      from_name nvarchar(max)   , 
      smtp_auth char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE especialidade( 
      id  INT IDENTITY    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      descricao nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      sigla char  (2)   NOT NULL  , 
      codigo_ibge nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado_agenda( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      estado_inicial char  (1)   NOT NULL    DEFAULT 'N', 
      estado_final char  (1)   NOT NULL    DEFAULT 'N', 
      cor varchar  (10)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado_agendamento( 
      id  INT IDENTITY    NOT NULL  , 
      agendamento_id int   NOT NULL  , 
      estado_agenda_id int   NOT NULL  , 
      system_users_id int   , 
      atribuido_em datetime2   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE exame( 
      id  INT IDENTITY    NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      nome nvarchar(max)   NOT NULL  , 
      codigo_referencia nvarchar(max)   , 
      clinica_id int   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE exame_atendimento( 
      id  INT IDENTITY    NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      exame_id int   NOT NULL  , 
      indicacao_clinica nvarchar(max)   NOT NULL  , 
      dt_exames date   NOT NULL  , 
      quantidade int   NOT NULL    DEFAULT 1, 
 PRIMARY KEY (id)) ; 

CREATE TABLE formulario( 
      id  INT IDENTITY    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      ordem int   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE grupo( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      cor varchar  (10)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE imposto( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      codigo nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE lancamento( 
      id  INT IDENTITY    NOT NULL  , 
      conta_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      tipo_pagamento_id int   , 
      nota_fiscal_servico_id int   , 
      parcela int   NOT NULL    DEFAULT 1, 
      dt_vencimento date   NOT NULL  , 
      valor float   NOT NULL  , 
      dt_pagamento date   , 
      ano_pagamento nvarchar(max)   , 
      mes_pagamento nvarchar(max)   , 
      ano_mes_pagamento nvarchar(max)   , 
      ano_vencimento nvarchar(max)   , 
      mes_vencimento nvarchar(max)   , 
      ano_mes_vencimento nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE material( 
      id  INT IDENTITY    NOT NULL  , 
      unidade_medida_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      estoque_minimo float   , 
      dt_vencimento date   , 
      estoque_atualizado float   , 
      lote nvarchar(max)   , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE medicamento( 
      id  INT IDENTITY    NOT NULL  , 
      prescricao_id int   NOT NULL  , 
      medicamento nvarchar(max)   NOT NULL  , 
      quantidade nvarchar(max)   NOT NULL  , 
      posologia nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE mensagem( 
      id  INT IDENTITY    NOT NULL  , 
      agendamento_id int   NOT NULL  , 
      template_clinica_id int   , 
      system_user_id int   NOT NULL  , 
      titulo nvarchar(max)   , 
      template nvarchar(max)   , 
      enviado_em datetime2   , 
      tipo_mensagem nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE mensagem_acao( 
      id  INT IDENTITY    NOT NULL  , 
      mensagem_id int   NOT NULL  , 
      url nvarchar(max)   , 
      label nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE movimentacao( 
      id  INT IDENTITY    NOT NULL  , 
      material_id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      dt_movimentacao nvarchar(max)   , 
      quantidade float   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE nota_fiscal_servico( 
      id  INT IDENTITY    NOT NULL  , 
      cidade_tomador_id int   NOT NULL  , 
      cidade_prestador_id int   NOT NULL  , 
      municipio_prestacao_servico_id int   NOT NULL  , 
      nota_fiscal_status_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      cliente_id int   NOT NULL  , 
      conta_id int   , 
      lancamento_id int   , 
      natureza_operacao nvarchar(max)   , 
      data_hora_emissao datetime2   NOT NULL  , 
      discriminacao nvarchar(max)   NOT NULL  , 
      numero nvarchar(max)   , 
      codigo_verificacao nvarchar(max)   , 
      id_gateway_externo nvarchar(max)   , 
      dados_gateway_externo nvarchar(max)   , 
      nome_tomador nvarchar(max)   NOT NULL  , 
      documento_tomador nvarchar(max)   NOT NULL  , 
      endereco_tomador nvarchar(max)   NOT NULL  , 
      email_tomador nvarchar(max)   NOT NULL  , 
      telefone_tomador nvarchar(max)   , 
      numero_tomador nvarchar(max)   NOT NULL  , 
      bairro_tomador nvarchar(max)   NOT NULL  , 
      cep_tomador nvarchar(max)   NOT NULL  , 
      inscricao_municipal_tomador nvarchar(max)   , 
      inscricao_municipal_prestador nvarchar(max)   , 
      nome_prestador nvarchar(max)   NOT NULL  , 
      documento_prestador nvarchar(max)   NOT NULL  , 
      endereco_prestador nvarchar(max)   NOT NULL  , 
      email_prestador nvarchar(max)   NOT NULL  , 
      telefone_prestador nvarchar(max)   , 
      numero_prestador nvarchar(max)   NOT NULL  , 
      bairro_prestador nvarchar(max)   NOT NULL  , 
      cep_prestador nvarchar(max)   NOT NULL  , 
      iss_retido char  (1)     DEFAULT 'F', 
      desconto_incondicionado float     DEFAULT 0.00, 
      desconto_condicionado float     DEFAULT 0.00, 
      base_calculo_iss float   , 
      aliquota_iss float   , 
      aliquota_pis float   , 
      aliquota_cofins float   , 
      aliquota_csll float   , 
      aliquota_irrf float   , 
      aliquota_inss float   , 
      valor_deducoes float   , 
      valor_retencoes float   , 
      valor_outras_retencoes float   , 
      valor_liquido float   , 
      valor_servicos float   , 
      valor_iss float   , 
      valor_pis float     DEFAULT 0.00, 
      valor_inss float     DEFAULT 0.00, 
      valor_cofins float     DEFAULT 0.00, 
      valor_csll float   , 
      valor_irrf float     DEFAULT 0.00, 
      incentivador_cultural char  (1)     DEFAULT 'F', 
      optante_simples_nacional char  (1)     DEFAULT 'F', 
      nfse_status nvarchar(max)   , 
      ano nvarchar(max)   , 
      mes nvarchar(max)   , 
      ano_mes nvarchar(max)   , 
      pdf nvarchar(max)   , 
      xml nvarchar(max)   , 
      link_pdf_prefeitura nvarchar(max)   , 
      regime_tributario_municipal nvarchar(max)   , 
      numero_rps nvarchar(max)   , 
      mensagem_erro nvarchar(max)   , 
      email_enviado char  (1)     DEFAULT 'F', 
      servico_id int   NOT NULL  , 
      serie_rps nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE nota_fiscal_status( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      cor nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa( 
      id  INT IDENTITY    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      nome varchar  (255)   NOT NULL  , 
      documento nvarchar(max)   , 
      email varchar  (255)   , 
      telefone varchar  (20)   , 
      system_users_id int   , 
      sexo char  (1)   , 
      nome_civel varchar  (255)   , 
      rg nvarchar(max)   , 
      dt_nascimento date   , 
      profissao nvarchar(max)   , 
      tratamento nvarchar(max)   , 
      observacao nvarchar(max)   , 
      assinatura nvarchar(max)   , 
      usuario varchar  (255)   , 
      senha varchar  (255)   , 
      foto nvarchar(max)   , 
      aceita_receber_mensagen_whatsapp char  (1)   NOT NULL    DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa_endereco( 
      id  INT IDENTITY    NOT NULL  , 
      pessoa_id int   NOT NULL  , 
      cidade_id int   NOT NULL  , 
      cep varchar  (10)   NOT NULL  , 
      rua varchar  (500)   NOT NULL  , 
      bairro varchar  (500)   NOT NULL  , 
      numero varchar  (100)   NOT NULL  , 
      complemento varchar  (500)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa_especialidade( 
      id  INT IDENTITY    NOT NULL  , 
      pessoa_id int   NOT NULL  , 
      especialidade_id int   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa_grupo( 
      id  INT IDENTITY    NOT NULL  , 
      pessoa_id int   NOT NULL  , 
      grupo_id int   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE prescricao( 
      id  INT IDENTITY    NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      controle_especial char  (1)   NOT NULL    DEFAULT 'N', 
      dt_prescricao date   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE procedimento( 
      id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      cor varchar  (10)   NOT NULL  , 
      duracao time   , 
      codigo_referencia nvarchar(max)   , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE procedimento_material( 
      id  INT IDENTITY    NOT NULL  , 
      procedimento_id int   NOT NULL  , 
      material_id int   NOT NULL  , 
      quantidade float   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE procedimento_preco( 
      id  INT IDENTITY    NOT NULL  , 
      procedimento_id int   NOT NULL  , 
      convenio_id int   NOT NULL  , 
      valor float   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE questao( 
      id  INT IDENTITY    NOT NULL  , 
      formulario_id int   NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      tipo_campo nvarchar(max)   NOT NULL  , 
      fl_obrigatorio char  (1)   NOT NULL    DEFAULT 'F', 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      opcoes nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE resposta( 
      id  INT IDENTITY    NOT NULL  , 
      resposta_formulario_id int   NOT NULL  , 
      questao_id int   NOT NULL  , 
      resposta nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE resposta_formulario( 
      id  INT IDENTITY    NOT NULL  , 
      formulario_id int   NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      dt_resposta date   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_configuracao( 
      id  INT IDENTITY    NOT NULL  , 
      cidade_id int   , 
      saas_plano_valor_trial_id int   , 
      contrato_inativo_system_group_id int   , 
      parametro_fiscal_id int   , 
      razao_social nvarchar(max)   , 
      nome_fantasia nvarchar(max)   , 
      cnpj nvarchar(max)   , 
      inscricao_estadual nvarchar(max)   , 
      inscricao_municipal nvarchar(max)   , 
      cep nvarchar(max)   , 
      rua nvarchar(max)   , 
      bairro nvarchar(max)   , 
      numero nvarchar(max)   , 
      complemento nvarchar(max)   , 
      email nvarchar(max)   NOT NULL  , 
      telefone nvarchar(max)   NOT NULL  , 
      dias_trial int   , 
      contrato nvarchar(max)   , 
      regime_tributacao nvarchar(max)   , 
      token_integra_notas nvarchar(max)   , 
      token_integra_notas_homologacao nvarchar(max)   , 
      nfse_emissao_producao char  (1)   NOT NULL    DEFAULT 'F', 
      nfse_numero nvarchar(max)   , 
      nfse_serie nvarchar(max)   , 
      nfse_info nvarchar(max)   , 
      termo_uso nvarchar(max)   , 
      email_port nvarchar(max)   , 
      email_username nvarchar(max)   , 
      email_password nvarchar(max)   , 
      email_host nvarchar(max)   , 
      email_from nvarchar(max)   , 
      email_from_name nvarchar(max)   , 
      email_smtp_auth char  (1)     DEFAULT 'F', 
      dias_renovacao_contrato int   , 
      dias_vencimento_pagamento int   , 
      token_integra_notas_software_house nvarchar(max)   , 
      url_sistema nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_contrato( 
      id  INT IDENTITY    NOT NULL  , 
      saas_plano_valor_id int   NOT NULL  , 
      account_id int   NOT NULL  , 
      saas_contrato_status_id int   NOT NULL  , 
      valor_total float   , 
      data_inicial date   NOT NULL  , 
      data_final date   , 
      criado_em datetime2   , 
      renovacao char  (1)     DEFAULT 'F', 
      total_usuarios int   , 
      total_unidades int   , 
      gateway_assinatura_id nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_contrato_grupo( 
      id  INT IDENTITY    NOT NULL  , 
      saas_contrato_id int   NOT NULL  , 
      system_group_id int   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_contrato_status( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      cor nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_email_log( 
      id  INT IDENTITY    NOT NULL  , 
      titulo nvarchar(max)   , 
      conteudo nvarchar(max)   , 
      destinatario nvarchar(max)   , 
      created_at datetime2   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_error_log( 
      id  INT IDENTITY    NOT NULL  , 
      system_unit_id int   , 
      system_user_id int   , 
      error_class varchar  (255)   , 
      error_method varchar  (255)   , 
      message nvarchar(max)   , 
      payload nvarchar(max)   , 
      created_at datetime2   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_forma_pagamento( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_forma_pagamento( 
      id  INT IDENTITY    NOT NULL  , 
      saas_forma_pagamento_id int   NOT NULL  , 
      saas_gateway_pagamento_id int   NOT NULL  , 
      codigo nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_pagamento( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      public_key nvarchar(max)   , 
      access_token nvarchar(max)   , 
      client_secret nvarchar(max)   , 
      client_id nvarchar(max)   , 
      oauth_token nvarchar(max)   , 
      oauth_token_created_at datetime2   , 
      certificado_crt nvarchar(max)   , 
      certificado_key nvarchar(max)   , 
      webhook_url nvarchar(max)   , 
      webhook_certificado_cert nvarchar(max)   , 
      fl_homologacao char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_pagamento_status( 
      id  INT IDENTITY    NOT NULL  , 
      saas_gateway_pagamento_id int   NOT NULL  , 
      saas_status_pagamento_id int   NOT NULL  , 
      codigo nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_imposto( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      codigo nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_nota_fiscal_servico( 
      id  INT IDENTITY    NOT NULL  , 
      saas_pagamento_id int   , 
      saas_plano_valor_id int   , 
      saas_servico_id int   , 
      cidade_tomador_id int   NOT NULL  , 
      cidade_prestador_id int   NOT NULL  , 
      municipio_prestacao_servico_id int   NOT NULL  , 
      nota_fiscal_status_id int   NOT NULL  , 
      account_id int   NOT NULL  , 
      natureza_operacao nvarchar(max)   , 
      data_hora_emissao datetime2   NOT NULL  , 
      discriminacao nvarchar(max)   NOT NULL  , 
      numero nvarchar(max)   , 
      codigo_verificacao nvarchar(max)   , 
      id_gateway_externo nvarchar(max)   , 
      dados_gateway_externo nvarchar(max)   , 
      nome_tomador nvarchar(max)   NOT NULL  , 
      documento_tomador nvarchar(max)   NOT NULL  , 
      endereco_tomador nvarchar(max)   NOT NULL  , 
      email_tomador nvarchar(max)   NOT NULL  , 
      telefone_tomador nvarchar(max)   , 
      numero_tomador nvarchar(max)   NOT NULL  , 
      bairro_tomador nvarchar(max)   NOT NULL  , 
      cep_tomador nvarchar(max)   NOT NULL  , 
      inscricao_municipal_tomador nvarchar(max)   , 
      inscricao_municipal_prestador nvarchar(max)   , 
      nome_prestador nvarchar(max)   NOT NULL  , 
      documento_prestador nvarchar(max)   NOT NULL  , 
      endereco_prestador nvarchar(max)   NOT NULL  , 
      email_prestador nvarchar(max)   NOT NULL  , 
      telefone_prestador nvarchar(max)   , 
      numero_prestador nvarchar(max)   NOT NULL  , 
      bairro_prestador nvarchar(max)   NOT NULL  , 
      cep_prestador nvarchar(max)   NOT NULL  , 
      iss_retido char  (1)     DEFAULT 'F', 
      desconto_incondicionado float     DEFAULT 0.00, 
      desconto_condicionado float     DEFAULT 0.00, 
      base_calculo_iss float   , 
      aliquota_iss float   , 
      aliquota_pis float   , 
      aliquota_cofins float   , 
      aliquota_csll float   , 
      aliquota_irrf float   , 
      aliquota_inss float   , 
      valor_deducoes float   , 
      valor_retencoes float   , 
      valor_outras_retencoes float   , 
      valor_liquido float   , 
      valor_servicos float   , 
      valor_iss float   , 
      valor_pis float     DEFAULT 0.00, 
      valor_inss float     DEFAULT 0.00, 
      valor_cofins float     DEFAULT 0.00, 
      valor_csll float   , 
      valor_irrf float     DEFAULT 0.00, 
      incentivador_cultural char  (1)     DEFAULT 'F', 
      optante_simples_nacional char  (1)     DEFAULT 'F', 
      nfse_status nvarchar(max)   , 
      ano nvarchar(max)   , 
      mes nvarchar(max)   , 
      ano_mes nvarchar(max)   , 
      pdf nvarchar(max)   , 
      xml nvarchar(max)   , 
      link_pdf_prefeitura nvarchar(max)   , 
      regime_tributario_municipal nvarchar(max)   , 
      numero_rps nvarchar(max)   , 
      mensagem_erro nvarchar(max)   , 
      email_enviado char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_pagamento( 
      id  INT IDENTITY    NOT NULL  , 
      account_id int   NOT NULL  , 
      saas_status_pagamento_id int   NOT NULL  , 
      saas_contrato_id int   , 
      saas_servico_id int   , 
      saas_forma_pagamento_id int   NOT NULL  , 
      saas_gateway_pagamento_id int   NOT NULL  , 
      saas_nota_fiscal_servico_id int   , 
      valor float   NOT NULL  , 
      data_compra datetime2   NOT NULL  , 
      data_vencimento date   , 
      data_pagamento date   , 
      dados_gateway nvarchar(max)   , 
      id_gateway nvarchar(max)   , 
      payment_id nvarchar(max)   , 
      link_gateway nvarchar(max)   , 
      mes_compra int   , 
      ano_compra int   , 
      ano_pagamento int   , 
      mes_pagamento int   , 
      mes_ano_pagamento nvarchar(max)   , 
      mes_ano_compra nvarchar(max)   , 
      renovacao char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_plano( 
      id  INT IDENTITY    NOT NULL  , 
      saas_servico_id int   , 
      nome nvarchar(max)   NOT NULL  , 
      descricao nvarchar(max)   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      limite_usuarios int   , 
      limite_unidades int   , 
      discriminacao nvarchar(max)   , 
      ordem int   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_plano_grupo( 
      id  INT IDENTITY    NOT NULL  , 
      saas_plano_id int   NOT NULL  , 
      system_group_id int   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_plano_valor( 
      id  INT IDENTITY    NOT NULL  , 
      saas_plano_id int   NOT NULL  , 
      valor float   NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      duracao int   , 
      ativo char  (1)     DEFAULT 'T', 
      desativado_em datetime2   , 
      recorrencia char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico( 
      id  INT IDENTITY    NOT NULL  , 
      servico_grupo_imposto_id int   , 
      nome nvarchar(max)   NOT NULL  , 
      preco float   , 
      descricao nvarchar(max)   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico_grupo_imposto( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      codigo_cnae nvarchar(max)   , 
      codigo_tributacao_municipio nvarchar(max)   , 
      codigo_nbs nvarchar(max)   , 
      codigo nvarchar(max)   , 
      descricao_servico_municipio nvarchar(max)   , 
      iss_retido nvarchar(max)   , 
      natureza_operacao nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico_grupo_imposto_item( 
      id  INT IDENTITY    NOT NULL  , 
      saas_servico_grupo_imposto_id int   NOT NULL  , 
      saas_imposto_id int   NOT NULL  , 
      aliquota float   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_status_pagamento( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      cor nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_template_email( 
      id  INT IDENTITY    NOT NULL  , 
      descricao nvarchar(max)   , 
      titulo nvarchar(max)   , 
      conteudo nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE servico( 
      id  INT IDENTITY    NOT NULL  , 
      account_id int   NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      descricao nvarchar(max)   , 
      codigo_cnae nvarchar(max)   , 
      codigo_tributacao_municipio nvarchar(max)   , 
      codigo_nbs nvarchar(max)   , 
      codigo nvarchar(max)   , 
      descricao_servico_municipio nvarchar(max)   , 
      iss_retido nvarchar(max)   , 
      natureza_operacao nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE servico_imposto_item( 
      id  INT IDENTITY    NOT NULL  , 
      servico_id int   NOT NULL  , 
      imposto_id int   NOT NULL  , 
      aliquota float   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document( 
      id int   NOT NULL  , 
      category_id int   NOT NULL  , 
      system_user_id int   , 
      title nvarchar(max)   NOT NULL  , 
      description nvarchar(max)   , 
      submission_date date   , 
      archive_date date   , 
      filename nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document_category( 
      id int   NOT NULL  , 
      name nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document_group( 
      id int   NOT NULL  , 
      document_id int   NOT NULL  , 
      system_group_id int   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document_user( 
      id int   NOT NULL  , 
      document_id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group( 
      id int   NOT NULL  , 
      name nvarchar(max)   NOT NULL  , 
      uuid varchar  (36)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group_program( 
      id int   NOT NULL  , 
      system_group_id int   NOT NULL  , 
      system_program_id int   NOT NULL  , 
      actions nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_message( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_user_to_id int   NOT NULL  , 
      subject nvarchar(max)   NOT NULL  , 
      message nvarchar(max)   , 
      dt_message datetime2   , 
      checked char  (1)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_notification( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_user_to_id int   NOT NULL  , 
      subject nvarchar(max)   , 
      message nvarchar(max)   , 
      dt_message datetime2   , 
      action_url nvarchar(max)   , 
      action_label nvarchar(max)   , 
      icon nvarchar(max)   , 
      checked char  (1)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_preference( 
      id varchar  (255)   NOT NULL  , 
      preference nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_program( 
      id int   NOT NULL  , 
      name nvarchar(max)   NOT NULL  , 
      controller nvarchar(max)   NOT NULL  , 
      actions nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_unit( 
      id int   NOT NULL  , 
      account_id int   , 
      name nvarchar(max)   NOT NULL  , 
      connection_name nvarchar(max)   , 
      active char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_group( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_group_id int   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_program( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_program_id int   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_users( 
      id int   NOT NULL  , 
      name nvarchar(max)   NOT NULL  , 
      login nvarchar(max)   NOT NULL  , 
      password nvarchar(max)   NOT NULL  , 
      email nvarchar(max)   , 
      frontpage_id int   , 
      system_unit_id int   , 
      account_id int   , 
      active char  (1)   , 
      accepted_term_policy char  (1)   , 
      accepted_term_policy_at nvarchar(max)   , 
      two_factor_enabled char  (1)     DEFAULT 'N', 
      two_factor_type varchar  (100)   , 
      two_factor_secret varchar  (255)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_unit( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_unit_id int   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE template_acao( 
      id  INT IDENTITY    NOT NULL  , 
      template_clinica_id int   NOT NULL  , 
      url nvarchar(max)   , 
      label nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE template_clinica( 
      id  INT IDENTITY    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      chave nvarchar(max)   NOT NULL  , 
      descricao nvarchar(max)   NOT NULL  , 
      habilitado char  (1)   NOT NULL    DEFAULT 'T', 
      template nvarchar(max)   , 
      titulo nvarchar(max)   , 
      tipo_template nvarchar(max)   , 
      readonly char  (1)   NOT NULL    DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_conta( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_documento( 
      id  INT IDENTITY    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      texto_padrao nvarchar(max)   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'S', 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_pagamento( 
      id  INT IDENTITY    NOT NULL  , 
      account_id int   NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE unidade_medida( 
      id  INT IDENTITY    NOT NULL  , 
      nome nvarchar(max)   NOT NULL  , 
      sigla nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE webhook_log( 
      id  INT IDENTITY    NOT NULL  , 
      gateway_pagamento_id int   , 
      payload nvarchar(max)   , 
      created_at datetime2   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE whatsapp_config( 
      id  INT IDENTITY    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      phone nvarchar(max)   , 
      status nvarchar(max)   , 
      api_token nvarchar(max)   , 
      api_key nvarchar(max)   , 
      api_client_token nvarchar(max)   , 
 PRIMARY KEY (id)) ; 

 
 ALTER TABLE cep_cache ADD UNIQUE (cep);
  
 ALTER TABLE account ADD CONSTRAINT fk_account_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE account ADD CONSTRAINT fk_account_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE agenda ADD CONSTRAINT fk_agenda_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE agenda ADD CONSTRAINT fk_agenda_2 FOREIGN KEY (profissional_id) references pessoa(id); 
ALTER TABLE agenda ADD CONSTRAINT fk_agenda_3 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_5 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_1 FOREIGN KEY (paciente_id) references pessoa(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_2 FOREIGN KEY (estado_agenda_id) references estado_agenda(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_3 FOREIGN KEY (agenda_id) references agenda(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_4 FOREIGN KEY (especialidade_id) references especialidade(id); 
ALTER TABLE agendamento_procedimento ADD CONSTRAINT fk_agendamento_procedimento_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE agendamento_procedimento ADD CONSTRAINT fk_agendamento_procedimento_2 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE agendamento_procedimento ADD CONSTRAINT fk_agendamento_procedimento_3 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE agenda_profissional ADD CONSTRAINT fk_agenda_profissional_3 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE agenda_profissional ADD CONSTRAINT fk_agenda_profissional_1 FOREIGN KEY (profissional_id) references pessoa(id); 
ALTER TABLE agenda_profissional ADD CONSTRAINT fk_agenda_profissional_2 FOREIGN KEY (agenda_id) references agenda(id); 
ALTER TABLE anexo ADD CONSTRAINT fk_anexo_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_4 FOREIGN KEY (clinica_id) references system_unit(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_2 FOREIGN KEY (paciente_id) references pessoa(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_3 FOREIGN KEY (profissional_id) references pessoa(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE atendimento_material ADD CONSTRAINT fk_atendimento_material_1 FOREIGN KEY (material_id) references material(id); 
ALTER TABLE atendimento_material ADD CONSTRAINT fk_atendimento_material_2 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE atendimento_procedimento ADD CONSTRAINT fk_atendimento_procedimento_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE atendimento_procedimento ADD CONSTRAINT fk_atendimento_procedimento_2 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE atendimento_procedimento ADD CONSTRAINT fk_atendimento_procedimento_3 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE bloqueio ADD CONSTRAINT fk_bloqueio_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE bloqueio ADD CONSTRAINT fk_bloqueio_1 FOREIGN KEY (agenda_id) references agenda(id); 
ALTER TABLE categoria_conta ADD CONSTRAINT fk_categoria_conta_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE categoria_conta ADD CONSTRAINT fk_categoria_conta_1 FOREIGN KEY (tipo_conta_id) references tipo_conta(id); 
ALTER TABLE cidade ADD CONSTRAINT fk_cidade_1 FOREIGN KEY (estado_id) references estado(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_3 FOREIGN KEY (atendimento_categoria_conta_id) references categoria_conta(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_4 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE clinica_convenio ADD CONSTRAINT fk_clinica_convenio_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE clinica_convenio ADD CONSTRAINT fk_clinica_convenio_1 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_3 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_4 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_5 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_2 FOREIGN KEY (tipo_conta_id) references tipo_conta(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_1 FOREIGN KEY (categoria_conta_id) references categoria_conta(id); 
ALTER TABLE convenio ADD CONSTRAINT fk_convenio_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_1 FOREIGN KEY (tipo_documento_id) references tipo_documento(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_2 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_3 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_4 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE email_config ADD CONSTRAINT fk_email_config_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE especialidade ADD CONSTRAINT fk_especialidade_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE estado_agendamento ADD CONSTRAINT fk_estado_agendamento_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE estado_agendamento ADD CONSTRAINT fk_estado_agendamento_2 FOREIGN KEY (estado_agenda_id) references estado_agenda(id); 
ALTER TABLE estado_agendamento ADD CONSTRAINT fk_estado_agendamento_3 FOREIGN KEY (system_users_id) references system_users(id); 
ALTER TABLE exame ADD CONSTRAINT fk_exame_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE exame_atendimento ADD CONSTRAINT fk_exame_atendimento_2 FOREIGN KEY (exame_id) references exame(id); 
ALTER TABLE exame_atendimento ADD CONSTRAINT fk_exame_atendimento_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE formulario ADD CONSTRAINT fk_formulario_1 FOREIGN KEY (clinica_id) references system_unit(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_4 FOREIGN KEY (nota_fiscal_servico_id) references nota_fiscal_servico(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_1 FOREIGN KEY (conta_id) references conta(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_2 FOREIGN KEY (tipo_pagamento_id) references tipo_pagamento(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_3 FOREIGN KEY (clinica_id) references system_unit(id); 
ALTER TABLE material ADD CONSTRAINT fk_material_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE material ADD CONSTRAINT fk_material_1 FOREIGN KEY (unidade_medida_id) references unidade_medida(id); 
ALTER TABLE medicamento ADD CONSTRAINT fk_medicamento_1 FOREIGN KEY (prescricao_id) references prescricao(id); 
ALTER TABLE mensagem ADD CONSTRAINT fk_message_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE mensagem ADD CONSTRAINT fk_message_2 FOREIGN KEY (template_clinica_id) references template_clinica(id); 
ALTER TABLE mensagem ADD CONSTRAINT fk_message_3 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE mensagem_acao ADD CONSTRAINT fk_mensagem_acao_1 FOREIGN KEY (mensagem_id) references mensagem(id); 
ALTER TABLE movimentacao ADD CONSTRAINT fk_movimentacao_3 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE movimentacao ADD CONSTRAINT fk_movimentacao_1 FOREIGN KEY (material_id) references material(id); 
ALTER TABLE movimentacao ADD CONSTRAINT fk_movimentacao_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_3 FOREIGN KEY (municipio_prestacao_servico_id) references cidade(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_4 FOREIGN KEY (nota_fiscal_status_id) references nota_fiscal_status(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_5 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_6 FOREIGN KEY (cliente_id) references pessoa(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_9 FOREIGN KEY (lancamento_id) references lancamento(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_7 FOREIGN KEY (cidade_tomador_id) references cidade(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_1 FOREIGN KEY (conta_id) references conta(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_2 FOREIGN KEY (cidade_prestador_id) references cidade(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_8 FOREIGN KEY (servico_id) references servico(id); 
ALTER TABLE pessoa ADD CONSTRAINT fk_pessoa_1 FOREIGN KEY (system_users_id) references system_users(id); 
ALTER TABLE pessoa ADD CONSTRAINT fk_pessoa_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE pessoa_endereco ADD CONSTRAINT fk_pessoa_endereco_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE pessoa_endereco ADD CONSTRAINT fk_pessoa_endereco_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_especialidade ADD CONSTRAINT fk_pessoa_especialidade_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_especialidade ADD CONSTRAINT fk_pessoa_especialidade_2 FOREIGN KEY (especialidade_id) references especialidade(id); 
ALTER TABLE pessoa_grupo ADD CONSTRAINT fk_pessoa_grupo_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_grupo ADD CONSTRAINT fk_pessoa_grupo_2 FOREIGN KEY (grupo_id) references grupo(id); 
ALTER TABLE prescricao ADD CONSTRAINT fk_prescricao_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE procedimento ADD CONSTRAINT fk_procedimento_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE procedimento_material ADD CONSTRAINT fk_procedimento_material_1 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE procedimento_material ADD CONSTRAINT fk_procedimento_material_2 FOREIGN KEY (material_id) references material(id); 
ALTER TABLE procedimento_preco ADD CONSTRAINT fk_procedimento_preco_1 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE procedimento_preco ADD CONSTRAINT fk_procedimento_preco_2 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE questao ADD CONSTRAINT fk_questao_1 FOREIGN KEY (formulario_id) references formulario(id); 
ALTER TABLE resposta ADD CONSTRAINT fk_resposta_2 FOREIGN KEY (resposta_formulario_id) references resposta_formulario(id); 
ALTER TABLE resposta ADD CONSTRAINT fk_resposta_1 FOREIGN KEY (questao_id) references questao(id); 
ALTER TABLE resposta_formulario ADD CONSTRAINT fk_resposta_formulario_1 FOREIGN KEY (formulario_id) references formulario(id); 
ALTER TABLE resposta_formulario ADD CONSTRAINT fk_resposta_formulario_2 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_1 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_2 FOREIGN KEY (saas_plano_valor_trial_id) references saas_plano_valor(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_4 FOREIGN KEY (contrato_inativo_system_group_id) references system_group(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_3 FOREIGN KEY (saas_contrato_status_id) references saas_contrato_status(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_4 FOREIGN KEY (saas_plano_valor_id) references saas_plano_valor(id); 
ALTER TABLE saas_contrato_grupo ADD CONSTRAINT fk_saas_contrato_grupo_2 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE saas_contrato_grupo ADD CONSTRAINT fk_saas_contrato_grupo_1 FOREIGN KEY (saas_contrato_id) references saas_contrato(id); 
ALTER TABLE saas_error_log ADD CONSTRAINT fk_saas_error_log_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE saas_error_log ADD CONSTRAINT fk_saas_error_log_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE saas_gateway_forma_pagamento ADD CONSTRAINT fk_saas_forma_pagamento_gateway_1 FOREIGN KEY (saas_forma_pagamento_id) references saas_forma_pagamento(id); 
ALTER TABLE saas_gateway_forma_pagamento ADD CONSTRAINT fk_saas_forma_pagamento_gateway_2 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_gateway_pagamento_status ADD CONSTRAINT fk_saas_gateway_pagamento_status_1 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_gateway_pagamento_status ADD CONSTRAINT fk_saas_gateway_pagamento_status_2 FOREIGN KEY (saas_status_pagamento_id) references saas_status_pagamento(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_6 FOREIGN KEY (saas_pagamento_id) references saas_pagamento(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_2 FOREIGN KEY (cidade_prestador_id) references cidade(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_3 FOREIGN KEY (municipio_prestacao_servico_id) references cidade(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_4 FOREIGN KEY (nota_fiscal_status_id) references nota_fiscal_status(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_5 FOREIGN KEY (saas_plano_valor_id) references saas_plano_valor(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_7 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_1 FOREIGN KEY (cidade_tomador_id) references cidade(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_1 FOREIGN KEY (saas_status_pagamento_id) references saas_status_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_2 FOREIGN KEY (saas_contrato_id) references saas_contrato(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_3 FOREIGN KEY (saas_forma_pagamento_id) references saas_forma_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_4 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_5 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_6 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_7 FOREIGN KEY (saas_nota_fiscal_servico_id) references saas_nota_fiscal_servico(id); 
ALTER TABLE saas_plano ADD CONSTRAINT fk_saas_plano_1 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_plano_grupo ADD CONSTRAINT fk_saas_plano_grupo_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE saas_plano_grupo ADD CONSTRAINT fk_saas_plano_grupo_2 FOREIGN KEY (saas_plano_id) references saas_plano(id); 
ALTER TABLE saas_plano_valor ADD CONSTRAINT fk_saas_plano_valor_1 FOREIGN KEY (saas_plano_id) references saas_plano(id); 
ALTER TABLE saas_servico ADD CONSTRAINT fk_saas_servico_2 FOREIGN KEY (servico_grupo_imposto_id) references saas_servico_grupo_imposto(id); 
ALTER TABLE saas_servico_grupo_imposto_item ADD CONSTRAINT fk_servico_grupo_imposto_item_1 FOREIGN KEY (saas_servico_grupo_imposto_id) references saas_servico_grupo_imposto(id); 
ALTER TABLE saas_servico_grupo_imposto_item ADD CONSTRAINT fk_servico_grupo_imposto_item_2 FOREIGN KEY (saas_imposto_id) references saas_imposto(id); 
ALTER TABLE servico ADD CONSTRAINT fk_servico_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE servico_imposto_item ADD CONSTRAINT fk_servico_imposto_item_1 FOREIGN KEY (servico_id) references servico(id); 
ALTER TABLE servico_imposto_item ADD CONSTRAINT fk_servico_imposto_item_2 FOREIGN KEY (imposto_id) references imposto(id); 
ALTER TABLE system_document ADD CONSTRAINT fk_system_document_2 FOREIGN KEY (category_id) references system_document_category(id); 
ALTER TABLE system_document ADD CONSTRAINT fk_system_document_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_document_group ADD CONSTRAINT fk_system_document_group_2 FOREIGN KEY (document_id) references system_document(id); 
ALTER TABLE system_document_group ADD CONSTRAINT fk_system_document_group_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_document_user ADD CONSTRAINT fk_system_document_user_2 FOREIGN KEY (document_id) references system_document(id); 
ALTER TABLE system_document_user ADD CONSTRAINT fk_system_document_user_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_group_program ADD CONSTRAINT fk_system_group_program_1 FOREIGN KEY (system_program_id) references system_program(id); 
ALTER TABLE system_group_program ADD CONSTRAINT fk_system_group_program_2 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_message ADD CONSTRAINT fk_system_message_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_message ADD CONSTRAINT fk_system_message_2 FOREIGN KEY (system_user_to_id) references system_users(id); 
ALTER TABLE system_notification ADD CONSTRAINT fk_system_notification_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_notification ADD CONSTRAINT fk_system_notification_2 FOREIGN KEY (system_user_to_id) references system_users(id); 
ALTER TABLE system_unit ADD CONSTRAINT fk_system_unit_1 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE system_user_group ADD CONSTRAINT fk_system_user_group_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_user_group ADD CONSTRAINT fk_system_user_group_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_user_program ADD CONSTRAINT fk_system_user_program_1 FOREIGN KEY (system_program_id) references system_program(id); 
ALTER TABLE system_user_program ADD CONSTRAINT fk_system_user_program_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_users_3 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_user_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_user_2 FOREIGN KEY (frontpage_id) references system_program(id); 
ALTER TABLE system_user_unit ADD CONSTRAINT fk_system_user_unit_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_user_unit ADD CONSTRAINT fk_system_user_unit_2 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE template_acao ADD CONSTRAINT fk_template_acao_1 FOREIGN KEY (template_clinica_id) references template_clinica(id); 
ALTER TABLE template_clinica ADD CONSTRAINT fk_template_clinica_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE tipo_documento ADD CONSTRAINT fk_tipo_documento_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE tipo_pagamento ADD CONSTRAINT fk_tipo_pagamento_1 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE webhook_log ADD CONSTRAINT fk_webhook_log_1 FOREIGN KEY (gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE whatsapp_config ADD CONSTRAINT fk_whatsapp_config_1 FOREIGN KEY (clinica_id) references clinica(id); 
