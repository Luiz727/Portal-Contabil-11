CREATE TABLE account( 
      id number(10)    NOT NULL , 
      cidade_id number(10)   , 
      system_user_id number(10)   , 
      nome_responsavel varchar(3000)    NOT NULL , 
      razao_social varchar(3000)    NOT NULL , 
      tipo_pessoa char  (1)    DEFAULT 'J' , 
      documento varchar(3000)   , 
      email varchar(3000)   , 
      telefone varchar(3000)   , 
      cep varchar(3000)   , 
      rua varchar(3000)   , 
      numero varchar(3000)   , 
      complemento varchar(3000)   , 
      bairro varchar(3000)   , 
      mes_criacao number(10)   , 
      ano_criacao number(10)   , 
      created_at timestamp(0)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE agenda( 
      id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      profissional_id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      horario_inicial time    NOT NULL , 
      horario_final time    NOT NULL , 
      visualizacao_inicial varchar  (30)    DEFAULT 'agendaWeek'  NOT NULL , 
      horario_inicio_intervalo time   , 
      horario_fim_intervalo time   , 
      duracao number(10)    DEFAULT 30  NOT NULL , 
      dias varchar(3000)    NOT NULL , 
      procedimento_id number(10)   , 
      cor varchar  (10)   , 
      aceita_agendamento_online char  (1)    DEFAULT 'F' , 
      publica char  (1)    DEFAULT 'F' , 
      fl_permite_choque_horario char  (1)    DEFAULT 'T' , 
 PRIMARY KEY (id)) ; 

CREATE TABLE agendamento( 
      id number(10)    NOT NULL , 
      paciente_id number(10)    NOT NULL , 
      estado_agenda_id number(10)    NOT NULL , 
      agenda_id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      especialidade_id number(10)   , 
      dt_inicial timestamp(0)    NOT NULL , 
      dt_final timestamp(0)    NOT NULL , 
      agendamento_original_id number(10)   , 
      observacao varchar(3000)   , 
      ativo char  (1)    DEFAULT 'T' , 
      ano_inicial varchar(3000)   , 
      mes_inicial varchar(3000)   , 
      ano_mes_inicial varchar(3000)   , 
      ano_final varchar(3000)   , 
      mes_final varchar(3000)   , 
      ano_mes_final varchar(3000)   , 
      online char  (1)    DEFAULT 'F' , 
      link_atendimento_online varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE agendamento_procedimento( 
      id number(10)    NOT NULL , 
      agendamento_id number(10)    NOT NULL , 
      procedimento_id number(10)    NOT NULL , 
      convenio_id number(10)    NOT NULL , 
      quantidade binary_double    NOT NULL , 
      valor binary_double   , 
      valor_total binary_double   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE agenda_profissional( 
      id number(10)    NOT NULL , 
      profissional_id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      agenda_id number(10)    NOT NULL , 
      fl_manipula_atendimento char  (1)    DEFAULT 'N'  NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE anexo( 
      id number(10)    NOT NULL , 
      atendimento_id number(10)    NOT NULL , 
      arquivo varchar(3000)    NOT NULL , 
      observacao varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE atendimento( 
      id number(10)    NOT NULL , 
      agendamento_id number(10)    NOT NULL , 
      paciente_id number(10)    NOT NULL , 
      profissional_id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      dt_inicio timestamp(0)    NOT NULL , 
      dt_final timestamp(0)   , 
      valor_total binary_double   , 
      ano_inicial varchar(3000)   , 
      mes_inicial varchar(3000)   , 
      ano_mes_inicial varchar(3000)   , 
      mes_final varchar(3000)   , 
      ano_final varchar(3000)   , 
      ano_mes_final varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE atendimento_material( 
      id number(10)    NOT NULL , 
      material_id number(10)    NOT NULL , 
      atendimento_id number(10)    NOT NULL , 
      quantidade binary_double    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE atendimento_procedimento( 
      id number(10)    NOT NULL , 
      convenio_id number(10)    NOT NULL , 
      atendimento_id number(10)    NOT NULL , 
      procedimento_id number(10)    NOT NULL , 
      quantidade binary_double    NOT NULL , 
      valor binary_double   , 
      valor_total binary_double   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE bloqueio( 
      id number(10)    NOT NULL , 
      agenda_id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      dt_inicio timestamp(0)    NOT NULL , 
      dt_final timestamp(0)    NOT NULL , 
      observacao varchar(3000)   , 
      horario_bloqueio_original number(10)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE categoria_conta( 
      id number(10)    NOT NULL , 
      tipo_conta_id number(10)    NOT NULL , 
      account_id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE cep_cache( 
      id number(10)    NOT NULL , 
      cep varchar  (12)    NOT NULL , 
      codigo_ibge varchar(3000)   , 
      rua varchar(3000)   , 
      cidade varchar(3000)   , 
      uf varchar(3000)   , 
      cidade_id number(10)   , 
      bairro varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE cidade( 
      id number(10)    NOT NULL , 
      estado_id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      codigo_ibge varchar(3000)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE clinica( 
      id number(10)    NOT NULL , 
      system_unit_id number(10)   , 
      atendimento_categoria_conta_id number(10)   , 
      cidade_id number(10)   , 
      account_id number(10)   , 
      token varchar(3000)   , 
      nome varchar(3000)    NOT NULL , 
      cnpj varchar(3000)   , 
      telefone varchar(3000)   , 
      email varchar(3000)    NOT NULL , 
      endereco varchar(3000)   , 
      bairro varchar(3000)   , 
      cep varchar(3000)   , 
      numero varchar(3000)   , 
      complemento varchar(3000)   , 
      logo_documento varchar(3000)   , 
      nfse_serie varchar(3000)   , 
      razao_social varchar  (255)   , 
      nfse_info varchar(3000)   , 
      nfse_numero varchar(3000)   , 
      regime_tributacao varchar(3000)   , 
      token_integra_notas varchar(3000)   , 
      token_integra_notas_homologacao varchar(3000)   , 
      nfse_emissao_producao char  (1)    DEFAULT 'F' , 
      certificado_a1_conteudo varchar(3000)   , 
      senha_certificado_a1 varchar(3000)   , 
      certificado_a1_nome varchar(3000)   , 
      emitente_configurado char  (1)    DEFAULT 'F' , 
      validade_certificado date   , 
      logo_horizontal_grande varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE clinica_convenio( 
      id number(10)    NOT NULL , 
      convenio_id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE conta( 
      id number(10)    NOT NULL , 
      pessoa_id number(10)    NOT NULL , 
      categoria_conta_id number(10)   , 
      tipo_conta_id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      atendimento_id number(10)   , 
      data_emissao date    NOT NULL , 
      total_parcelas number(10)    DEFAULT 1  NOT NULL , 
      quitada char  (1)    DEFAULT 'F'  NOT NULL , 
      descricao varchar(3000)    NOT NULL , 
      conta_origem_id number(10)   , 
      total_conta binary_double    NOT NULL , 
      mes varchar(3000)   , 
      ano varchar(3000)   , 
      ano_mes varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE convenio( 
      id number(10)    NOT NULL , 
      account_id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE documento( 
      id number(10)    NOT NULL , 
      atendimento_id number(10)    NOT NULL , 
      tipo_documento_id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      procedimento_id number(10)   , 
      texto varchar(3000)    NOT NULL , 
      dt_preenchimento timestamp(0)    NOT NULL , 
      autenticador varchar(3000)   , 
      dt_validade date    NOT NULL , 
      medico_assistente varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE email_config( 
      id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      port varchar(3000)   , 
      username varchar(3000)   , 
      password varchar(3000)   , 
      host varchar(3000)   , 
      from_email varchar(3000)   , 
      from_name varchar(3000)   , 
      smtp_auth char  (1)    DEFAULT 'T' , 
 PRIMARY KEY (id)) ; 

CREATE TABLE especialidade( 
      id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      descricao varchar(3000)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      sigla char  (2)    NOT NULL , 
      codigo_ibge varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado_agenda( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      estado_inicial char  (1)    DEFAULT 'N'  NOT NULL , 
      estado_final char  (1)    DEFAULT 'N'  NOT NULL , 
      cor varchar  (10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado_agendamento( 
      id number(10)    NOT NULL , 
      agendamento_id number(10)    NOT NULL , 
      estado_agenda_id number(10)    NOT NULL , 
      system_users_id number(10)   , 
      atribuido_em timestamp(0)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE exame( 
      id number(10)    NOT NULL , 
      ativo char  (1)    DEFAULT 'T'  NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      codigo_referencia varchar(3000)   , 
      clinica_id number(10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE exame_atendimento( 
      id number(10)    NOT NULL , 
      atendimento_id number(10)    NOT NULL , 
      exame_id number(10)    NOT NULL , 
      indicacao_clinica varchar(3000)    NOT NULL , 
      dt_exames date    NOT NULL , 
      quantidade number(10)    DEFAULT 1  NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE formulario( 
      id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      ativo char  (1)    DEFAULT 'T'  NOT NULL , 
      ordem number(10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE grupo( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      cor varchar  (10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE imposto( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      codigo varchar(3000)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE lancamento( 
      id number(10)    NOT NULL , 
      conta_id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      tipo_pagamento_id number(10)   , 
      nota_fiscal_servico_id number(10)   , 
      parcela number(10)    DEFAULT 1  NOT NULL , 
      dt_vencimento date    NOT NULL , 
      valor binary_double    NOT NULL , 
      dt_pagamento date   , 
      ano_pagamento varchar(3000)   , 
      mes_pagamento varchar(3000)   , 
      ano_mes_pagamento varchar(3000)   , 
      ano_vencimento varchar(3000)   , 
      mes_vencimento varchar(3000)   , 
      ano_mes_vencimento varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE material( 
      id number(10)    NOT NULL , 
      unidade_medida_id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      estoque_minimo binary_double   , 
      dt_vencimento date   , 
      estoque_atualizado binary_double   , 
      lote varchar(3000)   , 
      ativo char  (1)    DEFAULT 'T'  NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE medicamento( 
      id number(10)    NOT NULL , 
      prescricao_id number(10)    NOT NULL , 
      medicamento varchar(3000)    NOT NULL , 
      quantidade varchar(3000)    NOT NULL , 
      posologia varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE mensagem( 
      id number(10)    NOT NULL , 
      agendamento_id number(10)    NOT NULL , 
      template_clinica_id number(10)   , 
      system_user_id number(10)    NOT NULL , 
      titulo varchar(3000)   , 
      template varchar(3000)   , 
      enviado_em timestamp(0)   , 
      tipo_mensagem varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE mensagem_acao( 
      id number(10)    NOT NULL , 
      mensagem_id number(10)    NOT NULL , 
      url varchar(3000)   , 
      label varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE movimentacao( 
      id number(10)    NOT NULL , 
      material_id number(10)    NOT NULL , 
      system_user_id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      dt_movimentacao varchar(3000)   , 
      quantidade binary_double   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE nota_fiscal_servico( 
      id number(10)    NOT NULL , 
      cidade_tomador_id number(10)    NOT NULL , 
      cidade_prestador_id number(10)    NOT NULL , 
      municipio_prestacao_servico_id number(10)    NOT NULL , 
      nota_fiscal_status_id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      cliente_id number(10)    NOT NULL , 
      conta_id number(10)   , 
      lancamento_id number(10)   , 
      natureza_operacao varchar(3000)   , 
      data_hora_emissao timestamp(0)    NOT NULL , 
      discriminacao varchar(3000)    NOT NULL , 
      numero varchar(3000)   , 
      codigo_verificacao varchar(3000)   , 
      id_gateway_externo varchar(3000)   , 
      dados_gateway_externo varchar(3000)   , 
      nome_tomador varchar(3000)    NOT NULL , 
      documento_tomador varchar(3000)    NOT NULL , 
      endereco_tomador varchar(3000)    NOT NULL , 
      email_tomador varchar(3000)    NOT NULL , 
      telefone_tomador varchar(3000)   , 
      numero_tomador varchar(3000)    NOT NULL , 
      bairro_tomador varchar(3000)    NOT NULL , 
      cep_tomador varchar(3000)    NOT NULL , 
      inscricao_municipal_tomador varchar(3000)   , 
      inscricao_municipal_prestador varchar(3000)   , 
      nome_prestador varchar(3000)    NOT NULL , 
      documento_prestador varchar(3000)    NOT NULL , 
      endereco_prestador varchar(3000)    NOT NULL , 
      email_prestador varchar(3000)    NOT NULL , 
      telefone_prestador varchar(3000)   , 
      numero_prestador varchar(3000)    NOT NULL , 
      bairro_prestador varchar(3000)    NOT NULL , 
      cep_prestador varchar(3000)    NOT NULL , 
      iss_retido char  (1)    DEFAULT 'F' , 
      desconto_incondicionado binary_double    DEFAULT 0.00 , 
      desconto_condicionado binary_double    DEFAULT 0.00 , 
      base_calculo_iss binary_double   , 
      aliquota_iss binary_double   , 
      aliquota_pis binary_double   , 
      aliquota_cofins binary_double   , 
      aliquota_csll binary_double   , 
      aliquota_irrf binary_double   , 
      aliquota_inss binary_double   , 
      valor_deducoes binary_double   , 
      valor_retencoes binary_double   , 
      valor_outras_retencoes binary_double   , 
      valor_liquido binary_double   , 
      valor_servicos binary_double   , 
      valor_iss binary_double   , 
      valor_pis binary_double    DEFAULT 0.00 , 
      valor_inss binary_double    DEFAULT 0.00 , 
      valor_cofins binary_double    DEFAULT 0.00 , 
      valor_csll binary_double   , 
      valor_irrf binary_double    DEFAULT 0.00 , 
      incentivador_cultural char  (1)    DEFAULT 'F' , 
      optante_simples_nacional char  (1)    DEFAULT 'F' , 
      nfse_status varchar(3000)   , 
      ano varchar(3000)   , 
      mes varchar(3000)   , 
      ano_mes varchar(3000)   , 
      pdf varchar(3000)   , 
      xml varchar(3000)   , 
      link_pdf_prefeitura varchar(3000)   , 
      regime_tributario_municipal varchar(3000)   , 
      numero_rps varchar(3000)   , 
      mensagem_erro varchar(3000)   , 
      email_enviado char  (1)    DEFAULT 'F' , 
      servico_id number(10)    NOT NULL , 
      serie_rps varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE nota_fiscal_status( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      cor varchar(3000)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa( 
      id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      nome varchar  (255)    NOT NULL , 
      documento varchar(3000)   , 
      email varchar  (255)   , 
      telefone varchar  (20)   , 
      system_users_id number(10)   , 
      sexo char  (1)   , 
      nome_civel varchar  (255)   , 
      rg varchar(3000)   , 
      dt_nascimento date   , 
      profissao varchar(3000)   , 
      tratamento varchar(3000)   , 
      observacao varchar(3000)   , 
      assinatura varchar(3000)   , 
      usuario varchar  (255)   , 
      senha varchar  (255)   , 
      foto varchar(3000)   , 
      aceita_receber_mensagen_whatsapp char  (1)    DEFAULT 'F'  NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa_endereco( 
      id number(10)    NOT NULL , 
      pessoa_id number(10)    NOT NULL , 
      cidade_id number(10)    NOT NULL , 
      cep varchar  (10)    NOT NULL , 
      rua varchar  (500)    NOT NULL , 
      bairro varchar  (500)    NOT NULL , 
      numero varchar  (100)    NOT NULL , 
      complemento varchar  (500)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa_especialidade( 
      id number(10)    NOT NULL , 
      pessoa_id number(10)    NOT NULL , 
      especialidade_id number(10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa_grupo( 
      id number(10)    NOT NULL , 
      pessoa_id number(10)    NOT NULL , 
      grupo_id number(10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE prescricao( 
      id number(10)    NOT NULL , 
      atendimento_id number(10)    NOT NULL , 
      controle_especial char  (1)    DEFAULT 'N'  NOT NULL , 
      dt_prescricao date    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE procedimento( 
      id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      cor varchar  (10)    NOT NULL , 
      duracao time   , 
      codigo_referencia varchar(3000)   , 
      ativo char  (1)    DEFAULT 'T'  NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE procedimento_material( 
      id number(10)    NOT NULL , 
      procedimento_id number(10)    NOT NULL , 
      material_id number(10)    NOT NULL , 
      quantidade binary_double   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE procedimento_preco( 
      id number(10)    NOT NULL , 
      procedimento_id number(10)    NOT NULL , 
      convenio_id number(10)    NOT NULL , 
      valor binary_double    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE questao( 
      id number(10)    NOT NULL , 
      formulario_id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      tipo_campo varchar(3000)    NOT NULL , 
      fl_obrigatorio char  (1)    DEFAULT 'F'  NOT NULL , 
      ativo char  (1)    DEFAULT 'T'  NOT NULL , 
      opcoes varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE resposta( 
      id number(10)    NOT NULL , 
      resposta_formulario_id number(10)    NOT NULL , 
      questao_id number(10)    NOT NULL , 
      resposta varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE resposta_formulario( 
      id number(10)    NOT NULL , 
      formulario_id number(10)    NOT NULL , 
      atendimento_id number(10)    NOT NULL , 
      dt_resposta date   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_configuracao( 
      id number(10)    NOT NULL , 
      cidade_id number(10)   , 
      saas_plano_valor_trial_id number(10)   , 
      contrato_inativo_system_group_id number(10)   , 
      parametro_fiscal_id number(10)   , 
      razao_social varchar(3000)   , 
      nome_fantasia varchar(3000)   , 
      cnpj varchar(3000)   , 
      inscricao_estadual varchar(3000)   , 
      inscricao_municipal varchar(3000)   , 
      cep varchar(3000)   , 
      rua varchar(3000)   , 
      bairro varchar(3000)   , 
      numero varchar(3000)   , 
      complemento varchar(3000)   , 
      email varchar(3000)    NOT NULL , 
      telefone varchar(3000)    NOT NULL , 
      dias_trial number(10)   , 
      contrato varchar(3000)   , 
      regime_tributacao varchar(3000)   , 
      token_integra_notas varchar(3000)   , 
      token_integra_notas_homologacao varchar(3000)   , 
      nfse_emissao_producao char  (1)    DEFAULT 'F'  NOT NULL , 
      nfse_numero varchar(3000)   , 
      nfse_serie varchar(3000)   , 
      nfse_info varchar(3000)   , 
      termo_uso varchar(3000)   , 
      email_port varchar(3000)   , 
      email_username varchar(3000)   , 
      email_password varchar(3000)   , 
      email_host varchar(3000)   , 
      email_from varchar(3000)   , 
      email_from_name varchar(3000)   , 
      email_smtp_auth char  (1)    DEFAULT 'F' , 
      dias_renovacao_contrato number(10)   , 
      dias_vencimento_pagamento number(10)   , 
      token_integra_notas_software_house varchar(3000)   , 
      url_sistema varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_contrato( 
      id number(10)    NOT NULL , 
      saas_plano_valor_id number(10)    NOT NULL , 
      account_id number(10)    NOT NULL , 
      saas_contrato_status_id number(10)    NOT NULL , 
      valor_total binary_double   , 
      data_inicial date    NOT NULL , 
      data_final date   , 
      criado_em timestamp(0)   , 
      renovacao char  (1)    DEFAULT 'F' , 
      total_usuarios number(10)   , 
      total_unidades number(10)   , 
      gateway_assinatura_id varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_contrato_grupo( 
      id number(10)    NOT NULL , 
      saas_contrato_id number(10)    NOT NULL , 
      system_group_id number(10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_contrato_status( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      cor varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_email_log( 
      id number(10)    NOT NULL , 
      titulo varchar(3000)   , 
      conteudo varchar(3000)   , 
      destinatario varchar(3000)   , 
      created_at timestamp(0)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_error_log( 
      id number(10)    NOT NULL , 
      system_unit_id number(10)   , 
      system_user_id number(10)   , 
      error_class varchar  (255)   , 
      error_method varchar  (255)   , 
      message varchar(3000)   , 
      payload varchar(3000)   , 
      created_at timestamp(0)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_forma_pagamento( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_forma_pagamento( 
      id number(10)    NOT NULL , 
      saas_forma_pagamento_id number(10)    NOT NULL , 
      saas_gateway_pagamento_id number(10)    NOT NULL , 
      codigo varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_pagamento( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      ativo char  (1)    DEFAULT 'T'  NOT NULL , 
      public_key varchar(3000)   , 
      access_token varchar(3000)   , 
      client_secret varchar(3000)   , 
      client_id varchar(3000)   , 
      oauth_token varchar(3000)   , 
      oauth_token_created_at timestamp(0)   , 
      certificado_crt varchar(3000)   , 
      certificado_key varchar(3000)   , 
      webhook_url varchar(3000)   , 
      webhook_certificado_cert varchar(3000)   , 
      fl_homologacao char  (1)    DEFAULT 'T' , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_pagamento_status( 
      id number(10)    NOT NULL , 
      saas_gateway_pagamento_id number(10)    NOT NULL , 
      saas_status_pagamento_id number(10)    NOT NULL , 
      codigo varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_imposto( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      codigo varchar(3000)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_nota_fiscal_servico( 
      id number(10)    NOT NULL , 
      saas_pagamento_id number(10)   , 
      saas_plano_valor_id number(10)   , 
      saas_servico_id number(10)   , 
      cidade_tomador_id number(10)    NOT NULL , 
      cidade_prestador_id number(10)    NOT NULL , 
      municipio_prestacao_servico_id number(10)    NOT NULL , 
      nota_fiscal_status_id number(10)    NOT NULL , 
      account_id number(10)    NOT NULL , 
      natureza_operacao varchar(3000)   , 
      data_hora_emissao timestamp(0)    NOT NULL , 
      discriminacao varchar(3000)    NOT NULL , 
      numero varchar(3000)   , 
      codigo_verificacao varchar(3000)   , 
      id_gateway_externo varchar(3000)   , 
      dados_gateway_externo varchar(3000)   , 
      nome_tomador varchar(3000)    NOT NULL , 
      documento_tomador varchar(3000)    NOT NULL , 
      endereco_tomador varchar(3000)    NOT NULL , 
      email_tomador varchar(3000)    NOT NULL , 
      telefone_tomador varchar(3000)   , 
      numero_tomador varchar(3000)    NOT NULL , 
      bairro_tomador varchar(3000)    NOT NULL , 
      cep_tomador varchar(3000)    NOT NULL , 
      inscricao_municipal_tomador varchar(3000)   , 
      inscricao_municipal_prestador varchar(3000)   , 
      nome_prestador varchar(3000)    NOT NULL , 
      documento_prestador varchar(3000)    NOT NULL , 
      endereco_prestador varchar(3000)    NOT NULL , 
      email_prestador varchar(3000)    NOT NULL , 
      telefone_prestador varchar(3000)   , 
      numero_prestador varchar(3000)    NOT NULL , 
      bairro_prestador varchar(3000)    NOT NULL , 
      cep_prestador varchar(3000)    NOT NULL , 
      iss_retido char  (1)    DEFAULT 'F' , 
      desconto_incondicionado binary_double    DEFAULT 0.00 , 
      desconto_condicionado binary_double    DEFAULT 0.00 , 
      base_calculo_iss binary_double   , 
      aliquota_iss binary_double   , 
      aliquota_pis binary_double   , 
      aliquota_cofins binary_double   , 
      aliquota_csll binary_double   , 
      aliquota_irrf binary_double   , 
      aliquota_inss binary_double   , 
      valor_deducoes binary_double   , 
      valor_retencoes binary_double   , 
      valor_outras_retencoes binary_double   , 
      valor_liquido binary_double   , 
      valor_servicos binary_double   , 
      valor_iss binary_double   , 
      valor_pis binary_double    DEFAULT 0.00 , 
      valor_inss binary_double    DEFAULT 0.00 , 
      valor_cofins binary_double    DEFAULT 0.00 , 
      valor_csll binary_double   , 
      valor_irrf binary_double    DEFAULT 0.00 , 
      incentivador_cultural char  (1)    DEFAULT 'F' , 
      optante_simples_nacional char  (1)    DEFAULT 'F' , 
      nfse_status varchar(3000)   , 
      ano varchar(3000)   , 
      mes varchar(3000)   , 
      ano_mes varchar(3000)   , 
      pdf varchar(3000)   , 
      xml varchar(3000)   , 
      link_pdf_prefeitura varchar(3000)   , 
      regime_tributario_municipal varchar(3000)   , 
      numero_rps varchar(3000)   , 
      mensagem_erro varchar(3000)   , 
      email_enviado char  (1)    DEFAULT 'F' , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_pagamento( 
      id number(10)    NOT NULL , 
      account_id number(10)    NOT NULL , 
      saas_status_pagamento_id number(10)    NOT NULL , 
      saas_contrato_id number(10)   , 
      saas_servico_id number(10)   , 
      saas_forma_pagamento_id number(10)    NOT NULL , 
      saas_gateway_pagamento_id number(10)    NOT NULL , 
      saas_nota_fiscal_servico_id number(10)   , 
      valor binary_double    NOT NULL , 
      data_compra timestamp(0)    NOT NULL , 
      data_vencimento date   , 
      data_pagamento date   , 
      dados_gateway varchar(3000)   , 
      id_gateway varchar(3000)   , 
      payment_id varchar(3000)   , 
      link_gateway varchar(3000)   , 
      mes_compra number(10)   , 
      ano_compra number(10)   , 
      ano_pagamento number(10)   , 
      mes_pagamento number(10)   , 
      mes_ano_pagamento varchar(3000)   , 
      mes_ano_compra varchar(3000)   , 
      renovacao char  (1)    DEFAULT 'F' , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_plano( 
      id number(10)    NOT NULL , 
      saas_servico_id number(10)   , 
      nome varchar(3000)    NOT NULL , 
      descricao varchar(3000)    NOT NULL , 
      ativo char  (1)    DEFAULT 'T'  NOT NULL , 
      limite_usuarios number(10)   , 
      limite_unidades number(10)   , 
      discriminacao varchar(3000)   , 
      ordem number(10)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_plano_grupo( 
      id number(10)    NOT NULL , 
      saas_plano_id number(10)    NOT NULL , 
      system_group_id number(10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_plano_valor( 
      id number(10)    NOT NULL , 
      saas_plano_id number(10)    NOT NULL , 
      valor binary_double    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      duracao number(10)   , 
      ativo char  (1)    DEFAULT 'T' , 
      desativado_em timestamp(0)   , 
      recorrencia char  (1)    DEFAULT 'F' , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico( 
      id number(10)    NOT NULL , 
      servico_grupo_imposto_id number(10)   , 
      nome varchar(3000)    NOT NULL , 
      preco binary_double   , 
      descricao varchar(3000)    NOT NULL , 
      ativo char  (1)    DEFAULT 'T'  NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico_grupo_imposto( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      codigo_cnae varchar(3000)   , 
      codigo_tributacao_municipio varchar(3000)   , 
      codigo_nbs varchar(3000)   , 
      codigo varchar(3000)   , 
      descricao_servico_municipio varchar(3000)   , 
      iss_retido varchar(3000)   , 
      natureza_operacao varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico_grupo_imposto_item( 
      id number(10)    NOT NULL , 
      saas_servico_grupo_imposto_id number(10)    NOT NULL , 
      saas_imposto_id number(10)    NOT NULL , 
      aliquota binary_double    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_status_pagamento( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      cor varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_template_email( 
      id number(10)    NOT NULL , 
      descricao varchar(3000)   , 
      titulo varchar(3000)   , 
      conteudo varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE servico( 
      id number(10)    NOT NULL , 
      account_id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      descricao varchar(3000)   , 
      codigo_cnae varchar(3000)   , 
      codigo_tributacao_municipio varchar(3000)   , 
      codigo_nbs varchar(3000)   , 
      codigo varchar(3000)   , 
      descricao_servico_municipio varchar(3000)   , 
      iss_retido varchar(3000)   , 
      natureza_operacao varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE servico_imposto_item( 
      id number(10)    NOT NULL , 
      servico_id number(10)    NOT NULL , 
      imposto_id number(10)    NOT NULL , 
      aliquota binary_double    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document( 
      id number(10)    NOT NULL , 
      category_id number(10)    NOT NULL , 
      system_user_id number(10)   , 
      title varchar(3000)    NOT NULL , 
      description varchar(3000)   , 
      submission_date date   , 
      archive_date date   , 
      filename varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document_category( 
      id number(10)    NOT NULL , 
      name varchar(3000)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document_group( 
      id number(10)    NOT NULL , 
      document_id number(10)    NOT NULL , 
      system_group_id number(10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document_user( 
      id number(10)    NOT NULL , 
      document_id number(10)    NOT NULL , 
      system_user_id number(10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group( 
      id number(10)    NOT NULL , 
      name varchar(3000)    NOT NULL , 
      uuid varchar  (36)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group_program( 
      id number(10)    NOT NULL , 
      system_group_id number(10)    NOT NULL , 
      system_program_id number(10)    NOT NULL , 
      actions varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_message( 
      id number(10)    NOT NULL , 
      system_user_id number(10)    NOT NULL , 
      system_user_to_id number(10)    NOT NULL , 
      subject varchar(3000)    NOT NULL , 
      message varchar(3000)   , 
      dt_message timestamp(0)   , 
      checked char  (1)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_notification( 
      id number(10)    NOT NULL , 
      system_user_id number(10)    NOT NULL , 
      system_user_to_id number(10)    NOT NULL , 
      subject varchar(3000)   , 
      message varchar(3000)   , 
      dt_message timestamp(0)   , 
      action_url varchar(3000)   , 
      action_label varchar(3000)   , 
      icon varchar(3000)   , 
      checked char  (1)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_preference( 
      id varchar  (255)    NOT NULL , 
      preference varchar(3000)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_program( 
      id number(10)    NOT NULL , 
      name varchar(3000)    NOT NULL , 
      controller varchar(3000)    NOT NULL , 
      actions varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_unit( 
      id number(10)    NOT NULL , 
      account_id number(10)   , 
      name varchar(3000)    NOT NULL , 
      connection_name varchar(3000)   , 
      active char  (1)    DEFAULT 'T' , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_group( 
      id number(10)    NOT NULL , 
      system_user_id number(10)    NOT NULL , 
      system_group_id number(10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_program( 
      id number(10)    NOT NULL , 
      system_user_id number(10)    NOT NULL , 
      system_program_id number(10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_users( 
      id number(10)    NOT NULL , 
      name varchar(3000)    NOT NULL , 
      login varchar(3000)    NOT NULL , 
      password varchar(3000)    NOT NULL , 
      email varchar(3000)   , 
      frontpage_id number(10)   , 
      system_unit_id number(10)   , 
      account_id number(10)   , 
      active char  (1)   , 
      accepted_term_policy char  (1)   , 
      accepted_term_policy_at varchar(3000)   , 
      two_factor_enabled char  (1)    DEFAULT 'N' , 
      two_factor_type varchar  (100)   , 
      two_factor_secret varchar  (255)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_unit( 
      id number(10)    NOT NULL , 
      system_user_id number(10)    NOT NULL , 
      system_unit_id number(10)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE template_acao( 
      id number(10)    NOT NULL , 
      template_clinica_id number(10)    NOT NULL , 
      url varchar(3000)   , 
      label varchar(3000)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE template_clinica( 
      id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      chave varchar(3000)    NOT NULL , 
      descricao varchar(3000)    NOT NULL , 
      habilitado char  (1)    DEFAULT 'T'  NOT NULL , 
      template varchar(3000)   , 
      titulo varchar(3000)   , 
      tipo_template varchar(3000)   , 
      readonly char  (1)    DEFAULT 'F'  NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_conta( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_documento( 
      id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      texto_padrao varchar(3000)    NOT NULL , 
      ativo char  (1)    DEFAULT 'S'  NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_pagamento( 
      id number(10)    NOT NULL , 
      account_id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      ativo char  (1)    DEFAULT 'T'  NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE unidade_medida( 
      id number(10)    NOT NULL , 
      nome varchar(3000)    NOT NULL , 
      sigla varchar(3000)    NOT NULL , 
 PRIMARY KEY (id)) ; 

CREATE TABLE webhook_log( 
      id number(10)    NOT NULL , 
      gateway_pagamento_id number(10)   , 
      payload varchar(3000)   , 
      created_at timestamp(0)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE whatsapp_config( 
      id number(10)    NOT NULL , 
      clinica_id number(10)    NOT NULL , 
      phone varchar(3000)   , 
      status varchar(3000)   , 
      api_token varchar(3000)   , 
      api_key varchar(3000)   , 
      api_client_token varchar(3000)   , 
 PRIMARY KEY (id)) ; 

 
 ALTER TABLE cep_cache ADD UNIQUE (cep);
  
 ALTER TABLE account ADD CONSTRAINT fk_account_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE account ADD CONSTRAINT fk_account_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE agenda ADD CONSTRAINT fk_agenda_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE agenda ADD CONSTRAINT fk_agenda_2 FOREIGN KEY (profissional_id) references pessoa(id); 
ALTER TABLE agenda ADD CONSTRAINT fk_agenda_3 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_5 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_1 FOREIGN KEY (paciente_id) references pessoa(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_2 FOREIGN KEY (estado_agenda_id) references estado_agenda(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_3 FOREIGN KEY (agenda_id) references agenda(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_4 FOREIGN KEY (especialidade_id) references especialidade(id); 
ALTER TABLE agendamento_procedimento ADD CONSTRAINT fk_agendamento_procedimento_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE agendamento_procedimento ADD CONSTRAINT fk_agendamento_procedimento_2 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE agendamento_procedimento ADD CONSTRAINT fk_agendamento_procedimento_3 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE agenda_profissional ADD CONSTRAINT fk_agenda_profissional_3 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE agenda_profissional ADD CONSTRAINT fk_agenda_profissional_1 FOREIGN KEY (profissional_id) references pessoa(id); 
ALTER TABLE agenda_profissional ADD CONSTRAINT fk_agenda_profissional_2 FOREIGN KEY (agenda_id) references agenda(id); 
ALTER TABLE anexo ADD CONSTRAINT fk_anexo_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_4 FOREIGN KEY (clinica_id) references system_unit(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_2 FOREIGN KEY (paciente_id) references pessoa(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_3 FOREIGN KEY (profissional_id) references pessoa(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE atendimento_material ADD CONSTRAINT fk_atendimento_material_1 FOREIGN KEY (material_id) references material(id); 
ALTER TABLE atendimento_material ADD CONSTRAINT fk_atendimento_material_2 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE atendimento_procedimento ADD CONSTRAINT fk_atendimento_procedimento_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE atendimento_procedimento ADD CONSTRAINT fk_atendimento_procedimento_2 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE atendimento_procedimento ADD CONSTRAINT fk_atendimento_procedimento_3 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE bloqueio ADD CONSTRAINT fk_bloqueio_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE bloqueio ADD CONSTRAINT fk_bloqueio_1 FOREIGN KEY (agenda_id) references agenda(id); 
ALTER TABLE categoria_conta ADD CONSTRAINT fk_categoria_conta_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE categoria_conta ADD CONSTRAINT fk_categoria_conta_1 FOREIGN KEY (tipo_conta_id) references tipo_conta(id); 
ALTER TABLE cidade ADD CONSTRAINT fk_cidade_1 FOREIGN KEY (estado_id) references estado(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_3 FOREIGN KEY (atendimento_categoria_conta_id) references categoria_conta(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_4 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE clinica_convenio ADD CONSTRAINT fk_clinica_convenio_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE clinica_convenio ADD CONSTRAINT fk_clinica_convenio_1 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_3 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_4 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_5 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_2 FOREIGN KEY (tipo_conta_id) references tipo_conta(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_1 FOREIGN KEY (categoria_conta_id) references categoria_conta(id); 
ALTER TABLE convenio ADD CONSTRAINT fk_convenio_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_1 FOREIGN KEY (tipo_documento_id) references tipo_documento(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_2 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_3 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_4 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE email_config ADD CONSTRAINT fk_email_config_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE especialidade ADD CONSTRAINT fk_especialidade_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE estado_agendamento ADD CONSTRAINT fk_estado_agendamento_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE estado_agendamento ADD CONSTRAINT fk_estado_agendamento_2 FOREIGN KEY (estado_agenda_id) references estado_agenda(id); 
ALTER TABLE estado_agendamento ADD CONSTRAINT fk_estado_agendamento_3 FOREIGN KEY (system_users_id) references system_users(id); 
ALTER TABLE exame ADD CONSTRAINT fk_exame_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE exame_atendimento ADD CONSTRAINT fk_exame_atendimento_2 FOREIGN KEY (exame_id) references exame(id); 
ALTER TABLE exame_atendimento ADD CONSTRAINT fk_exame_atendimento_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE formulario ADD CONSTRAINT fk_formulario_1 FOREIGN KEY (clinica_id) references system_unit(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_4 FOREIGN KEY (nota_fiscal_servico_id) references nota_fiscal_servico(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_1 FOREIGN KEY (conta_id) references conta(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_2 FOREIGN KEY (tipo_pagamento_id) references tipo_pagamento(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_3 FOREIGN KEY (clinica_id) references system_unit(id); 
ALTER TABLE material ADD CONSTRAINT fk_material_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE material ADD CONSTRAINT fk_material_1 FOREIGN KEY (unidade_medida_id) references unidade_medida(id); 
ALTER TABLE medicamento ADD CONSTRAINT fk_medicamento_1 FOREIGN KEY (prescricao_id) references prescricao(id); 
ALTER TABLE mensagem ADD CONSTRAINT fk_message_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE mensagem ADD CONSTRAINT fk_message_2 FOREIGN KEY (template_clinica_id) references template_clinica(id); 
ALTER TABLE mensagem ADD CONSTRAINT fk_message_3 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE mensagem_acao ADD CONSTRAINT fk_mensagem_acao_1 FOREIGN KEY (mensagem_id) references mensagem(id); 
ALTER TABLE movimentacao ADD CONSTRAINT fk_movimentacao_3 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE movimentacao ADD CONSTRAINT fk_movimentacao_1 FOREIGN KEY (material_id) references material(id); 
ALTER TABLE movimentacao ADD CONSTRAINT fk_movimentacao_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_3 FOREIGN KEY (municipio_prestacao_servico_id) references cidade(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_4 FOREIGN KEY (nota_fiscal_status_id) references nota_fiscal_status(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_5 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_6 FOREIGN KEY (cliente_id) references pessoa(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_9 FOREIGN KEY (lancamento_id) references lancamento(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_7 FOREIGN KEY (cidade_tomador_id) references cidade(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_1 FOREIGN KEY (conta_id) references conta(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_2 FOREIGN KEY (cidade_prestador_id) references cidade(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_8 FOREIGN KEY (servico_id) references servico(id); 
ALTER TABLE pessoa ADD CONSTRAINT fk_pessoa_1 FOREIGN KEY (system_users_id) references system_users(id); 
ALTER TABLE pessoa ADD CONSTRAINT fk_pessoa_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE pessoa_endereco ADD CONSTRAINT fk_pessoa_endereco_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE pessoa_endereco ADD CONSTRAINT fk_pessoa_endereco_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_especialidade ADD CONSTRAINT fk_pessoa_especialidade_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_especialidade ADD CONSTRAINT fk_pessoa_especialidade_2 FOREIGN KEY (especialidade_id) references especialidade(id); 
ALTER TABLE pessoa_grupo ADD CONSTRAINT fk_pessoa_grupo_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_grupo ADD CONSTRAINT fk_pessoa_grupo_2 FOREIGN KEY (grupo_id) references grupo(id); 
ALTER TABLE prescricao ADD CONSTRAINT fk_prescricao_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE procedimento ADD CONSTRAINT fk_procedimento_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE procedimento_material ADD CONSTRAINT fk_procedimento_material_1 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE procedimento_material ADD CONSTRAINT fk_procedimento_material_2 FOREIGN KEY (material_id) references material(id); 
ALTER TABLE procedimento_preco ADD CONSTRAINT fk_procedimento_preco_1 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE procedimento_preco ADD CONSTRAINT fk_procedimento_preco_2 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE questao ADD CONSTRAINT fk_questao_1 FOREIGN KEY (formulario_id) references formulario(id); 
ALTER TABLE resposta ADD CONSTRAINT fk_resposta_2 FOREIGN KEY (resposta_formulario_id) references resposta_formulario(id); 
ALTER TABLE resposta ADD CONSTRAINT fk_resposta_1 FOREIGN KEY (questao_id) references questao(id); 
ALTER TABLE resposta_formulario ADD CONSTRAINT fk_resposta_formulario_1 FOREIGN KEY (formulario_id) references formulario(id); 
ALTER TABLE resposta_formulario ADD CONSTRAINT fk_resposta_formulario_2 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_1 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_2 FOREIGN KEY (saas_plano_valor_trial_id) references saas_plano_valor(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_4 FOREIGN KEY (contrato_inativo_system_group_id) references system_group(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_3 FOREIGN KEY (saas_contrato_status_id) references saas_contrato_status(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_4 FOREIGN KEY (saas_plano_valor_id) references saas_plano_valor(id); 
ALTER TABLE saas_contrato_grupo ADD CONSTRAINT fk_saas_contrato_grupo_2 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE saas_contrato_grupo ADD CONSTRAINT fk_saas_contrato_grupo_1 FOREIGN KEY (saas_contrato_id) references saas_contrato(id); 
ALTER TABLE saas_error_log ADD CONSTRAINT fk_saas_error_log_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE saas_error_log ADD CONSTRAINT fk_saas_error_log_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE saas_gateway_forma_pagamento ADD CONSTRAINT fk_saas_forma_pagamento_gateway_1 FOREIGN KEY (saas_forma_pagamento_id) references saas_forma_pagamento(id); 
ALTER TABLE saas_gateway_forma_pagamento ADD CONSTRAINT fk_saas_forma_pagamento_gateway_2 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_gateway_pagamento_status ADD CONSTRAINT fk_saas_gateway_pagamento_status_1 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_gateway_pagamento_status ADD CONSTRAINT fk_saas_gateway_pagamento_status_2 FOREIGN KEY (saas_status_pagamento_id) references saas_status_pagamento(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_6 FOREIGN KEY (saas_pagamento_id) references saas_pagamento(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_2 FOREIGN KEY (cidade_prestador_id) references cidade(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_3 FOREIGN KEY (municipio_prestacao_servico_id) references cidade(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_4 FOREIGN KEY (nota_fiscal_status_id) references nota_fiscal_status(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_5 FOREIGN KEY (saas_plano_valor_id) references saas_plano_valor(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_7 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_1 FOREIGN KEY (cidade_tomador_id) references cidade(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_1 FOREIGN KEY (saas_status_pagamento_id) references saas_status_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_2 FOREIGN KEY (saas_contrato_id) references saas_contrato(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_3 FOREIGN KEY (saas_forma_pagamento_id) references saas_forma_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_4 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_5 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_6 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_7 FOREIGN KEY (saas_nota_fiscal_servico_id) references saas_nota_fiscal_servico(id); 
ALTER TABLE saas_plano ADD CONSTRAINT fk_saas_plano_1 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_plano_grupo ADD CONSTRAINT fk_saas_plano_grupo_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE saas_plano_grupo ADD CONSTRAINT fk_saas_plano_grupo_2 FOREIGN KEY (saas_plano_id) references saas_plano(id); 
ALTER TABLE saas_plano_valor ADD CONSTRAINT fk_saas_plano_valor_1 FOREIGN KEY (saas_plano_id) references saas_plano(id); 
ALTER TABLE saas_servico ADD CONSTRAINT fk_saas_servico_2 FOREIGN KEY (servico_grupo_imposto_id) references saas_servico_grupo_imposto(id); 
ALTER TABLE saas_servico_grupo_imposto_item ADD CONSTRAINT fk_servico_grupo_imposto_item_1 FOREIGN KEY (saas_servico_grupo_imposto_id) references saas_servico_grupo_imposto(id); 
ALTER TABLE saas_servico_grupo_imposto_item ADD CONSTRAINT fk_servico_grupo_imposto_item_2 FOREIGN KEY (saas_imposto_id) references saas_imposto(id); 
ALTER TABLE servico ADD CONSTRAINT fk_servico_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE servico_imposto_item ADD CONSTRAINT fk_servico_imposto_item_1 FOREIGN KEY (servico_id) references servico(id); 
ALTER TABLE servico_imposto_item ADD CONSTRAINT fk_servico_imposto_item_2 FOREIGN KEY (imposto_id) references imposto(id); 
ALTER TABLE system_document ADD CONSTRAINT fk_system_document_2 FOREIGN KEY (category_id) references system_document_category(id); 
ALTER TABLE system_document ADD CONSTRAINT fk_system_document_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_document_group ADD CONSTRAINT fk_system_document_group_2 FOREIGN KEY (document_id) references system_document(id); 
ALTER TABLE system_document_group ADD CONSTRAINT fk_system_document_group_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_document_user ADD CONSTRAINT fk_system_document_user_2 FOREIGN KEY (document_id) references system_document(id); 
ALTER TABLE system_document_user ADD CONSTRAINT fk_system_document_user_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_group_program ADD CONSTRAINT fk_system_group_program_1 FOREIGN KEY (system_program_id) references system_program(id); 
ALTER TABLE system_group_program ADD CONSTRAINT fk_system_group_program_2 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_message ADD CONSTRAINT fk_system_message_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_message ADD CONSTRAINT fk_system_message_2 FOREIGN KEY (system_user_to_id) references system_users(id); 
ALTER TABLE system_notification ADD CONSTRAINT fk_system_notification_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_notification ADD CONSTRAINT fk_system_notification_2 FOREIGN KEY (system_user_to_id) references system_users(id); 
ALTER TABLE system_unit ADD CONSTRAINT fk_system_unit_1 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE system_user_group ADD CONSTRAINT fk_system_user_group_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_user_group ADD CONSTRAINT fk_system_user_group_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_user_program ADD CONSTRAINT fk_system_user_program_1 FOREIGN KEY (system_program_id) references system_program(id); 
ALTER TABLE system_user_program ADD CONSTRAINT fk_system_user_program_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_users_3 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_user_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_user_2 FOREIGN KEY (frontpage_id) references system_program(id); 
ALTER TABLE system_user_unit ADD CONSTRAINT fk_system_user_unit_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_user_unit ADD CONSTRAINT fk_system_user_unit_2 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE template_acao ADD CONSTRAINT fk_template_acao_1 FOREIGN KEY (template_clinica_id) references template_clinica(id); 
ALTER TABLE template_clinica ADD CONSTRAINT fk_template_clinica_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE tipo_documento ADD CONSTRAINT fk_tipo_documento_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE tipo_pagamento ADD CONSTRAINT fk_tipo_pagamento_1 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE webhook_log ADD CONSTRAINT fk_webhook_log_1 FOREIGN KEY (gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE whatsapp_config ADD CONSTRAINT fk_whatsapp_config_1 FOREIGN KEY (clinica_id) references clinica(id); 
 CREATE SEQUENCE account_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER account_id_seq_tr 

BEFORE INSERT ON account FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT account_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE agenda_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER agenda_id_seq_tr 

BEFORE INSERT ON agenda FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT agenda_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE agendamento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER agendamento_id_seq_tr 

BEFORE INSERT ON agendamento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT agendamento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE agendamento_procedimento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER agendamento_procedimento_id_seq_tr 

BEFORE INSERT ON agendamento_procedimento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT agendamento_procedimento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE agenda_profissional_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER agenda_profissional_id_seq_tr 

BEFORE INSERT ON agenda_profissional FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT agenda_profissional_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE anexo_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER anexo_id_seq_tr 

BEFORE INSERT ON anexo FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT anexo_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE atendimento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER atendimento_id_seq_tr 

BEFORE INSERT ON atendimento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT atendimento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE atendimento_material_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER atendimento_material_id_seq_tr 

BEFORE INSERT ON atendimento_material FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT atendimento_material_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE atendimento_procedimento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER atendimento_procedimento_id_seq_tr 

BEFORE INSERT ON atendimento_procedimento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT atendimento_procedimento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE bloqueio_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER bloqueio_id_seq_tr 

BEFORE INSERT ON bloqueio FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT bloqueio_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE categoria_conta_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER categoria_conta_id_seq_tr 

BEFORE INSERT ON categoria_conta FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT categoria_conta_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE cep_cache_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER cep_cache_id_seq_tr 

BEFORE INSERT ON cep_cache FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT cep_cache_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE cidade_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER cidade_id_seq_tr 

BEFORE INSERT ON cidade FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT cidade_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE clinica_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER clinica_id_seq_tr 

BEFORE INSERT ON clinica FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT clinica_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE clinica_convenio_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER clinica_convenio_id_seq_tr 

BEFORE INSERT ON clinica_convenio FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT clinica_convenio_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE conta_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER conta_id_seq_tr 

BEFORE INSERT ON conta FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT conta_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE convenio_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER convenio_id_seq_tr 

BEFORE INSERT ON convenio FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT convenio_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE documento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER documento_id_seq_tr 

BEFORE INSERT ON documento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT documento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE email_config_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER email_config_id_seq_tr 

BEFORE INSERT ON email_config FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT email_config_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE especialidade_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER especialidade_id_seq_tr 

BEFORE INSERT ON especialidade FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT especialidade_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE estado_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER estado_id_seq_tr 

BEFORE INSERT ON estado FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT estado_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE estado_agenda_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER estado_agenda_id_seq_tr 

BEFORE INSERT ON estado_agenda FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT estado_agenda_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE estado_agendamento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER estado_agendamento_id_seq_tr 

BEFORE INSERT ON estado_agendamento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT estado_agendamento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE exame_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER exame_id_seq_tr 

BEFORE INSERT ON exame FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT exame_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE exame_atendimento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER exame_atendimento_id_seq_tr 

BEFORE INSERT ON exame_atendimento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT exame_atendimento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE formulario_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER formulario_id_seq_tr 

BEFORE INSERT ON formulario FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT formulario_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE grupo_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER grupo_id_seq_tr 

BEFORE INSERT ON grupo FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT grupo_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE imposto_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER imposto_id_seq_tr 

BEFORE INSERT ON imposto FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT imposto_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE lancamento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER lancamento_id_seq_tr 

BEFORE INSERT ON lancamento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT lancamento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE material_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER material_id_seq_tr 

BEFORE INSERT ON material FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT material_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE medicamento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER medicamento_id_seq_tr 

BEFORE INSERT ON medicamento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT medicamento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE mensagem_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER mensagem_id_seq_tr 

BEFORE INSERT ON mensagem FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT mensagem_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE mensagem_acao_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER mensagem_acao_id_seq_tr 

BEFORE INSERT ON mensagem_acao FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT mensagem_acao_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE movimentacao_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER movimentacao_id_seq_tr 

BEFORE INSERT ON movimentacao FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT movimentacao_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE nota_fiscal_servico_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER nota_fiscal_servico_id_seq_tr 

BEFORE INSERT ON nota_fiscal_servico FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT nota_fiscal_servico_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE nota_fiscal_status_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER nota_fiscal_status_id_seq_tr 

BEFORE INSERT ON nota_fiscal_status FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT nota_fiscal_status_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE pessoa_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER pessoa_id_seq_tr 

BEFORE INSERT ON pessoa FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT pessoa_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE pessoa_endereco_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER pessoa_endereco_id_seq_tr 

BEFORE INSERT ON pessoa_endereco FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT pessoa_endereco_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE pessoa_especialidade_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER pessoa_especialidade_id_seq_tr 

BEFORE INSERT ON pessoa_especialidade FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT pessoa_especialidade_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE pessoa_grupo_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER pessoa_grupo_id_seq_tr 

BEFORE INSERT ON pessoa_grupo FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT pessoa_grupo_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE prescricao_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER prescricao_id_seq_tr 

BEFORE INSERT ON prescricao FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT prescricao_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE procedimento_material_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER procedimento_material_id_seq_tr 

BEFORE INSERT ON procedimento_material FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT procedimento_material_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE procedimento_preco_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER procedimento_preco_id_seq_tr 

BEFORE INSERT ON procedimento_preco FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT procedimento_preco_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE questao_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER questao_id_seq_tr 

BEFORE INSERT ON questao FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT questao_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE resposta_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER resposta_id_seq_tr 

BEFORE INSERT ON resposta FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT resposta_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE resposta_formulario_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER resposta_formulario_id_seq_tr 

BEFORE INSERT ON resposta_formulario FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT resposta_formulario_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_configuracao_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_configuracao_id_seq_tr 

BEFORE INSERT ON saas_configuracao FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_configuracao_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_contrato_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_contrato_id_seq_tr 

BEFORE INSERT ON saas_contrato FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_contrato_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_contrato_grupo_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_contrato_grupo_id_seq_tr 

BEFORE INSERT ON saas_contrato_grupo FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_contrato_grupo_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_contrato_status_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_contrato_status_id_seq_tr 

BEFORE INSERT ON saas_contrato_status FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_contrato_status_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_email_log_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_email_log_id_seq_tr 

BEFORE INSERT ON saas_email_log FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_email_log_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_error_log_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_error_log_id_seq_tr 

BEFORE INSERT ON saas_error_log FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_error_log_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_forma_pagamento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_forma_pagamento_id_seq_tr 

BEFORE INSERT ON saas_forma_pagamento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_forma_pagamento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_gateway_forma_pagamento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_gateway_forma_pagamento_id_seq_tr 

BEFORE INSERT ON saas_gateway_forma_pagamento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_gateway_forma_pagamento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_gateway_pagamento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_gateway_pagamento_id_seq_tr 

BEFORE INSERT ON saas_gateway_pagamento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_gateway_pagamento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_gateway_pagamento_status_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_gateway_pagamento_status_id_seq_tr 

BEFORE INSERT ON saas_gateway_pagamento_status FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_gateway_pagamento_status_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_imposto_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_imposto_id_seq_tr 

BEFORE INSERT ON saas_imposto FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_imposto_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_nota_fiscal_servico_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_nota_fiscal_servico_id_seq_tr 

BEFORE INSERT ON saas_nota_fiscal_servico FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_nota_fiscal_servico_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_pagamento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_pagamento_id_seq_tr 

BEFORE INSERT ON saas_pagamento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_pagamento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_plano_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_plano_id_seq_tr 

BEFORE INSERT ON saas_plano FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_plano_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_plano_grupo_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_plano_grupo_id_seq_tr 

BEFORE INSERT ON saas_plano_grupo FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_plano_grupo_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_plano_valor_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_plano_valor_id_seq_tr 

BEFORE INSERT ON saas_plano_valor FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_plano_valor_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_servico_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_servico_id_seq_tr 

BEFORE INSERT ON saas_servico FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_servico_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_servico_grupo_imposto_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_servico_grupo_imposto_id_seq_tr 

BEFORE INSERT ON saas_servico_grupo_imposto FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_servico_grupo_imposto_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_servico_grupo_imposto_item_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_servico_grupo_imposto_item_id_seq_tr 

BEFORE INSERT ON saas_servico_grupo_imposto_item FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_servico_grupo_imposto_item_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_status_pagamento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_status_pagamento_id_seq_tr 

BEFORE INSERT ON saas_status_pagamento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_status_pagamento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE saas_template_email_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER saas_template_email_id_seq_tr 

BEFORE INSERT ON saas_template_email FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT saas_template_email_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE servico_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER servico_id_seq_tr 

BEFORE INSERT ON servico FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT servico_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE servico_imposto_item_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER servico_imposto_item_id_seq_tr 

BEFORE INSERT ON servico_imposto_item FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT servico_imposto_item_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE template_acao_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER template_acao_id_seq_tr 

BEFORE INSERT ON template_acao FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT template_acao_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE template_clinica_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER template_clinica_id_seq_tr 

BEFORE INSERT ON template_clinica FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT template_clinica_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE tipo_conta_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER tipo_conta_id_seq_tr 

BEFORE INSERT ON tipo_conta FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT tipo_conta_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE tipo_documento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER tipo_documento_id_seq_tr 

BEFORE INSERT ON tipo_documento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT tipo_documento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE tipo_pagamento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER tipo_pagamento_id_seq_tr 

BEFORE INSERT ON tipo_pagamento FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT tipo_pagamento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE unidade_medida_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER unidade_medida_id_seq_tr 

BEFORE INSERT ON unidade_medida FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT unidade_medida_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE webhook_log_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER webhook_log_id_seq_tr 

BEFORE INSERT ON webhook_log FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT webhook_log_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE whatsapp_config_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER whatsapp_config_id_seq_tr 

BEFORE INSERT ON whatsapp_config FOR EACH ROW 

    WHEN 

        (NEW.id IS NULL) 

    BEGIN 

        SELECT whatsapp_config_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
 