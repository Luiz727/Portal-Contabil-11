CREATE TABLE account( 
      id  SERIAL    NOT NULL  , 
      cidade_id integer   , 
      system_user_id integer   , 
      nome_responsavel text   NOT NULL  , 
      razao_social text   NOT NULL  , 
      tipo_pessoa char  (1)     DEFAULT 'J', 
      documento text   , 
      email text   , 
      telefone text   , 
      cep text   , 
      rua text   , 
      numero text   , 
      complemento text   , 
      bairro text   , 
      mes_criacao integer   , 
      ano_criacao integer   , 
      created_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE agenda( 
      id  SERIAL    NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      profissional_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
      horario_inicial time   NOT NULL  , 
      horario_final time   NOT NULL  , 
      visualizacao_inicial varchar  (30)   NOT NULL    DEFAULT 'agendaWeek', 
      horario_inicio_intervalo time   , 
      horario_fim_intervalo time   , 
      duracao integer   NOT NULL    DEFAULT 30, 
      dias text   NOT NULL  , 
      procedimento_id integer   , 
      cor varchar  (10)   , 
      aceita_agendamento_online char  (1)     DEFAULT 'F', 
      publica char  (1)     DEFAULT 'F', 
      fl_permite_choque_horario char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE agendamento( 
      id  SERIAL    NOT NULL  , 
      paciente_id integer   NOT NULL  , 
      estado_agenda_id integer   NOT NULL  , 
      agenda_id integer   NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      especialidade_id integer   , 
      dt_inicial timestamp   NOT NULL  , 
      dt_final timestamp   NOT NULL  , 
      agendamento_original_id integer   , 
      observacao text   , 
      ativo char  (1)     DEFAULT 'T', 
      ano_inicial text   , 
      mes_inicial text   , 
      ano_mes_inicial text   , 
      ano_final text   , 
      mes_final text   , 
      ano_mes_final text   , 
      online char  (1)     DEFAULT 'F', 
      link_atendimento_online text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE agendamento_procedimento( 
      id  SERIAL    NOT NULL  , 
      agendamento_id integer   NOT NULL  , 
      procedimento_id integer   NOT NULL  , 
      convenio_id integer   NOT NULL  , 
      quantidade float   NOT NULL  , 
      valor float   , 
      valor_total float   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE agenda_profissional( 
      id  SERIAL    NOT NULL  , 
      profissional_id integer   NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      agenda_id integer   NOT NULL  , 
      fl_manipula_atendimento char  (1)   NOT NULL    DEFAULT 'N', 
 PRIMARY KEY (id)) ; 

CREATE TABLE anexo( 
      id  SERIAL    NOT NULL  , 
      atendimento_id integer   NOT NULL  , 
      arquivo text   NOT NULL  , 
      observacao text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE atendimento( 
      id  SERIAL    NOT NULL  , 
      agendamento_id integer   NOT NULL  , 
      paciente_id integer   NOT NULL  , 
      profissional_id integer   NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      dt_inicio timestamp   NOT NULL  , 
      dt_final timestamp   , 
      valor_total float   , 
      ano_inicial text   , 
      mes_inicial text   , 
      ano_mes_inicial text   , 
      mes_final text   , 
      ano_final text   , 
      ano_mes_final text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE atendimento_material( 
      id  SERIAL    NOT NULL  , 
      material_id integer   NOT NULL  , 
      atendimento_id integer   NOT NULL  , 
      quantidade float   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE atendimento_procedimento( 
      id  SERIAL    NOT NULL  , 
      convenio_id integer   NOT NULL  , 
      atendimento_id integer   NOT NULL  , 
      procedimento_id integer   NOT NULL  , 
      quantidade float   NOT NULL  , 
      valor float   , 
      valor_total float   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE bloqueio( 
      id  SERIAL    NOT NULL  , 
      agenda_id integer   NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      dt_inicio timestamp   NOT NULL  , 
      dt_final timestamp   NOT NULL  , 
      observacao text   , 
      horario_bloqueio_original integer   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE categoria_conta( 
      id  SERIAL    NOT NULL  , 
      tipo_conta_id integer   NOT NULL  , 
      account_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE cep_cache( 
      id  SERIAL    NOT NULL  , 
      cep varchar  (12)   NOT NULL  , 
      codigo_ibge text   , 
      rua text   , 
      cidade text   , 
      uf text   , 
      cidade_id integer   , 
      bairro text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE cidade( 
      id  SERIAL    NOT NULL  , 
      estado_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
      codigo_ibge text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE clinica( 
      id  SERIAL    NOT NULL  , 
      system_unit_id integer   , 
      atendimento_categoria_conta_id integer   , 
      cidade_id integer   , 
      account_id integer   , 
      token text   , 
      nome text   NOT NULL  , 
      cnpj text   , 
      telefone text   , 
      email text   NOT NULL  , 
      endereco text   , 
      bairro text   , 
      cep text   , 
      numero text   , 
      complemento text   , 
      logo_documento text   , 
      nfse_serie text   , 
      razao_social varchar  (255)   , 
      nfse_info text   , 
      nfse_numero text   , 
      regime_tributacao text   , 
      token_integra_notas text   , 
      token_integra_notas_homologacao text   , 
      nfse_emissao_producao char  (1)     DEFAULT 'F', 
      certificado_a1_conteudo text   , 
      senha_certificado_a1 text   , 
      certificado_a1_nome text   , 
      emitente_configurado char  (1)     DEFAULT 'F', 
      validade_certificado date   , 
      logo_horizontal_grande text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE clinica_convenio( 
      id  SERIAL    NOT NULL  , 
      convenio_id integer   NOT NULL  , 
      clinica_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE conta( 
      id  SERIAL    NOT NULL  , 
      pessoa_id integer   NOT NULL  , 
      categoria_conta_id integer   , 
      tipo_conta_id integer   NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      atendimento_id integer   , 
      data_emissao date   NOT NULL  , 
      total_parcelas integer   NOT NULL    DEFAULT 1, 
      quitada char  (1)   NOT NULL    DEFAULT 'F', 
      descricao text   NOT NULL  , 
      conta_origem_id integer   , 
      total_conta float   NOT NULL  , 
      mes text   , 
      ano text   , 
      ano_mes text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE convenio( 
      id  SERIAL    NOT NULL  , 
      account_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE documento( 
      id  SERIAL    NOT NULL  , 
      atendimento_id integer   NOT NULL  , 
      tipo_documento_id integer   NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      procedimento_id integer   , 
      texto text   NOT NULL  , 
      dt_preenchimento timestamp   NOT NULL  , 
      autenticador text   , 
      dt_validade date   NOT NULL  , 
      medico_assistente text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE email_config( 
      id  SERIAL    NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      port text   , 
      username text   , 
      password text   , 
      host text   , 
      from_email text   , 
      from_name text   , 
      smtp_auth char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE especialidade( 
      id  SERIAL    NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      descricao text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      sigla char  (2)   NOT NULL  , 
      codigo_ibge text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado_agenda( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      estado_inicial char  (1)   NOT NULL    DEFAULT 'N', 
      estado_final char  (1)   NOT NULL    DEFAULT 'N', 
      cor varchar  (10)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado_agendamento( 
      id  SERIAL    NOT NULL  , 
      agendamento_id integer   NOT NULL  , 
      estado_agenda_id integer   NOT NULL  , 
      system_users_id integer   , 
      atribuido_em timestamp   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE exame( 
      id  SERIAL    NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      nome text   NOT NULL  , 
      codigo_referencia text   , 
      clinica_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE exame_atendimento( 
      id  SERIAL    NOT NULL  , 
      atendimento_id integer   NOT NULL  , 
      exame_id integer   NOT NULL  , 
      indicacao_clinica text   NOT NULL  , 
      dt_exames date   NOT NULL  , 
      quantidade integer   NOT NULL    DEFAULT 1, 
 PRIMARY KEY (id)) ; 

CREATE TABLE formulario( 
      id  SERIAL    NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      ordem integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE grupo( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      cor varchar  (10)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE imposto( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      codigo text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE lancamento( 
      id  SERIAL    NOT NULL  , 
      conta_id integer   NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      tipo_pagamento_id integer   , 
      nota_fiscal_servico_id integer   , 
      parcela integer   NOT NULL    DEFAULT 1, 
      dt_vencimento date   NOT NULL  , 
      valor float   NOT NULL  , 
      dt_pagamento date   , 
      ano_pagamento text   , 
      mes_pagamento text   , 
      ano_mes_pagamento text   , 
      ano_vencimento text   , 
      mes_vencimento text   , 
      ano_mes_vencimento text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE material( 
      id  SERIAL    NOT NULL  , 
      unidade_medida_id integer   NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
      estoque_minimo float   , 
      dt_vencimento date   , 
      estoque_atualizado float   , 
      lote text   , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE medicamento( 
      id  SERIAL    NOT NULL  , 
      prescricao_id integer   NOT NULL  , 
      medicamento text   NOT NULL  , 
      quantidade text   NOT NULL  , 
      posologia text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE mensagem( 
      id  SERIAL    NOT NULL  , 
      agendamento_id integer   NOT NULL  , 
      template_clinica_id integer   , 
      system_user_id integer   NOT NULL  , 
      titulo text   , 
      template text   , 
      enviado_em timestamp   , 
      tipo_mensagem text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE mensagem_acao( 
      id  SERIAL    NOT NULL  , 
      mensagem_id integer   NOT NULL  , 
      url text   , 
      label text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE movimentacao( 
      id  SERIAL    NOT NULL  , 
      material_id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      dt_movimentacao text   , 
      quantidade float   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE nota_fiscal_servico( 
      id  SERIAL    NOT NULL  , 
      cidade_tomador_id integer   NOT NULL  , 
      cidade_prestador_id integer   NOT NULL  , 
      municipio_prestacao_servico_id integer   NOT NULL  , 
      nota_fiscal_status_id integer   NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      cliente_id integer   NOT NULL  , 
      conta_id integer   , 
      lancamento_id integer   , 
      natureza_operacao text   , 
      data_hora_emissao timestamp   NOT NULL  , 
      discriminacao text   NOT NULL  , 
      numero text   , 
      codigo_verificacao text   , 
      id_gateway_externo text   , 
      dados_gateway_externo text   , 
      nome_tomador text   NOT NULL  , 
      documento_tomador text   NOT NULL  , 
      endereco_tomador text   NOT NULL  , 
      email_tomador text   NOT NULL  , 
      telefone_tomador text   , 
      numero_tomador text   NOT NULL  , 
      bairro_tomador text   NOT NULL  , 
      cep_tomador text   NOT NULL  , 
      inscricao_municipal_tomador text   , 
      inscricao_municipal_prestador text   , 
      nome_prestador text   NOT NULL  , 
      documento_prestador text   NOT NULL  , 
      endereco_prestador text   NOT NULL  , 
      email_prestador text   NOT NULL  , 
      telefone_prestador text   , 
      numero_prestador text   NOT NULL  , 
      bairro_prestador text   NOT NULL  , 
      cep_prestador text   NOT NULL  , 
      iss_retido char  (1)     DEFAULT 'F', 
      desconto_incondicionado float     DEFAULT 0.00, 
      desconto_condicionado float     DEFAULT 0.00, 
      base_calculo_iss float   , 
      aliquota_iss float   , 
      aliquota_pis float   , 
      aliquota_cofins float   , 
      aliquota_csll float   , 
      aliquota_irrf float   , 
      aliquota_inss float   , 
      valor_deducoes float   , 
      valor_retencoes float   , 
      valor_outras_retencoes float   , 
      valor_liquido float   , 
      valor_servicos float   , 
      valor_iss float   , 
      valor_pis float     DEFAULT 0.00, 
      valor_inss float     DEFAULT 0.00, 
      valor_cofins float     DEFAULT 0.00, 
      valor_csll float   , 
      valor_irrf float     DEFAULT 0.00, 
      incentivador_cultural char  (1)     DEFAULT 'F', 
      optante_simples_nacional char  (1)     DEFAULT 'F', 
      nfse_status text   , 
      ano text   , 
      mes text   , 
      ano_mes text   , 
      pdf text   , 
      xml text   , 
      link_pdf_prefeitura text   , 
      regime_tributario_municipal text   , 
      numero_rps text   , 
      mensagem_erro text   , 
      email_enviado char  (1)     DEFAULT 'F', 
      servico_id integer   NOT NULL  , 
      serie_rps text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE nota_fiscal_status( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      cor text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa( 
      id  SERIAL    NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      nome varchar  (255)   NOT NULL  , 
      documento text   , 
      email varchar  (255)   , 
      telefone varchar  (20)   , 
      system_users_id integer   , 
      sexo char  (1)   , 
      nome_civel varchar  (255)   , 
      rg text   , 
      dt_nascimento date   , 
      profissao text   , 
      tratamento text   , 
      observacao text   , 
      assinatura text   , 
      usuario varchar  (255)   , 
      senha varchar  (255)   , 
      foto text   , 
      aceita_receber_mensagen_whatsapp char  (1)   NOT NULL    DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa_endereco( 
      id  SERIAL    NOT NULL  , 
      pessoa_id integer   NOT NULL  , 
      cidade_id integer   NOT NULL  , 
      cep varchar  (10)   NOT NULL  , 
      rua varchar  (500)   NOT NULL  , 
      bairro varchar  (500)   NOT NULL  , 
      numero varchar  (100)   NOT NULL  , 
      complemento varchar  (500)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa_especialidade( 
      id  SERIAL    NOT NULL  , 
      pessoa_id integer   NOT NULL  , 
      especialidade_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa_grupo( 
      id  SERIAL    NOT NULL  , 
      pessoa_id integer   NOT NULL  , 
      grupo_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE prescricao( 
      id  SERIAL    NOT NULL  , 
      atendimento_id integer   NOT NULL  , 
      controle_especial char  (1)   NOT NULL    DEFAULT 'N', 
      dt_prescricao date   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE procedimento( 
      id integer   NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
      cor varchar  (10)   NOT NULL  , 
      duracao time   , 
      codigo_referencia text   , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE procedimento_material( 
      id  SERIAL    NOT NULL  , 
      procedimento_id integer   NOT NULL  , 
      material_id integer   NOT NULL  , 
      quantidade float   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE procedimento_preco( 
      id  SERIAL    NOT NULL  , 
      procedimento_id integer   NOT NULL  , 
      convenio_id integer   NOT NULL  , 
      valor float   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE questao( 
      id  SERIAL    NOT NULL  , 
      formulario_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
      tipo_campo text   NOT NULL  , 
      fl_obrigatorio char  (1)   NOT NULL    DEFAULT 'F', 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      opcoes text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE resposta( 
      id  SERIAL    NOT NULL  , 
      resposta_formulario_id integer   NOT NULL  , 
      questao_id integer   NOT NULL  , 
      resposta text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE resposta_formulario( 
      id  SERIAL    NOT NULL  , 
      formulario_id integer   NOT NULL  , 
      atendimento_id integer   NOT NULL  , 
      dt_resposta date   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_configuracao( 
      id  SERIAL    NOT NULL  , 
      cidade_id integer   , 
      saas_plano_valor_trial_id integer   , 
      contrato_inativo_system_group_id integer   , 
      parametro_fiscal_id integer   , 
      razao_social text   , 
      nome_fantasia text   , 
      cnpj text   , 
      inscricao_estadual text   , 
      inscricao_municipal text   , 
      cep text   , 
      rua text   , 
      bairro text   , 
      numero text   , 
      complemento text   , 
      email text   NOT NULL  , 
      telefone text   NOT NULL  , 
      dias_trial integer   , 
      contrato text   , 
      regime_tributacao text   , 
      token_integra_notas text   , 
      token_integra_notas_homologacao text   , 
      nfse_emissao_producao char  (1)   NOT NULL    DEFAULT 'F', 
      nfse_numero text   , 
      nfse_serie text   , 
      nfse_info text   , 
      termo_uso text   , 
      email_port text   , 
      email_username text   , 
      email_password text   , 
      email_host text   , 
      email_from text   , 
      email_from_name text   , 
      email_smtp_auth char  (1)     DEFAULT 'F', 
      dias_renovacao_contrato integer   , 
      dias_vencimento_pagamento integer   , 
      token_integra_notas_software_house text   , 
      url_sistema text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_contrato( 
      id  SERIAL    NOT NULL  , 
      saas_plano_valor_id integer   NOT NULL  , 
      account_id integer   NOT NULL  , 
      saas_contrato_status_id integer   NOT NULL  , 
      valor_total float   , 
      data_inicial date   NOT NULL  , 
      data_final date   , 
      criado_em timestamp   , 
      renovacao char  (1)     DEFAULT 'F', 
      total_usuarios integer   , 
      total_unidades integer   , 
      gateway_assinatura_id text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_contrato_grupo( 
      id  SERIAL    NOT NULL  , 
      saas_contrato_id integer   NOT NULL  , 
      system_group_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_contrato_status( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      cor text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_email_log( 
      id  SERIAL    NOT NULL  , 
      titulo text   , 
      conteudo text   , 
      destinatario text   , 
      created_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_error_log( 
      id  SERIAL    NOT NULL  , 
      system_unit_id integer   , 
      system_user_id integer   , 
      error_class varchar  (255)   , 
      error_method varchar  (255)   , 
      message text   , 
      payload text   , 
      created_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_forma_pagamento( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_forma_pagamento( 
      id  SERIAL    NOT NULL  , 
      saas_forma_pagamento_id integer   NOT NULL  , 
      saas_gateway_pagamento_id integer   NOT NULL  , 
      codigo text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_pagamento( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      public_key text   , 
      access_token text   , 
      client_secret text   , 
      client_id text   , 
      oauth_token text   , 
      oauth_token_created_at timestamp   , 
      certificado_crt text   , 
      certificado_key text   , 
      webhook_url text   , 
      webhook_certificado_cert text   , 
      fl_homologacao char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_pagamento_status( 
      id  SERIAL    NOT NULL  , 
      saas_gateway_pagamento_id integer   NOT NULL  , 
      saas_status_pagamento_id integer   NOT NULL  , 
      codigo text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_imposto( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      codigo text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_nota_fiscal_servico( 
      id  SERIAL    NOT NULL  , 
      saas_pagamento_id integer   , 
      saas_plano_valor_id integer   , 
      saas_servico_id integer   , 
      cidade_tomador_id integer   NOT NULL  , 
      cidade_prestador_id integer   NOT NULL  , 
      municipio_prestacao_servico_id integer   NOT NULL  , 
      nota_fiscal_status_id integer   NOT NULL  , 
      account_id integer   NOT NULL  , 
      natureza_operacao text   , 
      data_hora_emissao timestamp   NOT NULL  , 
      discriminacao text   NOT NULL  , 
      numero text   , 
      codigo_verificacao text   , 
      id_gateway_externo text   , 
      dados_gateway_externo text   , 
      nome_tomador text   NOT NULL  , 
      documento_tomador text   NOT NULL  , 
      endereco_tomador text   NOT NULL  , 
      email_tomador text   NOT NULL  , 
      telefone_tomador text   , 
      numero_tomador text   NOT NULL  , 
      bairro_tomador text   NOT NULL  , 
      cep_tomador text   NOT NULL  , 
      inscricao_municipal_tomador text   , 
      inscricao_municipal_prestador text   , 
      nome_prestador text   NOT NULL  , 
      documento_prestador text   NOT NULL  , 
      endereco_prestador text   NOT NULL  , 
      email_prestador text   NOT NULL  , 
      telefone_prestador text   , 
      numero_prestador text   NOT NULL  , 
      bairro_prestador text   NOT NULL  , 
      cep_prestador text   NOT NULL  , 
      iss_retido char  (1)     DEFAULT 'F', 
      desconto_incondicionado float     DEFAULT 0.00, 
      desconto_condicionado float     DEFAULT 0.00, 
      base_calculo_iss float   , 
      aliquota_iss float   , 
      aliquota_pis float   , 
      aliquota_cofins float   , 
      aliquota_csll float   , 
      aliquota_irrf float   , 
      aliquota_inss float   , 
      valor_deducoes float   , 
      valor_retencoes float   , 
      valor_outras_retencoes float   , 
      valor_liquido float   , 
      valor_servicos float   , 
      valor_iss float   , 
      valor_pis float     DEFAULT 0.00, 
      valor_inss float     DEFAULT 0.00, 
      valor_cofins float     DEFAULT 0.00, 
      valor_csll float   , 
      valor_irrf float     DEFAULT 0.00, 
      incentivador_cultural char  (1)     DEFAULT 'F', 
      optante_simples_nacional char  (1)     DEFAULT 'F', 
      nfse_status text   , 
      ano text   , 
      mes text   , 
      ano_mes text   , 
      pdf text   , 
      xml text   , 
      link_pdf_prefeitura text   , 
      regime_tributario_municipal text   , 
      numero_rps text   , 
      mensagem_erro text   , 
      email_enviado char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_pagamento( 
      id  SERIAL    NOT NULL  , 
      account_id integer   NOT NULL  , 
      saas_status_pagamento_id integer   NOT NULL  , 
      saas_contrato_id integer   , 
      saas_servico_id integer   , 
      saas_forma_pagamento_id integer   NOT NULL  , 
      saas_gateway_pagamento_id integer   NOT NULL  , 
      saas_nota_fiscal_servico_id integer   , 
      valor float   NOT NULL  , 
      data_compra timestamp   NOT NULL  , 
      data_vencimento date   , 
      data_pagamento date   , 
      dados_gateway text   , 
      id_gateway text   , 
      payment_id text   , 
      link_gateway text   , 
      mes_compra integer   , 
      ano_compra integer   , 
      ano_pagamento integer   , 
      mes_pagamento integer   , 
      mes_ano_pagamento text   , 
      mes_ano_compra text   , 
      renovacao char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_plano( 
      id  SERIAL    NOT NULL  , 
      saas_servico_id integer   , 
      nome text   NOT NULL  , 
      descricao text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      limite_usuarios integer   , 
      limite_unidades integer   , 
      discriminacao text   , 
      ordem integer   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_plano_grupo( 
      id  SERIAL    NOT NULL  , 
      saas_plano_id integer   NOT NULL  , 
      system_group_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_plano_valor( 
      id  SERIAL    NOT NULL  , 
      saas_plano_id integer   NOT NULL  , 
      valor float   NOT NULL  , 
      nome text   NOT NULL  , 
      duracao integer   , 
      ativo char  (1)     DEFAULT 'T', 
      desativado_em timestamp   , 
      recorrencia char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico( 
      id  SERIAL    NOT NULL  , 
      servico_grupo_imposto_id integer   , 
      nome text   NOT NULL  , 
      preco float   , 
      descricao text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico_grupo_imposto( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      codigo_cnae text   , 
      codigo_tributacao_municipio text   , 
      codigo_nbs text   , 
      codigo text   , 
      descricao_servico_municipio text   , 
      iss_retido text   , 
      natureza_operacao text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico_grupo_imposto_item( 
      id  SERIAL    NOT NULL  , 
      saas_servico_grupo_imposto_id integer   NOT NULL  , 
      saas_imposto_id integer   NOT NULL  , 
      aliquota float   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_status_pagamento( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      cor text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_template_email( 
      id  SERIAL    NOT NULL  , 
      descricao text   , 
      titulo text   , 
      conteudo text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE servico( 
      id  SERIAL    NOT NULL  , 
      account_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
      descricao text   , 
      codigo_cnae text   , 
      codigo_tributacao_municipio text   , 
      codigo_nbs text   , 
      codigo text   , 
      descricao_servico_municipio text   , 
      iss_retido text   , 
      natureza_operacao text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE servico_imposto_item( 
      id  SERIAL    NOT NULL  , 
      servico_id integer   NOT NULL  , 
      imposto_id integer   NOT NULL  , 
      aliquota float   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document( 
      id integer   NOT NULL  , 
      category_id integer   NOT NULL  , 
      system_user_id integer   , 
      title text   NOT NULL  , 
      description text   , 
      submission_date date   , 
      archive_date date   , 
      filename text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document_category( 
      id integer   NOT NULL  , 
      name text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document_group( 
      id integer   NOT NULL  , 
      document_id integer   NOT NULL  , 
      system_group_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document_user( 
      id integer   NOT NULL  , 
      document_id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group( 
      id integer   NOT NULL  , 
      name text   NOT NULL  , 
      uuid varchar  (36)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group_program( 
      id integer   NOT NULL  , 
      system_group_id integer   NOT NULL  , 
      system_program_id integer   NOT NULL  , 
      actions text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_message( 
      id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
      system_user_to_id integer   NOT NULL  , 
      subject text   NOT NULL  , 
      message text   , 
      dt_message timestamp   , 
      checked char  (1)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_notification( 
      id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
      system_user_to_id integer   NOT NULL  , 
      subject text   , 
      message text   , 
      dt_message timestamp   , 
      action_url text   , 
      action_label text   , 
      icon text   , 
      checked char  (1)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_preference( 
      id varchar  (255)   NOT NULL  , 
      preference text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_program( 
      id integer   NOT NULL  , 
      name text   NOT NULL  , 
      controller text   NOT NULL  , 
      actions text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_unit( 
      id integer   NOT NULL  , 
      account_id integer   , 
      name text   NOT NULL  , 
      connection_name text   , 
      active char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_group( 
      id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
      system_group_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_program( 
      id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
      system_program_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_users( 
      id integer   NOT NULL  , 
      name text   NOT NULL  , 
      login text   NOT NULL  , 
      password text   NOT NULL  , 
      email text   , 
      frontpage_id integer   , 
      system_unit_id integer   , 
      account_id integer   , 
      active char  (1)   , 
      accepted_term_policy char  (1)   , 
      accepted_term_policy_at text   , 
      two_factor_enabled char  (1)     DEFAULT 'N', 
      two_factor_type varchar  (100)   , 
      two_factor_secret varchar  (255)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_unit( 
      id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
      system_unit_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE template_acao( 
      id  SERIAL    NOT NULL  , 
      template_clinica_id integer   NOT NULL  , 
      url text   , 
      label text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE template_clinica( 
      id  SERIAL    NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      chave text   NOT NULL  , 
      descricao text   NOT NULL  , 
      habilitado char  (1)   NOT NULL    DEFAULT 'T', 
      template text   , 
      titulo text   , 
      tipo_template text   , 
      readonly char  (1)   NOT NULL    DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_conta( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_documento( 
      id  SERIAL    NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
      texto_padrao text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'S', 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_pagamento( 
      id  SERIAL    NOT NULL  , 
      account_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE unidade_medida( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      sigla text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE webhook_log( 
      id  SERIAL    NOT NULL  , 
      gateway_pagamento_id integer   , 
      payload text   , 
      created_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE whatsapp_config( 
      id  SERIAL    NOT NULL  , 
      clinica_id integer   NOT NULL  , 
      phone text   , 
      status text   , 
      api_token text   , 
      api_key text   , 
      api_client_token text   , 
 PRIMARY KEY (id)) ; 

 
 ALTER TABLE cep_cache ADD UNIQUE (cep);
  
 ALTER TABLE account ADD CONSTRAINT fk_account_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE account ADD CONSTRAINT fk_account_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE agenda ADD CONSTRAINT fk_agenda_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE agenda ADD CONSTRAINT fk_agenda_2 FOREIGN KEY (profissional_id) references pessoa(id); 
ALTER TABLE agenda ADD CONSTRAINT fk_agenda_3 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_5 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_1 FOREIGN KEY (paciente_id) references pessoa(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_2 FOREIGN KEY (estado_agenda_id) references estado_agenda(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_3 FOREIGN KEY (agenda_id) references agenda(id); 
ALTER TABLE agendamento ADD CONSTRAINT fk_agendamento_4 FOREIGN KEY (especialidade_id) references especialidade(id); 
ALTER TABLE agendamento_procedimento ADD CONSTRAINT fk_agendamento_procedimento_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE agendamento_procedimento ADD CONSTRAINT fk_agendamento_procedimento_2 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE agendamento_procedimento ADD CONSTRAINT fk_agendamento_procedimento_3 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE agenda_profissional ADD CONSTRAINT fk_agenda_profissional_3 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE agenda_profissional ADD CONSTRAINT fk_agenda_profissional_1 FOREIGN KEY (profissional_id) references pessoa(id); 
ALTER TABLE agenda_profissional ADD CONSTRAINT fk_agenda_profissional_2 FOREIGN KEY (agenda_id) references agenda(id); 
ALTER TABLE anexo ADD CONSTRAINT fk_anexo_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_4 FOREIGN KEY (clinica_id) references system_unit(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_2 FOREIGN KEY (paciente_id) references pessoa(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_3 FOREIGN KEY (profissional_id) references pessoa(id); 
ALTER TABLE atendimento ADD CONSTRAINT fk_atendimento_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE atendimento_material ADD CONSTRAINT fk_atendimento_material_1 FOREIGN KEY (material_id) references material(id); 
ALTER TABLE atendimento_material ADD CONSTRAINT fk_atendimento_material_2 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE atendimento_procedimento ADD CONSTRAINT fk_atendimento_procedimento_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE atendimento_procedimento ADD CONSTRAINT fk_atendimento_procedimento_2 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE atendimento_procedimento ADD CONSTRAINT fk_atendimento_procedimento_3 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE bloqueio ADD CONSTRAINT fk_bloqueio_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE bloqueio ADD CONSTRAINT fk_bloqueio_1 FOREIGN KEY (agenda_id) references agenda(id); 
ALTER TABLE categoria_conta ADD CONSTRAINT fk_categoria_conta_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE categoria_conta ADD CONSTRAINT fk_categoria_conta_1 FOREIGN KEY (tipo_conta_id) references tipo_conta(id); 
ALTER TABLE cidade ADD CONSTRAINT fk_cidade_1 FOREIGN KEY (estado_id) references estado(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_3 FOREIGN KEY (atendimento_categoria_conta_id) references categoria_conta(id); 
ALTER TABLE clinica ADD CONSTRAINT fk_clinica_4 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE clinica_convenio ADD CONSTRAINT fk_clinica_convenio_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE clinica_convenio ADD CONSTRAINT fk_clinica_convenio_1 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_3 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_4 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_5 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_2 FOREIGN KEY (tipo_conta_id) references tipo_conta(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_1 FOREIGN KEY (categoria_conta_id) references categoria_conta(id); 
ALTER TABLE convenio ADD CONSTRAINT fk_convenio_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_1 FOREIGN KEY (tipo_documento_id) references tipo_documento(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_2 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_3 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE documento ADD CONSTRAINT fk_documento_4 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE email_config ADD CONSTRAINT fk_email_config_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE especialidade ADD CONSTRAINT fk_especialidade_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE estado_agendamento ADD CONSTRAINT fk_estado_agendamento_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE estado_agendamento ADD CONSTRAINT fk_estado_agendamento_2 FOREIGN KEY (estado_agenda_id) references estado_agenda(id); 
ALTER TABLE estado_agendamento ADD CONSTRAINT fk_estado_agendamento_3 FOREIGN KEY (system_users_id) references system_users(id); 
ALTER TABLE exame ADD CONSTRAINT fk_exame_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE exame_atendimento ADD CONSTRAINT fk_exame_atendimento_2 FOREIGN KEY (exame_id) references exame(id); 
ALTER TABLE exame_atendimento ADD CONSTRAINT fk_exame_atendimento_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE formulario ADD CONSTRAINT fk_formulario_1 FOREIGN KEY (clinica_id) references system_unit(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_4 FOREIGN KEY (nota_fiscal_servico_id) references nota_fiscal_servico(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_1 FOREIGN KEY (conta_id) references conta(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_2 FOREIGN KEY (tipo_pagamento_id) references tipo_pagamento(id); 
ALTER TABLE lancamento ADD CONSTRAINT fk_lancamento_3 FOREIGN KEY (clinica_id) references system_unit(id); 
ALTER TABLE material ADD CONSTRAINT fk_material_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE material ADD CONSTRAINT fk_material_1 FOREIGN KEY (unidade_medida_id) references unidade_medida(id); 
ALTER TABLE medicamento ADD CONSTRAINT fk_medicamento_1 FOREIGN KEY (prescricao_id) references prescricao(id); 
ALTER TABLE mensagem ADD CONSTRAINT fk_message_1 FOREIGN KEY (agendamento_id) references agendamento(id); 
ALTER TABLE mensagem ADD CONSTRAINT fk_message_2 FOREIGN KEY (template_clinica_id) references template_clinica(id); 
ALTER TABLE mensagem ADD CONSTRAINT fk_message_3 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE mensagem_acao ADD CONSTRAINT fk_mensagem_acao_1 FOREIGN KEY (mensagem_id) references mensagem(id); 
ALTER TABLE movimentacao ADD CONSTRAINT fk_movimentacao_3 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE movimentacao ADD CONSTRAINT fk_movimentacao_1 FOREIGN KEY (material_id) references material(id); 
ALTER TABLE movimentacao ADD CONSTRAINT fk_movimentacao_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_3 FOREIGN KEY (municipio_prestacao_servico_id) references cidade(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_4 FOREIGN KEY (nota_fiscal_status_id) references nota_fiscal_status(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_5 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_6 FOREIGN KEY (cliente_id) references pessoa(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_9 FOREIGN KEY (lancamento_id) references lancamento(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_7 FOREIGN KEY (cidade_tomador_id) references cidade(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_1 FOREIGN KEY (conta_id) references conta(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_2 FOREIGN KEY (cidade_prestador_id) references cidade(id); 
ALTER TABLE nota_fiscal_servico ADD CONSTRAINT fk_nota_fiscal_servico_8 FOREIGN KEY (servico_id) references servico(id); 
ALTER TABLE pessoa ADD CONSTRAINT fk_pessoa_1 FOREIGN KEY (system_users_id) references system_users(id); 
ALTER TABLE pessoa ADD CONSTRAINT fk_pessoa_2 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE pessoa_endereco ADD CONSTRAINT fk_pessoa_endereco_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE pessoa_endereco ADD CONSTRAINT fk_pessoa_endereco_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_especialidade ADD CONSTRAINT fk_pessoa_especialidade_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_especialidade ADD CONSTRAINT fk_pessoa_especialidade_2 FOREIGN KEY (especialidade_id) references especialidade(id); 
ALTER TABLE pessoa_grupo ADD CONSTRAINT fk_pessoa_grupo_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_grupo ADD CONSTRAINT fk_pessoa_grupo_2 FOREIGN KEY (grupo_id) references grupo(id); 
ALTER TABLE prescricao ADD CONSTRAINT fk_prescricao_1 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE procedimento ADD CONSTRAINT fk_procedimento_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE procedimento_material ADD CONSTRAINT fk_procedimento_material_1 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE procedimento_material ADD CONSTRAINT fk_procedimento_material_2 FOREIGN KEY (material_id) references material(id); 
ALTER TABLE procedimento_preco ADD CONSTRAINT fk_procedimento_preco_1 FOREIGN KEY (procedimento_id) references procedimento(id); 
ALTER TABLE procedimento_preco ADD CONSTRAINT fk_procedimento_preco_2 FOREIGN KEY (convenio_id) references convenio(id); 
ALTER TABLE questao ADD CONSTRAINT fk_questao_1 FOREIGN KEY (formulario_id) references formulario(id); 
ALTER TABLE resposta ADD CONSTRAINT fk_resposta_2 FOREIGN KEY (resposta_formulario_id) references resposta_formulario(id); 
ALTER TABLE resposta ADD CONSTRAINT fk_resposta_1 FOREIGN KEY (questao_id) references questao(id); 
ALTER TABLE resposta_formulario ADD CONSTRAINT fk_resposta_formulario_1 FOREIGN KEY (formulario_id) references formulario(id); 
ALTER TABLE resposta_formulario ADD CONSTRAINT fk_resposta_formulario_2 FOREIGN KEY (atendimento_id) references atendimento(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_1 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_2 FOREIGN KEY (saas_plano_valor_trial_id) references saas_plano_valor(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_4 FOREIGN KEY (contrato_inativo_system_group_id) references system_group(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_3 FOREIGN KEY (saas_contrato_status_id) references saas_contrato_status(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_4 FOREIGN KEY (saas_plano_valor_id) references saas_plano_valor(id); 
ALTER TABLE saas_contrato_grupo ADD CONSTRAINT fk_saas_contrato_grupo_2 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE saas_contrato_grupo ADD CONSTRAINT fk_saas_contrato_grupo_1 FOREIGN KEY (saas_contrato_id) references saas_contrato(id); 
ALTER TABLE saas_error_log ADD CONSTRAINT fk_saas_error_log_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE saas_error_log ADD CONSTRAINT fk_saas_error_log_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE saas_gateway_forma_pagamento ADD CONSTRAINT fk_saas_forma_pagamento_gateway_1 FOREIGN KEY (saas_forma_pagamento_id) references saas_forma_pagamento(id); 
ALTER TABLE saas_gateway_forma_pagamento ADD CONSTRAINT fk_saas_forma_pagamento_gateway_2 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_gateway_pagamento_status ADD CONSTRAINT fk_saas_gateway_pagamento_status_1 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_gateway_pagamento_status ADD CONSTRAINT fk_saas_gateway_pagamento_status_2 FOREIGN KEY (saas_status_pagamento_id) references saas_status_pagamento(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_6 FOREIGN KEY (saas_pagamento_id) references saas_pagamento(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_2 FOREIGN KEY (cidade_prestador_id) references cidade(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_3 FOREIGN KEY (municipio_prestacao_servico_id) references cidade(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_4 FOREIGN KEY (nota_fiscal_status_id) references nota_fiscal_status(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_5 FOREIGN KEY (saas_plano_valor_id) references saas_plano_valor(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_7 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_1 FOREIGN KEY (cidade_tomador_id) references cidade(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_1 FOREIGN KEY (saas_status_pagamento_id) references saas_status_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_2 FOREIGN KEY (saas_contrato_id) references saas_contrato(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_3 FOREIGN KEY (saas_forma_pagamento_id) references saas_forma_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_4 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_5 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_6 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_7 FOREIGN KEY (saas_nota_fiscal_servico_id) references saas_nota_fiscal_servico(id); 
ALTER TABLE saas_plano ADD CONSTRAINT fk_saas_plano_1 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_plano_grupo ADD CONSTRAINT fk_saas_plano_grupo_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE saas_plano_grupo ADD CONSTRAINT fk_saas_plano_grupo_2 FOREIGN KEY (saas_plano_id) references saas_plano(id); 
ALTER TABLE saas_plano_valor ADD CONSTRAINT fk_saas_plano_valor_1 FOREIGN KEY (saas_plano_id) references saas_plano(id); 
ALTER TABLE saas_servico ADD CONSTRAINT fk_saas_servico_2 FOREIGN KEY (servico_grupo_imposto_id) references saas_servico_grupo_imposto(id); 
ALTER TABLE saas_servico_grupo_imposto_item ADD CONSTRAINT fk_servico_grupo_imposto_item_1 FOREIGN KEY (saas_servico_grupo_imposto_id) references saas_servico_grupo_imposto(id); 
ALTER TABLE saas_servico_grupo_imposto_item ADD CONSTRAINT fk_servico_grupo_imposto_item_2 FOREIGN KEY (saas_imposto_id) references saas_imposto(id); 
ALTER TABLE servico ADD CONSTRAINT fk_servico_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE servico_imposto_item ADD CONSTRAINT fk_servico_imposto_item_1 FOREIGN KEY (servico_id) references servico(id); 
ALTER TABLE servico_imposto_item ADD CONSTRAINT fk_servico_imposto_item_2 FOREIGN KEY (imposto_id) references imposto(id); 
ALTER TABLE system_document ADD CONSTRAINT fk_system_document_2 FOREIGN KEY (category_id) references system_document_category(id); 
ALTER TABLE system_document ADD CONSTRAINT fk_system_document_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_document_group ADD CONSTRAINT fk_system_document_group_2 FOREIGN KEY (document_id) references system_document(id); 
ALTER TABLE system_document_group ADD CONSTRAINT fk_system_document_group_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_document_user ADD CONSTRAINT fk_system_document_user_2 FOREIGN KEY (document_id) references system_document(id); 
ALTER TABLE system_document_user ADD CONSTRAINT fk_system_document_user_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_group_program ADD CONSTRAINT fk_system_group_program_1 FOREIGN KEY (system_program_id) references system_program(id); 
ALTER TABLE system_group_program ADD CONSTRAINT fk_system_group_program_2 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_message ADD CONSTRAINT fk_system_message_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_message ADD CONSTRAINT fk_system_message_2 FOREIGN KEY (system_user_to_id) references system_users(id); 
ALTER TABLE system_notification ADD CONSTRAINT fk_system_notification_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_notification ADD CONSTRAINT fk_system_notification_2 FOREIGN KEY (system_user_to_id) references system_users(id); 
ALTER TABLE system_unit ADD CONSTRAINT fk_system_unit_1 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE system_user_group ADD CONSTRAINT fk_system_user_group_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_user_group ADD CONSTRAINT fk_system_user_group_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_user_program ADD CONSTRAINT fk_system_user_program_1 FOREIGN KEY (system_program_id) references system_program(id); 
ALTER TABLE system_user_program ADD CONSTRAINT fk_system_user_program_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_users_3 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_user_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_user_2 FOREIGN KEY (frontpage_id) references system_program(id); 
ALTER TABLE system_user_unit ADD CONSTRAINT fk_system_user_unit_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_user_unit ADD CONSTRAINT fk_system_user_unit_2 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE template_acao ADD CONSTRAINT fk_template_acao_1 FOREIGN KEY (template_clinica_id) references template_clinica(id); 
ALTER TABLE template_clinica ADD CONSTRAINT fk_template_clinica_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE tipo_documento ADD CONSTRAINT fk_tipo_documento_1 FOREIGN KEY (clinica_id) references clinica(id); 
ALTER TABLE tipo_pagamento ADD CONSTRAINT fk_tipo_pagamento_1 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE webhook_log ADD CONSTRAINT fk_webhook_log_1 FOREIGN KEY (gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE whatsapp_config ADD CONSTRAINT fk_whatsapp_config_1 FOREIGN KEY (clinica_id) references clinica(id); 
 
 CREATE index idx_account_cidade_id on account(cidade_id); 
CREATE index idx_account_system_user_id on account(system_user_id); 
CREATE index idx_agenda_clinica_id on agenda(clinica_id); 
CREATE index idx_agenda_profissional_id on agenda(profissional_id); 
CREATE index idx_agenda_procedimento_id on agenda(procedimento_id); 
CREATE index idx_agendamento_clinica_id on agendamento(clinica_id); 
CREATE index idx_agendamento_paciente_id on agendamento(paciente_id); 
CREATE index idx_agendamento_estado_agenda_id on agendamento(estado_agenda_id); 
CREATE index idx_agendamento_agenda_id on agendamento(agenda_id); 
CREATE index idx_agendamento_especialidade_id on agendamento(especialidade_id); 
CREATE index idx_agendamento_procedimento_agendamento_id on agendamento_procedimento(agendamento_id); 
CREATE index idx_agendamento_procedimento_procedimento_id on agendamento_procedimento(procedimento_id); 
CREATE index idx_agendamento_procedimento_convenio_id on agendamento_procedimento(convenio_id); 
CREATE index idx_agenda_profissional_clinica_id on agenda_profissional(clinica_id); 
CREATE index idx_agenda_profissional_profissional_id on agenda_profissional(profissional_id); 
CREATE index idx_agenda_profissional_agenda_id on agenda_profissional(agenda_id); 
CREATE index idx_anexo_atendimento_id on anexo(atendimento_id); 
CREATE index idx_atendimento_clinica_id on atendimento(clinica_id); 
CREATE index idx_atendimento_paciente_id on atendimento(paciente_id); 
CREATE index idx_atendimento_profissional_id on atendimento(profissional_id); 
CREATE index idx_atendimento_agendamento_id on atendimento(agendamento_id); 
CREATE index idx_atendimento_material_material_id on atendimento_material(material_id); 
CREATE index idx_atendimento_material_atendimento_id on atendimento_material(atendimento_id); 
CREATE index idx_atendimento_procedimento_atendimento_id on atendimento_procedimento(atendimento_id); 
CREATE index idx_atendimento_procedimento_procedimento_id on atendimento_procedimento(procedimento_id); 
CREATE index idx_atendimento_procedimento_convenio_id on atendimento_procedimento(convenio_id); 
CREATE index idx_bloqueio_clinica_id on bloqueio(clinica_id); 
CREATE index idx_bloqueio_agenda_id on bloqueio(agenda_id); 
CREATE index idx_categoria_conta_account_id on categoria_conta(account_id); 
CREATE index idx_categoria_conta_tipo_conta_id on categoria_conta(tipo_conta_id); 
CREATE index idx_cidade_estado_id on cidade(estado_id); 
CREATE index idx_clinica_system_unit_id on clinica(system_unit_id); 
CREATE index idx_clinica_cidade_id on clinica(cidade_id); 
CREATE index idx_clinica_atendimento_categoria_conta_id on clinica(atendimento_categoria_conta_id); 
CREATE index idx_clinica_account_id on clinica(account_id); 
CREATE index idx_clinica_convenio_clinica_id on clinica_convenio(clinica_id); 
CREATE index idx_clinica_convenio_convenio_id on clinica_convenio(convenio_id); 
CREATE index idx_conta_pessoa_id on conta(pessoa_id); 
CREATE index idx_conta_atendimento_id on conta(atendimento_id); 
CREATE index idx_conta_clinica_id on conta(clinica_id); 
CREATE index idx_conta_tipo_conta_id on conta(tipo_conta_id); 
CREATE index idx_conta_categoria_conta_id on conta(categoria_conta_id); 
CREATE index idx_convenio_account_id on convenio(account_id); 
CREATE index idx_documento_tipo_documento_id on documento(tipo_documento_id); 
CREATE index idx_documento_atendimento_id on documento(atendimento_id); 
CREATE index idx_documento_procedimento_id on documento(procedimento_id); 
CREATE index idx_documento_clinica_id on documento(clinica_id); 
CREATE index idx_email_config_clinica_id on email_config(clinica_id); 
CREATE index idx_especialidade_clinica_id on especialidade(clinica_id); 
CREATE index idx_estado_agendamento_agendamento_id on estado_agendamento(agendamento_id); 
CREATE index idx_estado_agendamento_estado_agenda_id on estado_agendamento(estado_agenda_id); 
CREATE index idx_estado_agendamento_system_users_id on estado_agendamento(system_users_id); 
CREATE index idx_exame_clinica_id on exame(clinica_id); 
CREATE index idx_exame_atendimento_exame_id on exame_atendimento(exame_id); 
CREATE index idx_exame_atendimento_atendimento_id on exame_atendimento(atendimento_id); 
CREATE index idx_formulario_clinica_id on formulario(clinica_id); 
CREATE index idx_lancamento_nota_fiscal_servico_id on lancamento(nota_fiscal_servico_id); 
CREATE index idx_lancamento_conta_id on lancamento(conta_id); 
CREATE index idx_lancamento_tipo_pagamento_id on lancamento(tipo_pagamento_id); 
CREATE index idx_lancamento_clinica_id on lancamento(clinica_id); 
CREATE index idx_material_clinica_id on material(clinica_id); 
CREATE index idx_material_unidade_medida_id on material(unidade_medida_id); 
CREATE index idx_medicamento_prescricao_id on medicamento(prescricao_id); 
CREATE index idx_mensagem_agendamento_id on mensagem(agendamento_id); 
CREATE index idx_mensagem_template_clinica_id on mensagem(template_clinica_id); 
CREATE index idx_mensagem_system_user_id on mensagem(system_user_id); 
CREATE index idx_mensagem_acao_mensagem_id on mensagem_acao(mensagem_id); 
CREATE index idx_movimentacao_clinica_id on movimentacao(clinica_id); 
CREATE index idx_movimentacao_material_id on movimentacao(material_id); 
CREATE index idx_movimentacao_system_user_id on movimentacao(system_user_id); 
CREATE index idx_nota_fiscal_servico_municipio_prestacao_servico_id on nota_fiscal_servico(municipio_prestacao_servico_id); 
CREATE index idx_nota_fiscal_servico_nota_fiscal_status_id on nota_fiscal_servico(nota_fiscal_status_id); 
CREATE index idx_nota_fiscal_servico_clinica_id on nota_fiscal_servico(clinica_id); 
CREATE index idx_nota_fiscal_servico_cliente_id on nota_fiscal_servico(cliente_id); 
CREATE index idx_nota_fiscal_servico_lancamento_id on nota_fiscal_servico(lancamento_id); 
CREATE index idx_nota_fiscal_servico_cidade_tomador_id on nota_fiscal_servico(cidade_tomador_id); 
CREATE index idx_nota_fiscal_servico_conta_id on nota_fiscal_servico(conta_id); 
CREATE index idx_nota_fiscal_servico_cidade_prestador_id on nota_fiscal_servico(cidade_prestador_id); 
CREATE index idx_nota_fiscal_servico_servico_id on nota_fiscal_servico(servico_id); 
CREATE index idx_pessoa_system_users_id on pessoa(system_users_id); 
CREATE index idx_pessoa_clinica_id on pessoa(clinica_id); 
CREATE index idx_pessoa_endereco_cidade_id on pessoa_endereco(cidade_id); 
CREATE index idx_pessoa_endereco_pessoa_id on pessoa_endereco(pessoa_id); 
CREATE index idx_pessoa_especialidade_pessoa_id on pessoa_especialidade(pessoa_id); 
CREATE index idx_pessoa_especialidade_especialidade_id on pessoa_especialidade(especialidade_id); 
CREATE index idx_pessoa_grupo_pessoa_id on pessoa_grupo(pessoa_id); 
CREATE index idx_pessoa_grupo_grupo_id on pessoa_grupo(grupo_id); 
CREATE index idx_prescricao_atendimento_id on prescricao(atendimento_id); 
CREATE index idx_procedimento_clinica_id on procedimento(clinica_id); 
CREATE index idx_procedimento_material_procedimento_id on procedimento_material(procedimento_id); 
CREATE index idx_procedimento_material_material_id on procedimento_material(material_id); 
CREATE index idx_procedimento_preco_procedimento_id on procedimento_preco(procedimento_id); 
CREATE index idx_procedimento_preco_convenio_id on procedimento_preco(convenio_id); 
CREATE index idx_questao_formulario_id on questao(formulario_id); 
CREATE index idx_resposta_resposta_formulario_id on resposta(resposta_formulario_id); 
CREATE index idx_resposta_questao_id on resposta(questao_id); 
CREATE index idx_resposta_formulario_formulario_id on resposta_formulario(formulario_id); 
CREATE index idx_resposta_formulario_atendimento_id on resposta_formulario(atendimento_id); 
CREATE index idx_saas_configuracao_cidade_id on saas_configuracao(cidade_id); 
CREATE index idx_saas_configuracao_saas_plano_valor_trial_id on saas_configuracao(saas_plano_valor_trial_id); 
CREATE index idx_saas_configuracao_contrato_inativo_system_group_id on saas_configuracao(contrato_inativo_system_group_id); 
CREATE index idx_saas_contrato_account_id on saas_contrato(account_id); 
CREATE index idx_saas_contrato_saas_contrato_status_id on saas_contrato(saas_contrato_status_id); 
CREATE index idx_saas_contrato_saas_plano_valor_id on saas_contrato(saas_plano_valor_id); 
CREATE index idx_saas_contrato_grupo_system_group_id on saas_contrato_grupo(system_group_id); 
CREATE index idx_saas_contrato_grupo_saas_contrato_id on saas_contrato_grupo(saas_contrato_id); 
CREATE index idx_saas_error_log_system_unit_id on saas_error_log(system_unit_id); 
CREATE index idx_saas_error_log_system_user_id on saas_error_log(system_user_id); 
CREATE index idx_saas_gateway_forma_pagamento_saas_forma_pagamento_id on saas_gateway_forma_pagamento(saas_forma_pagamento_id); 
CREATE index idx_saas_gateway_forma_pagamento_saas_gateway_pagamento_id on saas_gateway_forma_pagamento(saas_gateway_pagamento_id); 
CREATE index idx_saas_gateway_pagamento_status_saas_gateway_pagamento_id on saas_gateway_pagamento_status(saas_gateway_pagamento_id); 
CREATE index idx_saas_gateway_pagamento_status_saas_status_pagamento_id on saas_gateway_pagamento_status(saas_status_pagamento_id); 
CREATE index idx_saas_nota_fiscal_servico_saas_pagamento_id on saas_nota_fiscal_servico(saas_pagamento_id); 
CREATE index idx_saas_nota_fiscal_servico_cidade_prestador_id on saas_nota_fiscal_servico(cidade_prestador_id); 
CREATE index idx_saas_nota_fiscal_servico_municipio_prestacao_servico_id on saas_nota_fiscal_servico(municipio_prestacao_servico_id); 
CREATE index idx_saas_nota_fiscal_servico_nota_fiscal_status_id on saas_nota_fiscal_servico(nota_fiscal_status_id); 
CREATE index idx_saas_nota_fiscal_servico_saas_plano_valor_id on saas_nota_fiscal_servico(saas_plano_valor_id); 
CREATE index idx_saas_nota_fiscal_servico_saas_servico_id on saas_nota_fiscal_servico(saas_servico_id); 
CREATE index idx_saas_nota_fiscal_servico_cidade_tomador_id on saas_nota_fiscal_servico(cidade_tomador_id); 
CREATE index idx_saas_pagamento_saas_status_pagamento_id on saas_pagamento(saas_status_pagamento_id); 
CREATE index idx_saas_pagamento_saas_contrato_id on saas_pagamento(saas_contrato_id); 
CREATE index idx_saas_pagamento_saas_forma_pagamento_id on saas_pagamento(saas_forma_pagamento_id); 
CREATE index idx_saas_pagamento_saas_gateway_pagamento_id on saas_pagamento(saas_gateway_pagamento_id); 
CREATE index idx_saas_pagamento_saas_servico_id on saas_pagamento(saas_servico_id); 
CREATE index idx_saas_pagamento_account_id on saas_pagamento(account_id); 
CREATE index idx_saas_pagamento_saas_nota_fiscal_servico_id on saas_pagamento(saas_nota_fiscal_servico_id); 
CREATE index idx_saas_plano_saas_servico_id on saas_plano(saas_servico_id); 
CREATE index idx_saas_plano_grupo_system_group_id on saas_plano_grupo(system_group_id); 
CREATE index idx_saas_plano_grupo_saas_plano_id on saas_plano_grupo(saas_plano_id); 
CREATE index idx_saas_plano_valor_saas_plano_id on saas_plano_valor(saas_plano_id); 
CREATE index idx_saas_servico_servico_grupo_imposto_id on saas_servico(servico_grupo_imposto_id); 
CREATE index idx_saas_servico_grupo_imposto_item_saas_servi_68279c1f2c6ee on saas_servico_grupo_imposto_item(saas_servico_grupo_imposto_id); 
CREATE index idx_saas_servico_grupo_imposto_item_saas_imposto_id on saas_servico_grupo_imposto_item(saas_imposto_id); 
CREATE index idx_servico_account_id on servico(account_id); 
CREATE index idx_servico_imposto_item_servico_id on servico_imposto_item(servico_id); 
CREATE index idx_servico_imposto_item_imposto_id on servico_imposto_item(imposto_id); 
CREATE index idx_system_document_category_id on system_document(category_id); 
CREATE index idx_system_document_system_user_id on system_document(system_user_id); 
CREATE index idx_system_document_group_document_id on system_document_group(document_id); 
CREATE index idx_system_document_group_system_group_id on system_document_group(system_group_id); 
CREATE index idx_system_document_user_document_id on system_document_user(document_id); 
CREATE index idx_system_document_user_system_user_id on system_document_user(system_user_id); 
CREATE index idx_system_group_program_system_program_id on system_group_program(system_program_id); 
CREATE index idx_system_group_program_system_group_id on system_group_program(system_group_id); 
CREATE index idx_system_message_system_user_id on system_message(system_user_id); 
CREATE index idx_system_message_system_user_to_id on system_message(system_user_to_id); 
CREATE index idx_system_notification_system_user_id on system_notification(system_user_id); 
CREATE index idx_system_notification_system_user_to_id on system_notification(system_user_to_id); 
CREATE index idx_system_unit_account_id on system_unit(account_id); 
CREATE index idx_system_user_group_system_group_id on system_user_group(system_group_id); 
CREATE index idx_system_user_group_system_user_id on system_user_group(system_user_id); 
CREATE index idx_system_user_program_system_program_id on system_user_program(system_program_id); 
CREATE index idx_system_user_program_system_user_id on system_user_program(system_user_id); 
CREATE index idx_system_users_account_id on system_users(account_id); 
CREATE index idx_system_users_system_unit_id on system_users(system_unit_id); 
CREATE index idx_system_users_frontpage_id on system_users(frontpage_id); 
CREATE index idx_system_user_unit_system_user_id on system_user_unit(system_user_id); 
CREATE index idx_system_user_unit_system_unit_id on system_user_unit(system_unit_id); 
CREATE index idx_template_acao_template_clinica_id on template_acao(template_clinica_id); 
CREATE index idx_template_clinica_clinica_id on template_clinica(clinica_id); 
CREATE index idx_tipo_documento_clinica_id on tipo_documento(clinica_id); 
CREATE index idx_tipo_pagamento_account_id on tipo_pagamento(account_id); 
CREATE index idx_webhook_log_gateway_pagamento_id on webhook_log(gateway_pagamento_id); 
CREATE index idx_whatsapp_config_clinica_id on whatsapp_config(clinica_id); 
