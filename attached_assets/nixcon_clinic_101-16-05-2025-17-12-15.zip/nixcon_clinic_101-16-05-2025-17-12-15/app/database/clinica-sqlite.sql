PRAGMA foreign_keys=OFF; 

CREATE TABLE account( 
      id  INTEGER    NOT NULL  , 
      cidade_id int   , 
      system_user_id int   , 
      nome_responsavel text   NOT NULL  , 
      razao_social text   NOT NULL  , 
      tipo_pessoa char  (1)     DEFAULT 'J', 
      documento text   , 
      email text   , 
      telefone text   , 
      cep text   , 
      rua text   , 
      numero text   , 
      complemento text   , 
      bairro text   , 
      mes_criacao int   , 
      ano_criacao int   , 
      created_at datetime   , 
 PRIMARY KEY (id),
FOREIGN KEY(cidade_id) REFERENCES cidade(id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id)) ; 

CREATE TABLE agenda( 
      id  INTEGER    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      profissional_id int   NOT NULL  , 
      nome text   NOT NULL  , 
      horario_inicial text   NOT NULL  , 
      horario_final text   NOT NULL  , 
      visualizacao_inicial varchar  (30)   NOT NULL    DEFAULT 'agendaWeek', 
      horario_inicio_intervalo text   , 
      horario_fim_intervalo text   , 
      duracao int   NOT NULL    DEFAULT 30, 
      dias text   NOT NULL  , 
      procedimento_id int   , 
      cor varchar  (10)   , 
      aceita_agendamento_online char  (1)     DEFAULT 'F', 
      publica char  (1)     DEFAULT 'F', 
      fl_permite_choque_horario char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id),
FOREIGN KEY(profissional_id) REFERENCES pessoa(id),
FOREIGN KEY(procedimento_id) REFERENCES procedimento(id)) ; 

CREATE TABLE agendamento( 
      id  INTEGER    NOT NULL  , 
      paciente_id int   NOT NULL  , 
      estado_agenda_id int   NOT NULL  , 
      agenda_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      especialidade_id int   , 
      dt_inicial datetime   NOT NULL  , 
      dt_final datetime   NOT NULL  , 
      agendamento_original_id int   , 
      observacao text   , 
      ativo char  (1)     DEFAULT 'T', 
      ano_inicial text   , 
      mes_inicial text   , 
      ano_mes_inicial text   , 
      ano_final text   , 
      mes_final text   , 
      ano_mes_final text   , 
      online char  (1)     DEFAULT 'F', 
      link_atendimento_online text   , 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id),
FOREIGN KEY(paciente_id) REFERENCES pessoa(id),
FOREIGN KEY(estado_agenda_id) REFERENCES estado_agenda(id),
FOREIGN KEY(agenda_id) REFERENCES agenda(id),
FOREIGN KEY(especialidade_id) REFERENCES especialidade(id)) ; 

CREATE TABLE agendamento_procedimento( 
      id  INTEGER    NOT NULL  , 
      agendamento_id int   NOT NULL  , 
      procedimento_id int   NOT NULL  , 
      convenio_id int   NOT NULL  , 
      quantidade double   NOT NULL  , 
      valor double   , 
      valor_total double   , 
 PRIMARY KEY (id),
FOREIGN KEY(agendamento_id) REFERENCES agendamento(id),
FOREIGN KEY(procedimento_id) REFERENCES procedimento(id),
FOREIGN KEY(convenio_id) REFERENCES convenio(id)) ; 

CREATE TABLE agenda_profissional( 
      id  INTEGER    NOT NULL  , 
      profissional_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      agenda_id int   NOT NULL  , 
      fl_manipula_atendimento char  (1)   NOT NULL    DEFAULT 'N', 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id),
FOREIGN KEY(profissional_id) REFERENCES pessoa(id),
FOREIGN KEY(agenda_id) REFERENCES agenda(id)) ; 

CREATE TABLE anexo( 
      id  INTEGER    NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      arquivo text   NOT NULL  , 
      observacao text   , 
 PRIMARY KEY (id),
FOREIGN KEY(atendimento_id) REFERENCES atendimento(id)) ; 

CREATE TABLE atendimento( 
      id  INTEGER    NOT NULL  , 
      agendamento_id int   NOT NULL  , 
      paciente_id int   NOT NULL  , 
      profissional_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      dt_inicio datetime   NOT NULL  , 
      dt_final datetime   , 
      valor_total double   , 
      ano_inicial text   , 
      mes_inicial text   , 
      ano_mes_inicial text   , 
      mes_final text   , 
      ano_final text   , 
      ano_mes_final text   , 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES system_unit(id),
FOREIGN KEY(paciente_id) REFERENCES pessoa(id),
FOREIGN KEY(profissional_id) REFERENCES pessoa(id),
FOREIGN KEY(agendamento_id) REFERENCES agendamento(id)) ; 

CREATE TABLE atendimento_material( 
      id  INTEGER    NOT NULL  , 
      material_id int   NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      quantidade double   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(material_id) REFERENCES material(id),
FOREIGN KEY(atendimento_id) REFERENCES atendimento(id)) ; 

CREATE TABLE atendimento_procedimento( 
      id  INTEGER    NOT NULL  , 
      convenio_id int   NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      procedimento_id int   NOT NULL  , 
      quantidade double   NOT NULL  , 
      valor double   , 
      valor_total double   , 
 PRIMARY KEY (id),
FOREIGN KEY(atendimento_id) REFERENCES atendimento(id),
FOREIGN KEY(procedimento_id) REFERENCES procedimento(id),
FOREIGN KEY(convenio_id) REFERENCES convenio(id)) ; 

CREATE TABLE bloqueio( 
      id  INTEGER    NOT NULL  , 
      agenda_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      dt_inicio datetime   NOT NULL  , 
      dt_final datetime   NOT NULL  , 
      observacao text   , 
      horario_bloqueio_original int   , 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id),
FOREIGN KEY(agenda_id) REFERENCES agenda(id)) ; 

CREATE TABLE categoria_conta( 
      id  INTEGER    NOT NULL  , 
      tipo_conta_id int   NOT NULL  , 
      account_id int   NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(account_id) REFERENCES account(id),
FOREIGN KEY(tipo_conta_id) REFERENCES tipo_conta(id)) ; 

CREATE TABLE cep_cache( 
      id  INTEGER    NOT NULL  , 
      cep varchar  (12)   NOT NULL  , 
      codigo_ibge text   , 
      rua text   , 
      cidade text   , 
      uf text   , 
      cidade_id int   , 
      bairro text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE cidade( 
      id  INTEGER    NOT NULL  , 
      estado_id int   NOT NULL  , 
      nome text   NOT NULL  , 
      codigo_ibge text   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(estado_id) REFERENCES estado(id)) ; 

CREATE TABLE clinica( 
      id  INTEGER    NOT NULL  , 
      system_unit_id int   , 
      atendimento_categoria_conta_id int   , 
      cidade_id int   , 
      account_id int   , 
      token text   , 
      nome text   NOT NULL  , 
      cnpj text   , 
      telefone text   , 
      email text   NOT NULL  , 
      endereco text   , 
      bairro text   , 
      cep text   , 
      numero text   , 
      complemento text   , 
      logo_documento text   , 
      nfse_serie text   , 
      razao_social varchar  (255)   , 
      nfse_info text   , 
      nfse_numero text   , 
      regime_tributacao text   , 
      token_integra_notas text   , 
      token_integra_notas_homologacao text   , 
      nfse_emissao_producao char  (1)     DEFAULT 'F', 
      certificado_a1_conteudo text   , 
      senha_certificado_a1 text   , 
      certificado_a1_nome text   , 
      emitente_configurado char  (1)     DEFAULT 'F', 
      validade_certificado date   , 
      logo_horizontal_grande text   , 
 PRIMARY KEY (id),
FOREIGN KEY(system_unit_id) REFERENCES system_unit(id),
FOREIGN KEY(cidade_id) REFERENCES cidade(id),
FOREIGN KEY(atendimento_categoria_conta_id) REFERENCES categoria_conta(id),
FOREIGN KEY(account_id) REFERENCES account(id)) ; 

CREATE TABLE clinica_convenio( 
      id  INTEGER    NOT NULL  , 
      convenio_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id),
FOREIGN KEY(convenio_id) REFERENCES convenio(id)) ; 

CREATE TABLE conta( 
      id  INTEGER    NOT NULL  , 
      pessoa_id int   NOT NULL  , 
      categoria_conta_id int   , 
      tipo_conta_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      atendimento_id int   , 
      data_emissao date   NOT NULL  , 
      total_parcelas int   NOT NULL    DEFAULT 1, 
      quitada char  (1)   NOT NULL    DEFAULT 'F', 
      descricao text   NOT NULL  , 
      conta_origem_id int   , 
      total_conta double   NOT NULL  , 
      mes text   , 
      ano text   , 
      ano_mes text   , 
 PRIMARY KEY (id),
FOREIGN KEY(pessoa_id) REFERENCES pessoa(id),
FOREIGN KEY(atendimento_id) REFERENCES atendimento(id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id),
FOREIGN KEY(tipo_conta_id) REFERENCES tipo_conta(id),
FOREIGN KEY(categoria_conta_id) REFERENCES categoria_conta(id)) ; 

CREATE TABLE convenio( 
      id  INTEGER    NOT NULL  , 
      account_id int   NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(account_id) REFERENCES account(id)) ; 

CREATE TABLE documento( 
      id  INTEGER    NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      tipo_documento_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      procedimento_id int   , 
      texto text   NOT NULL  , 
      dt_preenchimento datetime   NOT NULL  , 
      autenticador text   , 
      dt_validade date   NOT NULL  , 
      medico_assistente text   , 
 PRIMARY KEY (id),
FOREIGN KEY(tipo_documento_id) REFERENCES tipo_documento(id),
FOREIGN KEY(atendimento_id) REFERENCES atendimento(id),
FOREIGN KEY(procedimento_id) REFERENCES procedimento(id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id)) ; 

CREATE TABLE email_config( 
      id  INTEGER    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      port text   , 
      username text   , 
      password text   , 
      host text   , 
      from_email text   , 
      from_name text   , 
      smtp_auth char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id)) ; 

CREATE TABLE especialidade( 
      id  INTEGER    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      descricao text   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id)) ; 

CREATE TABLE estado( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
      sigla char  (2)   NOT NULL  , 
      codigo_ibge text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado_agenda( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
      estado_inicial char  (1)   NOT NULL    DEFAULT 'N', 
      estado_final char  (1)   NOT NULL    DEFAULT 'N', 
      cor varchar  (10)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado_agendamento( 
      id  INTEGER    NOT NULL  , 
      agendamento_id int   NOT NULL  , 
      estado_agenda_id int   NOT NULL  , 
      system_users_id int   , 
      atribuido_em datetime   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(agendamento_id) REFERENCES agendamento(id),
FOREIGN KEY(estado_agenda_id) REFERENCES estado_agenda(id),
FOREIGN KEY(system_users_id) REFERENCES system_users(id)) ; 

CREATE TABLE exame( 
      id  INTEGER    NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      nome text   NOT NULL  , 
      codigo_referencia text   , 
      clinica_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id)) ; 

CREATE TABLE exame_atendimento( 
      id  INTEGER    NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      exame_id int   NOT NULL  , 
      indicacao_clinica text   NOT NULL  , 
      dt_exames date   NOT NULL  , 
      quantidade int   NOT NULL    DEFAULT 1, 
 PRIMARY KEY (id),
FOREIGN KEY(exame_id) REFERENCES exame(id),
FOREIGN KEY(atendimento_id) REFERENCES atendimento(id)) ; 

CREATE TABLE formulario( 
      id  INTEGER    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      nome text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      ordem int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES system_unit(id)) ; 

CREATE TABLE grupo( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
      cor varchar  (10)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE imposto( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
      codigo text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE lancamento( 
      id  INTEGER    NOT NULL  , 
      conta_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      tipo_pagamento_id int   , 
      nota_fiscal_servico_id int   , 
      parcela int   NOT NULL    DEFAULT 1, 
      dt_vencimento date   NOT NULL  , 
      valor double   NOT NULL  , 
      dt_pagamento date   , 
      ano_pagamento text   , 
      mes_pagamento text   , 
      ano_mes_pagamento text   , 
      ano_vencimento text   , 
      mes_vencimento text   , 
      ano_mes_vencimento text   , 
 PRIMARY KEY (id),
FOREIGN KEY(nota_fiscal_servico_id) REFERENCES nota_fiscal_servico(id),
FOREIGN KEY(conta_id) REFERENCES conta(id),
FOREIGN KEY(tipo_pagamento_id) REFERENCES tipo_pagamento(id),
FOREIGN KEY(clinica_id) REFERENCES system_unit(id)) ; 

CREATE TABLE material( 
      id  INTEGER    NOT NULL  , 
      unidade_medida_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      nome text   NOT NULL  , 
      estoque_minimo double   , 
      dt_vencimento date   , 
      estoque_atualizado double   , 
      lote text   , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id),
FOREIGN KEY(unidade_medida_id) REFERENCES unidade_medida(id)) ; 

CREATE TABLE medicamento( 
      id  INTEGER    NOT NULL  , 
      prescricao_id int   NOT NULL  , 
      medicamento text   NOT NULL  , 
      quantidade text   NOT NULL  , 
      posologia text   , 
 PRIMARY KEY (id),
FOREIGN KEY(prescricao_id) REFERENCES prescricao(id)) ; 

CREATE TABLE mensagem( 
      id  INTEGER    NOT NULL  , 
      agendamento_id int   NOT NULL  , 
      template_clinica_id int   , 
      system_user_id int   NOT NULL  , 
      titulo text   , 
      template text   , 
      enviado_em datetime   , 
      tipo_mensagem text   , 
 PRIMARY KEY (id),
FOREIGN KEY(agendamento_id) REFERENCES agendamento(id),
FOREIGN KEY(template_clinica_id) REFERENCES template_clinica(id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id)) ; 

CREATE TABLE mensagem_acao( 
      id  INTEGER    NOT NULL  , 
      mensagem_id int   NOT NULL  , 
      url text   , 
      label text   , 
 PRIMARY KEY (id),
FOREIGN KEY(mensagem_id) REFERENCES mensagem(id)) ; 

CREATE TABLE movimentacao( 
      id  INTEGER    NOT NULL  , 
      material_id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      dt_movimentacao text   , 
      quantidade double   , 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id),
FOREIGN KEY(material_id) REFERENCES material(id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id)) ; 

CREATE TABLE nota_fiscal_servico( 
      id  INTEGER    NOT NULL  , 
      cidade_tomador_id int   NOT NULL  , 
      cidade_prestador_id int   NOT NULL  , 
      municipio_prestacao_servico_id int   NOT NULL  , 
      nota_fiscal_status_id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      cliente_id int   NOT NULL  , 
      conta_id int   , 
      lancamento_id int   , 
      natureza_operacao text   , 
      data_hora_emissao datetime   NOT NULL  , 
      discriminacao text   NOT NULL  , 
      numero text   , 
      codigo_verificacao text   , 
      id_gateway_externo text   , 
      dados_gateway_externo text   , 
      nome_tomador text   NOT NULL  , 
      documento_tomador text   NOT NULL  , 
      endereco_tomador text   NOT NULL  , 
      email_tomador text   NOT NULL  , 
      telefone_tomador text   , 
      numero_tomador text   NOT NULL  , 
      bairro_tomador text   NOT NULL  , 
      cep_tomador text   NOT NULL  , 
      inscricao_municipal_tomador text   , 
      inscricao_municipal_prestador text   , 
      nome_prestador text   NOT NULL  , 
      documento_prestador text   NOT NULL  , 
      endereco_prestador text   NOT NULL  , 
      email_prestador text   NOT NULL  , 
      telefone_prestador text   , 
      numero_prestador text   NOT NULL  , 
      bairro_prestador text   NOT NULL  , 
      cep_prestador text   NOT NULL  , 
      iss_retido char  (1)     DEFAULT 'F', 
      desconto_incondicionado double     DEFAULT 0.00, 
      desconto_condicionado double     DEFAULT 0.00, 
      base_calculo_iss double   , 
      aliquota_iss double   , 
      aliquota_pis double   , 
      aliquota_cofins double   , 
      aliquota_csll double   , 
      aliquota_irrf double   , 
      aliquota_inss double   , 
      valor_deducoes double   , 
      valor_retencoes double   , 
      valor_outras_retencoes double   , 
      valor_liquido double   , 
      valor_servicos double   , 
      valor_iss double   , 
      valor_pis double     DEFAULT 0.00, 
      valor_inss double     DEFAULT 0.00, 
      valor_cofins double     DEFAULT 0.00, 
      valor_csll double   , 
      valor_irrf double     DEFAULT 0.00, 
      incentivador_cultural char  (1)     DEFAULT 'F', 
      optante_simples_nacional char  (1)     DEFAULT 'F', 
      nfse_status text   , 
      ano text   , 
      mes text   , 
      ano_mes text   , 
      pdf text   , 
      xml text   , 
      link_pdf_prefeitura text   , 
      regime_tributario_municipal text   , 
      numero_rps text   , 
      mensagem_erro text   , 
      email_enviado char  (1)     DEFAULT 'F', 
      servico_id int   NOT NULL  , 
      serie_rps text   , 
 PRIMARY KEY (id),
FOREIGN KEY(municipio_prestacao_servico_id) REFERENCES cidade(id),
FOREIGN KEY(nota_fiscal_status_id) REFERENCES nota_fiscal_status(id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id),
FOREIGN KEY(cliente_id) REFERENCES pessoa(id),
FOREIGN KEY(lancamento_id) REFERENCES lancamento(id),
FOREIGN KEY(cidade_tomador_id) REFERENCES cidade(id),
FOREIGN KEY(conta_id) REFERENCES conta(id),
FOREIGN KEY(cidade_prestador_id) REFERENCES cidade(id),
FOREIGN KEY(servico_id) REFERENCES servico(id)) ; 

CREATE TABLE nota_fiscal_status( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
      cor text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa( 
      id  INTEGER    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      nome varchar  (255)   NOT NULL  , 
      documento text   , 
      email varchar  (255)   , 
      telefone varchar  (20)   , 
      system_users_id int   , 
      sexo char  (1)   , 
      nome_civel varchar  (255)   , 
      rg text   , 
      dt_nascimento date   , 
      profissao text   , 
      tratamento text   , 
      observacao text   , 
      assinatura text   , 
      usuario varchar  (255)   , 
      senha varchar  (255)   , 
      foto text   , 
      aceita_receber_mensagen_whatsapp char  (1)   NOT NULL    DEFAULT 'F', 
 PRIMARY KEY (id),
FOREIGN KEY(system_users_id) REFERENCES system_users(id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id)) ; 

CREATE TABLE pessoa_endereco( 
      id  INTEGER    NOT NULL  , 
      pessoa_id int   NOT NULL  , 
      cidade_id int   NOT NULL  , 
      cep varchar  (10)   NOT NULL  , 
      rua varchar  (500)   NOT NULL  , 
      bairro varchar  (500)   NOT NULL  , 
      numero varchar  (100)   NOT NULL  , 
      complemento varchar  (500)   , 
 PRIMARY KEY (id),
FOREIGN KEY(cidade_id) REFERENCES cidade(id),
FOREIGN KEY(pessoa_id) REFERENCES pessoa(id)) ; 

CREATE TABLE pessoa_especialidade( 
      id  INTEGER    NOT NULL  , 
      pessoa_id int   NOT NULL  , 
      especialidade_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(pessoa_id) REFERENCES pessoa(id),
FOREIGN KEY(especialidade_id) REFERENCES especialidade(id)) ; 

CREATE TABLE pessoa_grupo( 
      id  INTEGER    NOT NULL  , 
      pessoa_id int   NOT NULL  , 
      grupo_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(pessoa_id) REFERENCES pessoa(id),
FOREIGN KEY(grupo_id) REFERENCES grupo(id)) ; 

CREATE TABLE prescricao( 
      id  INTEGER    NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      controle_especial char  (1)   NOT NULL    DEFAULT 'N', 
      dt_prescricao date   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(atendimento_id) REFERENCES atendimento(id)) ; 

CREATE TABLE procedimento( 
      id int   NOT NULL  , 
      clinica_id int   NOT NULL  , 
      nome text   NOT NULL  , 
      cor varchar  (10)   NOT NULL  , 
      duracao text   , 
      codigo_referencia text   , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id)) ; 

CREATE TABLE procedimento_material( 
      id  INTEGER    NOT NULL  , 
      procedimento_id int   NOT NULL  , 
      material_id int   NOT NULL  , 
      quantidade double   , 
 PRIMARY KEY (id),
FOREIGN KEY(procedimento_id) REFERENCES procedimento(id),
FOREIGN KEY(material_id) REFERENCES material(id)) ; 

CREATE TABLE procedimento_preco( 
      id  INTEGER    NOT NULL  , 
      procedimento_id int   NOT NULL  , 
      convenio_id int   NOT NULL  , 
      valor double   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(procedimento_id) REFERENCES procedimento(id),
FOREIGN KEY(convenio_id) REFERENCES convenio(id)) ; 

CREATE TABLE questao( 
      id  INTEGER    NOT NULL  , 
      formulario_id int   NOT NULL  , 
      nome text   NOT NULL  , 
      tipo_campo text   NOT NULL  , 
      fl_obrigatorio char  (1)   NOT NULL    DEFAULT 'F', 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      opcoes text   , 
 PRIMARY KEY (id),
FOREIGN KEY(formulario_id) REFERENCES formulario(id)) ; 

CREATE TABLE resposta( 
      id  INTEGER    NOT NULL  , 
      resposta_formulario_id int   NOT NULL  , 
      questao_id int   NOT NULL  , 
      resposta text   , 
 PRIMARY KEY (id),
FOREIGN KEY(resposta_formulario_id) REFERENCES resposta_formulario(id),
FOREIGN KEY(questao_id) REFERENCES questao(id)) ; 

CREATE TABLE resposta_formulario( 
      id  INTEGER    NOT NULL  , 
      formulario_id int   NOT NULL  , 
      atendimento_id int   NOT NULL  , 
      dt_resposta date   , 
 PRIMARY KEY (id),
FOREIGN KEY(formulario_id) REFERENCES formulario(id),
FOREIGN KEY(atendimento_id) REFERENCES atendimento(id)) ; 

CREATE TABLE saas_configuracao( 
      id  INTEGER    NOT NULL  , 
      cidade_id int   , 
      saas_plano_valor_trial_id int   , 
      contrato_inativo_system_group_id int   , 
      parametro_fiscal_id int   , 
      razao_social text   , 
      nome_fantasia text   , 
      cnpj text   , 
      inscricao_estadual text   , 
      inscricao_municipal text   , 
      cep text   , 
      rua text   , 
      bairro text   , 
      numero text   , 
      complemento text   , 
      email text   NOT NULL  , 
      telefone text   NOT NULL  , 
      dias_trial int   , 
      contrato text   , 
      regime_tributacao text   , 
      token_integra_notas text   , 
      token_integra_notas_homologacao text   , 
      nfse_emissao_producao char  (1)   NOT NULL    DEFAULT 'F', 
      nfse_numero text   , 
      nfse_serie text   , 
      nfse_info text   , 
      termo_uso text   , 
      email_port text   , 
      email_username text   , 
      email_password text   , 
      email_host text   , 
      email_from text   , 
      email_from_name text   , 
      email_smtp_auth char  (1)     DEFAULT 'F', 
      dias_renovacao_contrato int   , 
      dias_vencimento_pagamento int   , 
      token_integra_notas_software_house text   , 
      url_sistema text   , 
 PRIMARY KEY (id),
FOREIGN KEY(cidade_id) REFERENCES cidade(id),
FOREIGN KEY(saas_plano_valor_trial_id) REFERENCES saas_plano_valor(id),
FOREIGN KEY(contrato_inativo_system_group_id) REFERENCES system_group(id)) ; 

CREATE TABLE saas_contrato( 
      id  INTEGER    NOT NULL  , 
      saas_plano_valor_id int   NOT NULL  , 
      account_id int   NOT NULL  , 
      saas_contrato_status_id int   NOT NULL  , 
      valor_total double   , 
      data_inicial date   NOT NULL  , 
      data_final date   , 
      criado_em datetime   , 
      renovacao char  (1)     DEFAULT 'F', 
      total_usuarios int   , 
      total_unidades int   , 
      gateway_assinatura_id text   , 
 PRIMARY KEY (id),
FOREIGN KEY(account_id) REFERENCES account(id),
FOREIGN KEY(saas_contrato_status_id) REFERENCES saas_contrato_status(id),
FOREIGN KEY(saas_plano_valor_id) REFERENCES saas_plano_valor(id)) ; 

CREATE TABLE saas_contrato_grupo( 
      id  INTEGER    NOT NULL  , 
      saas_contrato_id int   NOT NULL  , 
      system_group_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(system_group_id) REFERENCES system_group(id),
FOREIGN KEY(saas_contrato_id) REFERENCES saas_contrato(id)) ; 

CREATE TABLE saas_contrato_status( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
      cor text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_email_log( 
      id  INTEGER    NOT NULL  , 
      titulo text   , 
      conteudo text   , 
      destinatario text   , 
      created_at datetime   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_error_log( 
      id  INTEGER    NOT NULL  , 
      system_unit_id int   , 
      system_user_id int   , 
      error_class varchar  (255)   , 
      error_method varchar  (255)   , 
      message text   , 
      payload text   , 
      created_at datetime   , 
 PRIMARY KEY (id),
FOREIGN KEY(system_unit_id) REFERENCES system_unit(id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id)) ; 

CREATE TABLE saas_forma_pagamento( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_forma_pagamento( 
      id  INTEGER    NOT NULL  , 
      saas_forma_pagamento_id int   NOT NULL  , 
      saas_gateway_pagamento_id int   NOT NULL  , 
      codigo text   , 
 PRIMARY KEY (id),
FOREIGN KEY(saas_forma_pagamento_id) REFERENCES saas_forma_pagamento(id),
FOREIGN KEY(saas_gateway_pagamento_id) REFERENCES saas_gateway_pagamento(id)) ; 

CREATE TABLE saas_gateway_pagamento( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      public_key text   , 
      access_token text   , 
      client_secret text   , 
      client_id text   , 
      oauth_token text   , 
      oauth_token_created_at datetime   , 
      certificado_crt text   , 
      certificado_key text   , 
      webhook_url text   , 
      webhook_certificado_cert text   , 
      fl_homologacao char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_pagamento_status( 
      id  INTEGER    NOT NULL  , 
      saas_gateway_pagamento_id int   NOT NULL  , 
      saas_status_pagamento_id int   NOT NULL  , 
      codigo text   , 
 PRIMARY KEY (id),
FOREIGN KEY(saas_gateway_pagamento_id) REFERENCES saas_gateway_pagamento(id),
FOREIGN KEY(saas_status_pagamento_id) REFERENCES saas_status_pagamento(id)) ; 

CREATE TABLE saas_imposto( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
      codigo text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_nota_fiscal_servico( 
      id  INTEGER    NOT NULL  , 
      saas_pagamento_id int   , 
      saas_plano_valor_id int   , 
      saas_servico_id int   , 
      cidade_tomador_id int   NOT NULL  , 
      cidade_prestador_id int   NOT NULL  , 
      municipio_prestacao_servico_id int   NOT NULL  , 
      nota_fiscal_status_id int   NOT NULL  , 
      account_id int   NOT NULL  , 
      natureza_operacao text   , 
      data_hora_emissao datetime   NOT NULL  , 
      discriminacao text   NOT NULL  , 
      numero text   , 
      codigo_verificacao text   , 
      id_gateway_externo text   , 
      dados_gateway_externo text   , 
      nome_tomador text   NOT NULL  , 
      documento_tomador text   NOT NULL  , 
      endereco_tomador text   NOT NULL  , 
      email_tomador text   NOT NULL  , 
      telefone_tomador text   , 
      numero_tomador text   NOT NULL  , 
      bairro_tomador text   NOT NULL  , 
      cep_tomador text   NOT NULL  , 
      inscricao_municipal_tomador text   , 
      inscricao_municipal_prestador text   , 
      nome_prestador text   NOT NULL  , 
      documento_prestador text   NOT NULL  , 
      endereco_prestador text   NOT NULL  , 
      email_prestador text   NOT NULL  , 
      telefone_prestador text   , 
      numero_prestador text   NOT NULL  , 
      bairro_prestador text   NOT NULL  , 
      cep_prestador text   NOT NULL  , 
      iss_retido char  (1)     DEFAULT 'F', 
      desconto_incondicionado double     DEFAULT 0.00, 
      desconto_condicionado double     DEFAULT 0.00, 
      base_calculo_iss double   , 
      aliquota_iss double   , 
      aliquota_pis double   , 
      aliquota_cofins double   , 
      aliquota_csll double   , 
      aliquota_irrf double   , 
      aliquota_inss double   , 
      valor_deducoes double   , 
      valor_retencoes double   , 
      valor_outras_retencoes double   , 
      valor_liquido double   , 
      valor_servicos double   , 
      valor_iss double   , 
      valor_pis double     DEFAULT 0.00, 
      valor_inss double     DEFAULT 0.00, 
      valor_cofins double     DEFAULT 0.00, 
      valor_csll double   , 
      valor_irrf double     DEFAULT 0.00, 
      incentivador_cultural char  (1)     DEFAULT 'F', 
      optante_simples_nacional char  (1)     DEFAULT 'F', 
      nfse_status text   , 
      ano text   , 
      mes text   , 
      ano_mes text   , 
      pdf text   , 
      xml text   , 
      link_pdf_prefeitura text   , 
      regime_tributario_municipal text   , 
      numero_rps text   , 
      mensagem_erro text   , 
      email_enviado char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id),
FOREIGN KEY(saas_pagamento_id) REFERENCES saas_pagamento(id),
FOREIGN KEY(cidade_prestador_id) REFERENCES cidade(id),
FOREIGN KEY(municipio_prestacao_servico_id) REFERENCES cidade(id),
FOREIGN KEY(nota_fiscal_status_id) REFERENCES nota_fiscal_status(id),
FOREIGN KEY(saas_plano_valor_id) REFERENCES saas_plano_valor(id),
FOREIGN KEY(saas_servico_id) REFERENCES saas_servico(id),
FOREIGN KEY(cidade_tomador_id) REFERENCES cidade(id)) ; 

CREATE TABLE saas_pagamento( 
      id  INTEGER    NOT NULL  , 
      account_id int   NOT NULL  , 
      saas_status_pagamento_id int   NOT NULL  , 
      saas_contrato_id int   , 
      saas_servico_id int   , 
      saas_forma_pagamento_id int   NOT NULL  , 
      saas_gateway_pagamento_id int   NOT NULL  , 
      saas_nota_fiscal_servico_id int   , 
      valor double   NOT NULL  , 
      data_compra datetime   NOT NULL  , 
      data_vencimento date   , 
      data_pagamento date   , 
      dados_gateway text   , 
      id_gateway text   , 
      payment_id text   , 
      link_gateway text   , 
      mes_compra int   , 
      ano_compra int   , 
      ano_pagamento int   , 
      mes_pagamento int   , 
      mes_ano_pagamento text   , 
      mes_ano_compra text   , 
      renovacao char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id),
FOREIGN KEY(saas_status_pagamento_id) REFERENCES saas_status_pagamento(id),
FOREIGN KEY(saas_contrato_id) REFERENCES saas_contrato(id),
FOREIGN KEY(saas_forma_pagamento_id) REFERENCES saas_forma_pagamento(id),
FOREIGN KEY(saas_gateway_pagamento_id) REFERENCES saas_gateway_pagamento(id),
FOREIGN KEY(saas_servico_id) REFERENCES saas_servico(id),
FOREIGN KEY(account_id) REFERENCES account(id),
FOREIGN KEY(saas_nota_fiscal_servico_id) REFERENCES saas_nota_fiscal_servico(id)) ; 

CREATE TABLE saas_plano( 
      id  INTEGER    NOT NULL  , 
      saas_servico_id int   , 
      nome text   NOT NULL  , 
      descricao text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      limite_usuarios int   , 
      limite_unidades int   , 
      discriminacao text   , 
      ordem int   , 
 PRIMARY KEY (id),
FOREIGN KEY(saas_servico_id) REFERENCES saas_servico(id)) ; 

CREATE TABLE saas_plano_grupo( 
      id  INTEGER    NOT NULL  , 
      saas_plano_id int   NOT NULL  , 
      system_group_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(system_group_id) REFERENCES system_group(id),
FOREIGN KEY(saas_plano_id) REFERENCES saas_plano(id)) ; 

CREATE TABLE saas_plano_valor( 
      id  INTEGER    NOT NULL  , 
      saas_plano_id int   NOT NULL  , 
      valor double   NOT NULL  , 
      nome text   NOT NULL  , 
      duracao int   , 
      ativo char  (1)     DEFAULT 'T', 
      desativado_em datetime   , 
      recorrencia char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id),
FOREIGN KEY(saas_plano_id) REFERENCES saas_plano(id)) ; 

CREATE TABLE saas_servico( 
      id  INTEGER    NOT NULL  , 
      servico_grupo_imposto_id int   , 
      nome text   NOT NULL  , 
      preco double   , 
      descricao text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id),
FOREIGN KEY(servico_grupo_imposto_id) REFERENCES saas_servico_grupo_imposto(id)) ; 

CREATE TABLE saas_servico_grupo_imposto( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
      codigo_cnae text   , 
      codigo_tributacao_municipio text   , 
      codigo_nbs text   , 
      codigo text   , 
      descricao_servico_municipio text   , 
      iss_retido text   , 
      natureza_operacao text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico_grupo_imposto_item( 
      id  INTEGER    NOT NULL  , 
      saas_servico_grupo_imposto_id int   NOT NULL  , 
      saas_imposto_id int   NOT NULL  , 
      aliquota double   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(saas_servico_grupo_imposto_id) REFERENCES saas_servico_grupo_imposto(id),
FOREIGN KEY(saas_imposto_id) REFERENCES saas_imposto(id)) ; 

CREATE TABLE saas_status_pagamento( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
      cor text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_template_email( 
      id  INTEGER    NOT NULL  , 
      descricao text   , 
      titulo text   , 
      conteudo text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE servico( 
      id  INTEGER    NOT NULL  , 
      account_id int   NOT NULL  , 
      nome text   NOT NULL  , 
      descricao text   , 
      codigo_cnae text   , 
      codigo_tributacao_municipio text   , 
      codigo_nbs text   , 
      codigo text   , 
      descricao_servico_municipio text   , 
      iss_retido text   , 
      natureza_operacao text   , 
 PRIMARY KEY (id),
FOREIGN KEY(account_id) REFERENCES account(id)) ; 

CREATE TABLE servico_imposto_item( 
      id  INTEGER    NOT NULL  , 
      servico_id int   NOT NULL  , 
      imposto_id int   NOT NULL  , 
      aliquota double   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(servico_id) REFERENCES servico(id),
FOREIGN KEY(imposto_id) REFERENCES imposto(id)) ; 

CREATE TABLE system_document( 
      id int   NOT NULL  , 
      category_id int   NOT NULL  , 
      system_user_id int   , 
      title text   NOT NULL  , 
      description text   , 
      submission_date date   , 
      archive_date date   , 
      filename text   , 
 PRIMARY KEY (id),
FOREIGN KEY(category_id) REFERENCES system_document_category(id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id)) ; 

CREATE TABLE system_document_category( 
      id int   NOT NULL  , 
      name text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_document_group( 
      id int   NOT NULL  , 
      document_id int   NOT NULL  , 
      system_group_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(document_id) REFERENCES system_document(id),
FOREIGN KEY(system_group_id) REFERENCES system_group(id)) ; 

CREATE TABLE system_document_user( 
      id int   NOT NULL  , 
      document_id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(document_id) REFERENCES system_document(id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id)) ; 

CREATE TABLE system_group( 
      id int   NOT NULL  , 
      name text   NOT NULL  , 
      uuid varchar  (36)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group_program( 
      id int   NOT NULL  , 
      system_group_id int   NOT NULL  , 
      system_program_id int   NOT NULL  , 
      actions text   , 
 PRIMARY KEY (id),
FOREIGN KEY(system_program_id) REFERENCES system_program(id),
FOREIGN KEY(system_group_id) REFERENCES system_group(id)) ; 

CREATE TABLE system_message( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_user_to_id int   NOT NULL  , 
      subject text   NOT NULL  , 
      message text   , 
      dt_message datetime   , 
      checked char  (1)   , 
 PRIMARY KEY (id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id),
FOREIGN KEY(system_user_to_id) REFERENCES system_users(id)) ; 

CREATE TABLE system_notification( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_user_to_id int   NOT NULL  , 
      subject text   , 
      message text   , 
      dt_message datetime   , 
      action_url text   , 
      action_label text   , 
      icon text   , 
      checked char  (1)   , 
 PRIMARY KEY (id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id),
FOREIGN KEY(system_user_to_id) REFERENCES system_users(id)) ; 

CREATE TABLE system_preference( 
      id varchar  (255)   NOT NULL  , 
      preference text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_program( 
      id int   NOT NULL  , 
      name text   NOT NULL  , 
      controller text   NOT NULL  , 
      actions text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_unit( 
      id int   NOT NULL  , 
      account_id int   , 
      name text   NOT NULL  , 
      connection_name text   , 
      active char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id),
FOREIGN KEY(account_id) REFERENCES account(id)) ; 

CREATE TABLE system_user_group( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_group_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(system_group_id) REFERENCES system_group(id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id)) ; 

CREATE TABLE system_user_program( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_program_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(system_program_id) REFERENCES system_program(id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id)) ; 

CREATE TABLE system_users( 
      id int   NOT NULL  , 
      name text   NOT NULL  , 
      login text   NOT NULL  , 
      password text   NOT NULL  , 
      email text   , 
      frontpage_id int   , 
      system_unit_id int   , 
      account_id int   , 
      active char  (1)   , 
      accepted_term_policy char  (1)   , 
      accepted_term_policy_at text   , 
      two_factor_enabled char  (1)     DEFAULT 'N', 
      two_factor_type varchar  (100)   , 
      two_factor_secret varchar  (255)   , 
 PRIMARY KEY (id),
FOREIGN KEY(account_id) REFERENCES account(id),
FOREIGN KEY(system_unit_id) REFERENCES system_unit(id),
FOREIGN KEY(frontpage_id) REFERENCES system_program(id)) ; 

CREATE TABLE system_user_unit( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_unit_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id),
FOREIGN KEY(system_unit_id) REFERENCES system_unit(id)) ; 

CREATE TABLE template_acao( 
      id  INTEGER    NOT NULL  , 
      template_clinica_id int   NOT NULL  , 
      url text   , 
      label text   , 
 PRIMARY KEY (id),
FOREIGN KEY(template_clinica_id) REFERENCES template_clinica(id)) ; 

CREATE TABLE template_clinica( 
      id  INTEGER    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      chave text   NOT NULL  , 
      descricao text   NOT NULL  , 
      habilitado char  (1)   NOT NULL    DEFAULT 'T', 
      template text   , 
      titulo text   , 
      tipo_template text   , 
      readonly char  (1)   NOT NULL    DEFAULT 'F', 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id)) ; 

CREATE TABLE tipo_conta( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_documento( 
      id  INTEGER    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      nome text   NOT NULL  , 
      texto_padrao text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'S', 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id)) ; 

CREATE TABLE tipo_pagamento( 
      id  INTEGER    NOT NULL  , 
      account_id int   NOT NULL  , 
      nome text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id),
FOREIGN KEY(account_id) REFERENCES account(id)) ; 

CREATE TABLE unidade_medida( 
      id  INTEGER    NOT NULL  , 
      nome text   NOT NULL  , 
      sigla text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE webhook_log( 
      id  INTEGER    NOT NULL  , 
      gateway_pagamento_id int   , 
      payload text   , 
      created_at datetime   , 
 PRIMARY KEY (id),
FOREIGN KEY(gateway_pagamento_id) REFERENCES saas_gateway_pagamento(id)) ; 

CREATE TABLE whatsapp_config( 
      id  INTEGER    NOT NULL  , 
      clinica_id int   NOT NULL  , 
      phone text   , 
      status text   , 
      api_token text   , 
      api_key text   , 
      api_client_token text   , 
 PRIMARY KEY (id),
FOREIGN KEY(clinica_id) REFERENCES clinica(id)) ; 

 
 CREATE UNIQUE INDEX unique_idx_cep_cache_cep ON cep_cache(cep);
 