<?php 
return[
    'host' => "",
    'name' => "clinica_communication",
    'user' => "",
    'pass' => "",
    'type' => "mysql",
    'prep' => "1",
    'slog' => "SystemSqlLogService"
];