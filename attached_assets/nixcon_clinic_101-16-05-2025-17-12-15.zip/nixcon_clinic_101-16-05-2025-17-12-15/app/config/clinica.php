<?php 
return[
    'host' => "",
    'name' => "clinica",
    'user' => "",
    'pass' => "",
    'type' => "mysql",
    'prep' => "1",
    'slog' => "SystemSqlLogService"
];