<?php 
return[
    'host' => "",
    'name' => "clinica_log",
    'user' => "",
    'pass' => "",
    'type' => "mysql",
    'prep' => "1",
    'slog' => "SystemSqlLogService"
];