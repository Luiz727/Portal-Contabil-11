<?php

require_once 'init.php';

$input    = json_decode(file_get_contents("php://input"), true);
$request  = array_merge($_REQUEST, (array) $input);


TTransaction::open(MAIN_DATABASE);
    
$webhookLog = new WebhookLog();
$webhookLog->gateway_pagamento_id = SaasGatewayPagamento::BANCO_INTER;
$webhookLog->payload = json_encode($request);
$webhookLog->store();

TTransaction::close();

if($request)
{
    foreach($request as $dados)
    {
        TTransaction::open(MAIN_DATABASE);
        
        if($dados->codigoCobranca)
        {
            $pagamento = SaasPagamento::where('id_gateway', '=', $dados->codigoCobranca)->first();

            if($pagamento)
            {
                $result = $service->getInfo($pagamento);
                SaasPagamentoService::update($pagamento, $result);
            }
        }
        
        TTransaction::close();
    }
    
    // [
    //   {
    //     "codigoCobranca": "string",
    //     "seuNumero": "string",
    //     "situacao": "A_RECEBER",
    //     "dataHoraSituacao": "2019-08-24T14:15:22Z",
    //     "valorTotalRecebido": "string",
    //     "origemRecebimento": "BOLETO",
    //     "nossoNumero": "string",
    //     "codigoBarras": "stringstringstringstringstringstringstringst",
    //     "linhaDigitavel": "stringstringstringstringstringstringstringstrin",
    //     "txid": "string",
    //     "pixCopiaECola": "string"
    //   }
    // ]
}