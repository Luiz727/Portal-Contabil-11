<?php

class SaasStatusPagamento extends TRecord
{
    const TABLENAME  = 'saas_status_pagamento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    const AGUARDANDO_PAGAMENTO = '1';
    const PAGO = '2';
    const CANCELADO = '3';
    const RETORNADO = '4';
    const INICIADO = '5';
    const REJEITADO = '6';
    const EM_ANALISE = '7';

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('nome');
        parent::addAttribute('cor');
            
    }

    /**
     * Method getSaasPagamentos
     */
    public function getSaasPagamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_status_pagamento_id', '=', $this->id));
        return SaasPagamento::getObjects( $criteria );
    }
    /**
     * Method getSaasGatewayPagamentoStatuss
     */
    public function getSaasGatewayPagamentoStatuss()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_status_pagamento_id', '=', $this->id));
        return SaasGatewayPagamentoStatus::getObjects( $criteria );
    }

    public function set_saas_pagamento_account_to_string($saas_pagamento_account_to_string)
    {
        if(is_array($saas_pagamento_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_pagamento_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_pagamento_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_account_to_string = $saas_pagamento_account_to_string;
        }

        $this->vdata['saas_pagamento_account_to_string'] = $this->saas_pagamento_account_to_string;
    }

    public function get_saas_pagamento_account_to_string()
    {
        if(!empty($this->saas_pagamento_account_to_string))
        {
            return $this->saas_pagamento_account_to_string;
        }
    
        $values = SaasPagamento::where('saas_status_pagamento_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_status_pagamento_to_string($saas_pagamento_saas_status_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_status_pagamento_to_string))
        {
            $values = SaasStatusPagamento::where('id', 'in', $saas_pagamento_saas_status_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_status_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_status_pagamento_to_string = $saas_pagamento_saas_status_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_status_pagamento_to_string'] = $this->saas_pagamento_saas_status_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_status_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_status_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_status_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_status_pagamento_id', '=', $this->id)->getIndexedArray('saas_status_pagamento_id','{saas_status_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_contrato_to_string($saas_pagamento_saas_contrato_to_string)
    {
        if(is_array($saas_pagamento_saas_contrato_to_string))
        {
            $values = SaasContrato::where('id', 'in', $saas_pagamento_saas_contrato_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_contrato_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_contrato_to_string = $saas_pagamento_saas_contrato_to_string;
        }

        $this->vdata['saas_pagamento_saas_contrato_to_string'] = $this->saas_pagamento_saas_contrato_to_string;
    }

    public function get_saas_pagamento_saas_contrato_to_string()
    {
        if(!empty($this->saas_pagamento_saas_contrato_to_string))
        {
            return $this->saas_pagamento_saas_contrato_to_string;
        }
    
        $values = SaasPagamento::where('saas_status_pagamento_id', '=', $this->id)->getIndexedArray('saas_contrato_id','{saas_contrato->id}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_servico_to_string($saas_pagamento_saas_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_pagamento_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_servico_to_string = $saas_pagamento_saas_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_servico_to_string'] = $this->saas_pagamento_saas_servico_to_string;
    }

    public function get_saas_pagamento_saas_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_servico_to_string))
        {
            return $this->saas_pagamento_saas_servico_to_string;
        }
    
        $values = SaasPagamento::where('saas_status_pagamento_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_forma_pagamento_to_string($saas_pagamento_saas_forma_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_forma_pagamento_to_string))
        {
            $values = SaasFormaPagamento::where('id', 'in', $saas_pagamento_saas_forma_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_forma_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_forma_pagamento_to_string = $saas_pagamento_saas_forma_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_forma_pagamento_to_string'] = $this->saas_pagamento_saas_forma_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_forma_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_forma_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_forma_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_status_pagamento_id', '=', $this->id)->getIndexedArray('saas_forma_pagamento_id','{saas_forma_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_gateway_pagamento_to_string($saas_pagamento_saas_gateway_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_gateway_pagamento_to_string))
        {
            $values = SaasGatewayPagamento::where('id', 'in', $saas_pagamento_saas_gateway_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_gateway_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_gateway_pagamento_to_string = $saas_pagamento_saas_gateway_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_gateway_pagamento_to_string'] = $this->saas_pagamento_saas_gateway_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_gateway_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_gateway_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_gateway_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_status_pagamento_id', '=', $this->id)->getIndexedArray('saas_gateway_pagamento_id','{saas_gateway_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_nota_fiscal_servico_to_string($saas_pagamento_saas_nota_fiscal_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            $values = SaasNotaFiscalServico::where('id', 'in', $saas_pagamento_saas_nota_fiscal_servico_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = $saas_pagamento_saas_nota_fiscal_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_nota_fiscal_servico_to_string'] = $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
    }

    public function get_saas_pagamento_saas_nota_fiscal_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            return $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
        }
    
        $values = SaasPagamento::where('saas_status_pagamento_id', '=', $this->id)->getIndexedArray('saas_nota_fiscal_servico_id','{saas_nota_fiscal_servico->id}');
        return implode(', ', $values);
    }

    public function set_saas_gateway_pagamento_status_saas_gateway_pagamento_to_string($saas_gateway_pagamento_status_saas_gateway_pagamento_to_string)
    {
        if(is_array($saas_gateway_pagamento_status_saas_gateway_pagamento_to_string))
        {
            $values = SaasGatewayPagamento::where('id', 'in', $saas_gateway_pagamento_status_saas_gateway_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_gateway_pagamento_status_saas_gateway_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_gateway_pagamento_status_saas_gateway_pagamento_to_string = $saas_gateway_pagamento_status_saas_gateway_pagamento_to_string;
        }

        $this->vdata['saas_gateway_pagamento_status_saas_gateway_pagamento_to_string'] = $this->saas_gateway_pagamento_status_saas_gateway_pagamento_to_string;
    }

    public function get_saas_gateway_pagamento_status_saas_gateway_pagamento_to_string()
    {
        if(!empty($this->saas_gateway_pagamento_status_saas_gateway_pagamento_to_string))
        {
            return $this->saas_gateway_pagamento_status_saas_gateway_pagamento_to_string;
        }
    
        $values = SaasGatewayPagamentoStatus::where('saas_status_pagamento_id', '=', $this->id)->getIndexedArray('saas_gateway_pagamento_id','{saas_gateway_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_gateway_pagamento_status_saas_status_pagamento_to_string($saas_gateway_pagamento_status_saas_status_pagamento_to_string)
    {
        if(is_array($saas_gateway_pagamento_status_saas_status_pagamento_to_string))
        {
            $values = SaasStatusPagamento::where('id', 'in', $saas_gateway_pagamento_status_saas_status_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_gateway_pagamento_status_saas_status_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_gateway_pagamento_status_saas_status_pagamento_to_string = $saas_gateway_pagamento_status_saas_status_pagamento_to_string;
        }

        $this->vdata['saas_gateway_pagamento_status_saas_status_pagamento_to_string'] = $this->saas_gateway_pagamento_status_saas_status_pagamento_to_string;
    }

    public function get_saas_gateway_pagamento_status_saas_status_pagamento_to_string()
    {
        if(!empty($this->saas_gateway_pagamento_status_saas_status_pagamento_to_string))
        {
            return $this->saas_gateway_pagamento_status_saas_status_pagamento_to_string;
        }
    
        $values = SaasGatewayPagamentoStatus::where('saas_status_pagamento_id', '=', $this->id)->getIndexedArray('saas_status_pagamento_id','{saas_status_pagamento->nome}');
        return implode(', ', $values);
    }

    
}

