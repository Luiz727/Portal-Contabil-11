<?php

class SaasEmailLog extends TRecord
{
    const TABLENAME  = 'saas_email_log';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    const CREATEDAT  = 'created_at';

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('titulo');
        parent::addAttribute('conteudo');
        parent::addAttribute('destinatario');
        parent::addAttribute('created_at');
            
    }

    
}

