<?php

class SaasConfiguracao extends TRecord
{
    const TABLENAME  = 'saas_configuracao';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Cidade $cidade;
    private SaasPlanoValor $saas_plano_valor_trial;
    private SystemGroup $contrato_inativo_system_group;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('cidade_id');
        parent::addAttribute('saas_plano_valor_trial_id');
        parent::addAttribute('contrato_inativo_system_group_id');
        parent::addAttribute('parametro_fiscal_id');
        parent::addAttribute('razao_social');
        parent::addAttribute('nome_fantasia');
        parent::addAttribute('cnpj');
        parent::addAttribute('inscricao_estadual');
        parent::addAttribute('inscricao_municipal');
        parent::addAttribute('cep');
        parent::addAttribute('rua');
        parent::addAttribute('bairro');
        parent::addAttribute('numero');
        parent::addAttribute('complemento');
        parent::addAttribute('email');
        parent::addAttribute('telefone');
        parent::addAttribute('dias_trial');
        parent::addAttribute('contrato');
        parent::addAttribute('regime_tributacao');
        parent::addAttribute('token_integra_notas');
        parent::addAttribute('token_integra_notas_homologacao');
        parent::addAttribute('token_integra_notas_software_house');
        parent::addAttribute('nfse_emissao_producao');
        parent::addAttribute('nfse_numero');
        parent::addAttribute('nfse_serie');
        parent::addAttribute('nfse_info');
        parent::addAttribute('termo_uso');
        parent::addAttribute('email_port');
        parent::addAttribute('email_username');
        parent::addAttribute('email_password');
        parent::addAttribute('email_host');
        parent::addAttribute('email_from');
        parent::addAttribute('email_from_name');
        parent::addAttribute('email_smtp_auth');
        parent::addAttribute('dias_renovacao_contrato');
        parent::addAttribute('dias_vencimento_pagamento');
        parent::addAttribute('url_sistema');
    
    }

    /**
     * Method set_cidade
     * Sample of usage: $var->cidade = $object;
     * @param $object Instance of Cidade
     */
    public function set_cidade(Cidade $object)
    {
        $this->cidade = $object;
        $this->cidade_id = $object->id;
    }

    /**
     * Method get_cidade
     * Sample of usage: $var->cidade->attribute;
     * @returns Cidade instance
     */
    public function get_cidade()
    {
    
        // loads the associated object
        if (empty($this->cidade))
            $this->cidade = new Cidade($this->cidade_id);
    
        // returns the associated object
        return $this->cidade;
    }
    /**
     * Method set_saas_plano_valor
     * Sample of usage: $var->saas_plano_valor = $object;
     * @param $object Instance of SaasPlanoValor
     */
    public function set_saas_plano_valor_trial(SaasPlanoValor $object)
    {
        $this->saas_plano_valor_trial = $object;
        $this->saas_plano_valor_trial_id = $object->id;
    }

    /**
     * Method get_saas_plano_valor_trial
     * Sample of usage: $var->saas_plano_valor_trial->attribute;
     * @returns SaasPlanoValor instance
     */
    public function get_saas_plano_valor_trial()
    {
    
        // loads the associated object
        if (empty($this->saas_plano_valor_trial))
            $this->saas_plano_valor_trial = new SaasPlanoValor($this->saas_plano_valor_trial_id);
    
        // returns the associated object
        return $this->saas_plano_valor_trial;
    }
    /**
     * Method set_system_group
     * Sample of usage: $var->system_group = $object;
     * @param $object Instance of SystemGroup
     */
    public function set_contrato_inativo_system_group(SystemGroup $object)
    {
        $this->contrato_inativo_system_group = $object;
        $this->contrato_inativo_system_group_id = $object->id;
    }

    /**
     * Method get_contrato_inativo_system_group
     * Sample of usage: $var->contrato_inativo_system_group->attribute;
     * @returns SystemGroup instance
     */
    public function get_contrato_inativo_system_group()
    {
    
        // loads the associated object
        if (empty($this->contrato_inativo_system_group))
            $this->contrato_inativo_system_group = new SystemGroup($this->contrato_inativo_system_group_id);
    
        // returns the associated object
        return $this->contrato_inativo_system_group;
    }

    public static function getGroupsTrial()
    {
        $configuracao = self::first();
        $plano_valor = SaasPlanoValor::find($configuracao->saas_plano_valor_trial_id);
        return $plano_valor->saas_plano->ids_groups;
    }

    public static function getDefaults()
    {
        TTransaction::open(MAIN_DATABASE);
        $first = self::first();
        TTransaction::close();
        return $first;
    }
        
}

