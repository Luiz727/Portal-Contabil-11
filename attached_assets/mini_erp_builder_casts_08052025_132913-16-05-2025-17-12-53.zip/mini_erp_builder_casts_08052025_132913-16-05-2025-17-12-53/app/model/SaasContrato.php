<?php

class SaasContrato extends TRecord
{
    const TABLENAME  = 'saas_contrato';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    const CREATEDAT  = 'criado_em';

    private Account $account;
    private SaasContratoStatus $saas_contrato_status;
    private SaasPlanoValor $saas_plano_valor;

    private  $saas_plano;
    private  $proximo_pagamento;
    private  $ids_groups = [];
    private  $saas_gateway_pagamento;

                                            

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('saas_plano_valor_id');
        parent::addAttribute('account_id');
        parent::addAttribute('saas_contrato_status_id');
        parent::addAttribute('valor_total');
        parent::addAttribute('data_inicial');
        parent::addAttribute('data_final');
        parent::addAttribute('criado_em');
        parent::addAttribute('renovacao');
        parent::addAttribute('total_usuarios');
        parent::addAttribute('total_unidades');
        parent::addAttribute('gateway_assinatura_id');
    
    }

    /**
     * Method set_account
     * Sample of usage: $var->account = $object;
     * @param $object Instance of Account
     */
    public function set_account(Account $object)
    {
        $this->account = $object;
        $this->account_id = $object->id;
    }

    /**
     * Method get_account
     * Sample of usage: $var->account->attribute;
     * @returns Account instance
     */
    public function get_account()
    {
    
        // loads the associated object
        if (empty($this->account))
            $this->account = new Account($this->account_id);
    
        // returns the associated object
        return $this->account;
    }
    /**
     * Method set_saas_contrato_status
     * Sample of usage: $var->saas_contrato_status = $object;
     * @param $object Instance of SaasContratoStatus
     */
    public function set_saas_contrato_status(SaasContratoStatus $object)
    {
        $this->saas_contrato_status = $object;
        $this->saas_contrato_status_id = $object->id;
    }

    /**
     * Method get_saas_contrato_status
     * Sample of usage: $var->saas_contrato_status->attribute;
     * @returns SaasContratoStatus instance
     */
    public function get_saas_contrato_status()
    {
    
        // loads the associated object
        if (empty($this->saas_contrato_status))
            $this->saas_contrato_status = new SaasContratoStatus($this->saas_contrato_status_id);
    
        // returns the associated object
        return $this->saas_contrato_status;
    }
    /**
     * Method set_saas_plano_valor
     * Sample of usage: $var->saas_plano_valor = $object;
     * @param $object Instance of SaasPlanoValor
     */
    public function set_saas_plano_valor(SaasPlanoValor $object)
    {
        $this->saas_plano_valor = $object;
        $this->saas_plano_valor_id = $object->id;
    }

    /**
     * Method get_saas_plano_valor
     * Sample of usage: $var->saas_plano_valor->attribute;
     * @returns SaasPlanoValor instance
     */
    public function get_saas_plano_valor()
    {
    
        // loads the associated object
        if (empty($this->saas_plano_valor))
            $this->saas_plano_valor = new SaasPlanoValor($this->saas_plano_valor_id);
    
        // returns the associated object
        return $this->saas_plano_valor;
    }

    /**
     * Method getSaasPagamentos
     */
    public function getSaasPagamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_contrato_id', '=', $this->id));
        return SaasPagamento::getObjects( $criteria );
    }
    /**
     * Method getSaasContratoGrupos
     */
    public function getSaasContratoGrupos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_contrato_id', '=', $this->id));
        return SaasContratoGrupo::getObjects( $criteria );
    }

    public function set_saas_pagamento_account_to_string($saas_pagamento_account_to_string)
    {
        if(is_array($saas_pagamento_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_pagamento_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_pagamento_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_account_to_string = $saas_pagamento_account_to_string;
        }

        $this->vdata['saas_pagamento_account_to_string'] = $this->saas_pagamento_account_to_string;
    }

    public function get_saas_pagamento_account_to_string()
    {
        if(!empty($this->saas_pagamento_account_to_string))
        {
            return $this->saas_pagamento_account_to_string;
        }
    
        $values = SaasPagamento::where('saas_contrato_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_status_pagamento_to_string($saas_pagamento_saas_status_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_status_pagamento_to_string))
        {
            $values = SaasStatusPagamento::where('id', 'in', $saas_pagamento_saas_status_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_status_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_status_pagamento_to_string = $saas_pagamento_saas_status_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_status_pagamento_to_string'] = $this->saas_pagamento_saas_status_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_status_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_status_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_status_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_contrato_id', '=', $this->id)->getIndexedArray('saas_status_pagamento_id','{saas_status_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_contrato_to_string($saas_pagamento_saas_contrato_to_string)
    {
        if(is_array($saas_pagamento_saas_contrato_to_string))
        {
            $values = SaasContrato::where('id', 'in', $saas_pagamento_saas_contrato_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_contrato_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_contrato_to_string = $saas_pagamento_saas_contrato_to_string;
        }

        $this->vdata['saas_pagamento_saas_contrato_to_string'] = $this->saas_pagamento_saas_contrato_to_string;
    }

    public function get_saas_pagamento_saas_contrato_to_string()
    {
        if(!empty($this->saas_pagamento_saas_contrato_to_string))
        {
            return $this->saas_pagamento_saas_contrato_to_string;
        }
    
        $values = SaasPagamento::where('saas_contrato_id', '=', $this->id)->getIndexedArray('saas_contrato_id','{saas_contrato->id}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_servico_to_string($saas_pagamento_saas_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_pagamento_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_servico_to_string = $saas_pagamento_saas_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_servico_to_string'] = $this->saas_pagamento_saas_servico_to_string;
    }

    public function get_saas_pagamento_saas_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_servico_to_string))
        {
            return $this->saas_pagamento_saas_servico_to_string;
        }
    
        $values = SaasPagamento::where('saas_contrato_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_forma_pagamento_to_string($saas_pagamento_saas_forma_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_forma_pagamento_to_string))
        {
            $values = SaasFormaPagamento::where('id', 'in', $saas_pagamento_saas_forma_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_forma_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_forma_pagamento_to_string = $saas_pagamento_saas_forma_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_forma_pagamento_to_string'] = $this->saas_pagamento_saas_forma_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_forma_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_forma_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_forma_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_contrato_id', '=', $this->id)->getIndexedArray('saas_forma_pagamento_id','{saas_forma_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_gateway_pagamento_to_string($saas_pagamento_saas_gateway_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_gateway_pagamento_to_string))
        {
            $values = SaasGatewayPagamento::where('id', 'in', $saas_pagamento_saas_gateway_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_gateway_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_gateway_pagamento_to_string = $saas_pagamento_saas_gateway_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_gateway_pagamento_to_string'] = $this->saas_pagamento_saas_gateway_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_gateway_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_gateway_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_gateway_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_contrato_id', '=', $this->id)->getIndexedArray('saas_gateway_pagamento_id','{saas_gateway_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_nota_fiscal_servico_to_string($saas_pagamento_saas_nota_fiscal_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            $values = SaasNotaFiscalServico::where('id', 'in', $saas_pagamento_saas_nota_fiscal_servico_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = $saas_pagamento_saas_nota_fiscal_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_nota_fiscal_servico_to_string'] = $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
    }

    public function get_saas_pagamento_saas_nota_fiscal_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            return $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
        }
    
        $values = SaasPagamento::where('saas_contrato_id', '=', $this->id)->getIndexedArray('saas_nota_fiscal_servico_id','{saas_nota_fiscal_servico->id}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_grupo_saas_contrato_to_string($saas_contrato_grupo_saas_contrato_to_string)
    {
        if(is_array($saas_contrato_grupo_saas_contrato_to_string))
        {
            $values = SaasContrato::where('id', 'in', $saas_contrato_grupo_saas_contrato_to_string)->getIndexedArray('id', 'id');
            $this->saas_contrato_grupo_saas_contrato_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_grupo_saas_contrato_to_string = $saas_contrato_grupo_saas_contrato_to_string;
        }

        $this->vdata['saas_contrato_grupo_saas_contrato_to_string'] = $this->saas_contrato_grupo_saas_contrato_to_string;
    }

    public function get_saas_contrato_grupo_saas_contrato_to_string()
    {
        if(!empty($this->saas_contrato_grupo_saas_contrato_to_string))
        {
            return $this->saas_contrato_grupo_saas_contrato_to_string;
        }
    
        $values = SaasContratoGrupo::where('saas_contrato_id', '=', $this->id)->getIndexedArray('saas_contrato_id','{saas_contrato->id}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_grupo_system_group_to_string($saas_contrato_grupo_system_group_to_string)
    {
        if(is_array($saas_contrato_grupo_system_group_to_string))
        {
            $values = SystemGroup::where('id', 'in', $saas_contrato_grupo_system_group_to_string)->getIndexedArray('name', 'name');
            $this->saas_contrato_grupo_system_group_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_grupo_system_group_to_string = $saas_contrato_grupo_system_group_to_string;
        }

        $this->vdata['saas_contrato_grupo_system_group_to_string'] = $this->saas_contrato_grupo_system_group_to_string;
    }

    public function get_saas_contrato_grupo_system_group_to_string()
    {
        if(!empty($this->saas_contrato_grupo_system_group_to_string))
        {
            return $this->saas_contrato_grupo_system_group_to_string;
        }
    
        $values = SaasContratoGrupo::where('saas_contrato_id', '=', $this->id)->getIndexedArray('system_group_id','{system_group->name}');
        return implode(', ', $values);
    }

    public function isAtivo()
    {
        if ($this->saas_contrato_status_id == SaasContratoStatus::INATIVO)
        {
            return FALSE;
        }
    
        if (! empty($this->data_final) AND $this->data_final < date('Y-m-d'))
        {
            return FALSE;
        }
    
        return TRUE;
    }

    public function get_ids_groups()
    {
        if (empty($this->ids_groups))
        {
            $this->ids_groups = $this->get_saas_plano()->ids_groups;
        }
    
        $grupos = $this->getSaasContratoGrupos();
    
        if($grupos)
        {
            $grupos = array_column($grupos, 'system_group_id');
            $this->ids_groups = array_merge($this->ids_groups, $grupos);
        }
    
        return $this->ids_groups;
    }
    public function get_saas_plano()
    {
        if (empty($this->saas_plano))
        {
            $this->saas_plano = $this->get_saas_plano_valor()->saas_plano;
        }
    
        return $this->saas_plano;
    }

    public function get_saas_gateway_pagamento()
    {
        if (empty($this->saas_gateway_pagamento))
        {
            $lastPagamento = SaasPagamento::where('saas_contrato_id', '=', $this->id)
                     ->orderBy('data_vencimento', 'desc')
                     ->first();
            if(!empty($lastPagamento->saas_gateway_pagamento))
            {
                $this->saas_gateway_pagamento = $lastPagamento->saas_gateway_pagamento;
            }
        }
    
        return $this->saas_gateway_pagamento ?? null;
    }

    public function get_proximo_pagamento()
    {
        if (empty($this->proximo_pagamento))
        {
            $this->proximo_pagamento = SaasPagamento::where('saas_contrato_id', '=', $this->id)
                     ->where('saas_status_pagamento_id', '=', SaasStatusPagamento::AGUARDANDO_PAGAMENTO)
                     ->last();
        }
    
        return $this->proximo_pagamento;
    }

    public function get_descricao_html()
    {
        $cliente = $this->get_account();
        $plano = $this->get_saas_plano();
        $data_inicial = TDate::date2br($this->data_inicial);
        $data_final = TDate::date2br($this->data_final);
        $valor_total = ToolService::toBRL($this->valor_total);
    
        $status = $this->get_saas_contrato_status();
    
        $status_contrato = "<span class = 'label label-default' style='width:190px; font-weight:normal; color:#fff; background-color: {$status->cor}'> {$status->nome} </span> ";
        return "
            <div class='row'>
            
                <div class = 'col-sm-12'>
                    <b>Id contrato:</b> {$this->id}  <br>
                    <b>Cliente:</b> {$cliente->razao_social} ({$cliente->email})
                </div>
                <div class = 'col-sm-6'>
                    <b>Plano:</b> {$plano->nome} <br>
                    <b>Valor:</b> R$ {$valor_total} <br>
                </div>
                <div class = 'col-sm-6'>
                    <b>Data inicial:</b> {$data_inicial} <br>
                    <b>Data final:</b> {$data_final} <br>
                </div>
                <div class='col-sm-12'>
                {$status_contrato}
                </div>
            
            </div>
        ";
    
        // <b>Renovação:</b> {$this->periodo_renovacao_dias} dias <br>
    }

    public function get_dias_vencimento()
    {
        $data1 = new DateTime(date('Y-m-d'));
        $data2 = new DateTime($this->data_final);
    
        // Calcula a diferença entre as datas
        $diferenca = $data1->diff($data2);
    
        return $diferenca->days;
    }

    public function get_valor_total_formatado()
    {
        return 'R$ ' . number_format($this->valor_total, 2, ',', '.');
    }

                                                    
}

