<?php

class WebhookLog extends TRecord
{
    const TABLENAME  = 'webhook_log';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    const CREATEDAT  = 'created_at';

    private SaasGatewayPagamento $gateway_pagamento;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('gateway_pagamento_id');
        parent::addAttribute('payload');
        parent::addAttribute('created_at');
            
    }

    /**
     * Method set_saas_gateway_pagamento
     * Sample of usage: $var->saas_gateway_pagamento = $object;
     * @param $object Instance of SaasGatewayPagamento
     */
    public function set_gateway_pagamento(SaasGatewayPagamento $object)
    {
        $this->gateway_pagamento = $object;
        $this->gateway_pagamento_id = $object->id;
    }

    /**
     * Method get_gateway_pagamento
     * Sample of usage: $var->gateway_pagamento->attribute;
     * @returns SaasGatewayPagamento instance
     */
    public function get_gateway_pagamento()
    {
    
        // loads the associated object
        if (empty($this->gateway_pagamento))
            $this->gateway_pagamento = new SaasGatewayPagamento($this->gateway_pagamento_id);
    
        // returns the associated object
        return $this->gateway_pagamento;
    }

    
}

