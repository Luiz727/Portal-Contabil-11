<?php

class SaasNotaFiscalServico extends TRecord
{
    const TABLENAME  = 'saas_nota_fiscal_servico';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SaasPagamento $saas_pagamento;
    private Cidade $cidade_prestador;
    private Cidade $municipio_prestacao_servico;
    private NotaFiscalStatus $nota_fiscal_status;
    private SaasPlanoValor $saas_plano_valor;
    private SaasServico $saas_servico;
    private Cidade $cidade_tomador;
    private Account $account;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByAccount');
    
    
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('saas_pagamento_id');
        parent::addAttribute('saas_plano_valor_id');
        parent::addAttribute('saas_servico_id');
        parent::addAttribute('cidade_tomador_id');
        parent::addAttribute('cidade_prestador_id');
        parent::addAttribute('municipio_prestacao_servico_id');
        parent::addAttribute('nota_fiscal_status_id');
        parent::addAttribute('account_id');
        parent::addAttribute('natureza_operacao');
        parent::addAttribute('data_hora_emissao');
        parent::addAttribute('discriminacao');
        parent::addAttribute('numero');
        parent::addAttribute('codigo_verificacao');
        parent::addAttribute('id_gateway_externo');
        parent::addAttribute('dados_gateway_externo');
        parent::addAttribute('nome_tomador');
        parent::addAttribute('documento_tomador');
        parent::addAttribute('endereco_tomador');
        parent::addAttribute('email_tomador');
        parent::addAttribute('telefone_tomador');
        parent::addAttribute('numero_tomador');
        parent::addAttribute('bairro_tomador');
        parent::addAttribute('cep_tomador');
        parent::addAttribute('inscricao_municipal_tomador');
        parent::addAttribute('inscricao_municipal_prestador');
        parent::addAttribute('nome_prestador');
        parent::addAttribute('documento_prestador');
        parent::addAttribute('endereco_prestador');
        parent::addAttribute('email_prestador');
        parent::addAttribute('telefone_prestador');
        parent::addAttribute('numero_prestador');
        parent::addAttribute('bairro_prestador');
        parent::addAttribute('cep_prestador');
        parent::addAttribute('iss_retido');
        parent::addAttribute('desconto_incondicionado');
        parent::addAttribute('desconto_condicionado');
        parent::addAttribute('base_calculo_iss');
        parent::addAttribute('aliquota_iss');
        parent::addAttribute('aliquota_pis');
        parent::addAttribute('aliquota_cofins');
        parent::addAttribute('aliquota_csll');
        parent::addAttribute('aliquota_irrf');
        parent::addAttribute('aliquota_inss');
        parent::addAttribute('valor_deducoes');
        parent::addAttribute('valor_retencoes');
        parent::addAttribute('valor_outras_retencoes');
        parent::addAttribute('valor_liquido');
        parent::addAttribute('valor_servicos');
        parent::addAttribute('valor_iss');
        parent::addAttribute('valor_pis');
        parent::addAttribute('valor_inss');
        parent::addAttribute('valor_cofins');
        parent::addAttribute('valor_csll');
        parent::addAttribute('valor_irrf');
        parent::addAttribute('incentivador_cultural');
        parent::addAttribute('optante_simples_nacional');
        parent::addAttribute('nfse_status');
        parent::addAttribute('ano');
        parent::addAttribute('mes');
        parent::addAttribute('ano_mes');
        parent::addAttribute('pdf');
        parent::addAttribute('xml');
        parent::addAttribute('link_pdf_prefeitura');
        parent::addAttribute('regime_tributario_municipal');
        parent::addAttribute('numero_rps');
        parent::addAttribute('mensagem_erro');
        parent::addAttribute('email_enviado');
    
    }

    /**
     * Method set_saas_pagamento
     * Sample of usage: $var->saas_pagamento = $object;
     * @param $object Instance of SaasPagamento
     */
    public function set_saas_pagamento(SaasPagamento $object)
    {
        $this->saas_pagamento = $object;
        $this->saas_pagamento_id = $object->id;
    }

    /**
     * Method get_saas_pagamento
     * Sample of usage: $var->saas_pagamento->attribute;
     * @returns SaasPagamento instance
     */
    public function get_saas_pagamento()
    {
    
        // loads the associated object
        if (empty($this->saas_pagamento))
            $this->saas_pagamento = new SaasPagamento($this->saas_pagamento_id);
    
        // returns the associated object
        return $this->saas_pagamento;
    }
    /**
     * Method set_cidade
     * Sample of usage: $var->cidade = $object;
     * @param $object Instance of Cidade
     */
    public function set_cidade_prestador(Cidade $object)
    {
        $this->cidade_prestador = $object;
        $this->cidade_prestador_id = $object->id;
    }

    /**
     * Method get_cidade_prestador
     * Sample of usage: $var->cidade_prestador->attribute;
     * @returns Cidade instance
     */
    public function get_cidade_prestador()
    {
    
        // loads the associated object
        if (empty($this->cidade_prestador))
            $this->cidade_prestador = new Cidade($this->cidade_prestador_id);
    
        // returns the associated object
        return $this->cidade_prestador;
    }
    /**
     * Method set_cidade
     * Sample of usage: $var->cidade = $object;
     * @param $object Instance of Cidade
     */
    public function set_municipio_prestacao_servico(Cidade $object)
    {
        $this->municipio_prestacao_servico = $object;
        $this->municipio_prestacao_servico_id = $object->id;
    }

    /**
     * Method get_municipio_prestacao_servico
     * Sample of usage: $var->municipio_prestacao_servico->attribute;
     * @returns Cidade instance
     */
    public function get_municipio_prestacao_servico()
    {
    
        // loads the associated object
        if (empty($this->municipio_prestacao_servico))
            $this->municipio_prestacao_servico = new Cidade($this->municipio_prestacao_servico_id);
    
        // returns the associated object
        return $this->municipio_prestacao_servico;
    }
    /**
     * Method set_nota_fiscal_status
     * Sample of usage: $var->nota_fiscal_status = $object;
     * @param $object Instance of NotaFiscalStatus
     */
    public function set_nota_fiscal_status(NotaFiscalStatus $object)
    {
        $this->nota_fiscal_status = $object;
        $this->nota_fiscal_status_id = $object->id;
    }

    /**
     * Method get_nota_fiscal_status
     * Sample of usage: $var->nota_fiscal_status->attribute;
     * @returns NotaFiscalStatus instance
     */
    public function get_nota_fiscal_status()
    {
    
        // loads the associated object
        if (empty($this->nota_fiscal_status))
            $this->nota_fiscal_status = new NotaFiscalStatus($this->nota_fiscal_status_id);
    
        // returns the associated object
        return $this->nota_fiscal_status;
    }
    /**
     * Method set_saas_plano_valor
     * Sample of usage: $var->saas_plano_valor = $object;
     * @param $object Instance of SaasPlanoValor
     */
    public function set_saas_plano_valor(SaasPlanoValor $object)
    {
        $this->saas_plano_valor = $object;
        $this->saas_plano_valor_id = $object->id;
    }

    /**
     * Method get_saas_plano_valor
     * Sample of usage: $var->saas_plano_valor->attribute;
     * @returns SaasPlanoValor instance
     */
    public function get_saas_plano_valor()
    {
    
        // loads the associated object
        if (empty($this->saas_plano_valor))
            $this->saas_plano_valor = new SaasPlanoValor($this->saas_plano_valor_id);
    
        // returns the associated object
        return $this->saas_plano_valor;
    }
    /**
     * Method set_saas_servico
     * Sample of usage: $var->saas_servico = $object;
     * @param $object Instance of SaasServico
     */
    public function set_saas_servico(SaasServico $object)
    {
        $this->saas_servico = $object;
        $this->saas_servico_id = $object->id;
    }

    /**
     * Method get_saas_servico
     * Sample of usage: $var->saas_servico->attribute;
     * @returns SaasServico instance
     */
    public function get_saas_servico()
    {
    
        // loads the associated object
        if (empty($this->saas_servico))
            $this->saas_servico = new SaasServico($this->saas_servico_id);
    
        // returns the associated object
        return $this->saas_servico;
    }
    /**
     * Method set_cidade
     * Sample of usage: $var->cidade = $object;
     * @param $object Instance of Cidade
     */
    public function set_cidade_tomador(Cidade $object)
    {
        $this->cidade_tomador = $object;
        $this->cidade_tomador_id = $object->id;
    }

    /**
     * Method get_cidade_tomador
     * Sample of usage: $var->cidade_tomador->attribute;
     * @returns Cidade instance
     */
    public function get_cidade_tomador()
    {
    
        // loads the associated object
        if (empty($this->cidade_tomador))
            $this->cidade_tomador = new Cidade($this->cidade_tomador_id);
    
        // returns the associated object
        return $this->cidade_tomador;
    }
    /**
     * Method set_account
     * Sample of usage: $var->account = $object;
     * @param $object Instance of Account
     */
    public function set_account(Account $object)
    {
        $this->account = $object;
        $this->account_id = $object->id;
    }

    /**
     * Method get_account
     * Sample of usage: $var->account->attribute;
     * @returns Account instance
     */
    public function get_account()
    {
    
        // loads the associated object
        if (empty($this->account))
            $this->account = new Account($this->account_id);
    
        // returns the associated object
        return $this->account;
    }

    /**
     * Method getSaasPagamentos
     */
    public function getSaasPagamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_nota_fiscal_servico_id', '=', $this->id));
        return SaasPagamento::getObjects( $criteria );
    }

    public function set_saas_pagamento_account_to_string($saas_pagamento_account_to_string)
    {
        if(is_array($saas_pagamento_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_pagamento_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_pagamento_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_account_to_string = $saas_pagamento_account_to_string;
        }

        $this->vdata['saas_pagamento_account_to_string'] = $this->saas_pagamento_account_to_string;
    }

    public function get_saas_pagamento_account_to_string()
    {
        if(!empty($this->saas_pagamento_account_to_string))
        {
            return $this->saas_pagamento_account_to_string;
        }
    
        $values = SaasPagamento::where('saas_nota_fiscal_servico_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_status_pagamento_to_string($saas_pagamento_saas_status_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_status_pagamento_to_string))
        {
            $values = SaasStatusPagamento::where('id', 'in', $saas_pagamento_saas_status_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_status_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_status_pagamento_to_string = $saas_pagamento_saas_status_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_status_pagamento_to_string'] = $this->saas_pagamento_saas_status_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_status_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_status_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_status_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_nota_fiscal_servico_id', '=', $this->id)->getIndexedArray('saas_status_pagamento_id','{saas_status_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_contrato_to_string($saas_pagamento_saas_contrato_to_string)
    {
        if(is_array($saas_pagamento_saas_contrato_to_string))
        {
            $values = SaasContrato::where('id', 'in', $saas_pagamento_saas_contrato_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_contrato_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_contrato_to_string = $saas_pagamento_saas_contrato_to_string;
        }

        $this->vdata['saas_pagamento_saas_contrato_to_string'] = $this->saas_pagamento_saas_contrato_to_string;
    }

    public function get_saas_pagamento_saas_contrato_to_string()
    {
        if(!empty($this->saas_pagamento_saas_contrato_to_string))
        {
            return $this->saas_pagamento_saas_contrato_to_string;
        }
    
        $values = SaasPagamento::where('saas_nota_fiscal_servico_id', '=', $this->id)->getIndexedArray('saas_contrato_id','{saas_contrato->id}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_servico_to_string($saas_pagamento_saas_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_pagamento_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_servico_to_string = $saas_pagamento_saas_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_servico_to_string'] = $this->saas_pagamento_saas_servico_to_string;
    }

    public function get_saas_pagamento_saas_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_servico_to_string))
        {
            return $this->saas_pagamento_saas_servico_to_string;
        }
    
        $values = SaasPagamento::where('saas_nota_fiscal_servico_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_forma_pagamento_to_string($saas_pagamento_saas_forma_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_forma_pagamento_to_string))
        {
            $values = SaasFormaPagamento::where('id', 'in', $saas_pagamento_saas_forma_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_forma_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_forma_pagamento_to_string = $saas_pagamento_saas_forma_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_forma_pagamento_to_string'] = $this->saas_pagamento_saas_forma_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_forma_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_forma_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_forma_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_nota_fiscal_servico_id', '=', $this->id)->getIndexedArray('saas_forma_pagamento_id','{saas_forma_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_gateway_pagamento_to_string($saas_pagamento_saas_gateway_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_gateway_pagamento_to_string))
        {
            $values = SaasGatewayPagamento::where('id', 'in', $saas_pagamento_saas_gateway_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_gateway_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_gateway_pagamento_to_string = $saas_pagamento_saas_gateway_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_gateway_pagamento_to_string'] = $this->saas_pagamento_saas_gateway_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_gateway_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_gateway_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_gateway_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_nota_fiscal_servico_id', '=', $this->id)->getIndexedArray('saas_gateway_pagamento_id','{saas_gateway_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_nota_fiscal_servico_to_string($saas_pagamento_saas_nota_fiscal_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            $values = SaasNotaFiscalServico::where('id', 'in', $saas_pagamento_saas_nota_fiscal_servico_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = $saas_pagamento_saas_nota_fiscal_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_nota_fiscal_servico_to_string'] = $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
    }

    public function get_saas_pagamento_saas_nota_fiscal_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            return $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
        }
    
        $values = SaasPagamento::where('saas_nota_fiscal_servico_id', '=', $this->id)->getIndexedArray('saas_nota_fiscal_servico_id','{saas_nota_fiscal_servico->id}');
        return implode(', ', $values);
    }

    public function podeTransmitir()
    {
        return (in_array($this->nota_fiscal_status_id, NotaFiscalStatus::getStatusTransmissao()));
    }

    public function getDadosGatewayFormatado()
    {
        if ($this->dados_gateway_externo)
        {
            $dados = json_decode($this->dados_gateway_externo);

            $result = [];

            if (! empty($dados->erros))
            {
                $dados->erros = is_string($dados->erros) ? $dados->erros : json_encode($dados->erros);
                $result[] = "Erros: <div><b>{$dados->erros}</b></div>";
            }
        
            if (! empty($dados->justificativa))
            {
                $dados->justificativa = nl2br($dados->justificativa);
                $result[] = "Justificativa: <div><b>{$dados->justificativa}</b></div>";
            }
        
            if (! empty($dados->documento))
            {
                $result[] = "<div><a target='_blank' href='{$dados->documento}'><i class='fa fa-file-pdf red'></i> Visualizar documento</a></div>";
            }
        
            if (! empty($dados->xml))
            {
                $result[] = "<div><a target='_blank' href='{$dados->xml}'><i class='fa fa-file-code orange'></i> Visualizar XML</a></div>";
            }
        
            return implode('', $result);
        }
    
        return null;
    }

   

    public function onBeforeStore($object)
    {
        if (! empty($object->data_hora_emissao))
        {
            $object->ano = date('Y', strtotime($object->data_hora_emissao));
            $object->mes = date('m', strtotime($object->data_hora_emissao));
        
            $object->ano_mes = $object->ano.$object->mes;
        }
    }

                                                
}

