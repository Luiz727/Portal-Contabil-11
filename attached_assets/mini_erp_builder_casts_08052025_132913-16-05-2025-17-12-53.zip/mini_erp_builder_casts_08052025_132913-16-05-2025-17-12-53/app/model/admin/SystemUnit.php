<?php

class SystemUnit extends TRecord
{
    const TABLENAME  = 'system_unit';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'max'; // {max, serial}

    private Account $account;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('name');
        parent::addAttribute('account_id');
        parent::addAttribute('connection_name');
        parent::addAttribute('active');
            
    }

    /**
     * Method set_account
     * Sample of usage: $var->account = $object;
     * @param $object Instance of Account
     */
    public function set_account(Account $object)
    {
        $this->account = $object;
        $this->account_id = $object->id;
    }

    /**
     * Method get_account
     * Sample of usage: $var->account->attribute;
     * @returns Account instance
     */
    public function get_account()
    {
    
        // loads the associated object
        if (empty($this->account))
            $this->account = new Account($this->account_id);
    
        // returns the associated object
        return $this->account;
    }

    /**
     * Method getSaasErrorLogs
     */
    public function getSaasErrorLogs()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('system_unit_id', '=', $this->id));
        return SaasErrorLog::getObjects( $criteria );
    }

    public function set_saas_error_log_system_unit_to_string($saas_error_log_system_unit_to_string)
    {
        if(is_array($saas_error_log_system_unit_to_string))
        {
            $values = SystemUnit::where('id', 'in', $saas_error_log_system_unit_to_string)->getIndexedArray('name', 'name');
            $this->saas_error_log_system_unit_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_error_log_system_unit_to_string = $saas_error_log_system_unit_to_string;
        }

        $this->vdata['saas_error_log_system_unit_to_string'] = $this->saas_error_log_system_unit_to_string;
    }

    public function get_saas_error_log_system_unit_to_string()
    {
        if(!empty($this->saas_error_log_system_unit_to_string))
        {
            return $this->saas_error_log_system_unit_to_string;
        }
    
        $values = SaasErrorLog::where('system_unit_id', '=', $this->id)->getIndexedArray('system_unit_id','{system_unit->name}');
        return implode(', ', $values);
    }

    public function set_saas_error_log_system_user_to_string($saas_error_log_system_user_to_string)
    {
        if(is_array($saas_error_log_system_user_to_string))
        {
            $values = SystemUsers::where('id', 'in', $saas_error_log_system_user_to_string)->getIndexedArray('name', 'name');
            $this->saas_error_log_system_user_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_error_log_system_user_to_string = $saas_error_log_system_user_to_string;
        }

        $this->vdata['saas_error_log_system_user_to_string'] = $this->saas_error_log_system_user_to_string;
    }

    public function get_saas_error_log_system_user_to_string()
    {
        if(!empty($this->saas_error_log_system_user_to_string))
        {
            return $this->saas_error_log_system_user_to_string;
        }
    
        $values = SaasErrorLog::where('system_unit_id', '=', $this->id)->getIndexedArray('system_user_id','{system_user->name}');
        return implode(', ', $values);
    }

    
}

