<?php

class SaasPlanoGrupo extends TRecord
{
    const TABLENAME  = 'saas_plano_grupo';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SystemGroup $system_group;
    private SaasPlano $saas_plano;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('saas_plano_id');
        parent::addAttribute('system_group_id');
            
    }

    /**
     * Method set_system_group
     * Sample of usage: $var->system_group = $object;
     * @param $object Instance of SystemGroup
     */
    public function set_system_group(SystemGroup $object)
    {
        $this->system_group = $object;
        $this->system_group_id = $object->id;
    }

    /**
     * Method get_system_group
     * Sample of usage: $var->system_group->attribute;
     * @returns SystemGroup instance
     */
    public function get_system_group()
    {
    
        // loads the associated object
        if (empty($this->system_group))
            $this->system_group = new SystemGroup($this->system_group_id);
    
        // returns the associated object
        return $this->system_group;
    }
    /**
     * Method set_saas_plano
     * Sample of usage: $var->saas_plano = $object;
     * @param $object Instance of SaasPlano
     */
    public function set_saas_plano(SaasPlano $object)
    {
        $this->saas_plano = $object;
        $this->saas_plano_id = $object->id;
    }

    /**
     * Method get_saas_plano
     * Sample of usage: $var->saas_plano->attribute;
     * @returns SaasPlano instance
     */
    public function get_saas_plano()
    {
    
        // loads the associated object
        if (empty($this->saas_plano))
            $this->saas_plano = new SaasPlano($this->saas_plano_id);
    
        // returns the associated object
        return $this->saas_plano;
    }

    
}

