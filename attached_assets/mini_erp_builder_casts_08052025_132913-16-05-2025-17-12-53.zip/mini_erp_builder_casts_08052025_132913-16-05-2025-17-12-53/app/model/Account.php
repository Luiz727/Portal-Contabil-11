<?php

class Account extends TRecord
{
    const TABLENAME  = 'account';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private Cidade $cidade;
    private SystemUsers $system_user;

    private $contrato;

                                                

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('cidade_id');
        parent::addAttribute('system_user_id');
        parent::addAttribute('nome_responsavel');
        parent::addAttribute('razao_social');
        parent::addAttribute('tipo_pessoa');
        parent::addAttribute('documento');
        parent::addAttribute('email');
        parent::addAttribute('telefone');
        parent::addAttribute('cep');
        parent::addAttribute('rua');
        parent::addAttribute('numero');
        parent::addAttribute('complemento');
        parent::addAttribute('bairro');
        parent::addAttribute('mes_criacao');
        parent::addAttribute('ano_criacao');
        parent::addAttribute('created_at');
    
    }

    /**
     * Method set_cidade
     * Sample of usage: $var->cidade = $object;
     * @param $object Instance of Cidade
     */
    public function set_cidade(Cidade $object)
    {
        $this->cidade = $object;
        $this->cidade_id = $object->id;
    }

    /**
     * Method get_cidade
     * Sample of usage: $var->cidade->attribute;
     * @returns Cidade instance
     */
    public function get_cidade()
    {
    
        // loads the associated object
        if (empty($this->cidade))
            $this->cidade = new Cidade($this->cidade_id);
    
        // returns the associated object
        return $this->cidade;
    }
    /**
     * Method set_system_users
     * Sample of usage: $var->system_users = $object;
     * @param $object Instance of SystemUsers
     */
    public function set_system_user(SystemUsers $object)
    {
        $this->system_user = $object;
        $this->system_user_id = $object->id;
    }

    /**
     * Method get_system_user
     * Sample of usage: $var->system_user->attribute;
     * @returns SystemUsers instance
     */
    public function get_system_user()
    {
    
        // loads the associated object
        if (empty($this->system_user))
            $this->system_user = new SystemUsers($this->system_user_id);
    
        // returns the associated object
        return $this->system_user;
    }

    /**
     * Method getSaasPagamentos
     */
    public function getSaasPagamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('account_id', '=', $this->id));
        return SaasPagamento::getObjects( $criteria );
    }
    /**
     * Method getSaasContratos
     */
    public function getSaasContratos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('account_id', '=', $this->id));
        return SaasContrato::getObjects( $criteria );
    }
    /**
     * Method getSaasNotaFiscalServicos
     */
    public function getSaasNotaFiscalServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('account_id', '=', $this->id));
        return SaasNotaFiscalServico::getObjects( $criteria );
    }

    public function set_saas_pagamento_account_to_string($saas_pagamento_account_to_string)
    {
        if(is_array($saas_pagamento_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_pagamento_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_pagamento_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_account_to_string = $saas_pagamento_account_to_string;
        }

        $this->vdata['saas_pagamento_account_to_string'] = $this->saas_pagamento_account_to_string;
    }

    public function get_saas_pagamento_account_to_string()
    {
        if(!empty($this->saas_pagamento_account_to_string))
        {
            return $this->saas_pagamento_account_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_status_pagamento_to_string($saas_pagamento_saas_status_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_status_pagamento_to_string))
        {
            $values = SaasStatusPagamento::where('id', 'in', $saas_pagamento_saas_status_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_status_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_status_pagamento_to_string = $saas_pagamento_saas_status_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_status_pagamento_to_string'] = $this->saas_pagamento_saas_status_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_status_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_status_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_status_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('saas_status_pagamento_id','{saas_status_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_contrato_to_string($saas_pagamento_saas_contrato_to_string)
    {
        if(is_array($saas_pagamento_saas_contrato_to_string))
        {
            $values = SaasContrato::where('id', 'in', $saas_pagamento_saas_contrato_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_contrato_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_contrato_to_string = $saas_pagamento_saas_contrato_to_string;
        }

        $this->vdata['saas_pagamento_saas_contrato_to_string'] = $this->saas_pagamento_saas_contrato_to_string;
    }

    public function get_saas_pagamento_saas_contrato_to_string()
    {
        if(!empty($this->saas_pagamento_saas_contrato_to_string))
        {
            return $this->saas_pagamento_saas_contrato_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('saas_contrato_id','{saas_contrato->id}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_servico_to_string($saas_pagamento_saas_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_pagamento_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_servico_to_string = $saas_pagamento_saas_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_servico_to_string'] = $this->saas_pagamento_saas_servico_to_string;
    }

    public function get_saas_pagamento_saas_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_servico_to_string))
        {
            return $this->saas_pagamento_saas_servico_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_forma_pagamento_to_string($saas_pagamento_saas_forma_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_forma_pagamento_to_string))
        {
            $values = SaasFormaPagamento::where('id', 'in', $saas_pagamento_saas_forma_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_forma_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_forma_pagamento_to_string = $saas_pagamento_saas_forma_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_forma_pagamento_to_string'] = $this->saas_pagamento_saas_forma_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_forma_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_forma_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_forma_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('saas_forma_pagamento_id','{saas_forma_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_gateway_pagamento_to_string($saas_pagamento_saas_gateway_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_gateway_pagamento_to_string))
        {
            $values = SaasGatewayPagamento::where('id', 'in', $saas_pagamento_saas_gateway_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_gateway_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_gateway_pagamento_to_string = $saas_pagamento_saas_gateway_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_gateway_pagamento_to_string'] = $this->saas_pagamento_saas_gateway_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_gateway_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_gateway_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_gateway_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('saas_gateway_pagamento_id','{saas_gateway_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_nota_fiscal_servico_to_string($saas_pagamento_saas_nota_fiscal_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            $values = SaasNotaFiscalServico::where('id', 'in', $saas_pagamento_saas_nota_fiscal_servico_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = $saas_pagamento_saas_nota_fiscal_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_nota_fiscal_servico_to_string'] = $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
    }

    public function get_saas_pagamento_saas_nota_fiscal_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            return $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
        }
    
        $values = SaasPagamento::where('account_id', '=', $this->id)->getIndexedArray('saas_nota_fiscal_servico_id','{saas_nota_fiscal_servico->id}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_saas_plano_valor_to_string($saas_contrato_saas_plano_valor_to_string)
    {
        if(is_array($saas_contrato_saas_plano_valor_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_contrato_saas_plano_valor_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_contrato_saas_plano_valor_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_saas_plano_valor_to_string = $saas_contrato_saas_plano_valor_to_string;
        }

        $this->vdata['saas_contrato_saas_plano_valor_to_string'] = $this->saas_contrato_saas_plano_valor_to_string;
    }

    public function get_saas_contrato_saas_plano_valor_to_string()
    {
        if(!empty($this->saas_contrato_saas_plano_valor_to_string))
        {
            return $this->saas_contrato_saas_plano_valor_to_string;
        }
    
        $values = SaasContrato::where('account_id', '=', $this->id)->getIndexedArray('saas_plano_valor_id','{saas_plano_valor->nome}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_account_to_string($saas_contrato_account_to_string)
    {
        if(is_array($saas_contrato_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_contrato_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_contrato_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_account_to_string = $saas_contrato_account_to_string;
        }

        $this->vdata['saas_contrato_account_to_string'] = $this->saas_contrato_account_to_string;
    }

    public function get_saas_contrato_account_to_string()
    {
        if(!empty($this->saas_contrato_account_to_string))
        {
            return $this->saas_contrato_account_to_string;
        }
    
        $values = SaasContrato::where('account_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_saas_contrato_saas_contrato_status_to_string($saas_contrato_saas_contrato_status_to_string)
    {
        if(is_array($saas_contrato_saas_contrato_status_to_string))
        {
            $values = SaasContratoStatus::where('id', 'in', $saas_contrato_saas_contrato_status_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_contrato_saas_contrato_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_contrato_saas_contrato_status_to_string = $saas_contrato_saas_contrato_status_to_string;
        }

        $this->vdata['saas_contrato_saas_contrato_status_to_string'] = $this->saas_contrato_saas_contrato_status_to_string;
    }

    public function get_saas_contrato_saas_contrato_status_to_string()
    {
        if(!empty($this->saas_contrato_saas_contrato_status_to_string))
        {
            return $this->saas_contrato_saas_contrato_status_to_string;
        }
    
        $values = SaasContrato::where('account_id', '=', $this->id)->getIndexedArray('saas_contrato_status_id','{saas_contrato_status->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_pagamento_to_string($saas_nota_fiscal_servico_saas_pagamento_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_pagamento_to_string))
        {
            $values = SaasPagamento::where('id', 'in', $saas_nota_fiscal_servico_saas_pagamento_to_string)->getIndexedArray('id', 'id');
            $this->saas_nota_fiscal_servico_saas_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_pagamento_to_string = $saas_nota_fiscal_servico_saas_pagamento_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_pagamento_to_string'] = $this->saas_nota_fiscal_servico_saas_pagamento_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_pagamento_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_pagamento_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_pagamento_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('account_id', '=', $this->id)->getIndexedArray('saas_pagamento_id','{saas_pagamento->id}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_plano_valor_to_string($saas_nota_fiscal_servico_saas_plano_valor_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_plano_valor_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_nota_fiscal_servico_saas_plano_valor_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_saas_plano_valor_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_plano_valor_to_string = $saas_nota_fiscal_servico_saas_plano_valor_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_plano_valor_to_string'] = $this->saas_nota_fiscal_servico_saas_plano_valor_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_plano_valor_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_plano_valor_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_plano_valor_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('account_id', '=', $this->id)->getIndexedArray('saas_plano_valor_id','{saas_plano_valor->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_servico_to_string($saas_nota_fiscal_servico_saas_servico_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_nota_fiscal_servico_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_servico_to_string = $saas_nota_fiscal_servico_saas_servico_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_servico_to_string'] = $this->saas_nota_fiscal_servico_saas_servico_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_servico_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_servico_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_servico_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('account_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_cidade_tomador_to_string($saas_nota_fiscal_servico_cidade_tomador_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_cidade_tomador_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_cidade_tomador_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_cidade_tomador_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_cidade_tomador_to_string = $saas_nota_fiscal_servico_cidade_tomador_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_cidade_tomador_to_string'] = $this->saas_nota_fiscal_servico_cidade_tomador_to_string;
    }

    public function get_saas_nota_fiscal_servico_cidade_tomador_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_cidade_tomador_to_string))
        {
            return $this->saas_nota_fiscal_servico_cidade_tomador_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('account_id', '=', $this->id)->getIndexedArray('cidade_tomador_id','{cidade_tomador->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_cidade_prestador_to_string($saas_nota_fiscal_servico_cidade_prestador_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_cidade_prestador_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_cidade_prestador_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_cidade_prestador_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_cidade_prestador_to_string = $saas_nota_fiscal_servico_cidade_prestador_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_cidade_prestador_to_string'] = $this->saas_nota_fiscal_servico_cidade_prestador_to_string;
    }

    public function get_saas_nota_fiscal_servico_cidade_prestador_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_cidade_prestador_to_string))
        {
            return $this->saas_nota_fiscal_servico_cidade_prestador_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('account_id', '=', $this->id)->getIndexedArray('cidade_prestador_id','{cidade_prestador->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_municipio_prestacao_servico_to_string($saas_nota_fiscal_servico_municipio_prestacao_servico_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_municipio_prestacao_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string = $saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_municipio_prestacao_servico_to_string'] = $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
    }

    public function get_saas_nota_fiscal_servico_municipio_prestacao_servico_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            return $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('account_id', '=', $this->id)->getIndexedArray('municipio_prestacao_servico_id','{municipio_prestacao_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_nota_fiscal_status_to_string($saas_nota_fiscal_servico_nota_fiscal_status_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            $values = NotaFiscalStatus::where('id', 'in', $saas_nota_fiscal_servico_nota_fiscal_status_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string = $saas_nota_fiscal_servico_nota_fiscal_status_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_nota_fiscal_status_to_string'] = $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string;
    }

    public function get_saas_nota_fiscal_servico_nota_fiscal_status_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            return $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('account_id', '=', $this->id)->getIndexedArray('nota_fiscal_status_id','{nota_fiscal_status->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_account_to_string($saas_nota_fiscal_servico_account_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_nota_fiscal_servico_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_nota_fiscal_servico_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_account_to_string = $saas_nota_fiscal_servico_account_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_account_to_string'] = $this->saas_nota_fiscal_servico_account_to_string;
    }

    public function get_saas_nota_fiscal_servico_account_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_account_to_string))
        {
            return $this->saas_nota_fiscal_servico_account_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('account_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function get_contrato()
    {
        $configs = SaasConfiguracaoService::getConfiguracoes();
    
        $criteria = new TCriteria;
        $criteria->add(new TFilter('account_id', '=', $this->id));
        $criteria->add(new TFilter('saas_contrato_status_id', '=', SaasContratoStatus::ATIVO));
        $criteria->add(new TFilter('saas_plano_valor_id', '!=', $configs->saas_plano_valor_trial_id));
        $criteria->add(new TFilter('data_final', '>=', date('Y-m-d')));
        $criteria->setProperty('order', 'data_final desc');

        $contrato = new TRepository('SaasContrato');
        $contrato->setCriteria($criteria);
        $contrato = $contrato->first();
    
        if(!$contrato)
        {
            $criteria = new TCriteria;
            $criteria->add(new TFilter('account_id', '=', $this->id));
            $criteria->add(new TFilter('saas_contrato_status_id', '=', SaasContratoStatus::ATIVO));
            $criteria->add(new TFilter('saas_plano_valor_id', '=', $configs->saas_plano_valor_trial_id));
            $criteria->add(new TFilter('data_final', '>=', date('Y-m-d')));
            $criteria->setProperty('order', 'data_final desc');

            $contrato = new TRepository('SaasContrato');
            $contrato->setCriteria($criteria);
            $contrato = $contrato->first();
        }
    
        if(!$contrato)
        {
            $criteria = new TCriteria;
            $criteria->add(new TFilter('account_id', '=', $this->id));
            $criteria->add(new TFilter('saas_contrato_status_id', '!=', SaasContratoStatus::AGUARDANDO_PAGAMENTO));
            $criteria->setProperty('order', 'data_final desc');

            $contrato = new TRepository('SaasContrato');
            $contrato->setCriteria($criteria);
            $contrato = $contrato->first();
        }
    
        return $contrato;
    }
                                                            
}

