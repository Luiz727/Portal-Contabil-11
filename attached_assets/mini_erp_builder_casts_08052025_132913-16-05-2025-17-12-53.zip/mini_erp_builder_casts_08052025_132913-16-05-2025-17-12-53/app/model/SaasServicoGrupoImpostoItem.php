<?php

class SaasServicoGrupoImpostoItem extends TRecord
{
    const TABLENAME  = 'saas_servico_grupo_imposto_item';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SaasServicoGrupoImposto $saas_servico_grupo_imposto;
    private SaasImposto $saas_imposto;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('saas_servico_grupo_imposto_id');
        parent::addAttribute('saas_imposto_id');
        parent::addAttribute('aliquota');
            
    }

    /**
     * Method set_saas_servico_grupo_imposto
     * Sample of usage: $var->saas_servico_grupo_imposto = $object;
     * @param $object Instance of SaasServicoGrupoImposto
     */
    public function set_saas_servico_grupo_imposto(SaasServicoGrupoImposto $object)
    {
        $this->saas_servico_grupo_imposto = $object;
        $this->saas_servico_grupo_imposto_id = $object->id;
    }

    /**
     * Method get_saas_servico_grupo_imposto
     * Sample of usage: $var->saas_servico_grupo_imposto->attribute;
     * @returns SaasServicoGrupoImposto instance
     */
    public function get_saas_servico_grupo_imposto()
    {
    
        // loads the associated object
        if (empty($this->saas_servico_grupo_imposto))
            $this->saas_servico_grupo_imposto = new SaasServicoGrupoImposto($this->saas_servico_grupo_imposto_id);
    
        // returns the associated object
        return $this->saas_servico_grupo_imposto;
    }
    /**
     * Method set_saas_imposto
     * Sample of usage: $var->saas_imposto = $object;
     * @param $object Instance of SaasImposto
     */
    public function set_saas_imposto(SaasImposto $object)
    {
        $this->saas_imposto = $object;
        $this->saas_imposto_id = $object->id;
    }

    /**
     * Method get_saas_imposto
     * Sample of usage: $var->saas_imposto->attribute;
     * @returns SaasImposto instance
     */
    public function get_saas_imposto()
    {
    
        // loads the associated object
        if (empty($this->saas_imposto))
            $this->saas_imposto = new SaasImposto($this->saas_imposto_id);
    
        // returns the associated object
        return $this->saas_imposto;
    }

    
}

