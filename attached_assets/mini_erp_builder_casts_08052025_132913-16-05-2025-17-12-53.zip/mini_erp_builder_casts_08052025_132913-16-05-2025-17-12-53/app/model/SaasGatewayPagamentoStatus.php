<?php

class SaasGatewayPagamentoStatus extends TRecord
{
    const TABLENAME  = 'saas_gateway_pagamento_status';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SaasGatewayPagamento $saas_gateway_pagamento;
    private SaasStatusPagamento $saas_status_pagamento;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('saas_gateway_pagamento_id');
        parent::addAttribute('saas_status_pagamento_id');
        parent::addAttribute('codigo');
    
    }

    /**
     * Method set_saas_gateway_pagamento
     * Sample of usage: $var->saas_gateway_pagamento = $object;
     * @param $object Instance of SaasGatewayPagamento
     */
    public function set_saas_gateway_pagamento(SaasGatewayPagamento $object)
    {
        $this->saas_gateway_pagamento = $object;
        $this->saas_gateway_pagamento_id = $object->id;
    }

    /**
     * Method get_saas_gateway_pagamento
     * Sample of usage: $var->saas_gateway_pagamento->attribute;
     * @returns SaasGatewayPagamento instance
     */
    public function get_saas_gateway_pagamento()
    {
    
        // loads the associated object
        if (empty($this->saas_gateway_pagamento))
            $this->saas_gateway_pagamento = new SaasGatewayPagamento($this->saas_gateway_pagamento_id);
    
        // returns the associated object
        return $this->saas_gateway_pagamento;
    }
    /**
     * Method set_saas_status_pagamento
     * Sample of usage: $var->saas_status_pagamento = $object;
     * @param $object Instance of SaasStatusPagamento
     */
    public function set_saas_status_pagamento(SaasStatusPagamento $object)
    {
        $this->saas_status_pagamento = $object;
        $this->saas_status_pagamento_id = $object->id;
    }

    /**
     * Method get_saas_status_pagamento
     * Sample of usage: $var->saas_status_pagamento->attribute;
     * @returns SaasStatusPagamento instance
     */
    public function get_saas_status_pagamento()
    {
    
        // loads the associated object
        if (empty($this->saas_status_pagamento))
            $this->saas_status_pagamento = new SaasStatusPagamento($this->saas_status_pagamento_id);
    
        // returns the associated object
        return $this->saas_status_pagamento;
    }

    public static function getSaasStatusPagamento($gateway_id, $status)
    {
        $gs = self::where('saas_gateway_pagamento_id', '=', $gateway_id)->where('codigo', '=', $status)->first();
    
        if ($gs)
        {
            return $gs->get_saas_status_pagamento();
        }
    
        return null;
    }
    
}

