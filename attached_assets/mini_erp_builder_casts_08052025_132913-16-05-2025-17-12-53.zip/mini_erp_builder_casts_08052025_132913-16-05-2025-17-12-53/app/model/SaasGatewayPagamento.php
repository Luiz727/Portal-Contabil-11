<?php

class SaasGatewayPagamento extends TRecord
{
    const TABLENAME  = 'saas_gateway_pagamento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    const BANCO_INTER = '1';
    const MERCADO_PAGO = '2';

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('nome');
        parent::addAttribute('ativo');
        parent::addAttribute('public_key');
        parent::addAttribute('access_token');
        parent::addAttribute('client_secret');
        parent::addAttribute('client_id');
        parent::addAttribute('oauth_token');
        parent::addAttribute('oauth_token_created_at');
        parent::addAttribute('certificado_crt');
        parent::addAttribute('certificado_key');
        parent::addAttribute('webhook_url');
        parent::addAttribute('webhook_certificado_cert');
        parent::addAttribute('fl_homologacao');
            
    }

    /**
     * Method getSaasPagamentos
     */
    public function getSaasPagamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_gateway_pagamento_id', '=', $this->id));
        return SaasPagamento::getObjects( $criteria );
    }
    /**
     * Method getSaasGatewayFormaPagamentos
     */
    public function getSaasGatewayFormaPagamentos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_gateway_pagamento_id', '=', $this->id));
        return SaasGatewayFormaPagamento::getObjects( $criteria );
    }
    /**
     * Method getSaasGatewayPagamentoStatuss
     */
    public function getSaasGatewayPagamentoStatuss()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_gateway_pagamento_id', '=', $this->id));
        return SaasGatewayPagamentoStatus::getObjects( $criteria );
    }
    /**
     * Method getWebhookLogs
     */
    public function getWebhookLogs()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('gateway_pagamento_id', '=', $this->id));
        return WebhookLog::getObjects( $criteria );
    }

    public function set_saas_pagamento_account_to_string($saas_pagamento_account_to_string)
    {
        if(is_array($saas_pagamento_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_pagamento_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_pagamento_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_account_to_string = $saas_pagamento_account_to_string;
        }

        $this->vdata['saas_pagamento_account_to_string'] = $this->saas_pagamento_account_to_string;
    }

    public function get_saas_pagamento_account_to_string()
    {
        if(!empty($this->saas_pagamento_account_to_string))
        {
            return $this->saas_pagamento_account_to_string;
        }
    
        $values = SaasPagamento::where('saas_gateway_pagamento_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_status_pagamento_to_string($saas_pagamento_saas_status_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_status_pagamento_to_string))
        {
            $values = SaasStatusPagamento::where('id', 'in', $saas_pagamento_saas_status_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_status_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_status_pagamento_to_string = $saas_pagamento_saas_status_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_status_pagamento_to_string'] = $this->saas_pagamento_saas_status_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_status_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_status_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_status_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_gateway_pagamento_id', '=', $this->id)->getIndexedArray('saas_status_pagamento_id','{saas_status_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_contrato_to_string($saas_pagamento_saas_contrato_to_string)
    {
        if(is_array($saas_pagamento_saas_contrato_to_string))
        {
            $values = SaasContrato::where('id', 'in', $saas_pagamento_saas_contrato_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_contrato_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_contrato_to_string = $saas_pagamento_saas_contrato_to_string;
        }

        $this->vdata['saas_pagamento_saas_contrato_to_string'] = $this->saas_pagamento_saas_contrato_to_string;
    }

    public function get_saas_pagamento_saas_contrato_to_string()
    {
        if(!empty($this->saas_pagamento_saas_contrato_to_string))
        {
            return $this->saas_pagamento_saas_contrato_to_string;
        }
    
        $values = SaasPagamento::where('saas_gateway_pagamento_id', '=', $this->id)->getIndexedArray('saas_contrato_id','{saas_contrato->id}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_servico_to_string($saas_pagamento_saas_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_pagamento_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_servico_to_string = $saas_pagamento_saas_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_servico_to_string'] = $this->saas_pagamento_saas_servico_to_string;
    }

    public function get_saas_pagamento_saas_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_servico_to_string))
        {
            return $this->saas_pagamento_saas_servico_to_string;
        }
    
        $values = SaasPagamento::where('saas_gateway_pagamento_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_forma_pagamento_to_string($saas_pagamento_saas_forma_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_forma_pagamento_to_string))
        {
            $values = SaasFormaPagamento::where('id', 'in', $saas_pagamento_saas_forma_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_forma_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_forma_pagamento_to_string = $saas_pagamento_saas_forma_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_forma_pagamento_to_string'] = $this->saas_pagamento_saas_forma_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_forma_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_forma_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_forma_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_gateway_pagamento_id', '=', $this->id)->getIndexedArray('saas_forma_pagamento_id','{saas_forma_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_gateway_pagamento_to_string($saas_pagamento_saas_gateway_pagamento_to_string)
    {
        if(is_array($saas_pagamento_saas_gateway_pagamento_to_string))
        {
            $values = SaasGatewayPagamento::where('id', 'in', $saas_pagamento_saas_gateway_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_pagamento_saas_gateway_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_gateway_pagamento_to_string = $saas_pagamento_saas_gateway_pagamento_to_string;
        }

        $this->vdata['saas_pagamento_saas_gateway_pagamento_to_string'] = $this->saas_pagamento_saas_gateway_pagamento_to_string;
    }

    public function get_saas_pagamento_saas_gateway_pagamento_to_string()
    {
        if(!empty($this->saas_pagamento_saas_gateway_pagamento_to_string))
        {
            return $this->saas_pagamento_saas_gateway_pagamento_to_string;
        }
    
        $values = SaasPagamento::where('saas_gateway_pagamento_id', '=', $this->id)->getIndexedArray('saas_gateway_pagamento_id','{saas_gateway_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_pagamento_saas_nota_fiscal_servico_to_string($saas_pagamento_saas_nota_fiscal_servico_to_string)
    {
        if(is_array($saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            $values = SaasNotaFiscalServico::where('id', 'in', $saas_pagamento_saas_nota_fiscal_servico_to_string)->getIndexedArray('id', 'id');
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_pagamento_saas_nota_fiscal_servico_to_string = $saas_pagamento_saas_nota_fiscal_servico_to_string;
        }

        $this->vdata['saas_pagamento_saas_nota_fiscal_servico_to_string'] = $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
    }

    public function get_saas_pagamento_saas_nota_fiscal_servico_to_string()
    {
        if(!empty($this->saas_pagamento_saas_nota_fiscal_servico_to_string))
        {
            return $this->saas_pagamento_saas_nota_fiscal_servico_to_string;
        }
    
        $values = SaasPagamento::where('saas_gateway_pagamento_id', '=', $this->id)->getIndexedArray('saas_nota_fiscal_servico_id','{saas_nota_fiscal_servico->id}');
        return implode(', ', $values);
    }

    public function set_saas_gateway_forma_pagamento_saas_forma_pagamento_to_string($saas_gateway_forma_pagamento_saas_forma_pagamento_to_string)
    {
        if(is_array($saas_gateway_forma_pagamento_saas_forma_pagamento_to_string))
        {
            $values = SaasFormaPagamento::where('id', 'in', $saas_gateway_forma_pagamento_saas_forma_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_gateway_forma_pagamento_saas_forma_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_gateway_forma_pagamento_saas_forma_pagamento_to_string = $saas_gateway_forma_pagamento_saas_forma_pagamento_to_string;
        }

        $this->vdata['saas_gateway_forma_pagamento_saas_forma_pagamento_to_string'] = $this->saas_gateway_forma_pagamento_saas_forma_pagamento_to_string;
    }

    public function get_saas_gateway_forma_pagamento_saas_forma_pagamento_to_string()
    {
        if(!empty($this->saas_gateway_forma_pagamento_saas_forma_pagamento_to_string))
        {
            return $this->saas_gateway_forma_pagamento_saas_forma_pagamento_to_string;
        }
    
        $values = SaasGatewayFormaPagamento::where('saas_gateway_pagamento_id', '=', $this->id)->getIndexedArray('saas_forma_pagamento_id','{saas_forma_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_gateway_forma_pagamento_saas_gateway_pagamento_to_string($saas_gateway_forma_pagamento_saas_gateway_pagamento_to_string)
    {
        if(is_array($saas_gateway_forma_pagamento_saas_gateway_pagamento_to_string))
        {
            $values = SaasGatewayPagamento::where('id', 'in', $saas_gateway_forma_pagamento_saas_gateway_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_gateway_forma_pagamento_saas_gateway_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_gateway_forma_pagamento_saas_gateway_pagamento_to_string = $saas_gateway_forma_pagamento_saas_gateway_pagamento_to_string;
        }

        $this->vdata['saas_gateway_forma_pagamento_saas_gateway_pagamento_to_string'] = $this->saas_gateway_forma_pagamento_saas_gateway_pagamento_to_string;
    }

    public function get_saas_gateway_forma_pagamento_saas_gateway_pagamento_to_string()
    {
        if(!empty($this->saas_gateway_forma_pagamento_saas_gateway_pagamento_to_string))
        {
            return $this->saas_gateway_forma_pagamento_saas_gateway_pagamento_to_string;
        }
    
        $values = SaasGatewayFormaPagamento::where('saas_gateway_pagamento_id', '=', $this->id)->getIndexedArray('saas_gateway_pagamento_id','{saas_gateway_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_gateway_pagamento_status_saas_gateway_pagamento_to_string($saas_gateway_pagamento_status_saas_gateway_pagamento_to_string)
    {
        if(is_array($saas_gateway_pagamento_status_saas_gateway_pagamento_to_string))
        {
            $values = SaasGatewayPagamento::where('id', 'in', $saas_gateway_pagamento_status_saas_gateway_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_gateway_pagamento_status_saas_gateway_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_gateway_pagamento_status_saas_gateway_pagamento_to_string = $saas_gateway_pagamento_status_saas_gateway_pagamento_to_string;
        }

        $this->vdata['saas_gateway_pagamento_status_saas_gateway_pagamento_to_string'] = $this->saas_gateway_pagamento_status_saas_gateway_pagamento_to_string;
    }

    public function get_saas_gateway_pagamento_status_saas_gateway_pagamento_to_string()
    {
        if(!empty($this->saas_gateway_pagamento_status_saas_gateway_pagamento_to_string))
        {
            return $this->saas_gateway_pagamento_status_saas_gateway_pagamento_to_string;
        }
    
        $values = SaasGatewayPagamentoStatus::where('saas_gateway_pagamento_id', '=', $this->id)->getIndexedArray('saas_gateway_pagamento_id','{saas_gateway_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_saas_gateway_pagamento_status_saas_status_pagamento_to_string($saas_gateway_pagamento_status_saas_status_pagamento_to_string)
    {
        if(is_array($saas_gateway_pagamento_status_saas_status_pagamento_to_string))
        {
            $values = SaasStatusPagamento::where('id', 'in', $saas_gateway_pagamento_status_saas_status_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_gateway_pagamento_status_saas_status_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_gateway_pagamento_status_saas_status_pagamento_to_string = $saas_gateway_pagamento_status_saas_status_pagamento_to_string;
        }

        $this->vdata['saas_gateway_pagamento_status_saas_status_pagamento_to_string'] = $this->saas_gateway_pagamento_status_saas_status_pagamento_to_string;
    }

    public function get_saas_gateway_pagamento_status_saas_status_pagamento_to_string()
    {
        if(!empty($this->saas_gateway_pagamento_status_saas_status_pagamento_to_string))
        {
            return $this->saas_gateway_pagamento_status_saas_status_pagamento_to_string;
        }
    
        $values = SaasGatewayPagamentoStatus::where('saas_gateway_pagamento_id', '=', $this->id)->getIndexedArray('saas_status_pagamento_id','{saas_status_pagamento->nome}');
        return implode(', ', $values);
    }

    public function set_webhook_log_gateway_pagamento_to_string($webhook_log_gateway_pagamento_to_string)
    {
        if(is_array($webhook_log_gateway_pagamento_to_string))
        {
            $values = SaasGatewayPagamento::where('id', 'in', $webhook_log_gateway_pagamento_to_string)->getIndexedArray('nome', 'nome');
            $this->webhook_log_gateway_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->webhook_log_gateway_pagamento_to_string = $webhook_log_gateway_pagamento_to_string;
        }

        $this->vdata['webhook_log_gateway_pagamento_to_string'] = $this->webhook_log_gateway_pagamento_to_string;
    }

    public function get_webhook_log_gateway_pagamento_to_string()
    {
        if(!empty($this->webhook_log_gateway_pagamento_to_string))
        {
            return $this->webhook_log_gateway_pagamento_to_string;
        }
    
        $values = WebhookLog::where('gateway_pagamento_id', '=', $this->id)->getIndexedArray('gateway_pagamento_id','{gateway_pagamento->nome}');
        return implode(', ', $values);
    }

    
}

