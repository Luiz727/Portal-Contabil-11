<?php

class SaasImposto extends TRecord
{
    const TABLENAME  = 'saas_imposto';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    const ISS = '1';
    const PIS = '2';
    const COFINS = '3';
    const INSS = '4';
    const IRRF = '5';
    const CSLL = '6';

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('nome');
        parent::addAttribute('codigo');
            
    }

    /**
     * Method getSaasServicoGrupoImpostoItems
     */
    public function getSaasServicoGrupoImpostoItems()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_imposto_id', '=', $this->id));
        return SaasServicoGrupoImpostoItem::getObjects( $criteria );
    }

    public function set_saas_servico_grupo_imposto_item_saas_servico_grupo_imposto_to_string($saas_servico_grupo_imposto_item_saas_servico_grupo_imposto_to_string)
    {
        if(is_array($saas_servico_grupo_imposto_item_saas_servico_grupo_imposto_to_string))
        {
            $values = SaasServicoGrupoImposto::where('id', 'in', $saas_servico_grupo_imposto_item_saas_servico_grupo_imposto_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_servico_grupo_imposto_item_saas_servico_grupo_imposto_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_servico_grupo_imposto_item_saas_servico_grupo_imposto_to_string = $saas_servico_grupo_imposto_item_saas_servico_grupo_imposto_to_string;
        }

        $this->vdata['saas_servico_grupo_imposto_item_saas_servico_grupo_imposto_to_string'] = $this->saas_servico_grupo_imposto_item_saas_servico_grupo_imposto_to_string;
    }

    public function get_saas_servico_grupo_imposto_item_saas_servico_grupo_imposto_to_string()
    {
        if(!empty($this->saas_servico_grupo_imposto_item_saas_servico_grupo_imposto_to_string))
        {
            return $this->saas_servico_grupo_imposto_item_saas_servico_grupo_imposto_to_string;
        }
    
        $values = SaasServicoGrupoImpostoItem::where('saas_imposto_id', '=', $this->id)->getIndexedArray('saas_servico_grupo_imposto_id','{saas_servico_grupo_imposto->nome}');
        return implode(', ', $values);
    }

    public function set_saas_servico_grupo_imposto_item_saas_imposto_to_string($saas_servico_grupo_imposto_item_saas_imposto_to_string)
    {
        if(is_array($saas_servico_grupo_imposto_item_saas_imposto_to_string))
        {
            $values = SaasImposto::where('id', 'in', $saas_servico_grupo_imposto_item_saas_imposto_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_servico_grupo_imposto_item_saas_imposto_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_servico_grupo_imposto_item_saas_imposto_to_string = $saas_servico_grupo_imposto_item_saas_imposto_to_string;
        }

        $this->vdata['saas_servico_grupo_imposto_item_saas_imposto_to_string'] = $this->saas_servico_grupo_imposto_item_saas_imposto_to_string;
    }

    public function get_saas_servico_grupo_imposto_item_saas_imposto_to_string()
    {
        if(!empty($this->saas_servico_grupo_imposto_item_saas_imposto_to_string))
        {
            return $this->saas_servico_grupo_imposto_item_saas_imposto_to_string;
        }
    
        $values = SaasServicoGrupoImpostoItem::where('saas_imposto_id', '=', $this->id)->getIndexedArray('saas_imposto_id','{saas_imposto->nome}');
        return implode(', ', $values);
    }

    
}

