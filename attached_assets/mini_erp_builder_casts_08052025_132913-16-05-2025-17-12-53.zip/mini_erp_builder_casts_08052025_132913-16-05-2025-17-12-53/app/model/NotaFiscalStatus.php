<?php

class NotaFiscalStatus extends TRecord
{
    const TABLENAME  = 'nota_fiscal_status';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    const PENDENTE = '1';
    const ENVIADA = '2';
    const AUTORIZADA = '3';
    const CANCELADA = '4';
    const REJEITADA = '5';
    const EM_PROCESSAMENTO = '6';

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('nome');
        parent::addAttribute('cor');
    
    }

    /**
     * Method getSaasNotaFiscalServicos
     */
    public function getSaasNotaFiscalServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('nota_fiscal_status_id', '=', $this->id));
        return SaasNotaFiscalServico::getObjects( $criteria );
    }

    public function set_saas_nota_fiscal_servico_saas_pagamento_to_string($saas_nota_fiscal_servico_saas_pagamento_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_pagamento_to_string))
        {
            $values = SaasPagamento::where('id', 'in', $saas_nota_fiscal_servico_saas_pagamento_to_string)->getIndexedArray('id', 'id');
            $this->saas_nota_fiscal_servico_saas_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_pagamento_to_string = $saas_nota_fiscal_servico_saas_pagamento_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_pagamento_to_string'] = $this->saas_nota_fiscal_servico_saas_pagamento_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_pagamento_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_pagamento_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_pagamento_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('nota_fiscal_status_id', '=', $this->id)->getIndexedArray('saas_pagamento_id','{saas_pagamento->id}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_plano_valor_to_string($saas_nota_fiscal_servico_saas_plano_valor_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_plano_valor_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_nota_fiscal_servico_saas_plano_valor_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_saas_plano_valor_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_plano_valor_to_string = $saas_nota_fiscal_servico_saas_plano_valor_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_plano_valor_to_string'] = $this->saas_nota_fiscal_servico_saas_plano_valor_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_plano_valor_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_plano_valor_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_plano_valor_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('nota_fiscal_status_id', '=', $this->id)->getIndexedArray('saas_plano_valor_id','{saas_plano_valor->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_servico_to_string($saas_nota_fiscal_servico_saas_servico_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_nota_fiscal_servico_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_servico_to_string = $saas_nota_fiscal_servico_saas_servico_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_servico_to_string'] = $this->saas_nota_fiscal_servico_saas_servico_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_servico_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_servico_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_servico_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('nota_fiscal_status_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_cidade_tomador_to_string($saas_nota_fiscal_servico_cidade_tomador_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_cidade_tomador_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_cidade_tomador_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_cidade_tomador_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_cidade_tomador_to_string = $saas_nota_fiscal_servico_cidade_tomador_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_cidade_tomador_to_string'] = $this->saas_nota_fiscal_servico_cidade_tomador_to_string;
    }

    public function get_saas_nota_fiscal_servico_cidade_tomador_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_cidade_tomador_to_string))
        {
            return $this->saas_nota_fiscal_servico_cidade_tomador_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('nota_fiscal_status_id', '=', $this->id)->getIndexedArray('cidade_tomador_id','{cidade_tomador->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_cidade_prestador_to_string($saas_nota_fiscal_servico_cidade_prestador_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_cidade_prestador_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_cidade_prestador_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_cidade_prestador_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_cidade_prestador_to_string = $saas_nota_fiscal_servico_cidade_prestador_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_cidade_prestador_to_string'] = $this->saas_nota_fiscal_servico_cidade_prestador_to_string;
    }

    public function get_saas_nota_fiscal_servico_cidade_prestador_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_cidade_prestador_to_string))
        {
            return $this->saas_nota_fiscal_servico_cidade_prestador_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('nota_fiscal_status_id', '=', $this->id)->getIndexedArray('cidade_prestador_id','{cidade_prestador->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_municipio_prestacao_servico_to_string($saas_nota_fiscal_servico_municipio_prestacao_servico_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_municipio_prestacao_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string = $saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_municipio_prestacao_servico_to_string'] = $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
    }

    public function get_saas_nota_fiscal_servico_municipio_prestacao_servico_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            return $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('nota_fiscal_status_id', '=', $this->id)->getIndexedArray('municipio_prestacao_servico_id','{municipio_prestacao_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_nota_fiscal_status_to_string($saas_nota_fiscal_servico_nota_fiscal_status_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            $values = NotaFiscalStatus::where('id', 'in', $saas_nota_fiscal_servico_nota_fiscal_status_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string = $saas_nota_fiscal_servico_nota_fiscal_status_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_nota_fiscal_status_to_string'] = $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string;
    }

    public function get_saas_nota_fiscal_servico_nota_fiscal_status_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            return $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('nota_fiscal_status_id', '=', $this->id)->getIndexedArray('nota_fiscal_status_id','{nota_fiscal_status->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_account_to_string($saas_nota_fiscal_servico_account_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_nota_fiscal_servico_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_nota_fiscal_servico_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_account_to_string = $saas_nota_fiscal_servico_account_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_account_to_string'] = $this->saas_nota_fiscal_servico_account_to_string;
    }

    public function get_saas_nota_fiscal_servico_account_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_account_to_string))
        {
            return $this->saas_nota_fiscal_servico_account_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('nota_fiscal_status_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public static function getStatusTransmissao()
    {
        return [self::PENDENTE, self::REJEITADA];
    }
    
}

