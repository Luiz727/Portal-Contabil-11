<?php

class SaasPagamento extends TRecord
{
    const TABLENAME  = 'saas_pagamento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private SaasStatusPagamento $saas_status_pagamento;
    private SaasContrato $saas_contrato;
    private SaasFormaPagamento $saas_forma_pagamento;
    private SaasGatewayPagamento $saas_gateway_pagamento;
    private SaasServico $saas_servico;
    private Account $account;
    private SaasNotaFiscalServico $saas_nota_fiscal_servico;

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
    
    
        $this->addManagePermission('PermissaoService::canManageRecordByAccount');
    
                            
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('account_id');
        parent::addAttribute('saas_status_pagamento_id');
        parent::addAttribute('saas_contrato_id');
        parent::addAttribute('saas_servico_id');
        parent::addAttribute('saas_forma_pagamento_id');
        parent::addAttribute('saas_gateway_pagamento_id');
        parent::addAttribute('saas_nota_fiscal_servico_id');
        parent::addAttribute('valor');
        parent::addAttribute('data_compra');
        parent::addAttribute('data_vencimento');
        parent::addAttribute('data_pagamento');
        parent::addAttribute('dados_gateway');
        parent::addAttribute('id_gateway');
        parent::addAttribute('payment_id');
        parent::addAttribute('link_gateway');
        parent::addAttribute('mes_compra');
        parent::addAttribute('ano_compra');
        parent::addAttribute('ano_pagamento');
        parent::addAttribute('mes_pagamento');
        parent::addAttribute('mes_ano_pagamento');
        parent::addAttribute('mes_ano_compra');
        parent::addAttribute('renovacao');
    
    }

    /**
     * Method set_saas_status_pagamento
     * Sample of usage: $var->saas_status_pagamento = $object;
     * @param $object Instance of SaasStatusPagamento
     */
    public function set_saas_status_pagamento(SaasStatusPagamento $object)
    {
        $this->saas_status_pagamento = $object;
        $this->saas_status_pagamento_id = $object->id;
    }

    /**
     * Method get_saas_status_pagamento
     * Sample of usage: $var->saas_status_pagamento->attribute;
     * @returns SaasStatusPagamento instance
     */
    public function get_saas_status_pagamento()
    {
    
        // loads the associated object
        if (empty($this->saas_status_pagamento))
            $this->saas_status_pagamento = new SaasStatusPagamento($this->saas_status_pagamento_id);
    
        // returns the associated object
        return $this->saas_status_pagamento;
    }
    /**
     * Method set_saas_contrato
     * Sample of usage: $var->saas_contrato = $object;
     * @param $object Instance of SaasContrato
     */
    public function set_saas_contrato(SaasContrato $object)
    {
        $this->saas_contrato = $object;
        $this->saas_contrato_id = $object->id;
    }

    /**
     * Method get_saas_contrato
     * Sample of usage: $var->saas_contrato->attribute;
     * @returns SaasContrato instance
     */
    public function get_saas_contrato()
    {
    
        // loads the associated object
        if (empty($this->saas_contrato))
            $this->saas_contrato = new SaasContrato($this->saas_contrato_id);
    
        // returns the associated object
        return $this->saas_contrato;
    }
    /**
     * Method set_saas_forma_pagamento
     * Sample of usage: $var->saas_forma_pagamento = $object;
     * @param $object Instance of SaasFormaPagamento
     */
    public function set_saas_forma_pagamento(SaasFormaPagamento $object)
    {
        $this->saas_forma_pagamento = $object;
        $this->saas_forma_pagamento_id = $object->id;
    }

    /**
     * Method get_saas_forma_pagamento
     * Sample of usage: $var->saas_forma_pagamento->attribute;
     * @returns SaasFormaPagamento instance
     */
    public function get_saas_forma_pagamento()
    {
    
        // loads the associated object
        if (empty($this->saas_forma_pagamento))
            $this->saas_forma_pagamento = new SaasFormaPagamento($this->saas_forma_pagamento_id);
    
        // returns the associated object
        return $this->saas_forma_pagamento;
    }
    /**
     * Method set_saas_gateway_pagamento
     * Sample of usage: $var->saas_gateway_pagamento = $object;
     * @param $object Instance of SaasGatewayPagamento
     */
    public function set_saas_gateway_pagamento(SaasGatewayPagamento $object)
    {
        $this->saas_gateway_pagamento = $object;
        $this->saas_gateway_pagamento_id = $object->id;
    }

    /**
     * Method get_saas_gateway_pagamento
     * Sample of usage: $var->saas_gateway_pagamento->attribute;
     * @returns SaasGatewayPagamento instance
     */
    public function get_saas_gateway_pagamento()
    {
    
        // loads the associated object
        if (empty($this->saas_gateway_pagamento))
            $this->saas_gateway_pagamento = new SaasGatewayPagamento($this->saas_gateway_pagamento_id);
    
        // returns the associated object
        return $this->saas_gateway_pagamento;
    }
    /**
     * Method set_saas_servico
     * Sample of usage: $var->saas_servico = $object;
     * @param $object Instance of SaasServico
     */
    public function set_saas_servico(SaasServico $object)
    {
        $this->saas_servico = $object;
        $this->saas_servico_id = $object->id;
    }

    /**
     * Method get_saas_servico
     * Sample of usage: $var->saas_servico->attribute;
     * @returns SaasServico instance
     */
    public function get_saas_servico()
    {
    
        // loads the associated object
        if (empty($this->saas_servico))
            $this->saas_servico = new SaasServico($this->saas_servico_id);
    
        // returns the associated object
        return $this->saas_servico;
    }
    /**
     * Method set_account
     * Sample of usage: $var->account = $object;
     * @param $object Instance of Account
     */
    public function set_account(Account $object)
    {
        $this->account = $object;
        $this->account_id = $object->id;
    }

    /**
     * Method get_account
     * Sample of usage: $var->account->attribute;
     * @returns Account instance
     */
    public function get_account()
    {
    
        // loads the associated object
        if (empty($this->account))
            $this->account = new Account($this->account_id);
    
        // returns the associated object
        return $this->account;
    }
    /**
     * Method set_saas_nota_fiscal_servico
     * Sample of usage: $var->saas_nota_fiscal_servico = $object;
     * @param $object Instance of SaasNotaFiscalServico
     */
    public function set_saas_nota_fiscal_servico(SaasNotaFiscalServico $object)
    {
        $this->saas_nota_fiscal_servico = $object;
        $this->saas_nota_fiscal_servico_id = $object->id;
    }

    /**
     * Method get_saas_nota_fiscal_servico
     * Sample of usage: $var->saas_nota_fiscal_servico->attribute;
     * @returns SaasNotaFiscalServico instance
     */
    public function get_saas_nota_fiscal_servico()
    {
    
        // loads the associated object
        if (empty($this->saas_nota_fiscal_servico))
            $this->saas_nota_fiscal_servico = new SaasNotaFiscalServico($this->saas_nota_fiscal_servico_id);
    
        // returns the associated object
        return $this->saas_nota_fiscal_servico;
    }

    /**
     * Method getSaasNotaFiscalServicos
     */
    public function getSaasNotaFiscalServicos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('saas_pagamento_id', '=', $this->id));
        return SaasNotaFiscalServico::getObjects( $criteria );
    }

    public function set_saas_nota_fiscal_servico_saas_pagamento_to_string($saas_nota_fiscal_servico_saas_pagamento_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_pagamento_to_string))
        {
            $values = SaasPagamento::where('id', 'in', $saas_nota_fiscal_servico_saas_pagamento_to_string)->getIndexedArray('id', 'id');
            $this->saas_nota_fiscal_servico_saas_pagamento_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_pagamento_to_string = $saas_nota_fiscal_servico_saas_pagamento_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_pagamento_to_string'] = $this->saas_nota_fiscal_servico_saas_pagamento_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_pagamento_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_pagamento_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_pagamento_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_pagamento_id', '=', $this->id)->getIndexedArray('saas_pagamento_id','{saas_pagamento->id}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_plano_valor_to_string($saas_nota_fiscal_servico_saas_plano_valor_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_plano_valor_to_string))
        {
            $values = SaasPlanoValor::where('id', 'in', $saas_nota_fiscal_servico_saas_plano_valor_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_saas_plano_valor_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_plano_valor_to_string = $saas_nota_fiscal_servico_saas_plano_valor_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_plano_valor_to_string'] = $this->saas_nota_fiscal_servico_saas_plano_valor_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_plano_valor_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_plano_valor_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_plano_valor_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_pagamento_id', '=', $this->id)->getIndexedArray('saas_plano_valor_id','{saas_plano_valor->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_saas_servico_to_string($saas_nota_fiscal_servico_saas_servico_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_saas_servico_to_string))
        {
            $values = SaasServico::where('id', 'in', $saas_nota_fiscal_servico_saas_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_saas_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_saas_servico_to_string = $saas_nota_fiscal_servico_saas_servico_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_saas_servico_to_string'] = $this->saas_nota_fiscal_servico_saas_servico_to_string;
    }

    public function get_saas_nota_fiscal_servico_saas_servico_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_saas_servico_to_string))
        {
            return $this->saas_nota_fiscal_servico_saas_servico_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_pagamento_id', '=', $this->id)->getIndexedArray('saas_servico_id','{saas_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_cidade_tomador_to_string($saas_nota_fiscal_servico_cidade_tomador_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_cidade_tomador_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_cidade_tomador_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_cidade_tomador_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_cidade_tomador_to_string = $saas_nota_fiscal_servico_cidade_tomador_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_cidade_tomador_to_string'] = $this->saas_nota_fiscal_servico_cidade_tomador_to_string;
    }

    public function get_saas_nota_fiscal_servico_cidade_tomador_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_cidade_tomador_to_string))
        {
            return $this->saas_nota_fiscal_servico_cidade_tomador_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_pagamento_id', '=', $this->id)->getIndexedArray('cidade_tomador_id','{cidade_tomador->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_cidade_prestador_to_string($saas_nota_fiscal_servico_cidade_prestador_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_cidade_prestador_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_cidade_prestador_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_cidade_prestador_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_cidade_prestador_to_string = $saas_nota_fiscal_servico_cidade_prestador_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_cidade_prestador_to_string'] = $this->saas_nota_fiscal_servico_cidade_prestador_to_string;
    }

    public function get_saas_nota_fiscal_servico_cidade_prestador_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_cidade_prestador_to_string))
        {
            return $this->saas_nota_fiscal_servico_cidade_prestador_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_pagamento_id', '=', $this->id)->getIndexedArray('cidade_prestador_id','{cidade_prestador->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_municipio_prestacao_servico_to_string($saas_nota_fiscal_servico_municipio_prestacao_servico_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            $values = Cidade::where('id', 'in', $saas_nota_fiscal_servico_municipio_prestacao_servico_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string = $saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_municipio_prestacao_servico_to_string'] = $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
    }

    public function get_saas_nota_fiscal_servico_municipio_prestacao_servico_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string))
        {
            return $this->saas_nota_fiscal_servico_municipio_prestacao_servico_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_pagamento_id', '=', $this->id)->getIndexedArray('municipio_prestacao_servico_id','{municipio_prestacao_servico->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_nota_fiscal_status_to_string($saas_nota_fiscal_servico_nota_fiscal_status_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            $values = NotaFiscalStatus::where('id', 'in', $saas_nota_fiscal_servico_nota_fiscal_status_to_string)->getIndexedArray('nome', 'nome');
            $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string = $saas_nota_fiscal_servico_nota_fiscal_status_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_nota_fiscal_status_to_string'] = $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string;
    }

    public function get_saas_nota_fiscal_servico_nota_fiscal_status_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_nota_fiscal_status_to_string))
        {
            return $this->saas_nota_fiscal_servico_nota_fiscal_status_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_pagamento_id', '=', $this->id)->getIndexedArray('nota_fiscal_status_id','{nota_fiscal_status->nome}');
        return implode(', ', $values);
    }

    public function set_saas_nota_fiscal_servico_account_to_string($saas_nota_fiscal_servico_account_to_string)
    {
        if(is_array($saas_nota_fiscal_servico_account_to_string))
        {
            $values = Account::where('id', 'in', $saas_nota_fiscal_servico_account_to_string)->getIndexedArray('razao_social', 'razao_social');
            $this->saas_nota_fiscal_servico_account_to_string = implode(', ', $values);
        }
        else
        {
            $this->saas_nota_fiscal_servico_account_to_string = $saas_nota_fiscal_servico_account_to_string;
        }

        $this->vdata['saas_nota_fiscal_servico_account_to_string'] = $this->saas_nota_fiscal_servico_account_to_string;
    }

    public function get_saas_nota_fiscal_servico_account_to_string()
    {
        if(!empty($this->saas_nota_fiscal_servico_account_to_string))
        {
            return $this->saas_nota_fiscal_servico_account_to_string;
        }
    
        $values = SaasNotaFiscalServico::where('saas_pagamento_id', '=', $this->id)->getIndexedArray('account_id','{account->razao_social}');
        return implode(', ', $values);
    }

    public function get_valor_f()
    {
        return 'R$ ' . number_format($this->valor, 2, ',', '.');
    }

    public function get_data_vencimento_f()
    {
        return TDate::date2br($this->data_vencimento);
    }

    public function get_valor_formatado()
    {
        return 'R$ ' . number_format($this->valor, 2, ',', '.');
    }

    public function get_data_vencimento_formatada()
    {
        return TDate::date2br($this->data_vencimento);
    }

    public function onBeforeStore($object)
    {
        if(! empty($object->data_pagamento))
        {
            $data_pagamento = new DateTime($object->data_pagamento);
            $object->mes_pagamento = $data_pagamento->format('m');
            $object->ano_pagamento = $data_pagamento->format('Y');
            $object->mes_ano_pagamento = $data_pagamento->format('m/Y');
        }
    
        if(!empty($object->data_compra))
        {
            $data_compra = new DateTime($object->data_compra);
            $object->mes_compra = $data_compra->format('m');
            $object->ano_compra = $data_compra->format('Y');
            $object->mes_ano_compra = $data_compra->format('m/Y');
        }
    }

    public function gerarNotaFiscal()
    {
    
        $account = $this->get_account();
        if(SaasNotaFiscalServico::where('saas_pagamento_id', '=', $this->id)->where('nota_fiscal_status_id', 'not in', [NotaFiscalStatus::CANCELADA, NotaFiscalStatus::REJEITADA])->first())
        {
            throw new Exception('Já existe uma nota fiscal gerada para esse pagamento');
        }
    
        // configs da empresa dona do saas
        $configuracao = SaasConfiguracao::getDefaults();
    
    
        $notaFiscal = new SaasNotaFiscalServico();

        $notaFiscal->saas_pagamento_id = $this->id;
    
        if($this->saas_contrato_id)
        {
            $contrato = $this->get_saas_contrato();
            $notaFiscal->saas_plano_valor_id = $contrato->saas_plano_valor_id;
            $notaFiscal->saas_servico_id = $contrato->saas_plano_valor->saas_plano->saas_servico_id;
            $notaFiscal->discriminacao = $contrato->saas_plano_valor->saas_plano->discriminacao;
        
            $servico = $contrato->saas_plano_valor->saas_plano->saas_servico;
        
            $notaFiscal->iss_retido = $servico->servico_grupo_imposto->iss_retido;
        }
        elseif($this->saas_servico_id)
        {
            $notaFiscal->saas_servico_id = $this->saas_servico_id;
        
            $servico = $this->get_saas_servico();
        
            $notaFiscal->discriminacao = $servico->descricao;
            $notaFiscal->iss_retido = $servico->servico_grupo_imposto->iss_retido;
        }
   
        if(!$account->cidade_id)
        {
            throw new Exception('A cidade do cliente não foi definida, ajuste o cadastro.');
        }
    
        if(!$account->documento)
        {
            throw new Exception('O documento do cliente não foi definido, ajuste o cadastro.');
        }
   
        $notaFiscal->valor_servicos = $this->valor; 
        $notaFiscal->cidade_tomador_id = $account->cidade_id;
        $notaFiscal->cidade_prestador_id = $configuracao->cidade_id;
        $notaFiscal->municipio_prestacao_servico_id = $configuracao->cidade_id;
        $notaFiscal->nota_fiscal_status_id = NotaFiscalStatus::PENDENTE;
        $notaFiscal->account_id = $account->id;
    
        $notaFiscal->natureza_operacao = $configuracao->natureza_operacao;
        $notaFiscal->data_hora_emissao = date('Y-m-d H:i:s');
    
        //substr($campo,0,60);
    
        $notaFiscal->nome_tomador = $account->razao_social;
        $notaFiscal->documento_tomador = $account->documento;
        $notaFiscal->endereco_tomador = substr($account->rua,0,19);
        $notaFiscal->email_tomador = $account->email;
        $notaFiscal->telefone_tomador = $account->telefone;
        $notaFiscal->numero_tomador = $account->numero;
        $notaFiscal->bairro_tomador = substr($account->bairro,0,24);
        $notaFiscal->cep_tomador = $account->cep;
        $notaFiscal->inscricao_municipal_tomador = '';
        $notaFiscal->inscricao_municipal_prestador = $configuracao->inscricao_municipal;
        $notaFiscal->nome_prestador = $configuracao->razao_social;
        $notaFiscal->documento_prestador = $configuracao->cnpj;
        $notaFiscal->endereco_prestador = substr($configuracao->rua,0,19);
        $notaFiscal->email_prestador = $configuracao->email;
        $notaFiscal->telefone_prestador = $configuracao->telefone;
        $notaFiscal->numero_prestador = $configuracao->numero;
        $notaFiscal->bairro_prestador = substr($configuracao->bairro,0,24);
        $notaFiscal->cep_prestador = $configuracao->cep;
    
        // echo '<pre>';
        // var_dump($notaFiscal);
        // die;
    
        $notaFiscal = SaasNotaFiscalServicoService::calculaImpostos($notaFiscal);
    
        $notaFiscal->ano = date('Y');
        $notaFiscal->mes = date('m');
        $notaFiscal->ano_mes = date('Y/m');
    
        $notaFiscal->store();
    
        $this->saas_nota_fiscal_servico_id = $notaFiscal->id;
        $this->store();
    
        return $notaFiscal;
    }

                                                                    
}

