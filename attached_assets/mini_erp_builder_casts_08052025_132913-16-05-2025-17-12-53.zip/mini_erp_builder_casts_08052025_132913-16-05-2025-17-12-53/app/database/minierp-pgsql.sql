CREATE TABLE account( 
      id  SERIAL    NOT NULL  , 
      cidade_id integer   , 
      system_user_id integer   , 
      nome_responsavel text   NOT NULL  , 
      razao_social text   NOT NULL  , 
      tipo_pessoa char  (1)     DEFAULT 'J', 
      documento text   , 
      email text   , 
      telefone text   , 
      cep text   , 
      rua text   , 
      numero text   , 
      complemento text   , 
      bairro text   , 
      mes_criacao integer   , 
      ano_criacao integer   , 
      created_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE api_error( 
      id  SERIAL    NOT NULL  , 
      classe varchar  (255)   , 
      metodo varchar  (255)   , 
      url varchar  (500)   , 
      dados varchar  (3000)   , 
      error_message varchar  (3000)   , 
      created_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE aprovador( 
      id  SERIAL    NOT NULL  , 
      system_user_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE categoria( 
      id  SERIAL    NOT NULL  , 
      tipo_conta_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE categoria_cliente( 
      id  SERIAL    NOT NULL  , 
      nome varchar  (255)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE cep_cache( 
      id  SERIAL    NOT NULL  , 
      cep varchar  (10)   , 
      rua varchar  (10)   , 
      cidade varchar  (500)   , 
      bairro varchar  (500)   , 
      codigo_ibge varchar  (20)   , 
      uf varchar  (2)   , 
      cidade_id integer   , 
      estado_id integer   , 
      created_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE cidade( 
      id  SERIAL    NOT NULL  , 
      estado_id integer   NOT NULL  , 
      nome varchar  (255)   NOT NULL  , 
      codigo_ibge varchar  (10)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE condicao_pagamento( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      numero_parcelas integer   , 
      inicio integer   , 
      intervalo integer   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE conta( 
      id  SERIAL    NOT NULL  , 
      pessoa_id integer   NOT NULL  , 
      tipo_conta_id integer   NOT NULL  , 
      categoria_id integer   NOT NULL  , 
      forma_pagamento_id integer   NOT NULL  , 
      pedido_venda_id integer   , 
      dt_vencimento date   , 
      dt_emissao date   , 
      dt_pagamento date   , 
      valor float   , 
      parcela integer   , 
      obs text   , 
      mes_vencimento integer   , 
      ano_vencimento integer   , 
      ano_mes_vencimento integer   , 
      mes_emissao integer   , 
      ano_emissao integer   , 
      ano_mes_emissao integer   , 
      mes_pagamento integer   , 
      ano_pagamento integer   , 
      ano_mes_pagamento integer   , 
      created_at timestamp   , 
      updated_at timestamp   , 
      deleted_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE conta_anexo( 
      id  SERIAL    NOT NULL  , 
      conta_id integer   NOT NULL  , 
      tipo_anexo_id integer   NOT NULL  , 
      descricao text   , 
      arquivo text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE email_template( 
      id  SERIAL    NOT NULL  , 
      titulo text   , 
      mensagem text   , 
      created_at timestamp   , 
      updated_at timestamp   , 
      deleted_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE error_log_crontab( 
      id  SERIAL    NOT NULL  , 
      classe text   , 
      metodo text   , 
      mensagem text   , 
      created_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado( 
      id  SERIAL    NOT NULL  , 
      nome varchar  (255)   NOT NULL  , 
      sigla char  (2)   NOT NULL  , 
      codigo_ibge varchar  (10)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado_pedido_venda( 
      id  SERIAL    NOT NULL  , 
      nome varchar  (255)   , 
      cor varchar  (100)   , 
      kanban char  (1)   , 
      ordem integer   , 
      estado_final char  (1)   , 
      estado_inicial char  (1)   , 
      permite_edicao char  (1)   , 
      permite_exclusao char  (1)   , 
      created_at timestamp   , 
      updated_at timestamp   , 
      deleted_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE estado_pedido_venda_aprovador( 
      id  SERIAL    NOT NULL  , 
      estado_pedido_venda_id integer   NOT NULL  , 
      aprovador_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE etapa_negociacao( 
      id  SERIAL    NOT NULL  , 
      nome text   , 
      cor text   , 
      ordem integer   , 
      roteiro text   , 
      kanban char  (1)   , 
      permite_edicao char  (1)   , 
      permite_exclusao char  (1)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE fabricante( 
      id  SERIAL    NOT NULL  , 
      nome varchar  (255)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE familia_produto( 
      id  SERIAL    NOT NULL  , 
      nome varchar  (255)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE forma_pagamento( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE grupo_pessoa( 
      id  SERIAL    NOT NULL  , 
      nome varchar  (255)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE matriz_estado_pedido_venda( 
      id  SERIAL    NOT NULL  , 
      estado_pedido_venda_origem_id integer   NOT NULL  , 
      estado_pedido_venda_destino_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE negociacao( 
      id  SERIAL    NOT NULL  , 
      cliente_id integer   NOT NULL  , 
      vendedor_id integer   NOT NULL  , 
      origem_contato_id integer   NOT NULL  , 
      etapa_negociacao_id integer   NOT NULL  , 
      data_inicio date   NOT NULL  , 
      data_fechamento date   , 
      data_fechamento_esperada date   , 
      valor_total float   , 
      ordem integer   , 
      mes integer   , 
      ano integer   , 
      created_at timestamp   , 
      updated_at timestamp   , 
      deleted_at timestamp   , 
      email_novo_pedido_enviado char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE negociacao_arquivo( 
      id  SERIAL    NOT NULL  , 
      negociacao_id integer   NOT NULL  , 
      nome_arquivo text   , 
      conteudo_arquivo text   , 
      dt_arquivo timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE negociacao_atividade( 
      id  SERIAL    NOT NULL  , 
      tipo_atividade_id integer   NOT NULL  , 
      negociacao_id integer   NOT NULL  , 
      descricao text   , 
      horario_inicial timestamp   , 
      horario_final timestamp   , 
      observacao text   , 
      dt_atividade timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE negociacao_historico_etapa( 
      id  SERIAL    NOT NULL  , 
      negociacao_id integer   NOT NULL  , 
      etapa_negociacao_id integer   NOT NULL  , 
      dt_etapa timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE negociacao_item( 
      id  SERIAL    NOT NULL  , 
      produto_id integer   NOT NULL  , 
      negociacao_id integer   NOT NULL  , 
      quantidade float   , 
      valor float   , 
      valor_total float   , 
      dt_item timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE negociacao_observacao( 
      id  SERIAL    NOT NULL  , 
      negociacao_id integer   NOT NULL  , 
      observacao text   , 
      dt_observacao timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE nota_fiscal( 
      id  SERIAL    NOT NULL  , 
      cliente_id integer   NOT NULL  , 
      pedido_venda_id integer   NOT NULL  , 
      condicao_pagamento_id integer   NOT NULL  , 
      obs text   , 
      mes integer   , 
      ano integer   , 
      valor_total float   , 
      data_emissao date   , 
      created_at timestamp   , 
      updated_at timestamp   , 
      deleted_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE nota_fiscal_item( 
      id  SERIAL    NOT NULL  , 
      pedido_venda_item_id integer   , 
      nota_fiscal_id integer   NOT NULL  , 
      produto_id integer   NOT NULL  , 
      quantidade float   , 
      valor float   , 
      desconto float   , 
      valor_total float   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE nota_fiscal_status( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      cor text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE origem_contato( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE ouvidoria( 
      id  SERIAL    NOT NULL  , 
      tipo_ouvidoria_id integer   NOT NULL  , 
      nome text   , 
      telefone text   , 
      email text   , 
      mensagem text   NOT NULL  , 
      created_at timestamp   , 
      updated_at timestamp   , 
      deleted_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pedido_venda( 
      id  SERIAL    NOT NULL  , 
      tipo_pedido_id integer   NOT NULL  , 
      cliente_id integer   NOT NULL  , 
      vendedor_id integer   NOT NULL  , 
      estado_pedido_venda_id integer   NOT NULL  , 
      condicao_pagamento_id integer   NOT NULL  , 
      transportadora_id integer   NOT NULL  , 
      negociacao_id integer   , 
      dt_pedido date   , 
      obs varchar  (255)   , 
      frete float   , 
      mes char  (2)   , 
      ano char  (4)   , 
      valor_total float   , 
      created_at timestamp   , 
      updated_at timestamp   , 
      deleted_at timestamp   , 
      obs_comercial text   , 
      obs_financeiro text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pedido_venda_historico( 
      id  SERIAL    NOT NULL  , 
      pedido_venda_id integer   NOT NULL  , 
      estado_pedido_venda_id integer   NOT NULL  , 
      aprovador_id integer   , 
      data_operacao timestamp   , 
      obs text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pedido_venda_item( 
      id  SERIAL    NOT NULL  , 
      pedido_venda_id integer   NOT NULL  , 
      produto_id integer   NOT NULL  , 
      quantidade float   , 
      valor float   , 
      desconto float   , 
      valor_total float   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa( 
      id  SERIAL    NOT NULL  , 
      tipo_cliente_id integer   NOT NULL  , 
      categoria_cliente_id integer   , 
      system_user_id integer   , 
      nome varchar  (500)   NOT NULL  , 
      documento varchar  (20)   NOT NULL  , 
      obs varchar  (1000)   , 
      fone varchar  (255)   , 
      email varchar  (255)   , 
      created_at timestamp   , 
      updated_at timestamp   , 
      deleted_at timestamp   , 
      login varchar  (255)   , 
      senha varchar  (255)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa_contato( 
      id  SERIAL    NOT NULL  , 
      pessoa_id integer   NOT NULL  , 
      email varchar  (255)   , 
      nome varchar  (255)   , 
      telefone varchar  (255)   , 
      obs varchar  (500)   , 
      created_at timestamp   , 
      updated_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa_endereco( 
      id  SERIAL    NOT NULL  , 
      pessoa_id integer   NOT NULL  , 
      cidade_id integer   NOT NULL  , 
      nome varchar  (255)   , 
      principal char  (1)   , 
      cep varchar  (10)   , 
      rua varchar  (500)   , 
      numero varchar  (20)   , 
      bairro varchar  (500)   , 
      complemento varchar  (500)   , 
      data_desativacao date   , 
      created_at timestamp   , 
      updated_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pessoa_grupo( 
      id  SERIAL    NOT NULL  , 
      pessoa_id integer   NOT NULL  , 
      grupo_pessoa_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE produto( 
      id  SERIAL    NOT NULL  , 
      tipo_produto_id integer   NOT NULL  , 
      familia_produto_id integer   NOT NULL  , 
      fornecedor_id integer   NOT NULL  , 
      unidade_medida_id integer   NOT NULL  , 
      fabricante_id integer   , 
      nome varchar  (255)   NOT NULL  , 
      cod_barras varchar  (255)   , 
      preco_venda float   , 
      preco_custo float   , 
      peso_liquido float   , 
      peso_bruto float   , 
      largura float   , 
      altura float   , 
      volume float   , 
      estoque_minimo float   , 
      qtde_estoque float   , 
      estoque_maximo float   , 
      obs varchar  (500)   , 
      ativo char  (1)   , 
      foto varchar  (500)   , 
      data_ultimo_reajuste_preco timestamp   , 
      created_at timestamp   , 
      updated_at timestamp   , 
      deleted_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_configuracao( 
      id  SERIAL    NOT NULL  , 
      cidade_id integer   , 
      saas_plano_valor_trial_id integer   , 
      contrato_inativo_system_group_id integer   , 
      parametro_fiscal_id integer   , 
      razao_social text   , 
      nome_fantasia text   , 
      cnpj text   , 
      inscricao_estadual text   , 
      inscricao_municipal text   , 
      cep text   , 
      rua text   , 
      bairro text   , 
      numero text   , 
      complemento text   , 
      email text   NOT NULL  , 
      telefone text   NOT NULL  , 
      dias_trial integer   , 
      contrato text   , 
      regime_tributacao text   , 
      token_integra_notas text   , 
      token_integra_notas_homologacao text   , 
      token_integra_notas_software_house text   , 
      nfse_emissao_producao char  (1)   NOT NULL    DEFAULT 'F', 
      nfse_numero text   , 
      nfse_serie text   , 
      nfse_info text   , 
      termo_uso text   , 
      email_port text   , 
      email_username text   , 
      email_password text   , 
      email_host text   , 
      email_from text   , 
      email_from_name text   , 
      email_smtp_auth char  (1)     DEFAULT 'F', 
      dias_renovacao_contrato integer   , 
      dias_vencimento_pagamento integer   , 
      url_sistema text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_contrato( 
      id  SERIAL    NOT NULL  , 
      saas_plano_valor_id integer   NOT NULL  , 
      account_id integer   NOT NULL  , 
      saas_contrato_status_id integer   NOT NULL  , 
      valor_total float   , 
      data_inicial date   NOT NULL  , 
      data_final date   , 
      criado_em timestamp   , 
      renovacao char  (1)     DEFAULT 'F', 
      total_usuarios integer   , 
      total_unidades integer   , 
      gateway_assinatura_id text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_contrato_grupo( 
      id  SERIAL    NOT NULL  , 
      saas_contrato_id integer   NOT NULL  , 
      system_group_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_contrato_status( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      cor text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_email_log( 
      id  SERIAL    NOT NULL  , 
      titulo text   , 
      conteudo text   , 
      destinatario text   , 
      created_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_error_log( 
      id  SERIAL    NOT NULL  , 
      system_unit_id integer   , 
      system_user_id integer   , 
      error_class varchar  (255)   , 
      error_method varchar  (255)   , 
      message text   , 
      payload text   , 
      created_at timestamp   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_forma_pagamento( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_forma_pagamento( 
      id  SERIAL    NOT NULL  , 
      saas_forma_pagamento_id integer   NOT NULL  , 
      saas_gateway_pagamento_id integer   NOT NULL  , 
      codigo text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_pagamento( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      public_key text   , 
      access_token text   , 
      client_secret text   , 
      client_id text   , 
      oauth_token text   , 
      oauth_token_created_at timestamp   , 
      certificado_crt text   , 
      certificado_key text   , 
      webhook_url text   , 
      webhook_certificado_cert text   , 
      fl_homologacao char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_gateway_pagamento_status( 
      id  SERIAL    NOT NULL  , 
      saas_gateway_pagamento_id integer   NOT NULL  , 
      saas_status_pagamento_id integer   NOT NULL  , 
      codigo text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_imposto( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      codigo text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_nota_fiscal_servico( 
      id  SERIAL    NOT NULL  , 
      saas_pagamento_id integer   , 
      saas_plano_valor_id integer   , 
      saas_servico_id integer   , 
      cidade_tomador_id integer   NOT NULL  , 
      cidade_prestador_id integer   NOT NULL  , 
      municipio_prestacao_servico_id integer   NOT NULL  , 
      nota_fiscal_status_id integer   NOT NULL  , 
      account_id integer   NOT NULL  , 
      natureza_operacao text   , 
      data_hora_emissao timestamp   NOT NULL  , 
      discriminacao text   NOT NULL  , 
      numero text   , 
      codigo_verificacao text   , 
      id_gateway_externo text   , 
      dados_gateway_externo text   , 
      nome_tomador text   NOT NULL  , 
      documento_tomador text   NOT NULL  , 
      endereco_tomador text   NOT NULL  , 
      email_tomador text   NOT NULL  , 
      telefone_tomador text   , 
      numero_tomador text   NOT NULL  , 
      bairro_tomador text   NOT NULL  , 
      cep_tomador text   NOT NULL  , 
      inscricao_municipal_tomador text   , 
      inscricao_municipal_prestador text   , 
      nome_prestador text   NOT NULL  , 
      documento_prestador text   NOT NULL  , 
      endereco_prestador text   NOT NULL  , 
      email_prestador text   NOT NULL  , 
      telefone_prestador text   , 
      numero_prestador text   NOT NULL  , 
      bairro_prestador text   NOT NULL  , 
      cep_prestador text   NOT NULL  , 
      iss_retido char  (1)     DEFAULT 'F', 
      desconto_incondicionado float     DEFAULT 0.00, 
      desconto_condicionado float     DEFAULT 0.00, 
      base_calculo_iss float   , 
      aliquota_iss float   , 
      aliquota_pis float   , 
      aliquota_cofins float   , 
      aliquota_csll float   , 
      aliquota_irrf float   , 
      aliquota_inss float   , 
      valor_deducoes float   , 
      valor_retencoes float   , 
      valor_outras_retencoes float   , 
      valor_liquido float   , 
      valor_servicos float   , 
      valor_iss float   , 
      valor_pis float     DEFAULT 0.00, 
      valor_inss float     DEFAULT 0.00, 
      valor_cofins float     DEFAULT 0.00, 
      valor_csll float   , 
      valor_irrf float     DEFAULT 0.00, 
      incentivador_cultural char  (1)     DEFAULT 'F', 
      optante_simples_nacional char  (1)     DEFAULT 'F', 
      nfse_status text   , 
      ano text   , 
      mes text   , 
      ano_mes text   , 
      pdf text   , 
      xml text   , 
      link_pdf_prefeitura text   , 
      regime_tributario_municipal text   , 
      numero_rps text   , 
      mensagem_erro text   , 
      email_enviado char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_pagamento( 
      id  SERIAL    NOT NULL  , 
      account_id integer   NOT NULL  , 
      saas_status_pagamento_id integer   NOT NULL  , 
      saas_contrato_id integer   , 
      saas_servico_id integer   , 
      saas_forma_pagamento_id integer   NOT NULL  , 
      saas_gateway_pagamento_id integer   NOT NULL  , 
      saas_nota_fiscal_servico_id integer   , 
      valor float   NOT NULL  , 
      data_compra timestamp   NOT NULL  , 
      data_vencimento date   , 
      data_pagamento date   , 
      dados_gateway text   , 
      id_gateway text   , 
      payment_id text   , 
      link_gateway text   , 
      mes_compra integer   , 
      ano_compra integer   , 
      ano_pagamento integer   , 
      mes_pagamento integer   , 
      mes_ano_pagamento text   , 
      mes_ano_compra text   , 
      renovacao char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_plano( 
      id  SERIAL    NOT NULL  , 
      saas_servico_id integer   , 
      nome text   NOT NULL  , 
      descricao text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
      limite_usuarios integer   , 
      limite_unidades integer   , 
      discriminacao text   , 
      ordem integer   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_plano_grupo( 
      id  SERIAL    NOT NULL  , 
      saas_plano_id integer   NOT NULL  , 
      system_group_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_plano_valor( 
      id  SERIAL    NOT NULL  , 
      saas_plano_id integer   NOT NULL  , 
      valor float   NOT NULL  , 
      nome text   NOT NULL  , 
      duracao integer   , 
      ativo char  (1)     DEFAULT 'T', 
      desativado_em timestamp   , 
      recorrencia char  (1)     DEFAULT 'F', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico( 
      id  SERIAL    NOT NULL  , 
      servico_grupo_imposto_id integer   , 
      nome text   NOT NULL  , 
      preco float   , 
      descricao text   NOT NULL  , 
      ativo char  (1)   NOT NULL    DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico_grupo_imposto( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      codigo_cnae text   , 
      codigo_tributacao_municipio text   , 
      codigo_nbs text   , 
      codigo text   , 
      descricao_servico_municipio text   , 
      iss_retido text   , 
      natureza_operacao text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_servico_grupo_imposto_item( 
      id  SERIAL    NOT NULL  , 
      saas_servico_grupo_imposto_id integer   NOT NULL  , 
      saas_imposto_id integer   NOT NULL  , 
      aliquota float   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_status_pagamento( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
      cor text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE saas_template_email( 
      id  SERIAL    NOT NULL  , 
      descricao text   , 
      titulo text   , 
      conteudo text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group( 
      id integer   NOT NULL  , 
      name text   NOT NULL  , 
      uuid varchar  (36)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group_program( 
      id integer   NOT NULL  , 
      system_group_id integer   NOT NULL  , 
      system_program_id integer   NOT NULL  , 
      actions text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_preference( 
      id varchar  (255)   NOT NULL  , 
      preference text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_program( 
      id integer   NOT NULL  , 
      name text   NOT NULL  , 
      controller text   NOT NULL  , 
      actions text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_unit( 
      id integer   NOT NULL  , 
      name text   NOT NULL  , 
      account_id integer   , 
      connection_name text   , 
      active char  (1)     DEFAULT 'T', 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_group( 
      id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
      system_group_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_program( 
      id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
      system_program_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_users( 
      id integer   NOT NULL  , 
      name text   NOT NULL  , 
      login text   NOT NULL  , 
      password text   NOT NULL  , 
      email text   , 
      frontpage_id integer   , 
      system_unit_id integer   , 
      account_id integer   , 
      active char  (1)   , 
      accepted_term_policy_at text   , 
      accepted_term_policy char  (1)   , 
      two_factor_enabled char  (1)     DEFAULT 'N', 
      two_factor_type varchar  (100)   , 
      two_factor_secret varchar  (255)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_unit( 
      id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
      system_unit_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_anexo( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_atividade( 
      id  SERIAL    NOT NULL  , 
      nome text   , 
      cor text   , 
      icone text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_cliente( 
      id  SERIAL    NOT NULL  , 
      nome varchar  (255)   NOT NULL  , 
      sigla char  (2)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_conta( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_ouvidoria( 
      id  SERIAL    NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_pedido( 
      id  SERIAL    NOT NULL  , 
      categoria_id integer   NOT NULL  , 
      nome text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE tipo_produto( 
      id  SERIAL    NOT NULL  , 
      nome varchar  (255)   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE unidade_medida( 
      id  SERIAL    NOT NULL  , 
      nome varchar  (255)   NOT NULL  , 
      sigla char  (2)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE webhook_log( 
      id  SERIAL    NOT NULL  , 
      gateway_pagamento_id integer   , 
      payload text   , 
      created_at timestamp   , 
 PRIMARY KEY (id)) ; 

 
  
 ALTER TABLE account ADD CONSTRAINT fk_account_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE account ADD CONSTRAINT fk_account_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE aprovador ADD CONSTRAINT fk_aprovador_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE categoria ADD CONSTRAINT fk_categoria_1 FOREIGN KEY (tipo_conta_id) references tipo_conta(id); 
ALTER TABLE cidade ADD CONSTRAINT fk_cidade_1 FOREIGN KEY (estado_id) references estado(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_1 FOREIGN KEY (tipo_conta_id) references tipo_conta(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_2 FOREIGN KEY (categoria_id) references categoria(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_3 FOREIGN KEY (forma_pagamento_id) references forma_pagamento(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_4 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE conta ADD CONSTRAINT fk_conta_5 FOREIGN KEY (pedido_venda_id) references pedido_venda(id); 
ALTER TABLE conta_anexo ADD CONSTRAINT fk_conta_anexo_1 FOREIGN KEY (conta_id) references conta(id); 
ALTER TABLE conta_anexo ADD CONSTRAINT fk_conta_anexo_2 FOREIGN KEY (tipo_anexo_id) references tipo_anexo(id); 
ALTER TABLE estado_pedido_venda_aprovador ADD CONSTRAINT fk_estado_pedido_venda_aprovador_1 FOREIGN KEY (estado_pedido_venda_id) references estado_pedido_venda(id); 
ALTER TABLE estado_pedido_venda_aprovador ADD CONSTRAINT fk_estado_pedido_venda_aprovador_2 FOREIGN KEY (aprovador_id) references aprovador(id); 
ALTER TABLE matriz_estado_pedido_venda ADD CONSTRAINT fk_matriz_estado_pedido_venda_1 FOREIGN KEY (estado_pedido_venda_origem_id) references estado_pedido_venda(id); 
ALTER TABLE matriz_estado_pedido_venda ADD CONSTRAINT fk_matriz_estado_pedido_venda_2 FOREIGN KEY (estado_pedido_venda_destino_id) references estado_pedido_venda(id); 
ALTER TABLE negociacao ADD CONSTRAINT fk_negociacao_1 FOREIGN KEY (cliente_id) references pessoa(id); 
ALTER TABLE negociacao ADD CONSTRAINT fk_negociacao_2 FOREIGN KEY (vendedor_id) references pessoa(id); 
ALTER TABLE negociacao ADD CONSTRAINT fk_negociacao_3 FOREIGN KEY (origem_contato_id) references origem_contato(id); 
ALTER TABLE negociacao ADD CONSTRAINT fk_negociacao_4 FOREIGN KEY (etapa_negociacao_id) references etapa_negociacao(id); 
ALTER TABLE negociacao_arquivo ADD CONSTRAINT fk_negociacao_arquivo_1 FOREIGN KEY (negociacao_id) references negociacao(id); 
ALTER TABLE negociacao_atividade ADD CONSTRAINT fk_negociacao_atividade_1 FOREIGN KEY (negociacao_id) references negociacao(id); 
ALTER TABLE negociacao_atividade ADD CONSTRAINT fk_negociacao_atividade_2 FOREIGN KEY (tipo_atividade_id) references tipo_atividade(id); 
ALTER TABLE negociacao_historico_etapa ADD CONSTRAINT fk_negociacao_historico_etapa_1 FOREIGN KEY (negociacao_id) references negociacao(id); 
ALTER TABLE negociacao_historico_etapa ADD CONSTRAINT fk_negociacao_historico_etapa_2 FOREIGN KEY (etapa_negociacao_id) references etapa_negociacao(id); 
ALTER TABLE negociacao_item ADD CONSTRAINT fk_negociacao_item_1 FOREIGN KEY (negociacao_id) references negociacao(id); 
ALTER TABLE negociacao_item ADD CONSTRAINT fk_negociacao_item_2 FOREIGN KEY (produto_id) references produto(id); 
ALTER TABLE negociacao_observacao ADD CONSTRAINT fk_negociacao_observacao_1 FOREIGN KEY (negociacao_id) references negociacao(id); 
ALTER TABLE nota_fiscal ADD CONSTRAINT fk_nota_fiscal_1 FOREIGN KEY (pedido_venda_id) references pedido_venda(id); 
ALTER TABLE nota_fiscal ADD CONSTRAINT fk_nota_fiscal_2 FOREIGN KEY (cliente_id) references pessoa(id); 
ALTER TABLE nota_fiscal ADD CONSTRAINT fk_nota_fiscal_3 FOREIGN KEY (condicao_pagamento_id) references condicao_pagamento(id); 
ALTER TABLE nota_fiscal_item ADD CONSTRAINT fk_nota_fiscal_item_1 FOREIGN KEY (pedido_venda_item_id) references pedido_venda_item(id); 
ALTER TABLE nota_fiscal_item ADD CONSTRAINT fk_nota_fiscal_item_2 FOREIGN KEY (nota_fiscal_id) references nota_fiscal(id); 
ALTER TABLE nota_fiscal_item ADD CONSTRAINT fk_nota_fiscal_item_3 FOREIGN KEY (produto_id) references produto(id); 
ALTER TABLE ouvidoria ADD CONSTRAINT fk_ouvidoria_1 FOREIGN KEY (tipo_ouvidoria_id) references tipo_ouvidoria(id); 
ALTER TABLE pedido_venda ADD CONSTRAINT fk_pedido_venda_1 FOREIGN KEY (cliente_id) references pessoa(id); 
ALTER TABLE pedido_venda ADD CONSTRAINT fk_pedido_venda_2 FOREIGN KEY (vendedor_id) references pessoa(id); 
ALTER TABLE pedido_venda ADD CONSTRAINT fk_pedido_venda_3 FOREIGN KEY (estado_pedido_venda_id) references estado_pedido_venda(id); 
ALTER TABLE pedido_venda ADD CONSTRAINT fk_pedido_venda_4 FOREIGN KEY (condicao_pagamento_id) references condicao_pagamento(id); 
ALTER TABLE pedido_venda ADD CONSTRAINT fk_pedido_venda_5 FOREIGN KEY (transportadora_id) references pessoa(id); 
ALTER TABLE pedido_venda ADD CONSTRAINT fk_pedido_venda_6 FOREIGN KEY (tipo_pedido_id) references tipo_pedido(id); 
ALTER TABLE pedido_venda ADD CONSTRAINT fk_pedido_venda_7 FOREIGN KEY (negociacao_id) references negociacao(id); 
ALTER TABLE pedido_venda_historico ADD CONSTRAINT fk_pedido_venda_historico_1 FOREIGN KEY (pedido_venda_id) references pedido_venda(id); 
ALTER TABLE pedido_venda_historico ADD CONSTRAINT fk_pedido_venda_historico_2 FOREIGN KEY (estado_pedido_venda_id) references estado_pedido_venda(id); 
ALTER TABLE pedido_venda_historico ADD CONSTRAINT fk_pedido_venda_historico_3 FOREIGN KEY (aprovador_id) references aprovador(id); 
ALTER TABLE pedido_venda_item ADD CONSTRAINT fk_pedido_venda_item_2 FOREIGN KEY (produto_id) references produto(id); 
ALTER TABLE pedido_venda_item ADD CONSTRAINT fk_pedido_venda_item_1 FOREIGN KEY (pedido_venda_id) references pedido_venda(id); 
ALTER TABLE pessoa ADD CONSTRAINT fk_pessoa_1 FOREIGN KEY (tipo_cliente_id) references tipo_cliente(id); 
ALTER TABLE pessoa ADD CONSTRAINT fk_pessoa_2 FOREIGN KEY (categoria_cliente_id) references categoria_cliente(id); 
ALTER TABLE pessoa ADD CONSTRAINT fk_pessoa_3 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE pessoa_contato ADD CONSTRAINT fk_pessoa_contato_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_endereco ADD CONSTRAINT fk_pessoa_endereco_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_endereco ADD CONSTRAINT fk_pessoa_endereco_2 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE pessoa_grupo ADD CONSTRAINT fk_pessoa_grupo_1 FOREIGN KEY (pessoa_id) references pessoa(id); 
ALTER TABLE pessoa_grupo ADD CONSTRAINT fk_pessoa_grupo_2 FOREIGN KEY (grupo_pessoa_id) references grupo_pessoa(id); 
ALTER TABLE produto ADD CONSTRAINT fk_produto_1 FOREIGN KEY (tipo_produto_id) references tipo_produto(id); 
ALTER TABLE produto ADD CONSTRAINT fk_produto_2 FOREIGN KEY (familia_produto_id) references familia_produto(id); 
ALTER TABLE produto ADD CONSTRAINT fk_produto_3 FOREIGN KEY (fabricante_id) references fabricante(id); 
ALTER TABLE produto ADD CONSTRAINT fk_produto_4 FOREIGN KEY (unidade_medida_id) references unidade_medida(id); 
ALTER TABLE produto ADD CONSTRAINT fk_produto_5 FOREIGN KEY (fornecedor_id) references pessoa(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_1 FOREIGN KEY (cidade_id) references cidade(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_2 FOREIGN KEY (saas_plano_valor_trial_id) references saas_plano_valor(id); 
ALTER TABLE saas_configuracao ADD CONSTRAINT fk_saas_configuracao_4 FOREIGN KEY (contrato_inativo_system_group_id) references system_group(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_2 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_3 FOREIGN KEY (saas_contrato_status_id) references saas_contrato_status(id); 
ALTER TABLE saas_contrato ADD CONSTRAINT fk_saas_contrato_4 FOREIGN KEY (saas_plano_valor_id) references saas_plano_valor(id); 
ALTER TABLE saas_contrato_grupo ADD CONSTRAINT fk_saas_contrato_grupo_2 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE saas_contrato_grupo ADD CONSTRAINT fk_saas_contrato_grupo_1 FOREIGN KEY (saas_contrato_id) references saas_contrato(id); 
ALTER TABLE saas_error_log ADD CONSTRAINT fk_saas_error_log_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE saas_error_log ADD CONSTRAINT fk_saas_error_log_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE saas_gateway_forma_pagamento ADD CONSTRAINT fk_saas_forma_pagamento_gateway_1 FOREIGN KEY (saas_forma_pagamento_id) references saas_forma_pagamento(id); 
ALTER TABLE saas_gateway_forma_pagamento ADD CONSTRAINT fk_saas_forma_pagamento_gateway_2 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_gateway_pagamento_status ADD CONSTRAINT fk_saas_gateway_pagamento_status_1 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_gateway_pagamento_status ADD CONSTRAINT fk_saas_gateway_pagamento_status_2 FOREIGN KEY (saas_status_pagamento_id) references saas_status_pagamento(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_6 FOREIGN KEY (saas_pagamento_id) references saas_pagamento(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_2 FOREIGN KEY (cidade_prestador_id) references cidade(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_3 FOREIGN KEY (municipio_prestacao_servico_id) references cidade(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_4 FOREIGN KEY (nota_fiscal_status_id) references nota_fiscal_status(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_5 FOREIGN KEY (saas_plano_valor_id) references saas_plano_valor(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_7 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_1 FOREIGN KEY (cidade_tomador_id) references cidade(id); 
ALTER TABLE saas_nota_fiscal_servico ADD CONSTRAINT fk_saas_nota_fiscal_servico_8 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_1 FOREIGN KEY (saas_status_pagamento_id) references saas_status_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_2 FOREIGN KEY (saas_contrato_id) references saas_contrato(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_3 FOREIGN KEY (saas_forma_pagamento_id) references saas_forma_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_4 FOREIGN KEY (saas_gateway_pagamento_id) references saas_gateway_pagamento(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_5 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_6 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE saas_pagamento ADD CONSTRAINT fk_saas_pagamento_7 FOREIGN KEY (saas_nota_fiscal_servico_id) references saas_nota_fiscal_servico(id); 
ALTER TABLE saas_plano ADD CONSTRAINT fk_saas_plano_1 FOREIGN KEY (saas_servico_id) references saas_servico(id); 
ALTER TABLE saas_plano_grupo ADD CONSTRAINT fk_saas_plano_grupo_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE saas_plano_grupo ADD CONSTRAINT fk_saas_plano_grupo_2 FOREIGN KEY (saas_plano_id) references saas_plano(id); 
ALTER TABLE saas_plano_valor ADD CONSTRAINT fk_saas_plano_valor_1 FOREIGN KEY (saas_plano_id) references saas_plano(id); 
ALTER TABLE saas_servico ADD CONSTRAINT fk_saas_servico_2 FOREIGN KEY (servico_grupo_imposto_id) references saas_servico_grupo_imposto(id); 
ALTER TABLE saas_servico_grupo_imposto_item ADD CONSTRAINT fk_servico_grupo_imposto_item_1 FOREIGN KEY (saas_servico_grupo_imposto_id) references saas_servico_grupo_imposto(id); 
ALTER TABLE saas_servico_grupo_imposto_item ADD CONSTRAINT fk_servico_grupo_imposto_item_2 FOREIGN KEY (saas_imposto_id) references saas_imposto(id); 
ALTER TABLE system_group_program ADD CONSTRAINT fk_system_group_program_1 FOREIGN KEY (system_program_id) references system_program(id); 
ALTER TABLE system_group_program ADD CONSTRAINT fk_system_group_program_2 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_unit ADD CONSTRAINT fk_system_unit_1 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE system_user_group ADD CONSTRAINT fk_system_user_group_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_user_group ADD CONSTRAINT fk_system_user_group_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_user_program ADD CONSTRAINT fk_system_user_program_1 FOREIGN KEY (system_program_id) references system_program(id); 
ALTER TABLE system_user_program ADD CONSTRAINT fk_system_user_program_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_user_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_user_2 FOREIGN KEY (frontpage_id) references system_program(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_users_3 FOREIGN KEY (account_id) references account(id); 
ALTER TABLE system_user_unit ADD CONSTRAINT fk_system_user_unit_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_user_unit ADD CONSTRAINT fk_system_user_unit_2 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE tipo_pedido ADD CONSTRAINT fk_tipo_pedido_1 FOREIGN KEY (categoria_id) references categoria(id); 
ALTER TABLE webhook_log ADD CONSTRAINT fk_webhook_log_1 FOREIGN KEY (gateway_pagamento_id) references saas_gateway_pagamento(id); 

 CREATE VIEW view_negociacao_timeline AS SELECT
     id as "chave",
     negociacao_id as "negociacao_id",
     dt_observacao as "dt_historico",
     'observacao' as "tipo"
 FROM negociacao_observacao

UNION ALL

SELECT
     id as "chave",
     negociacao_id as "negociacao_id",
     dt_arquivo as "dt_historico",
     'arquivo' as "tipo"
 FROM negociacao_arquivo

UNION ALL

SELECT
     id as "chave",
     negociacao_id as "negociacao_id",
     dt_atividade as "dt_historico",
     'atividade' as "tipo"
 FROM negociacao_atividade

UNION ALL

SELECT
     id as "chave",
     negociacao_id as "negociacao_id",
     dt_item as "dt_historico",
     'produto' as "tipo"
 FROM negociacao_item


UNION ALL

SELECT
     id as "chave",
     negociacao_id as "negociacao_id",
     dt_etapa as "dt_historico",
     'etapa' as "tipo"
 FROM negociacao_historico_etapa; 
 
 
 CREATE index idx_account_cidade_id on account(cidade_id); 
CREATE index idx_account_system_user_id on account(system_user_id); 
CREATE index idx_aprovador_system_user_id on aprovador(system_user_id); 
CREATE index idx_categoria_tipo_conta_id on categoria(tipo_conta_id); 
CREATE index idx_cidade_estado_id on cidade(estado_id); 
CREATE index idx_conta_tipo_conta_id on conta(tipo_conta_id); 
CREATE index idx_conta_categoria_id on conta(categoria_id); 
CREATE index idx_conta_forma_pagamento_id on conta(forma_pagamento_id); 
CREATE index idx_conta_pessoa_id on conta(pessoa_id); 
CREATE index idx_conta_pedido_venda_id on conta(pedido_venda_id); 
CREATE index idx_conta_anexo_conta_id on conta_anexo(conta_id); 
CREATE index idx_conta_anexo_tipo_anexo_id on conta_anexo(tipo_anexo_id); 
CREATE index idx_estado_pedido_venda_aprovador_estado_pedido_venda_id on estado_pedido_venda_aprovador(estado_pedido_venda_id); 
CREATE index idx_estado_pedido_venda_aprovador_aprovador_id on estado_pedido_venda_aprovador(aprovador_id); 
CREATE index idx_matriz_estado_pedido_venda_estado_pedido_venda_origem_id on matriz_estado_pedido_venda(estado_pedido_venda_origem_id); 
CREATE index idx_matriz_estado_pedido_venda_estado_pedido_v_68279c4540deb on matriz_estado_pedido_venda(estado_pedido_venda_destino_id); 
CREATE index idx_negociacao_cliente_id on negociacao(cliente_id); 
CREATE index idx_negociacao_vendedor_id on negociacao(vendedor_id); 
CREATE index idx_negociacao_origem_contato_id on negociacao(origem_contato_id); 
CREATE index idx_negociacao_etapa_negociacao_id on negociacao(etapa_negociacao_id); 
CREATE index idx_negociacao_arquivo_negociacao_id on negociacao_arquivo(negociacao_id); 
CREATE index idx_negociacao_atividade_negociacao_id on negociacao_atividade(negociacao_id); 
CREATE index idx_negociacao_atividade_tipo_atividade_id on negociacao_atividade(tipo_atividade_id); 
CREATE index idx_negociacao_historico_etapa_negociacao_id on negociacao_historico_etapa(negociacao_id); 
CREATE index idx_negociacao_historico_etapa_etapa_negociacao_id on negociacao_historico_etapa(etapa_negociacao_id); 
CREATE index idx_negociacao_item_negociacao_id on negociacao_item(negociacao_id); 
CREATE index idx_negociacao_item_produto_id on negociacao_item(produto_id); 
CREATE index idx_negociacao_observacao_negociacao_id on negociacao_observacao(negociacao_id); 
CREATE index idx_nota_fiscal_pedido_venda_id on nota_fiscal(pedido_venda_id); 
CREATE index idx_nota_fiscal_cliente_id on nota_fiscal(cliente_id); 
CREATE index idx_nota_fiscal_condicao_pagamento_id on nota_fiscal(condicao_pagamento_id); 
CREATE index idx_nota_fiscal_item_pedido_venda_item_id on nota_fiscal_item(pedido_venda_item_id); 
CREATE index idx_nota_fiscal_item_nota_fiscal_id on nota_fiscal_item(nota_fiscal_id); 
CREATE index idx_nota_fiscal_item_produto_id on nota_fiscal_item(produto_id); 
CREATE index idx_ouvidoria_tipo_ouvidoria_id on ouvidoria(tipo_ouvidoria_id); 
CREATE index idx_pedido_venda_cliente_id on pedido_venda(cliente_id); 
CREATE index idx_pedido_venda_vendedor_id on pedido_venda(vendedor_id); 
CREATE index idx_pedido_venda_estado_pedido_venda_id on pedido_venda(estado_pedido_venda_id); 
CREATE index idx_pedido_venda_condicao_pagamento_id on pedido_venda(condicao_pagamento_id); 
CREATE index idx_pedido_venda_transportadora_id on pedido_venda(transportadora_id); 
CREATE index idx_pedido_venda_tipo_pedido_id on pedido_venda(tipo_pedido_id); 
CREATE index idx_pedido_venda_negociacao_id on pedido_venda(negociacao_id); 
CREATE index idx_pedido_venda_historico_pedido_venda_id on pedido_venda_historico(pedido_venda_id); 
CREATE index idx_pedido_venda_historico_estado_pedido_venda_id on pedido_venda_historico(estado_pedido_venda_id); 
CREATE index idx_pedido_venda_historico_aprovador_id on pedido_venda_historico(aprovador_id); 
CREATE index idx_pedido_venda_item_produto_id on pedido_venda_item(produto_id); 
CREATE index idx_pedido_venda_item_pedido_venda_id on pedido_venda_item(pedido_venda_id); 
CREATE index idx_pessoa_tipo_cliente_id on pessoa(tipo_cliente_id); 
CREATE index idx_pessoa_categoria_cliente_id on pessoa(categoria_cliente_id); 
CREATE index idx_pessoa_system_user_id on pessoa(system_user_id); 
CREATE index idx_pessoa_contato_pessoa_id on pessoa_contato(pessoa_id); 
CREATE index idx_pessoa_endereco_pessoa_id on pessoa_endereco(pessoa_id); 
CREATE index idx_pessoa_endereco_cidade_id on pessoa_endereco(cidade_id); 
CREATE index idx_pessoa_grupo_pessoa_id on pessoa_grupo(pessoa_id); 
CREATE index idx_pessoa_grupo_grupo_pessoa_id on pessoa_grupo(grupo_pessoa_id); 
CREATE index idx_produto_tipo_produto_id on produto(tipo_produto_id); 
CREATE index idx_produto_familia_produto_id on produto(familia_produto_id); 
CREATE index idx_produto_fabricante_id on produto(fabricante_id); 
CREATE index idx_produto_unidade_medida_id on produto(unidade_medida_id); 
CREATE index idx_produto_fornecedor_id on produto(fornecedor_id); 
CREATE index idx_saas_configuracao_cidade_id on saas_configuracao(cidade_id); 
CREATE index idx_saas_configuracao_saas_plano_valor_trial_id on saas_configuracao(saas_plano_valor_trial_id); 
CREATE index idx_saas_configuracao_contrato_inativo_system_group_id on saas_configuracao(contrato_inativo_system_group_id); 
CREATE index idx_saas_contrato_account_id on saas_contrato(account_id); 
CREATE index idx_saas_contrato_saas_contrato_status_id on saas_contrato(saas_contrato_status_id); 
CREATE index idx_saas_contrato_saas_plano_valor_id on saas_contrato(saas_plano_valor_id); 
CREATE index idx_saas_contrato_grupo_system_group_id on saas_contrato_grupo(system_group_id); 
CREATE index idx_saas_contrato_grupo_saas_contrato_id on saas_contrato_grupo(saas_contrato_id); 
CREATE index idx_saas_error_log_system_unit_id on saas_error_log(system_unit_id); 
CREATE index idx_saas_error_log_system_user_id on saas_error_log(system_user_id); 
CREATE index idx_saas_gateway_forma_pagamento_saas_forma_pagamento_id on saas_gateway_forma_pagamento(saas_forma_pagamento_id); 
CREATE index idx_saas_gateway_forma_pagamento_saas_gateway_pagamento_id on saas_gateway_forma_pagamento(saas_gateway_pagamento_id); 
CREATE index idx_saas_gateway_pagamento_status_saas_gateway_pagamento_id on saas_gateway_pagamento_status(saas_gateway_pagamento_id); 
CREATE index idx_saas_gateway_pagamento_status_saas_status_pagamento_id on saas_gateway_pagamento_status(saas_status_pagamento_id); 
CREATE index idx_saas_nota_fiscal_servico_saas_pagamento_id on saas_nota_fiscal_servico(saas_pagamento_id); 
CREATE index idx_saas_nota_fiscal_servico_cidade_prestador_id on saas_nota_fiscal_servico(cidade_prestador_id); 
CREATE index idx_saas_nota_fiscal_servico_municipio_prestacao_servico_id on saas_nota_fiscal_servico(municipio_prestacao_servico_id); 
CREATE index idx_saas_nota_fiscal_servico_nota_fiscal_status_id on saas_nota_fiscal_servico(nota_fiscal_status_id); 
CREATE index idx_saas_nota_fiscal_servico_saas_plano_valor_id on saas_nota_fiscal_servico(saas_plano_valor_id); 
CREATE index idx_saas_nota_fiscal_servico_saas_servico_id on saas_nota_fiscal_servico(saas_servico_id); 
CREATE index idx_saas_nota_fiscal_servico_cidade_tomador_id on saas_nota_fiscal_servico(cidade_tomador_id); 
CREATE index idx_saas_nota_fiscal_servico_account_id on saas_nota_fiscal_servico(account_id); 
CREATE index idx_saas_pagamento_saas_status_pagamento_id on saas_pagamento(saas_status_pagamento_id); 
CREATE index idx_saas_pagamento_saas_contrato_id on saas_pagamento(saas_contrato_id); 
CREATE index idx_saas_pagamento_saas_forma_pagamento_id on saas_pagamento(saas_forma_pagamento_id); 
CREATE index idx_saas_pagamento_saas_gateway_pagamento_id on saas_pagamento(saas_gateway_pagamento_id); 
CREATE index idx_saas_pagamento_saas_servico_id on saas_pagamento(saas_servico_id); 
CREATE index idx_saas_pagamento_account_id on saas_pagamento(account_id); 
CREATE index idx_saas_pagamento_saas_nota_fiscal_servico_id on saas_pagamento(saas_nota_fiscal_servico_id); 
CREATE index idx_saas_plano_saas_servico_id on saas_plano(saas_servico_id); 
CREATE index idx_saas_plano_grupo_system_group_id on saas_plano_grupo(system_group_id); 
CREATE index idx_saas_plano_grupo_saas_plano_id on saas_plano_grupo(saas_plano_id); 
CREATE index idx_saas_plano_valor_saas_plano_id on saas_plano_valor(saas_plano_id); 
CREATE index idx_saas_servico_servico_grupo_imposto_id on saas_servico(servico_grupo_imposto_id); 
CREATE index idx_saas_servico_grupo_imposto_item_saas_servi_68279c454781d on saas_servico_grupo_imposto_item(saas_servico_grupo_imposto_id); 
CREATE index idx_saas_servico_grupo_imposto_item_saas_imposto_id on saas_servico_grupo_imposto_item(saas_imposto_id); 
CREATE index idx_system_group_program_system_program_id on system_group_program(system_program_id); 
CREATE index idx_system_group_program_system_group_id on system_group_program(system_group_id); 
CREATE index idx_system_unit_account_id on system_unit(account_id); 
CREATE index idx_system_user_group_system_group_id on system_user_group(system_group_id); 
CREATE index idx_system_user_group_system_user_id on system_user_group(system_user_id); 
CREATE index idx_system_user_program_system_program_id on system_user_program(system_program_id); 
CREATE index idx_system_user_program_system_user_id on system_user_program(system_user_id); 
CREATE index idx_system_users_system_unit_id on system_users(system_unit_id); 
CREATE index idx_system_users_frontpage_id on system_users(frontpage_id); 
CREATE index idx_system_users_account_id on system_users(account_id); 
CREATE index idx_system_user_unit_system_user_id on system_user_unit(system_user_id); 
CREATE index idx_system_user_unit_system_unit_id on system_user_unit(system_unit_id); 
CREATE index idx_tipo_pedido_categoria_id on tipo_pedido(categoria_id); 
CREATE index idx_webhook_log_gateway_pagamento_id on webhook_log(gateway_pagamento_id); 
