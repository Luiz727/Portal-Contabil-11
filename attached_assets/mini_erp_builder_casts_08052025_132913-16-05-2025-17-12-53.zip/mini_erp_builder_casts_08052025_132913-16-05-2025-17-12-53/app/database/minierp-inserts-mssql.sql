SET IDENTITY_INSERT account ON; 

INSERT INTO account (id,cidade_id,system_user_id,nome_responsavel,razao_social,tipo_pessoa,documento,email,telefone,cep,rua,numero,complemento,bairro,mes_criacao,ano_criacao,created_at) VALUES (1,1,1,'Administrador','Administrador','F','','admin@admin.com','','','','','','',null,null,null); 

INSERT INTO account (id,cidade_id,system_user_id,nome_responsavel,razao_social,tipo_pessoa,documento,email,telefone,cep,rua,numero,complemento,bairro,mes_criacao,ano_criacao,created_at) VALUES (2,1,null,'Juca Bala','Juca Bala','','','','','','','','','',null,null,null); 

SET IDENTITY_INSERT account OFF; 

SET IDENTITY_INSERT aprovador ON; 

INSERT INTO aprovador (id,system_user_id) VALUES (1,1); 

INSERT INTO aprovador (id,system_user_id) VALUES (2,2); 

SET IDENTITY_INSERT aprovador OFF; 

SET IDENTITY_INSERT categoria ON; 

INSERT INTO categoria (id,tipo_conta_id,nome) VALUES (1,1,'Vendas de mercadorias'); 

INSERT INTO categoria (id,tipo_conta_id,nome) VALUES (2,1,'Vendas de produtos'); 

INSERT INTO categoria (id,tipo_conta_id,nome) VALUES (3,1,'Venda de insumos'); 

INSERT INTO categoria (id,tipo_conta_id,nome) VALUES (4,1,'Serviços de manutenção'); 

INSERT INTO categoria (id,tipo_conta_id,nome) VALUES (5,1,'Receitas financeiras'); 

INSERT INTO categoria (id,tipo_conta_id,nome) VALUES (6,2,'Compras de matérias primas'); 

INSERT INTO categoria (id,tipo_conta_id,nome) VALUES (7,2,'Compras de insumos'); 

INSERT INTO categoria (id,tipo_conta_id,nome) VALUES (8,2,'Pagamento de salários'); 

INSERT INTO categoria (id,tipo_conta_id,nome) VALUES (9,2,'Investimentos em imobilizado'); 

INSERT INTO categoria (id,tipo_conta_id,nome) VALUES (10,2,'Despesas administrativas'); 

INSERT INTO categoria (id,tipo_conta_id,nome) VALUES (11,2,'Despesas comerciais'); 

SET IDENTITY_INSERT categoria OFF; 

SET IDENTITY_INSERT categoria_cliente ON; 

INSERT INTO categoria_cliente (id,nome) VALUES (1,'Supermercado'); 

INSERT INTO categoria_cliente (id,nome) VALUES (2,'Posto de gasolina'); 

INSERT INTO categoria_cliente (id,nome) VALUES (3,'Igreja'); 

INSERT INTO categoria_cliente (id,nome) VALUES (4,'Escola'); 

INSERT INTO categoria_cliente (id,nome) VALUES (5,'Consumidor final'); 

INSERT INTO categoria_cliente (id,nome) VALUES (6,'Fornecedor'); 

INSERT INTO categoria_cliente (id,nome) VALUES (7,'Vendedor'); 

SET IDENTITY_INSERT categoria_cliente OFF; 

SET IDENTITY_INSERT cidade ON; 

INSERT INTO cidade (id,estado_id,nome,codigo_ibge) VALUES (1,1,'Lajeado','123123'); 

SET IDENTITY_INSERT cidade OFF; 

SET IDENTITY_INSERT condicao_pagamento ON; 

INSERT INTO condicao_pagamento (id,nome,numero_parcelas,inicio,intervalo) VALUES (1,'À vista',1,0,0); 

INSERT INTO condicao_pagamento (id,nome,numero_parcelas,inicio,intervalo) VALUES (2,'Entrada + 1',2,0,30); 

INSERT INTO condicao_pagamento (id,nome,numero_parcelas,inicio,intervalo) VALUES (3,'Entrada + 2',3,0,30); 

INSERT INTO condicao_pagamento (id,nome,numero_parcelas,inicio,intervalo) VALUES (4,'1x sem entrada',1,30,30); 

INSERT INTO condicao_pagamento (id,nome,numero_parcelas,inicio,intervalo) VALUES (5,'2x sem entrada',2,30,30); 

INSERT INTO condicao_pagamento (id,nome,numero_parcelas,inicio,intervalo) VALUES (6,'3x sem entrada',3,30,30); 

SET IDENTITY_INSERT condicao_pagamento OFF; 

SET IDENTITY_INSERT conta ON; 

INSERT INTO conta (id,pessoa_id,tipo_conta_id,categoria_id,forma_pagamento_id,pedido_venda_id,dt_vencimento,dt_emissao,dt_pagamento,valor,parcela,obs,mes_vencimento,ano_vencimento,ano_mes_vencimento,mes_emissao,ano_emissao,ano_mes_emissao,mes_pagamento,ano_pagamento,ano_mes_pagamento,created_at,updated_at,deleted_at) VALUES (1,1,2,8,1,null,'2022-07-20','2022-07-20',null,150,1,'',null,null,null,null,null,null,null,null,null,null,null,null); 

INSERT INTO conta (id,pessoa_id,tipo_conta_id,categoria_id,forma_pagamento_id,pedido_venda_id,dt_vencimento,dt_emissao,dt_pagamento,valor,parcela,obs,mes_vencimento,ano_vencimento,ano_mes_vencimento,mes_emissao,ano_emissao,ano_mes_emissao,mes_pagamento,ano_pagamento,ano_mes_pagamento,created_at,updated_at,deleted_at) VALUES (2,1,2,6,2,null,'2022-07-21','2022-07-20',null,250,1,'',null,null,null,null,null,null,null,null,null,null,null,null); 

INSERT INTO conta (id,pessoa_id,tipo_conta_id,categoria_id,forma_pagamento_id,pedido_venda_id,dt_vencimento,dt_emissao,dt_pagamento,valor,parcela,obs,mes_vencimento,ano_vencimento,ano_mes_vencimento,mes_emissao,ano_emissao,ano_mes_emissao,mes_pagamento,ano_pagamento,ano_mes_pagamento,created_at,updated_at,deleted_at) VALUES (3,1,2,11,3,null,'2022-07-30','2022-07-01',null,300,1,'',null,null,null,null,null,null,null,null,null,null,null,null); 

INSERT INTO conta (id,pessoa_id,tipo_conta_id,categoria_id,forma_pagamento_id,pedido_venda_id,dt_vencimento,dt_emissao,dt_pagamento,valor,parcela,obs,mes_vencimento,ano_vencimento,ano_mes_vencimento,mes_emissao,ano_emissao,ano_mes_emissao,mes_pagamento,ano_pagamento,ano_mes_pagamento,created_at,updated_at,deleted_at) VALUES (4,1,2,10,1,null,'2022-07-30','2022-07-01',null,400,1,'',null,null,null,null,null,null,null,null,null,null,null,null); 

SET IDENTITY_INSERT conta OFF; 

SET IDENTITY_INSERT email_template ON; 

INSERT INTO email_template (id,titulo,mensagem,created_at,updated_at,deleted_at) VALUES (1,'Atualização do Pedido #{id}','O pedido #{id} foi atualizado para o estado {estado_pedido_venda->nome}.',null,null,null); 

INSERT INTO email_template (id,titulo,mensagem,created_at,updated_at,deleted_at) VALUES (2,'Pedido #{id} aguardando aprovação','O pedido #{id} está aguardando a sua aprovação.',null,null,null); 

INSERT INTO email_template (id,titulo,mensagem,created_at,updated_at,deleted_at) VALUES (3,'Pedido {id} confirmado','Olá {nome} o seu pedido {id} feito na data {data_pedido} foi confirmado com os seguintes itens: <br><br> {itens_pedido}',null,null,null); 

SET IDENTITY_INSERT email_template OFF; 

SET IDENTITY_INSERT estado ON; 

INSERT INTO estado (id,nome,sigla,codigo_ibge) VALUES (1,'Rio Grande do Sul','RS',''); 

SET IDENTITY_INSERT estado OFF; 

SET IDENTITY_INSERT estado_pedido_venda ON; 

INSERT INTO estado_pedido_venda (id,nome,cor,kanban,ordem,estado_final,estado_inicial,permite_edicao,permite_exclusao,created_at,updated_at,deleted_at) VALUES (1,'Elaboração','#81ecec','T',1,'F','T','T','T',null,null,null); 

INSERT INTO estado_pedido_venda (id,nome,cor,kanban,ordem,estado_final,estado_inicial,permite_edicao,permite_exclusao,created_at,updated_at,deleted_at) VALUES (2,'Análise comercial','#fd79a8','T',2,'F','F','T','T',null,null,null); 

INSERT INTO estado_pedido_venda (id,nome,cor,kanban,ordem,estado_final,estado_inicial,permite_edicao,permite_exclusao,created_at,updated_at,deleted_at) VALUES (3,'Análise de crédito','#f1c40f','T',3,'F','F','T','T',null,null,null); 

INSERT INTO estado_pedido_venda (id,nome,cor,kanban,ordem,estado_final,estado_inicial,permite_edicao,permite_exclusao,created_at,updated_at,deleted_at) VALUES (4,'Processamento','#3498db','T',4,'F','F','F','F',null,null,null); 

INSERT INTO estado_pedido_venda (id,nome,cor,kanban,ordem,estado_final,estado_inicial,permite_edicao,permite_exclusao,created_at,updated_at,deleted_at) VALUES (6,'Faturamento','#8e44ad','T',6,'F','F','F','F',null,null,null); 

INSERT INTO estado_pedido_venda (id,nome,cor,kanban,ordem,estado_final,estado_inicial,permite_edicao,permite_exclusao,created_at,updated_at,deleted_at) VALUES (7,'Aguardando entrega','#f39c12','T',7,'F','F','F','F',null,null,null); 

INSERT INTO estado_pedido_venda (id,nome,cor,kanban,ordem,estado_final,estado_inicial,permite_edicao,permite_exclusao,created_at,updated_at,deleted_at) VALUES (8,'Finalizado','#2ecc71','T',8,'T','F','F','F',null,null,null); 

INSERT INTO estado_pedido_venda (id,nome,cor,kanban,ordem,estado_final,estado_inicial,permite_edicao,permite_exclusao,created_at,updated_at,deleted_at) VALUES (9,'Cancelado','#e74c3c','F',null,'T','F','F','F',null,null,null); 

INSERT INTO estado_pedido_venda (id,nome,cor,kanban,ordem,estado_final,estado_inicial,permite_edicao,permite_exclusao,created_at,updated_at,deleted_at) VALUES (10,'Reprovado','#c0392b','F',null,'T','F','F','F',null,null,null); 

INSERT INTO estado_pedido_venda (id,nome,cor,kanban,ordem,estado_final,estado_inicial,permite_edicao,permite_exclusao,created_at,updated_at,deleted_at) VALUES (5,'Gerando Financeiro','#44bd32','T',5,'F','F','F','F',null,null,null); 

SET IDENTITY_INSERT estado_pedido_venda OFF; 

SET IDENTITY_INSERT estado_pedido_venda_aprovador ON; 

INSERT INTO estado_pedido_venda_aprovador (id,estado_pedido_venda_id,aprovador_id) VALUES (1,1,1); 

INSERT INTO estado_pedido_venda_aprovador (id,estado_pedido_venda_id,aprovador_id) VALUES (2,2,2); 

INSERT INTO estado_pedido_venda_aprovador (id,estado_pedido_venda_id,aprovador_id) VALUES (3,2,1); 

INSERT INTO estado_pedido_venda_aprovador (id,estado_pedido_venda_id,aprovador_id) VALUES (4,3,1); 

INSERT INTO estado_pedido_venda_aprovador (id,estado_pedido_venda_id,aprovador_id) VALUES (5,4,1); 

INSERT INTO estado_pedido_venda_aprovador (id,estado_pedido_venda_id,aprovador_id) VALUES (6,5,1); 

INSERT INTO estado_pedido_venda_aprovador (id,estado_pedido_venda_id,aprovador_id) VALUES (7,6,1); 

INSERT INTO estado_pedido_venda_aprovador (id,estado_pedido_venda_id,aprovador_id) VALUES (8,7,1); 

SET IDENTITY_INSERT estado_pedido_venda_aprovador OFF; 

SET IDENTITY_INSERT etapa_negociacao ON; 

INSERT INTO etapa_negociacao (id,nome,cor,ordem,roteiro,kanban,permite_edicao,permite_exclusao) VALUES (1,'Prospectar','#1abc9c',1,'','T','T','T'); 

INSERT INTO etapa_negociacao (id,nome,cor,ordem,roteiro,kanban,permite_edicao,permite_exclusao) VALUES (2,'Qualificar','#2ecc71',2,'','T','T','T'); 

INSERT INTO etapa_negociacao (id,nome,cor,ordem,roteiro,kanban,permite_edicao,permite_exclusao) VALUES (3,'Levantar necessidades','#3498db',3,'','T','T','T'); 

INSERT INTO etapa_negociacao (id,nome,cor,ordem,roteiro,kanban,permite_edicao,permite_exclusao) VALUES (4,'Elaborar proposta','#9b59b6',4,'','T','T','T'); 

INSERT INTO etapa_negociacao (id,nome,cor,ordem,roteiro,kanban,permite_edicao,permite_exclusao) VALUES (5,'FollowUp (Cobrar feedback)','#e67e22',5,'','T','T','T'); 

INSERT INTO etapa_negociacao (id,nome,cor,ordem,roteiro,kanban,permite_edicao,permite_exclusao) VALUES (6,'Iniciar negociacão','#f1c40f',6,'','T','T','T'); 

INSERT INTO etapa_negociacao (id,nome,cor,ordem,roteiro,kanban,permite_edicao,permite_exclusao) VALUES (7,'Negociacão finalizada','#2ecc71',7,'','T','F','F'); 

INSERT INTO etapa_negociacao (id,nome,cor,ordem,roteiro,kanban,permite_edicao,permite_exclusao) VALUES (8,'Negociacão cancelada','#c0392b',8,'','F','F','F'); 

SET IDENTITY_INSERT etapa_negociacao OFF; 

SET IDENTITY_INSERT fabricante ON; 

INSERT INTO fabricante (id,nome) VALUES (1,'Apple'); 

INSERT INTO fabricante (id,nome) VALUES (2,'LG'); 

INSERT INTO fabricante (id,nome) VALUES (3,'Samsung'); 

INSERT INTO fabricante (id,nome) VALUES (4,'Sony'); 

INSERT INTO fabricante (id,nome) VALUES (5,'Nikon'); 

INSERT INTO fabricante (id,nome) VALUES (6,'Dell'); 

SET IDENTITY_INSERT fabricante OFF; 

SET IDENTITY_INSERT familia_produto ON; 

INSERT INTO familia_produto (id,nome) VALUES (1,'Games'); 

INSERT INTO familia_produto (id,nome) VALUES (2,'Cadeiras'); 

INSERT INTO familia_produto (id,nome) VALUES (3,'Computadores'); 

INSERT INTO familia_produto (id,nome) VALUES (4,'Tablets'); 

INSERT INTO familia_produto (id,nome) VALUES (5,'Smartphones'); 

INSERT INTO familia_produto (id,nome) VALUES (6,'Tvs'); 

INSERT INTO familia_produto (id,nome) VALUES (7,'Audio'); 

INSERT INTO familia_produto (id,nome) VALUES (8,'Camêras'); 

SET IDENTITY_INSERT familia_produto OFF; 

SET IDENTITY_INSERT forma_pagamento ON; 

INSERT INTO forma_pagamento (id,nome) VALUES (1,'Dinheiro'); 

INSERT INTO forma_pagamento (id,nome) VALUES (2,'Boleto'); 

INSERT INTO forma_pagamento (id,nome) VALUES (3,'Cartão'); 

SET IDENTITY_INSERT forma_pagamento OFF; 

SET IDENTITY_INSERT grupo_pessoa ON; 

INSERT INTO grupo_pessoa (id,nome) VALUES (1,'Funcionário'); 

INSERT INTO grupo_pessoa (id,nome) VALUES (2,'Vendedor'); 

INSERT INTO grupo_pessoa (id,nome) VALUES (3,'Cliente'); 

INSERT INTO grupo_pessoa (id,nome) VALUES (4,'Fornecedor'); 

INSERT INTO grupo_pessoa (id,nome) VALUES (5,'Distribuidor'); 

INSERT INTO grupo_pessoa (id,nome) VALUES (6,'Revendedor'); 

INSERT INTO grupo_pessoa (id,nome) VALUES (7,'Transportadora'); 

SET IDENTITY_INSERT grupo_pessoa OFF; 

SET IDENTITY_INSERT matriz_estado_pedido_venda ON; 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (1,1,2); 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (2,1,8); 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (3,1,9); 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (4,2,3); 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (5,2,9); 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (6,3,4); 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (7,3,9); 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (8,4,5); 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (9,4,9); 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (10,6,7); 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (11,7,8); 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (12,5,6); 

INSERT INTO matriz_estado_pedido_venda (id,estado_pedido_venda_origem_id,estado_pedido_venda_destino_id) VALUES (13,5,9); 

SET IDENTITY_INSERT matriz_estado_pedido_venda OFF; 

SET IDENTITY_INSERT nota_fiscal_status ON; 

INSERT INTO nota_fiscal_status (id,nome,cor) VALUES (1,'Pendente','#95a5a6'); 

INSERT INTO nota_fiscal_status (id,nome,cor) VALUES (2,'Enviada','#3498db'); 

INSERT INTO nota_fiscal_status (id,nome,cor) VALUES (3,'Autorizada','#2ecc71'); 

INSERT INTO nota_fiscal_status (id,nome,cor) VALUES (4,'Cancelada','#2c3e50'); 

INSERT INTO nota_fiscal_status (id,nome,cor) VALUES (5,'Rejeitada','#e74c3c'); 

INSERT INTO nota_fiscal_status (id,nome,cor) VALUES (6,'Em processamento','#9b59b6'); 

SET IDENTITY_INSERT nota_fiscal_status OFF; 

SET IDENTITY_INSERT origem_contato ON; 

INSERT INTO origem_contato (id,nome) VALUES (1,'Anúncio Facebook'); 

INSERT INTO origem_contato (id,nome) VALUES (2,'Anúncio Google Ads'); 

INSERT INTO origem_contato (id,nome) VALUES (3,'Indicacão'); 

SET IDENTITY_INSERT origem_contato OFF; 

SET IDENTITY_INSERT pedido_venda ON; 

INSERT INTO pedido_venda (id,tipo_pedido_id,cliente_id,vendedor_id,estado_pedido_venda_id,condicao_pagamento_id,transportadora_id,negociacao_id,dt_pedido,obs,frete,mes,ano,valor_total,created_at,updated_at,deleted_at,obs_comercial,obs_financeiro) VALUES (1,1,1,2,1,1,4,null,null,'',null,'','',5000,null,null,null,'',''); 

INSERT INTO pedido_venda (id,tipo_pedido_id,cliente_id,vendedor_id,estado_pedido_venda_id,condicao_pagamento_id,transportadora_id,negociacao_id,dt_pedido,obs,frete,mes,ano,valor_total,created_at,updated_at,deleted_at,obs_comercial,obs_financeiro) VALUES (2,1,1,2,2,2,4,null,null,'',null,'','',10000,null,null,null,'',''); 

INSERT INTO pedido_venda (id,tipo_pedido_id,cliente_id,vendedor_id,estado_pedido_venda_id,condicao_pagamento_id,transportadora_id,negociacao_id,dt_pedido,obs,frete,mes,ano,valor_total,created_at,updated_at,deleted_at,obs_comercial,obs_financeiro) VALUES (3,1,1,2,3,2,4,null,null,'',null,'','',150000,null,null,null,'',''); 

INSERT INTO pedido_venda (id,tipo_pedido_id,cliente_id,vendedor_id,estado_pedido_venda_id,condicao_pagamento_id,transportadora_id,negociacao_id,dt_pedido,obs,frete,mes,ano,valor_total,created_at,updated_at,deleted_at,obs_comercial,obs_financeiro) VALUES (4,1,1,2,4,1,4,null,null,'',null,'','',250000,null,null,null,'',''); 

INSERT INTO pedido_venda (id,tipo_pedido_id,cliente_id,vendedor_id,estado_pedido_venda_id,condicao_pagamento_id,transportadora_id,negociacao_id,dt_pedido,obs,frete,mes,ano,valor_total,created_at,updated_at,deleted_at,obs_comercial,obs_financeiro) VALUES (5,1,1,2,5,1,4,null,null,'',null,'','',30000,null,null,null,'',''); 

INSERT INTO pedido_venda (id,tipo_pedido_id,cliente_id,vendedor_id,estado_pedido_venda_id,condicao_pagamento_id,transportadora_id,negociacao_id,dt_pedido,obs,frete,mes,ano,valor_total,created_at,updated_at,deleted_at,obs_comercial,obs_financeiro) VALUES (6,1,1,2,6,2,4,null,null,'',null,'','',4500,null,null,null,'',''); 

SET IDENTITY_INSERT pedido_venda OFF; 

SET IDENTITY_INSERT pedido_venda_historico ON; 

INSERT INTO pedido_venda_historico (id,pedido_venda_id,estado_pedido_venda_id,aprovador_id,data_operacao,obs) VALUES (1,5,1,1,'2022-05-08','Tudo certo, pode seguir!'); 

INSERT INTO pedido_venda_historico (id,pedido_venda_id,estado_pedido_venda_id,aprovador_id,data_operacao,obs) VALUES (2,5,2,1,'2022-05-08','Comercial OK'); 

INSERT INTO pedido_venda_historico (id,pedido_venda_id,estado_pedido_venda_id,aprovador_id,data_operacao,obs) VALUES (3,5,3,1,'2022-05-09','Cliente possui bastante crédito aprovado'); 

INSERT INTO pedido_venda_historico (id,pedido_venda_id,estado_pedido_venda_id,aprovador_id,data_operacao,obs) VALUES (4,5,4,1,'2022-05-09','Processado com Sucesso!'); 

INSERT INTO pedido_venda_historico (id,pedido_venda_id,estado_pedido_venda_id,aprovador_id,data_operacao,obs) VALUES (5,5,5,1,'2022-05-10','Faturado Ok!'); 

SET IDENTITY_INSERT pedido_venda_historico OFF; 

SET IDENTITY_INSERT pessoa ON; 

INSERT INTO pessoa (id,tipo_cliente_id,categoria_cliente_id,system_user_id,nome,documento,obs,fone,email,created_at,updated_at,deleted_at,login,senha) VALUES (1,1,5,null,'Cliente 01','111.111.111-11','','(51) 9 9813-1234','cliente@cliente.com.br',null,null,null,null,null); 

INSERT INTO pessoa (id,tipo_cliente_id,categoria_cliente_id,system_user_id,nome,documento,obs,fone,email,created_at,updated_at,deleted_at,login,senha) VALUES (2,1,7,1,'Vendedor 01','1111111','','','',null,null,null,null,null); 

INSERT INTO pessoa (id,tipo_cliente_id,categoria_cliente_id,system_user_id,nome,documento,obs,fone,email,created_at,updated_at,deleted_at,login,senha) VALUES (3,2,6,null,'Fornecedor 01','1111111','','','',null,null,null,null,null); 

INSERT INTO pessoa (id,tipo_cliente_id,categoria_cliente_id,system_user_id,nome,documento,obs,fone,email,created_at,updated_at,deleted_at,login,senha) VALUES (4,2,null,null,'Transportadora','111111111','','','',null,null,null,null,null); 

SET IDENTITY_INSERT pessoa OFF; 

SET IDENTITY_INSERT pessoa_grupo ON; 

INSERT INTO pessoa_grupo (id,pessoa_id,grupo_pessoa_id) VALUES (1,1,3); 

INSERT INTO pessoa_grupo (id,pessoa_id,grupo_pessoa_id) VALUES (2,2,2); 

INSERT INTO pessoa_grupo (id,pessoa_id,grupo_pessoa_id) VALUES (3,3,4); 

INSERT INTO pessoa_grupo (id,pessoa_id,grupo_pessoa_id) VALUES (4,4,7); 

SET IDENTITY_INSERT pessoa_grupo OFF; 

SET IDENTITY_INSERT produto ON; 

INSERT INTO produto (id,tipo_produto_id,familia_produto_id,fornecedor_id,unidade_medida_id,fabricante_id,nome,cod_barras,preco_venda,preco_custo,peso_liquido,peso_bruto,largura,altura,volume,estoque_minimo,qtde_estoque,estoque_maximo,obs,ativo,foto,data_ultimo_reajuste_preco,created_at,updated_at,deleted_at) VALUES (1,2,3,3,1,1,'Macbook','',25000,15000,null,null,null,null,null,5,3,10,'','T','',null,null,null,null); 

INSERT INTO produto (id,tipo_produto_id,familia_produto_id,fornecedor_id,unidade_medida_id,fabricante_id,nome,cod_barras,preco_venda,preco_custo,peso_liquido,peso_bruto,largura,altura,volume,estoque_minimo,qtde_estoque,estoque_maximo,obs,ativo,foto,data_ultimo_reajuste_preco,created_at,updated_at,deleted_at) VALUES (2,2,5,3,1,1,'Iphone','',5000,2500,null,null,null,null,null,5,3,10,'','T','',null,null,null,null); 

INSERT INTO produto (id,tipo_produto_id,familia_produto_id,fornecedor_id,unidade_medida_id,fabricante_id,nome,cod_barras,preco_venda,preco_custo,peso_liquido,peso_bruto,largura,altura,volume,estoque_minimo,qtde_estoque,estoque_maximo,obs,ativo,foto,data_ultimo_reajuste_preco,created_at,updated_at,deleted_at) VALUES (3,1,1,3,1,4,'Fifa 2021','',120,30,null,null,null,null,null,5,3,10,'','T','',null,null,null,null); 

INSERT INTO produto (id,tipo_produto_id,familia_produto_id,fornecedor_id,unidade_medida_id,fabricante_id,nome,cod_barras,preco_venda,preco_custo,peso_liquido,peso_bruto,largura,altura,volume,estoque_minimo,qtde_estoque,estoque_maximo,obs,ativo,foto,data_ultimo_reajuste_preco,created_at,updated_at,deleted_at) VALUES (4,1,1,3,1,4,'Fifa 2022','', 120,30,null,null,null,null,null,5,3,10,'','T','',null,null,null,null); 

INSERT INTO produto (id,tipo_produto_id,familia_produto_id,fornecedor_id,unidade_medida_id,fabricante_id,nome,cod_barras,preco_venda,preco_custo,peso_liquido,peso_bruto,largura,altura,volume,estoque_minimo,qtde_estoque,estoque_maximo,obs,ativo,foto,data_ultimo_reajuste_preco,created_at,updated_at,deleted_at) VALUES (5,1,2,3,1,2,'Cadeira Gamer','',1200,550,null,null,null,null,null,null,null,null,'','','',null,null,null,null); 

INSERT INTO produto (id,tipo_produto_id,familia_produto_id,fornecedor_id,unidade_medida_id,fabricante_id,nome,cod_barras,preco_venda,preco_custo,peso_liquido,peso_bruto,largura,altura,volume,estoque_minimo,qtde_estoque,estoque_maximo,obs,ativo,foto,data_ultimo_reajuste_preco,created_at,updated_at,deleted_at) VALUES (6,1,4,3,1,1,'Ipda PRO','',8000,5000,null,null,null,null,null,null,null,null,'','','',null,null,null,null); 

INSERT INTO produto (id,tipo_produto_id,familia_produto_id,fornecedor_id,unidade_medida_id,fabricante_id,nome,cod_barras,preco_venda,preco_custo,peso_liquido,peso_bruto,largura,altura,volume,estoque_minimo,qtde_estoque,estoque_maximo,obs,ativo,foto,data_ultimo_reajuste_preco,created_at,updated_at,deleted_at) VALUES (7,1,5,3,1,3,'Galaxy S22','',5500,3500,null,null,null,null,null,null,null,null,'','','',null,null,null,null); 

SET IDENTITY_INSERT produto OFF; 

SET IDENTITY_INSERT saas_configuracao ON; 

INSERT INTO saas_configuracao (id,cidade_id,saas_plano_valor_trial_id,contrato_inativo_system_group_id,parametro_fiscal_id,razao_social,nome_fantasia,cnpj,inscricao_estadual,inscricao_municipal,cep,rua,bairro,numero,complemento,email,telefone,dias_trial,contrato,regime_tributacao,token_integra_notas,token_integra_notas_homologacao,token_integra_notas_software_house,nfse_emissao_producao,nfse_numero,nfse_serie,nfse_info,termo_uso,email_port,email_username,email_password,email_host,email_from,email_from_name,email_smtp_auth,dias_renovacao_contrato,dias_vencimento_pagamento,url_sistema) VALUES (1,1,6,null,null,'MadSaaS','Builder Saas','','','','','','','','','builder@madbuilder.com.br','55999999999',5,'','1','','','','F','','','','','','','','','','','T',10,1,''); 

SET IDENTITY_INSERT saas_configuracao OFF; 

SET IDENTITY_INSERT saas_contrato ON; 

INSERT INTO saas_contrato (id,saas_plano_valor_id,account_id,saas_contrato_status_id,valor_total,data_inicial,data_final,criado_em,renovacao,total_usuarios,total_unidades,gateway_assinatura_id) VALUES (1,2,1,2,1000,'2024-04-01','2024-07-15',null,'F',null,null,null); 

SET IDENTITY_INSERT saas_contrato OFF; 

SET IDENTITY_INSERT saas_contrato_status ON; 

INSERT INTO saas_contrato_status (id,nome,cor) VALUES (1,'Aguardando pagamento','#3498db'); 

INSERT INTO saas_contrato_status (id,nome,cor) VALUES (2,'Ativo','#2ecc71'); 

INSERT INTO saas_contrato_status (id,nome,cor) VALUES (3,'Pagamento atrazado','#e67e22'); 

INSERT INTO saas_contrato_status (id,nome,cor) VALUES (4,'Inativo','#e74c3c'); 

SET IDENTITY_INSERT saas_contrato_status OFF; 

SET IDENTITY_INSERT saas_forma_pagamento ON; 

INSERT INTO saas_forma_pagamento (id,nome) VALUES (1,'Dinheiro'); 

INSERT INTO saas_forma_pagamento (id,nome) VALUES (2,'Boleto & Pix'); 

INSERT INTO saas_forma_pagamento (id,nome) VALUES (3,'Cartão de Crédito'); 

INSERT INTO saas_forma_pagamento (id,nome) VALUES (4,'Cartão de Débito'); 

INSERT INTO saas_forma_pagamento (id,nome) VALUES (5,'Transferência'); 

INSERT INTO saas_forma_pagamento (id,nome) VALUES (6,'Moeda digital'); 

INSERT INTO saas_forma_pagamento (id,nome) VALUES (7,'Cartão Pré-Pago'); 

SET IDENTITY_INSERT saas_forma_pagamento OFF; 

SET IDENTITY_INSERT saas_gateway_forma_pagamento ON; 

INSERT INTO saas_gateway_forma_pagamento (id,saas_forma_pagamento_id,saas_gateway_pagamento_id,codigo) VALUES (1,1,2,'account_money'); 

INSERT INTO saas_gateway_forma_pagamento (id,saas_forma_pagamento_id,saas_gateway_pagamento_id,codigo) VALUES (2,2,2,'ticket'); 

INSERT INTO saas_gateway_forma_pagamento (id,saas_forma_pagamento_id,saas_gateway_pagamento_id,codigo) VALUES (4,3,2,'credit_card'); 

INSERT INTO saas_gateway_forma_pagamento (id,saas_forma_pagamento_id,saas_gateway_pagamento_id,codigo) VALUES (5,4,2,'debit_card'); 

INSERT INTO saas_gateway_forma_pagamento (id,saas_forma_pagamento_id,saas_gateway_pagamento_id,codigo) VALUES (6,5,2,'bank_transfer'); 

INSERT INTO saas_gateway_forma_pagamento (id,saas_forma_pagamento_id,saas_gateway_pagamento_id,codigo) VALUES (7,6,2,'digital_currency'); 

INSERT INTO saas_gateway_forma_pagamento (id,saas_forma_pagamento_id,saas_gateway_pagamento_id,codigo) VALUES (8,7,2,'prepaid_card'); 

INSERT INTO saas_gateway_forma_pagamento (id,saas_forma_pagamento_id,saas_gateway_pagamento_id,codigo) VALUES (9,2,1,'boleto_pix'); 

SET IDENTITY_INSERT saas_gateway_forma_pagamento OFF; 

SET IDENTITY_INSERT saas_gateway_pagamento ON; 

INSERT INTO saas_gateway_pagamento (id,nome,ativo,public_key,access_token,client_secret,client_id,oauth_token,oauth_token_created_at,certificado_crt,certificado_key,webhook_url,webhook_certificado_cert,fl_homologacao) VALUES (1,'Banco Inter Boleto e Pix','T','','','','','',null,'','','','','T'); 

INSERT INTO saas_gateway_pagamento (id,nome,ativo,public_key,access_token,client_secret,client_id,oauth_token,oauth_token_created_at,certificado_crt,certificado_key,webhook_url,webhook_certificado_cert,fl_homologacao) VALUES (2,'Mercado Pago','T','','','','','',null,'','','','','T'); 

SET IDENTITY_INSERT saas_gateway_pagamento OFF; 

SET IDENTITY_INSERT saas_gateway_pagamento_status ON; 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (1,2,1,'pending'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (2,2,2,'approved'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (3,2,1,'inprocess'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (4,2,1,'inmediation'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (5,2,3,'rejected'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (6,2,3,'cancelled'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (7,2,4,'refunded'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (8,1,2,'RECEBIDO'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (9,1,1,'EMPROCESSAMENTO'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (10,1,6,'VENCIDO'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (11,1,2,'PAGO'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (12,1,6,'EXPIRADO'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (13,1,3,'CANCELADO'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (14,1,1,'A_RECEBER'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (15,1,2,'MARCADO_RECEBIDO'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (16,1,6,'ATRASADO'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (17,2,2,'authorized'); 

INSERT INTO saas_gateway_pagamento_status (id,saas_gateway_pagamento_id,saas_status_pagamento_id,codigo) VALUES (18,2,3,'paused'); 

SET IDENTITY_INSERT saas_gateway_pagamento_status OFF; 

SET IDENTITY_INSERT saas_imposto ON; 

INSERT INTO saas_imposto (id,nome,codigo) VALUES (1,'ISS (Valor devido)','iss'); 

INSERT INTO saas_imposto (id,nome,codigo) VALUES (2,'PIS (Retenção)','pis'); 

INSERT INTO saas_imposto (id,nome,codigo) VALUES (3,'COFINS (Retenção)','cofins'); 

INSERT INTO saas_imposto (id,nome,codigo) VALUES (4,'INSS (Retenção)','inss'); 

INSERT INTO saas_imposto (id,nome,codigo) VALUES (5,'IR (Retenção)','ir'); 

INSERT INTO saas_imposto (id,nome,codigo) VALUES (6,'CSLL (Retenção)','csll'); 

SET IDENTITY_INSERT saas_imposto OFF; 

SET IDENTITY_INSERT saas_pagamento ON; 

INSERT INTO saas_pagamento (id,account_id,saas_status_pagamento_id,saas_contrato_id,saas_servico_id,saas_forma_pagamento_id,saas_gateway_pagamento_id,saas_nota_fiscal_servico_id,valor,data_compra,data_vencimento,data_pagamento,dados_gateway,id_gateway,payment_id,link_gateway,mes_compra,ano_compra,ano_pagamento,mes_pagamento,mes_ano_pagamento,mes_ano_compra,renovacao) VALUES (1,1,2,1,1,1,2,null,1000,'2024-04-01','2024-04-10','2024-04-01','','',null,'',4,2024,2024,4,'04/2024','04/2024','F'); 

SET IDENTITY_INSERT saas_pagamento OFF; 

SET IDENTITY_INSERT saas_plano ON; 

INSERT INTO saas_plano (id,saas_servico_id,nome,descricao,ativo,limite_usuarios,limite_unidades,discriminacao,ordem) VALUES (1,1,'Standard','Plano standard','T',5,2,'Plano standard',3); 

INSERT INTO saas_plano (id,saas_servico_id,nome,descricao,ativo,limite_usuarios,limite_unidades,discriminacao,ordem) VALUES (2,1,'Enterprise','Plano enterprise','T',15,5,'Plano enterprise',2); 

INSERT INTO saas_plano (id,saas_servico_id,nome,descricao,ativo,limite_usuarios,limite_unidades,discriminacao,ordem) VALUES (3,1,'Premium','Plano premium','T',100,10,'Plano premium',1); 

INSERT INTO saas_plano (id,saas_servico_id,nome,descricao,ativo,limite_usuarios,limite_unidades,discriminacao,ordem) VALUES (4,1,'Trial','Trial teste','T',1,1,'Trial teste',4); 

SET IDENTITY_INSERT saas_plano OFF; 

SET IDENTITY_INSERT saas_plano_grupo ON; 

INSERT INTO saas_plano_grupo (id,saas_plano_id,system_group_id) VALUES (1,1,2); 

INSERT INTO saas_plano_grupo (id,saas_plano_id,system_group_id) VALUES (2,2,2); 

INSERT INTO saas_plano_grupo (id,saas_plano_id,system_group_id) VALUES (3,3,2); 

INSERT INTO saas_plano_grupo (id,saas_plano_id,system_group_id) VALUES (4,4,2); 

SET IDENTITY_INSERT saas_plano_grupo OFF; 

SET IDENTITY_INSERT saas_plano_valor ON; 

INSERT INTO saas_plano_valor (id,saas_plano_id,valor,nome,duracao,ativo,desativado_em,recorrencia) VALUES (1,1,100,'Mensal',1,null,null,null); 

INSERT INTO saas_plano_valor (id,saas_plano_id,valor,nome,duracao,ativo,desativado_em,recorrencia) VALUES (2,1,1000,'Anual',12,null,null,null); 

INSERT INTO saas_plano_valor (id,saas_plano_id,valor,nome,duracao,ativo,desativado_em,recorrencia) VALUES (3,2,200,'Mensal',1,null,null,null); 

INSERT INTO saas_plano_valor (id,saas_plano_id,valor,nome,duracao,ativo,desativado_em,recorrencia) VALUES (4,2,2000,'Anual',12,null,null,null); 

INSERT INTO saas_plano_valor (id,saas_plano_id,valor,nome,duracao,ativo,desativado_em,recorrencia) VALUES (5,3,1500,'Anual',12,null,null,null); 

INSERT INTO saas_plano_valor (id,saas_plano_id,valor,nome,duracao,ativo,desativado_em,recorrencia) VALUES (6,4,0,'Mensal',0,null,null,null); 

SET IDENTITY_INSERT saas_plano_valor OFF; 

SET IDENTITY_INSERT saas_servico ON; 

INSERT INTO saas_servico (id,servico_grupo_imposto_id,nome,preco,descricao,ativo) VALUES (1,1,'Licença Software',100,'Licença de Software','T'); 

SET IDENTITY_INSERT saas_servico OFF; 

SET IDENTITY_INSERT saas_servico_grupo_imposto ON; 

INSERT INTO saas_servico_grupo_imposto (id,nome,codigo_cnae,codigo_tributacao_municipio,codigo_nbs,codigo,descricao_servico_municipio,iss_retido,natureza_operacao) VALUES (1,'Licença Software','','1.03','','1.03','Serviços de processamento de documentos fiscais eletrônicos','',''); 

SET IDENTITY_INSERT saas_servico_grupo_imposto OFF; 

SET IDENTITY_INSERT saas_servico_grupo_imposto_item ON; 

INSERT INTO saas_servico_grupo_imposto_item (id,saas_servico_grupo_imposto_id,saas_imposto_id,aliquota) VALUES (1,1,1,3); 

SET IDENTITY_INSERT saas_servico_grupo_imposto_item OFF; 

SET IDENTITY_INSERT saas_status_pagamento ON; 

INSERT INTO saas_status_pagamento (id,nome,cor) VALUES (1,'Aguardando Pagamento','#34495e'); 

INSERT INTO saas_status_pagamento (id,nome,cor) VALUES (2,'Pago','#27ae60'); 

INSERT INTO saas_status_pagamento (id,nome,cor) VALUES (3,'Cancelado','#e74c3c'); 

INSERT INTO saas_status_pagamento (id,nome,cor) VALUES (4,'Retornado','#f39c12'); 

INSERT INTO saas_status_pagamento (id,nome,cor) VALUES (5,'Iniciado','#34495e'); 

INSERT INTO saas_status_pagamento (id,nome,cor) VALUES (6,'Rejeitado','#f39c12'); 

INSERT INTO saas_status_pagamento (id,nome,cor) VALUES (7,'Em análise','#34495e'); 

SET IDENTITY_INSERT saas_status_pagamento OFF; 

SET IDENTITY_INSERT saas_template_email ON; 

INSERT INTO saas_template_email (id,descricao,titulo,conteudo) VALUES (1,'Bem vindo','Bem-vindo ao Builder SaaS','<div style="background: #f4f4f4;font-family: Arial, Helvetica, sans-serif;color:#5a6571cf;font-size: 15px;line-height: 25px; padding-top: 40px; padding-bottom: 40px;">    <div style=max-width: 650px;margin: auto;>       <div style="text-align: center; margin-bottom: 28px;">             <img alt="logo" src="https://manager.madbuilder.com.br/app/images/logo-horizontal.png" style="max-width: 300px;">         </div>       <div style="overflow: hidden;padding: 37px;background: #fff;border: 1px solid #eee;">          <div>             <div style="color: #5a6571;padding: 0px;font-weight: 400;font-size: 33px;line-height: 36px; text-align: center;">                     {$titulo}                 </div>          </div>          <div style=text-align: justify; margin-top: 60px;>             <p>Olá {$nome}!</p>             <p> Estamos felizes em tê-lo conosco. Comece a explorar nossa plataforma e descubra como podemos ajudar você a construir e gerenciar seus projetos com facilidade. </p>             <br><br>                                                 <p>Atenciosamente,<br>Equipe Builder SaaS.</p>          </div>       </div>    </div> </div>'); 

INSERT INTO saas_template_email (id,descricao,titulo,conteudo) VALUES (2,'Criação de nota fiscal','Sua nota Fiscal Chegou','<div style="background: #f4f4f4;font-family: Arial, Helvetica, sans-serif;color:#5a6571cf;font-size: 15px;line-height: 25px; padding-top: 40px; padding-bottom: 40px;">    <div style=max-width: 650px;margin: auto;>       <div style="text-align: center; margin-bottom: 28px;">             <img alt="logo" src="https://manager.madbuilder.com.br/app/images/logo-horizontal.png" style="max-width: 300px;">         </div>       <div style="overflow: hidden;padding: 37px;background: #fff;border: 1px solid #eee;">          <div>             <div style="color: #5a6571;padding: 0px;font-weight: 400;font-size: 33px;line-height: 36px; text-align: center">                                      {$titulo}                              </div>          </div>          <div style=text-align: justify; margin-top: 60px;>             <p>Olá {$nome},</p>             <p>Informamos que sua nota fiscal referente à sua última compra no Builder SaaS está disponível em anexo.</p>             <p>Por favor, verifique o anexo para acessar a nota fiscal.</p>             <p>Se tiver alguma dúvida ou precisar de mais informações, nossa equipe de suporte está à disposição para ajudar.</p>             <p>Obrigado por escolher o Builder SaaS!</p>             <br><br>             <p>Atenciosamente,<br>Equipe Builder SaaS</p>          </div>       </div>    </div> </div>'); 

INSERT INTO saas_template_email (id,descricao,titulo,conteudo) VALUES (3,'Aviso de vencimento do plano','Aviso de Vencimento','<div style="background: #f4f4f4;font-family: Arial, Helvetica, sans-serif;color:#5a6571cf;font-size: 15px;line-height: 25px; padding-top: 40px; padding-bottom: 40px;">    <div style=max-width: 650px;margin: auto;>       <div style="text-align: center; margin-bottom: 28px;">             <img alt="logo" src="https://manager.madbuilder.com.br/app/images/logo-horizontal.png" style="max-width: 300px;">         </div>       <div style="overflow: hidden;padding: 37px;background: #fff;border: 1px solid #eee;">          <div>             <div style="color: #5a6571;padding: 0px;font-weight: 400;font-size: 33px;line-height: 36px; text-align: center">                                      {$titulo}                              </div>          </div>          <div style=text-align: justify; margin-top: 60px;>             <p>Olá {$nome},</p>             <p>Esperamos que você esteja aproveitando ao máximo o Builder SaaS!</p>             <p>Gostaríamos de lembrá-lo que sua licença está prestes a vencer em {$data_vencimento}. Para evitar qualquer interrupção no seu acesso e continuar aproveitando todos os nossos recursos, por favor, renove sua licença antes da data de vencimento.</p>              <p>Se precisar de ajuda ou tiver alguma dúvida, nossa equipe de suporte está pronta para assisti-lo.</p>             <p>Obrigado por ser parte da nossa comunidade!</p>             <br><br>             <p>Atenciosamente,<br>Equipe Builder SaaS</p>          </div>       </div>    </div>'); 

INSERT INTO saas_template_email (id,descricao,titulo,conteudo) VALUES (4,'Solicitação de resete de senha','Resetar a Senha','<div style="background: #f4f4f4;font-family: Arial, Helvetica, sans-serif;color:#5a6571cf;font-size: 15px;line-height: 25px; padding-top: 40px; padding-bottom: 40px;">     <div style=max-width: 650px;margin: auto;>         <div style="text-align: center; margin-bottom: 28px;">             <img alt="logo" src="https://manager.madbuilder.com.br/app/images/logo-horizontal.png" style="max-width: 300px;">         </div>         <div style="overflow: hidden;padding: 37px;background: #fff;border: 1px solid #eee;">             <div>                 <div style="color: #5a6571;padding: 0px;font-weight: 400;font-size: 33px;line-height: 36px; text-align: center;">                     {$titulo}                 </div>             </div>             <div style=text-align: justify; margin-top: 60px;>                 <p>Olá {$nome}!</p>                  <p> Para iniciar o processo de reset de senha clique no link: </p>                  <a href="{$link}" target="_blank">RESETAR A SENHA</a>                              <p>Atenciosamente,<br>Equipe Builder SaaS.</p>              </div>         </div>     </div> </div>'); 

INSERT INTO saas_template_email (id,descricao,titulo,conteudo) VALUES (5,'Ativação do plano','Plano ativado','<div style="background: #f4f4f4;font-family: Arial, Helvetica, sans-serif;color:#5a6571cf;font-size: 15px;line-height: 25px; padding-top: 40px; padding-bottom: 40px;">     <div style=max-width: 650px;margin: auto;>         <div style="text-align: center; margin-bottom: 28px;">             <img alt="logo" src="https://manager.madbuilder.com.br/app/images/logo-horizontal.png" style="max-width: 300px;">         </div>         <div style="overflow: hidden;padding: 37px;background: #fff;border: 1px solid #eee;">             <div>                 <div style="color: #5a6571;padding: 0px;font-weight: 400;font-size: 33px;line-height: 36px; text-align: center;">                     {$titulo}                 </div>             </div>             <div style=text-align: justify; margin-top: 60px;>                 <p>Olá {$nome}!</p>                  <p>Seu plano foi ativado com sucesso.</p>                  <p>Para começar a utilizar todos os recursos do nosso sistema, clique no link abaixo:</p>                  <a href="{$link}" target="_blank">ACESSAR O SISTEMA</a>                  <p>Atenciosamente,<br>Equipe Builder SaaS.</p>             </div>         </div>     </div> </div>'); 

SET IDENTITY_INSERT saas_template_email OFF; 

INSERT INTO system_group (id,name,uuid) VALUES (1,'Admin',null); 

INSERT INTO system_group (id,name,uuid) VALUES (2,'Standard',null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (1,1,1,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (2,1,2,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (3,1,3,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (4,1,4,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (5,1,5,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (6,1,6,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (7,1,8,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (8,1,9,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (9,1,11,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (10,1,14,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (11,1,15,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (12,2,10,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (13,2,12,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (14,2,13,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (15,2,16,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (16,2,17,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (17,2,18,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (18,2,19,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (19,2,20,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (20,1,21,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (21,2,22,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (22,2,23,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (23,2,24,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (24,2,25,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (25,1,26,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (26,1,27,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (27,1,28,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (28,1,29,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (29,2,30,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (30,1,31,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (31,1,32,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (32,1,33,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (33,1,34,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (34,1,35,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (35,1,36,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (36,1,37,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (37,1,38,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (38,1,39,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (39,1,40,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (40,1,41,null); 

INSERT INTO system_group_program (id,system_group_id,system_program_id,actions) VALUES (41,1,42,null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (1,'System Group Form','SystemGroupForm',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (2,'System Group List','SystemGroupList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (3,'System Program Form','SystemProgramForm',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (4,'System Program List','SystemProgramList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (5,'System User Form','SystemUserForm',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (6,'System User List','SystemUserList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (7,'Common Page','CommonPage',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (8,'System PHP Info','SystemPHPInfoView',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (9,'System ChangeLog View','SystemChangeLogView',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (10,'Welcome View','WelcomeView',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (11,'System Sql Log','SystemSqlLogList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (12,'System Profile View','SystemProfileView',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (13,'System Profile Form','SystemProfileForm',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (14,'System SQL Panel','SystemSQLPanel',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (15,'System Access Log','SystemAccessLogList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (16,'System Message Form','SystemMessageForm',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (17,'System Message List','SystemMessageList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (18,'System Message Form View','SystemMessageFormView',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (19,'System Notification List','SystemNotificationList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (20,'System Notification Form View','SystemNotificationFormView',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (21,'System Document Category List','SystemDocumentCategoryFormList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (22,'System Document Form','SystemDocumentForm',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (23,'System Document Upload Form','SystemDocumentUploadForm',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (24,'System Document List','SystemDocumentList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (25,'System Shared Document List','SystemSharedDocumentList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (26,'System Unit Form','SystemUnitForm',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (27,'System Unit List','SystemUnitList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (28,'System Access stats','SystemAccessLogStats',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (29,'System Preference form','SystemPreferenceForm',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (30,'System Support form','SystemSupportForm',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (31,'System PHP Error','SystemPHPErrorLogView',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (32,'System Database Browser','SystemDatabaseExplorer',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (33,'System Table List','SystemTableList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (34,'System Data Browser','SystemDataBrowser',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (35,'System Menu Editor','SystemMenuEditor',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (36,'System Request Log','SystemRequestLogList',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (37,'System Request Log View','SystemRequestLogView',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (38,'System Administration Dashboard','SystemAdministrationDashboard',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (39,'System Log Dashboard','SystemLogDashboard',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (40,'System Session dump','SystemSessionDumpView',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (41,'Files diff','SystemFilesDiff',null); 

INSERT INTO system_program (id,name,controller,actions) VALUES (42,'System Information','SystemInformationView',null); 

INSERT INTO system_unit (id,name,account_id,connection_name,active) VALUES (1,'Matriz',null,'matriz',null); 

INSERT INTO system_user_group (id,system_user_id,system_group_id) VALUES (1,1,1); 

INSERT INTO system_user_group (id,system_user_id,system_group_id) VALUES (2,2,2); 

INSERT INTO system_user_group (id,system_user_id,system_group_id) VALUES (3,1,2); 

INSERT INTO system_user_program (id,system_user_id,system_program_id) VALUES (1,2,7); 

INSERT INTO system_users (id,name,login,password,email,frontpage_id,system_unit_id,account_id,active,accepted_term_policy_at,accepted_term_policy,two_factor_enabled,two_factor_type,two_factor_secret) VALUES (1,'Administrator','admin','21232f297a57a5a743894a0e4a801fc3','admin@admin.net',10,null,null,'Y','','',null,null,null); 

INSERT INTO system_users (id,name,login,password,email,frontpage_id,system_unit_id,account_id,active,accepted_term_policy_at,accepted_term_policy,two_factor_enabled,two_factor_type,two_factor_secret) VALUES (2,'User','user','ee11cbb19052e40b07aac0ca060c23ee','user@user.net',7,null,null,'Y','','',null,null,null); 

INSERT INTO system_user_unit (id,system_user_id,system_unit_id) VALUES (1,1,1); 

SET IDENTITY_INSERT tipo_anexo ON; 

INSERT INTO tipo_anexo (id,nome) VALUES (1,'Recibo'); 

INSERT INTO tipo_anexo (id,nome) VALUES (2,'Boleto'); 

SET IDENTITY_INSERT tipo_anexo OFF; 

SET IDENTITY_INSERT tipo_atividade ON; 

INSERT INTO tipo_atividade (id,nome,cor,icone) VALUES (1,'Ligar','#00d2d3','fas fa-phone'); 

INSERT INTO tipo_atividade (id,nome,cor,icone) VALUES (2,'Reunião','#54a0ff','fas fa-users'); 

INSERT INTO tipo_atividade (id,nome,cor,icone) VALUES (3,'Tarefa','#5f27cd','fas fa-tasks'); 

INSERT INTO tipo_atividade (id,nome,cor,icone) VALUES (4,'Prazo','#341f97','far fa-clock'); 

INSERT INTO tipo_atividade (id,nome,cor,icone) VALUES (5,'Email','#ee5253','far fa-envelope'); 

INSERT INTO tipo_atividade (id,nome,cor,icone) VALUES (6,'Almoço','#feca57','fas fa-utensils'); 

SET IDENTITY_INSERT tipo_atividade OFF; 

SET IDENTITY_INSERT tipo_cliente ON; 

INSERT INTO tipo_cliente (id,nome,sigla) VALUES (1,'Física','PF'); 

INSERT INTO tipo_cliente (id,nome,sigla) VALUES (2,'Jurídica','PJ'); 

SET IDENTITY_INSERT tipo_cliente OFF; 

SET IDENTITY_INSERT tipo_conta ON; 

INSERT INTO tipo_conta (id,nome) VALUES (1,'Receber'); 

INSERT INTO tipo_conta (id,nome) VALUES (2,'Pagar'); 

SET IDENTITY_INSERT tipo_conta OFF; 

SET IDENTITY_INSERT tipo_ouvidoria ON; 

INSERT INTO tipo_ouvidoria (id,nome) VALUES (1,'Sugestão'); 

INSERT INTO tipo_ouvidoria (id,nome) VALUES (2,'Elogio'); 

INSERT INTO tipo_ouvidoria (id,nome) VALUES (3,'Critica'); 

INSERT INTO tipo_ouvidoria (id,nome) VALUES (4,'Reclamação'); 

SET IDENTITY_INSERT tipo_ouvidoria OFF; 

SET IDENTITY_INSERT tipo_pedido ON; 

INSERT INTO tipo_pedido (id,categoria_id,nome) VALUES (1,1,'Vendas de mercadorias'); 

INSERT INTO tipo_pedido (id,categoria_id,nome) VALUES (2,2,'Vendas de produtos'); 

SET IDENTITY_INSERT tipo_pedido OFF; 

SET IDENTITY_INSERT tipo_produto ON; 

INSERT INTO tipo_produto (id,nome) VALUES (1,'Mercadoria'); 

INSERT INTO tipo_produto (id,nome) VALUES (2,'Produto'); 

INSERT INTO tipo_produto (id,nome) VALUES (3,'Serviço'); 

SET IDENTITY_INSERT tipo_produto OFF; 

SET IDENTITY_INSERT unidade_medida ON; 

INSERT INTO unidade_medida (id,nome,sigla) VALUES (1,'Peça','PC'); 

INSERT INTO unidade_medida (id,nome,sigla) VALUES (2,'Litro','LT'); 

INSERT INTO unidade_medida (id,nome,sigla) VALUES (3,'Metro cúbico','M3'); 

SET IDENTITY_INSERT unidade_medida OFF; 
