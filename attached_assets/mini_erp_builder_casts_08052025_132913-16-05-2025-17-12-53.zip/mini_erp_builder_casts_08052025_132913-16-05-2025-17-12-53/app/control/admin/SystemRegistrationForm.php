<?php

class SystemRegistrationForm extends TPage
{

    function __construct()
    {
        parent::__construct();
    }
    
}
