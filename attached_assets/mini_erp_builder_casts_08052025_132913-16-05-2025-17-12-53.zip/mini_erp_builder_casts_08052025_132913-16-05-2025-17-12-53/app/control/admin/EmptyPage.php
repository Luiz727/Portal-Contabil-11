<?php


class EmptyPage extends TPage
{
    /**
     * Class constructor
     * Creates the page
     */
    function __construct()
    {
        parent::__construct();
        
        $programs = TSession::getValue('programs');
        if(!empty($programs['SaasMinhaContaDashboard']))
        {
            $dashboard = new SaasMinhaContaDashboard([]);
            $dashboard->setIsWrapped(true);
            $dashboard->onShow([]);
            parent::add($dashboard);
        }
    }
}
