<?php


class SystemPasswordResetForm extends TPage
{
   
    function __construct($param)
    {
        parent::__construct();
    }
}
