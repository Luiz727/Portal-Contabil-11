<?php

class SystemRequestPasswordResetForm extends TPage
{
   
    function __construct($param)
    {
        parent::__construct();
    }
    
}
