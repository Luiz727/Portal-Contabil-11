<?php

class SaasUnidadeForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'minierp';
    private static $activeRecord = 'SystemUnit';
    private static $primaryKey = 'id';
    private static $formName = 'form_SistemaUnidadeForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de unidade");

        $criteria_usuarios = new TCriteria();

        $filterVar = AccountService::getId();
        $criteria_usuarios->add(new TFilter('account_id', '=', $filterVar)); 

        $id = new TEntry('id');
        $name = new TEntry('name');
        $active = new TCheckButton('active');
        $usuarios = new TCheckList('usuarios');

        $name->addValidation("Name", new TRequiredValidator()); 

        $id->setEditable(false);
        $active->setValue('T');
        $active->setUseSwitch(true, 'blue');
        $active->setIndexValue("T");
        $active->setInactiveIndexValue("F");
        $id->setSize(100);
        $name->setSize('100%');

        $usuarios->setIdColumn('id');

        $column_usuarios_name = $usuarios->addColumn('name', "Nome", 'center' , '50%');
        $column_usuarios_login = $usuarios->addColumn('login', "Login", 'center' , '50%');

        $usuarios->setHeight(250);
        $usuarios->makeScrollable();

        $usuarios->fillWith('minierp', 'SystemUsers', 'id', 'name asc' , $criteria_usuarios);

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null, '100%'),$id]);
        $row1->layout = ['col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$name],[new TLabel("Ativa:", '#FF0000', '14px', null, '100%'),$active]);
        $row2->layout = ['col-sm-6','col-sm-6'];

        $row3 = $this->form->addFields([new TFormSeparator("Usuários com acesso a Unidade", '#333', '18', '#eee')]);
        $row3->layout = [' col-sm-12'];

        $row4 = $this->form->addFields([$usuarios]);
        $row4->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new SystemUnit(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data
            $object->account_id = AccountService::getId();

            if(!$data->id)
            {
                $countUnidades = SystemUnit::where('account_id', '=', PermissaoService::getAccountId())->count();

                if($countUnidades >= PermissaoService::getLimiteUnidades())
                {
                    throw new Exception(" Não é possível criar uma nova unidade pois você atingiu o limite do seu plano. ");
                }
            }

            if($data->id)
            {
                $dbUnit = SystemUnit::find($data->id);
                if($dbUnit && $dbUnit->account_id != PermissaoService::getAccountId())
                {
                    throw new Exception('Permissão negada');
                }
            }

            $object->store(); // save the object 

            if ($data->usuarios) 
            {
                foreach ($data->usuarios as $usuario_id) 
                {
                    $user = new SystemUsers($usuario_id);

                    if($user->account_id != PermissaoService::getAccountId())
                    {
                        throw new Exception('Permissão negada!');
                    }
                }
            }

            $repository = SystemUserUnit::where('system_unit_id', '=', $object->id);
            $repository->delete(); 

            if ($data->usuarios) 
            {
                foreach ($data->usuarios as $usuarios_value) 
                {
                    $system_user_unit = new SystemUserUnit;

                    $system_user_unit->system_user_id = $usuarios_value;
                    $system_user_unit->system_unit_id = $object->id;
                    $system_user_unit->store();
                }
            }

            $messageAction = new TAction(['SaasUnidadeList', 'onShow']);   

            if(!empty($param['target_container']))
            {
                $messageAction->setParameter('target_container', $param['target_container']);
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            new TMessage('info', "Registro salvo", $messageAction); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new SystemUnit($key); // instantiates the Active Record 

                if($object->account_id != PermissaoService::getAccountId())
                {
                    throw new Exception('Permissão negada');
                }

                $object->usuarios = SystemUserUnit::where('system_unit_id', '=', $object->id)->getIndexedArray('system_user_id', 'system_user_id');

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

