<?php

class SaasPagamentoList extends TPage
{
    private $form; // form
    private $datagrid; // listing
    private $pageNavigation;
    private $loaded;
    private $filter_criteria;
    private static $database = 'minierp';
    private static $activeRecord = 'SaasPagamento';
    private static $primaryKey = 'id';
    private static $formName = 'form_SaasPagamentoList';
    private $showMethods = ['onReload', 'onSearch', 'onRefresh', 'onClearFilters'];
    private $limit = 20;

    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct($param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        // define the form title
        $this->form->setFormTitle("Listagem de pagamentos");
        $this->limit = 20;

        $criteria_cliente_id = new TCriteria();
        $criteria_plano_id = new TCriteria();
        $criteria_saas_status_pagamento_id = new TCriteria();

        $filterVar = "T";
        $criteria_plano_id->add(new TFilter('ativo', '=', $filterVar)); 

        $id = new TEntry('id');
        $saas_contrato_id = new TSeekButton('saas_contrato_id');
        $contrato_descricao_html = new BElement('div');
        $cliente_id = new TDBUniqueSearch('cliente_id', 'minierp', 'Account', 'id', 'nome_responsavel','razao_social asc' , $criteria_cliente_id );
        $plano_id = new TDBCombo('plano_id', 'minierp', 'SaasPlano', 'id', '{nome}','nome asc' , $criteria_plano_id );
        $data_compra = new TDate('data_compra');
        $data_compra_final = new TDate('data_compra_final');
        $data_pagamento = new TDate('data_pagamento');
        $data_pagamento_final = new TDate('data_pagamento_final');
        $data_vencimento = new TDate('data_vencimento');
        $data_vencimento_final = new TDate('data_vencimento_final');
        $saas_status_pagamento_id = new TDBCombo('saas_status_pagamento_id', 'minierp', 'SaasStatusPagamento', 'id', '{nome}','nome asc' , $criteria_saas_status_pagamento_id );

        $saas_contrato_id->setExitAction(new TAction([$this,'onChangeContrato']));

        $cliente_id->setMinLength(2);
        $cliente_id->setFilterColumns(["email","telefone","nome_responsavel"]);
        $plano_id->enableSearch();
        $saas_status_pagamento_id->enableSearch();

        $data_compra->setDatabaseMask('yyyy-mm-dd');
        $data_pagamento->setDatabaseMask('yyyy-mm-dd');
        $data_vencimento->setDatabaseMask('yyyy-mm-dd');
        $data_compra_final->setDatabaseMask('yyyy-mm-dd');
        $data_pagamento_final->setDatabaseMask('yyyy-mm-dd');
        $data_vencimento_final->setDatabaseMask('yyyy-mm-dd');

        $data_compra->setMask('dd/mm/yyyy');
        $data_pagamento->setMask('dd/mm/yyyy');
        $data_vencimento->setMask('dd/mm/yyyy');
        $data_compra_final->setMask('dd/mm/yyyy');
        $data_pagamento_final->setMask('dd/mm/yyyy');
        $data_vencimento_final->setMask('dd/mm/yyyy');
        $cliente_id->setMask('{nome_responsavel} ( {telefone} - {email} )');

        $id->setSize('100%');
        $plano_id->setSize('100%');
        $data_compra->setSize(110);
        $cliente_id->setSize('100%');
        $data_pagamento->setSize(110);
        $data_vencimento->setSize(110);
        $data_compra_final->setSize(110);
        $saas_contrato_id->setSize('100%');
        $data_pagamento_final->setSize(110);
        $data_vencimento_final->setSize(110);
        $saas_status_pagamento_id->setSize('100%');
        $contrato_descricao_html->setSize('100%', 80);

        $contrato_descricao_html->id = 'contrato_descricao_html';

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null, '100%'),$id]);
        $row1->layout = [' col-sm-2'];

        $row2 = $this->form->addFields([new TLabel("Contrato:", null, '14px', null, '100%'),$saas_contrato_id],[$contrato_descricao_html]);
        $row2->layout = [' col-sm-2',' col-sm-10'];

        $row3 = $this->form->addFields([new TLabel("Cliente:", null, '14px', null),$cliente_id],[new TLabel("Plano:", null, '14px', null),$plano_id]);
        $row3->layout = [' col-sm-6',' col-sm-6'];

        $row4 = $this->form->addFields([new TLabel("Data compra:", null, '14px', null, '100%'),$data_compra,new TLabel("até", null, '14px', null),$data_compra_final],[new TLabel("Data de pagamento:", null, '14px', null, '100%'),$data_pagamento,new TLabel("até", null, '14px', null),$data_pagamento_final]);
        $row4->layout = ['col-sm-6',' col-sm-6'];

        $row5 = $this->form->addFields([new TLabel("Data de vencimento:", null, '14px', null, '100%'),$data_vencimento,new TLabel("até", null, '14px', null),$data_vencimento_final],[new TLabel("Status:", null, '14px', null, '100%'),$saas_status_pagamento_id]);
        $row5->layout = ['col-sm-6','col-sm-6'];

        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );
        $this->fireEvents( TSession::getValue(__CLASS__.'_filter_data') );

        $btn_onsearch = $this->form->addAction("Buscar", new TAction([$this, 'onSearch']), 'fas:search #ffffff');
        $this->btn_onsearch = $btn_onsearch;
        $btn_onsearch->addStyleClass('btn-primary'); 

        // creates a Datagrid
        $this->datagrid = new TDataGrid;
        $this->datagrid->setId(__CLASS__.'_datagrid');

        $this->datagrid_form = new TForm('datagrid_'.self::$formName);
        $this->datagrid_form->onsubmit = 'return false';

        $this->datagrid = new BootstrapDatagridWrapper($this->datagrid);
        $this->filter_criteria = new TCriteria;

        $this->datagrid->style = 'width: 100%';
        $this->datagrid->setHeight(250);

        $column_id = new TDataGridColumn('id', "Id", 'center' , '70px');
        $column_saas_contrato_descricao_html = new TDataGridColumn('saas_contrato->descricao_html', "Contrato", 'left');
        $column_saas_gateway_pagamento_nome = new TDataGridColumn('saas_gateway_pagamento->nome', "Gateway", 'left');
        $column_valor_transformed = new TDataGridColumn('valor', "Valor", 'right' , '150px');
        $column_data_compra_transformed = new TDataGridColumn('data_compra', "Compra em", 'center' , '125px');
        $column_data_vencimento_transformed = new TDataGridColumn('data_vencimento', "Vencimento", 'center' , '125px');
        $column_data_pagamento_transformed = new TDataGridColumn('data_pagamento', "Pagamento", 'center' , '125px');
        $column_saas_contrato_saas_plano_valor_recorrencia_transformed = new TDataGridColumn('saas_contrato->saas_plano_valor->recorrencia', "Recorrência MP", 'center');
        $column_saas_status_pagamento_nome_transformed = new TDataGridColumn('saas_status_pagamento->nome', "Status", 'center' , '150px');

        $column_valor_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });

        $column_data_compra_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y H:i');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_data_vencimento_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_data_pagamento_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_saas_contrato_saas_plano_valor_recorrencia_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            if($value === 'T' || $value === true || $value === 't' || $value === 'S' || $value === 'Y'  || $value === 'y'  )
            {
                return '<span class="label label-success">Sim</span>';
            }
            elseif($value === 'F' || $value === false || $value === 'f' || $value === 'N' || $value === 'n'  )
            {
                return '<span class="label label-danger">Não</span>';
            }

            return '';

        });

        $column_saas_status_pagamento_nome_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            return "<span class = 'label label-default' style='color:#fff; background-color: {$object->saas_status_pagamento->cor}'> {$object->saas_status_pagamento->nome} <span> ";

        });        

        $order_id = new TAction(array($this, 'onReload'));
        $order_id->setParameter('order', 'id');
        $column_id->setAction($order_id);

        $column_saas_contrato_descricao_html->disableHtmlConversion();
        $column_saas_status_pagamento_nome_transformed->disableHtmlConversion();

        $this->datagrid->addColumn($column_id);
        $this->datagrid->addColumn($column_saas_contrato_descricao_html);
        $this->datagrid->addColumn($column_saas_gateway_pagamento_nome);
        $this->datagrid->addColumn($column_valor_transformed);
        $this->datagrid->addColumn($column_data_compra_transformed);
        $this->datagrid->addColumn($column_data_vencimento_transformed);
        $this->datagrid->addColumn($column_data_pagamento_transformed);
        $this->datagrid->addColumn($column_saas_contrato_saas_plano_valor_recorrencia_transformed);
        $this->datagrid->addColumn($column_saas_status_pagamento_nome_transformed);

        $action_group = new TDataGridActionGroup("", 'fas:cog');
        $action_group->addHeader('');

        $action_onEdit = new TDataGridAction(array('SaasPagamentoForm', 'onEdit'));
        $action_onEdit->setUseButton(TRUE);
        $action_onEdit->setButtonClass('btn btn-default');
        $action_onEdit->setLabel("Editar");
        $action_onEdit->setImage('far:edit #478fca');
        $action_onEdit->setField(self::$primaryKey);

        $action_group->addAction($action_onEdit);

        $action_onDelete = new TDataGridAction(array('SaasPagamentoList', 'onDelete'));
        $action_onDelete->setUseButton(TRUE);
        $action_onDelete->setButtonClass('btn btn-default');
        $action_onDelete->setLabel("Excluir");
        $action_onDelete->setImage('fas:trash-alt #dd5a43');
        $action_onDelete->setField(self::$primaryKey);

        $action_group->addAction($action_onDelete);

        $action_onGerarCobrancaGatewayPagamento = new TDataGridAction(array('SaasPagamentoList', 'onGerarCobrancaGatewayPagamento'));
        $action_onGerarCobrancaGatewayPagamento->setUseButton(TRUE);
        $action_onGerarCobrancaGatewayPagamento->setButtonClass('btn btn-default');
        $action_onGerarCobrancaGatewayPagamento->setLabel("Gerar Cobrança");
        $action_onGerarCobrancaGatewayPagamento->setImage('fas:file-invoice-dollar #9C27B0');
        $action_onGerarCobrancaGatewayPagamento->setField(self::$primaryKey);
        $action_onGerarCobrancaGatewayPagamento->setDisplayCondition('SaasPagamentoList::onExibirGerarCobranca');

        $action_group->addAction($action_onGerarCobrancaGatewayPagamento);

        $action_onVerificarPagamento = new TDataGridAction(array('SaasPagamentoList', 'onVerificarPagamento'));
        $action_onVerificarPagamento->setUseButton(TRUE);
        $action_onVerificarPagamento->setButtonClass('btn btn-default');
        $action_onVerificarPagamento->setLabel("Verificar pagamento");
        $action_onVerificarPagamento->setImage('fas:sync #00BCD4');
        $action_onVerificarPagamento->setField(self::$primaryKey);
        $action_onVerificarPagamento->setDisplayCondition('SaasPagamentoList::onShowVerificar');

        $action_group->addAction($action_onVerificarPagamento);

        $action_onGerarNotaFiscal = new TDataGridAction(array('SaasPagamentoList', 'onGerarNotaFiscal'));
        $action_onGerarNotaFiscal->setUseButton(TRUE);
        $action_onGerarNotaFiscal->setButtonClass('btn btn-default');
        $action_onGerarNotaFiscal->setLabel("Gerar Nota Fiscal");
        $action_onGerarNotaFiscal->setImage('fas:file-alt #8BC34A');
        $action_onGerarNotaFiscal->setField(self::$primaryKey);
        $action_onGerarNotaFiscal->setDisplayCondition('SaasPagamentoList::onExibirGerarNF');

        $action_group->addAction($action_onGerarNotaFiscal);

        $action_onDownloadBoletoPix = new TDataGridAction(array('SaasPagamentoList', 'onDownloadBoletoPix'));
        $action_onDownloadBoletoPix->setUseButton(TRUE);
        $action_onDownloadBoletoPix->setButtonClass('btn btn-default');
        $action_onDownloadBoletoPix->setLabel("Download Boleto&Pix");
        $action_onDownloadBoletoPix->setImage('fas:file-invoice-dollar #FF9800');
        $action_onDownloadBoletoPix->setField(self::$primaryKey);
        $action_onDownloadBoletoPix->setDisplayCondition('SaasPagamentoList::onShowDownloadBoletoPix');

        $action_group->addAction($action_onDownloadBoletoPix);

        $this->datagrid->addActionGroup($action_group);    

        // create the datagrid model
        $this->datagrid->createModel();

        // creates the page navigation
        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
        $this->pageNavigation->setWidth($this->datagrid->getWidth());

        $panel = new TPanelGroup("Listagem de pagamentos");
        $panel->datagrid = 'datagrid-container';
        $this->datagridPanel = $panel;
        $this->datagrid_form->add($this->datagrid);
        $panel->add($this->datagrid_form);

        $panel->getBody()->class .= ' table-responsive';

        $panel->addFooter($this->pageNavigation);

        $headerActions = new TElement('div');
        $headerActions->class = ' datagrid-header-actions ';
        $headerActions->style = 'justify-content: space-between;';

        $head_left_actions = new TElement('div');
        $head_left_actions->class = ' datagrid-header-actions-left-actions ';

        $head_right_actions = new TElement('div');
        $head_right_actions->class = ' datagrid-header-actions-left-actions ';

        $headerActions->add($head_left_actions);
        $headerActions->add($head_right_actions);

        $panel->getBody()->insert(0, $headerActions);

        $button_cadastrar = new TButton('button_button_cadastrar');
        $button_cadastrar->setAction(new TAction(['SaasPagamentoForm', 'onShow']), "Cadastrar");
        $button_cadastrar->addStyleClass('btn-default');
        $button_cadastrar->setImage('fas:plus #69aa46');

        $this->datagrid_form->addField($button_cadastrar);

        $btnShowCurtainFilters = new TButton('button_btnShowCurtainFilters');
        $btnShowCurtainFilters->setAction(new TAction(['SaasPagamentoList', 'onShowCurtainFilters']), "Filtros");
        $btnShowCurtainFilters->addStyleClass('btn-default');
        $btnShowCurtainFilters->setImage('fas:filter #000000');

        $this->datagrid_form->addField($btnShowCurtainFilters);

        $button_limpar_filtros = new TButton('button_button_limpar_filtros');
        $button_limpar_filtros->setAction(new TAction(['SaasPagamentoList', 'onClearFilters']), "Limpar filtros");
        $button_limpar_filtros->addStyleClass('btn-default');
        $button_limpar_filtros->setImage('fas:eraser #f44336');

        $this->datagrid_form->addField($button_limpar_filtros);

        $button_atualizar = new TButton('button_button_atualizar');
        $button_atualizar->setAction(new TAction(['SaasPagamentoList', 'onRefresh']), "Atualizar");
        $button_atualizar->addStyleClass('btn-default');
        $button_atualizar->setImage('fas:sync-alt #03a9f4');

        $this->datagrid_form->addField($button_atualizar);

        $button_verificar_pagamentos = new TButton('button_button_verificar_pagamentos');
        $button_verificar_pagamentos->setAction(new TAction(['SaasPagamentoList', 'onVerificarLote']), "Verificar pagamentos");
        $button_verificar_pagamentos->addStyleClass('btn-default');
        $button_verificar_pagamentos->setImage('fas:funnel-dollar #FF9800');

        $this->datagrid_form->addField($button_verificar_pagamentos);

        $head_left_actions->add($button_cadastrar);
        $head_left_actions->add($btnShowCurtainFilters);
        $head_left_actions->add($button_limpar_filtros);
        $head_left_actions->add($button_atualizar);
        $head_left_actions->add($button_verificar_pagamentos);

        $this->contrato_descricao_html = $contrato_descricao_html;

        $seed = AdiantiApplicationConfig::get()['general']['seed'];
        $saas_contrato_id_seekAction = new TAction(['SaasContratoSeekWindow', 'onShow']);
        $seekFilters = [];
        $seekFields = base64_encode(serialize([
            ['name'=> 'saas_contrato_id', 'column'=>'{id}']
        ]));

        $seekFilters = base64_encode(serialize($seekFilters));
        $saas_contrato_id_seekAction->setParameter('_seek_fields', $seekFields);
        $saas_contrato_id_seekAction->setParameter('_seek_filters', $seekFilters);
        $saas_contrato_id_seekAction->setParameter('_seek_hash', md5($seed.$seekFields.$seekFilters));
        $saas_contrato_id->setAction($saas_contrato_id_seekAction);
        $this->btnShowCurtainFilters = $btnShowCurtainFilters;

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["SaaS Admin","Pagamentos"]));
        }

        $container->add($panel);

        parent::add($container);

    }

    public static function onChangeContrato($param = null) 
    {
        try 
        {
            if(!empty($param['key']))
            {
                TTransaction::open(self::$database);

                $contrato = new SaasContrato($param['key']);

                TScript::create("$('#contrato_descricao_html').html(`{$contrato->descricao_html}`)");

                TTransaction::close();
            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onDelete($param = null) 
    { 
        if(isset($param['delete']) && $param['delete'] == 1)
        {
            try
            {
                // get the paramseter $key
                $key = $param['key'];
                // open a transaction with database
                TTransaction::open(self::$database);

                // instantiates object
                $object = new SaasPagamento($key, FALSE); 

                // deletes the object from the database
                $object->delete();

                // close the transaction
                TTransaction::close();

                // reload the listing
                $this->onReload( $param );
                // shows the success message
                new TMessage('info', AdiantiCoreTranslator::translate('Record deleted'));
            }
            catch (Exception $e) // in case of exception
            {
                // shows the exception error message
                new TMessage('error', $e->getMessage());
                // undo all pending operations
                TTransaction::rollback();
            }
        }
        else
        {
            // define the delete action
            $action = new TAction(array($this, 'onDelete'));
            $action->setParameters($param); // pass the key paramseter ahead
            $action->setParameter('delete', 1);
            // shows a dialog to the user
            new TQuestion(AdiantiCoreTranslator::translate('Do you really want to delete ?'), $action);   
        }
    }
    public static function onGerarCobrancaGatewayPagamento($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $pagamento = new SaasPagamento($param['key'], FALSE);

            if (empty($pagamento->id_gateway))
            {
                $service = new GatewayPagamentoService($pagamento->saas_gateway_pagamento);
                $result = $service->generate($pagamento);

                $pagamento->dados_gateway = $result['dados'];
                $pagamento->id_gateway = $result['id'];
                $pagamento->link_gateway = $result['link'];
                $pagamento->saas_status_pagamento_id = SaasStatusPagamento::AGUARDANDO_PAGAMENTO;
                $pagamento->store();
            }

            new TMessage('info', 'Link para pagamento: <br>' . $pagamento->link_gateway, null, 'Sucesso');

            TTransaction::close();

            self::manageRow($pagamento->id);

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onExibirGerarCobranca($object)
    {
        try 
        {
            if($object->saas_status_pagamento_id == SaasStatusPagamento::INICIADO)
            {
                return true;
            }

            return false;
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onVerificarPagamento($param = null) 
    {
        try 
        {
            TTransaction::open(self::$database);

            $pagamento = new SaasPagamento($param['key'], FALSE);
            $service = new GatewayPagamentoService($pagamento->saas_gateway_pagamento);

            if($pagamento->saas_contrato->gateway_assinatura_id && $pagamento->saas_gateway_pagamento_id == SaasGatewayPagamento::MERCADO_PAGO)
            {
                $subscriptionDetails = $service->getSubscriptionDetails($pagamento->id);
                SaasPagamentoService::atualizaAssinatura($pagamento, $subscriptionDetails);    
            }
            else
            {
                $result = $service->getInfo($pagamento);
                SaasPagamentoService::update($pagamento, $result);
            }

            TToast::show("info", $pagamento->saas_status_pagamento->nome);

            TTransaction::close();

            self::manageRow($pagamento->id);
            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onShowVerificar($object)
    {
        try 
        {
            if($object->saas_status_pagamento_id != SaasStatusPagamento::PAGO)
            {
                return true;
            }

            return false;
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onGerarNotaFiscal($param = null) 
    {
        try 
        {
            if(!empty($param['key']))
            {
                TTransaction::open(self::$database);

                $pagamento = new SaasPagamento($param['key']);
                $pagamento->gerarNotaFiscal();

                TTransaction::close();

                self::manageRow($pagamento->id);

                new TMessage('info', 'NFS-e criada!');
            }

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onExibirGerarNF($object)
    {
        try 
        {
            if($object->saas_status_pagamento_id == SaasStatusPagamento::PAGO && $object->saas_nota_fiscal_servico_id && in_array($object->saas_nota_fiscal_servico->nota_fiscal_status_id, [NotaFiscalStatus::CANCELADA, NotaFiscalStatus::REJEITADA]))
            {
                return true;
            }

            if($object->saas_status_pagamento_id == SaasStatusPagamento::PAGO && !$object->saas_nota_fiscal_servico_id)
            {
                return true;
            }

            return false;
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onDownloadBoletoPix($param = null) 
    {
        try 
        {

            TTransaction::open(self::$database);

            $pagamento = new SaasPagamento($param['key']);

            TTransaction::close();

            parent::openFile($pagamento->link_gateway);

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onShowDownloadBoletoPix($object)
    {
        try 
        {
            if($object->saas_gateway_pagamento_id == SaasGatewayPagamento::BANCO_INTER && $object->saas_status_pagamento_id == SaasStatusPagamento::AGUARDANDO_PAGAMENTO)
            {
                return true;
            }

            return false;
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onShowCurtainFilters($param = null) 
    {
        try 
        {
            //code here

                        $filter = new self([]);

            $btnClose = new TButton('closeCurtain');
            $btnClose->class = 'btn btn-sm btn-default';
            $btnClose->style = 'margin-right:10px;';
            $btnClose->onClick = "Template.closeRightPanel();";
            $btnClose->setLabel("Fechar");
            $btnClose->setImage('fas:times');

            $filter->form->addHeaderWidget($btnClose);

            $page = new TPage();
            $page->setTargetContainer('adianti_right_panel');
            $page->setProperty('page-name', 'SaasPagamentoListSearch');
            $page->setProperty('page_name', 'SaasPagamentoListSearch');
            $page->adianti_target_container = 'adianti_right_panel';
            $page->target_container = 'adianti_right_panel';
            $page->add($filter->form);
            $page->setIsWrapped(true);
            $page->show();

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onClearFilters($param = null) 
    {
        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }
    public function onRefresh($param = null) 
    {
        $this->onReload([]);
    }
    public static function onVerificarLote($param = null) 
    {
        try 
        {
            if(isset($param['verificar']) && $param['verificar'] == 1)
            {
                ob_start();
                SaasPagamentoBatchService::verificarPagamentos();
                $result = ob_get_contents();
                ob_end_clean();

                new TMessage('info', TElement::tag('div', nl2br($result), ['style' => 'max-height: 80vh; overflow: auto;']), new TAction(['SaasPagamentoList', 'onShow']));
            }
            else
            {
                $action = new TAction(array(__CLASS__, 'onVerificarLote'));
                $action->setParameters($param);
                $action->setParameter('verificar', 1);

                new TQuestion('Deseja verificar pagamentos em lote?', $action);   
            }

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function fireEvents( $object )
    {
        $obj = new stdClass;
        if(is_object($object) && get_class($object) == 'stdClass')
        {
            if(isset($object->saas_contrato_id))
            {
                $value = $object->saas_contrato_id;

                $obj->saas_contrato_id = $value;
            }
        }
        elseif(is_object($object))
        {
            if(isset($object->saas_contrato_id))
            {
                $value = $object->saas_contrato_id;

                $obj->saas_contrato_id = $value;
            }
        }
        TForm::sendData(self::$formName, $obj);
    }  

    /**
     * Register the filter in the session
     */
    public function onSearch($param = null)
    {
        $data = $this->form->getData();
        $filters = [];

        $dataClone = clone $data;

        if (isset($data->data_compra_final) AND ( (is_scalar($data->data_compra_final) AND $data->data_compra_final !== '') OR (is_array($data->data_compra_final) AND (!empty($data->data_compra_final)) )) )
        {
            $data->data_compra_final = $data->data_compra_final . ' 23:59:59';
        }

        if (isset($data->data_compra) AND ( (is_scalar($data->data_compra) AND $data->data_compra !== '') OR (is_array($data->data_compra) AND (!empty($data->data_compra)) )) )
        {
            $data->data_compra = $data->data_compra . ' 00:00:00';
        }

        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        if (isset($data->id) AND ( (is_scalar($data->id) AND $data->id !== '') OR (is_array($data->id) AND (!empty($data->id)) )) )
        {

            $filters[] = new TFilter('id', '=', $data->id);// create the filter 
        }

        if (isset($data->saas_contrato_id) AND ( (is_scalar($data->saas_contrato_id) AND $data->saas_contrato_id !== '') OR (is_array($data->saas_contrato_id) AND (!empty($data->saas_contrato_id)) )) )
        {

            $filters[] = new TFilter('saas_contrato_id', '=', $data->saas_contrato_id);// create the filter 
        }

        if (isset($data->cliente_id) AND ( (is_scalar($data->cliente_id) AND $data->cliente_id !== '') OR (is_array($data->cliente_id) AND (!empty($data->cliente_id)) )) )
        {

            $filters[] = new TFilter('saas_contrato_id', 'in', "(SELECT id FROM saas_contrato WHERE account_id = '{$data->cliente_id}')");// create the filter 
        }

        if (isset($data->plano_id) AND ( (is_scalar($data->plano_id) AND $data->plano_id !== '') OR (is_array($data->plano_id) AND (!empty($data->plano_id)) )) )
        {

            $filters[] = new TFilter('saas_contrato_id', 'in', "(SELECT id FROM saas_contrato WHERE saas_plano_valor_id in (SELECT id FROM saas_plano_valor WHERE saas_plano_id = '{$data->plano_id}'))");// create the filter 
        }

        if (isset($data->data_compra) AND ( (is_scalar($data->data_compra) AND $data->data_compra !== '') OR (is_array($data->data_compra) AND (!empty($data->data_compra)) )) )
        {

            $filters[] = new TFilter('data_compra', '>=', $data->data_compra);// create the filter 
        }

        if (isset($data->data_compra_final) AND ( (is_scalar($data->data_compra_final) AND $data->data_compra_final !== '') OR (is_array($data->data_compra_final) AND (!empty($data->data_compra_final)) )) )
        {

            $filters[] = new TFilter('data_compra', '<=', $data->data_compra_final);// create the filter 
        }

        if (isset($data->data_pagamento) AND ( (is_scalar($data->data_pagamento) AND $data->data_pagamento !== '') OR (is_array($data->data_pagamento) AND (!empty($data->data_pagamento)) )) )
        {

            $filters[] = new TFilter('data_pagamento', '>=', $data->data_pagamento);// create the filter 
        }

        if (isset($data->data_pagamento_final) AND ( (is_scalar($data->data_pagamento_final) AND $data->data_pagamento_final !== '') OR (is_array($data->data_pagamento_final) AND (!empty($data->data_pagamento_final)) )) )
        {

            $filters[] = new TFilter('data_pagamento', '<=', $data->data_pagamento_final);// create the filter 
        }

        if (isset($data->data_vencimento) AND ( (is_scalar($data->data_vencimento) AND $data->data_vencimento !== '') OR (is_array($data->data_vencimento) AND (!empty($data->data_vencimento)) )) )
        {

            $filters[] = new TFilter('data_vencimento', '>=', $data->data_vencimento);// create the filter 
        }

        if (isset($data->data_vencimento_final) AND ( (is_scalar($data->data_vencimento_final) AND $data->data_vencimento_final !== '') OR (is_array($data->data_vencimento_final) AND (!empty($data->data_vencimento_final)) )) )
        {

            $filters[] = new TFilter('data_vencimento', '<=', $data->data_vencimento_final);// create the filter 
        }

        if (isset($data->saas_status_pagamento_id) AND ( (is_scalar($data->saas_status_pagamento_id) AND $data->saas_status_pagamento_id !== '') OR (is_array($data->saas_status_pagamento_id) AND (!empty($data->saas_status_pagamento_id)) )) )
        {

            $filters[] = new TFilter('saas_status_pagamento_id', '=', $data->saas_status_pagamento_id);// create the filter 
        }

        $this->fireEvents($data);

        $data = $dataClone;

        // fill the form with data again
        $this->form->setData($data);

        // keep the search data in the session
        TSession::setValue(__CLASS__.'_filter_data', $data);
        TSession::setValue(__CLASS__.'_filters', $filters);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }

    /**
     * Load the datagrid with data
     */
    public function onReload($param = NULL)
    {
        try
        {
            // open a transaction with database 'minierp'
            TTransaction::open(self::$database);

            // creates a repository for SaasPagamento
            $repository = new TRepository(self::$activeRecord);

            $criteria = clone $this->filter_criteria;

            if (empty($param['order']))
            {
                $param['order'] = 'id';    
            }

            if (empty($param['direction']))
            {
                $param['direction'] = 'desc';
            }

            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $this->limit);

            if($filters = TSession::getValue(__CLASS__.'_filters'))
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            //</blockLine><btnShowCurtainFiltersAutoCode>
            if(!empty($this->btnShowCurtainFilters) && empty($this->btnShowCurtainFiltersAdjusted))
            {
                $this->btnShowCurtainFiltersAdjusted = true;
                $this->btnShowCurtainFilters->style = 'position: relative';
                $countFilters = count($filters ?? []);
                $this->btnShowCurtainFilters->setLabel($this->btnShowCurtainFilters->getLabel(). "<span class='badge badge-success' style='position: absolute'>{$countFilters}<span>");
            }
            //</blockLine></btnShowCurtainFiltersAutoCode>

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            $this->datagrid->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {

                    $row = $this->datagrid->addItem($object);
                    $row->id = "row_{$object->id}";

                }
            }

            // reset the criteria for record count
            $criteria->resetProperties();
            $count= $repository->count($criteria);

            $this->pageNavigation->setCount($count); // count of records
            $this->pageNavigation->setProperties($param); // order, page
            $this->pageNavigation->setLimit($this->limit); // limit

            // close the transaction
            TTransaction::close();
            $this->loaded = true;

            return $objects;
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

    /**
     * method show()
     * Shows the page
     */
    public function show()
    {
        // check if the datagrid is already loaded
        if (!$this->loaded AND (!isset($_GET['method']) OR !(in_array($_GET['method'],  $this->showMethods))) )
        {
            if (func_num_args() > 0)
            {
                $this->onReload( func_get_arg(0) );
            }
            else
            {
                $this->onReload();
            }
        }
        parent::show();
    }

    public static function manageRow($id, $param = [])
    {
        $list = new self($param);

        $openTransaction = TTransaction::getDatabase() != self::$database ? true : false;

        if($openTransaction)
        {
            TTransaction::open(self::$database);    
        }

        $object = new SaasPagamento($id);

        $row = $list->datagrid->addItem($object);
        $row->id = "row_{$object->id}";

        if($openTransaction)
        {
            TTransaction::close();    
        }

        TDataGrid::replaceRowById(__CLASS__.'_datagrid', $row->id, $row);
    }

}

