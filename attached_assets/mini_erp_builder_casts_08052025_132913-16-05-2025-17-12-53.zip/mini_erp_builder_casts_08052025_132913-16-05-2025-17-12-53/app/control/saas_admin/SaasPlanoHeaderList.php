<?php

class SaasPlanoHeaderList extends TPage
{
    private $form; // form
    private $datagrid; // listing
    private $pageNavigation;
    private $loaded;
    private $filter_criteria;
    private static $database = 'minierp';
    private static $activeRecord = 'SaasPlano';
    private static $primaryKey = 'id';
    private static $formName = 'formList_SaasPlano';
    private $showMethods = ['onReload', 'onSearch'];
    private $limit = 20;

    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct($param = null)
    {
        parent::__construct();
        // creates the form

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        $this->limit = 20;

        $id = new TEntry('id');
        $nome = new TEntry('nome');
        $ativo = new TCombo('ativo');

        $id->exitOnEnter();
        $nome->exitOnEnter();

        $id->setExitAction(new TAction([$this, 'onSearch'], ['static'=>'1', 'target_container' => $param['target_container'] ?? null]));
        $nome->setExitAction(new TAction([$this, 'onSearch'], ['static'=>'1', 'target_container' => $param['target_container'] ?? null]));

        $ativo->setChangeAction(new TAction([$this, 'onSearch'], ['static'=>'1', 'target_container' => $param['target_container'] ?? null]));

        $ativo->addItems(["T"=>"Sim","F"=>"Não"]);
        $id->setSize('100%');
        $nome->setSize('100%');
        $ativo->setSize('100%');

        // creates a Datagrid
        $this->datagrid = new TDataGrid;
        $this->datagrid->setId(__CLASS__.'_datagrid');

        $this->datagrid_form = new TForm(self::$formName);
        $this->datagrid_form->onsubmit = 'return false';

        $this->datagrid = new BootstrapDatagridWrapper($this->datagrid);
        $this->filter_criteria = new TCriteria;

        $this->datagrid->disableDefaultClick();
        $this->datagrid->style = 'width: 100%';
        $this->datagrid->setHeight(320);

        $column_id = new TDataGridColumn('id', "Id", 'center' , '70px');
        $column_nome = new TDataGridColumn('nome', "Nome", 'left');
        $column_saas_servico_nome = new TDataGridColumn('saas_servico->nome', "Serviço", 'left');
        $column_ordem = new TDataGridColumn('ordem', "Ordem", 'left');
        $column_ativo_transformed = new TDataGridColumn('ativo', "Ativo", 'right' , '100px');

        $column_ativo_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            if($value === 'T' || $value === true || $value === 't' || $value === 'S' || $value === 'Y'  || $value === 'y'  )
            {
                return '<span class="label label-success">Sim</span>';
            }
            elseif($value === 'F' || $value === false || $value === 'f' || $value === 'N' || $value === 'n'  )
            {
                return '<span class="label label-danger">Não</span>';
            }

            return '';

        });        

        $column_ordem->setTransformer( function($value, $object, $row) {

            $pk = $object->getPrimaryKey();

            $ordem = new TSpinner($object->$pk.'_'.'ordem');
            $ordem->setSize(110);
            $ordem->setRange(1, 20, 1);

            $ordem->setFormName(self::$formName);
            $ordem->setValue($value);
            $action = new TAction( [$this, 'onSaveInline'] );
            $action->setParameter('column', 'ordem');

            $ordem->setExitAction( $action );

            return $ordem;
        });

        $order_id = new TAction(array($this, 'onReload'));
        $order_id->setParameter('order', 'id');
        $column_id->setAction($order_id);

        $this->datagrid->addColumn($column_id);
        $this->datagrid->addColumn($column_nome);
        $this->datagrid->addColumn($column_saas_servico_nome);
        $this->datagrid->addColumn($column_ordem);
        $this->datagrid->addColumn($column_ativo_transformed);

        $action_onShowDetailList = new TDataGridAction(array('SaasPlanoHeaderList', 'onShowDetailList'));
        $action_onShowDetailList->setUseButton(false);
        $action_onShowDetailList->setButtonClass('btn btn-default btn-sm');
        $action_onShowDetailList->setLabel("Visualizar valores do plano");
        $action_onShowDetailList->setImage('fas:plus #2196F3');
        $action_onShowDetailList->setField(self::$primaryKey);

        $action_onShowDetailList->setParameter('saas_plano_id', '{id}');

        $this->datagrid->addAction($action_onShowDetailList);

        $action_onEdit = new TDataGridAction(array('SaasPlanoForm', 'onEdit'));
        $action_onEdit->setUseButton(false);
        $action_onEdit->setButtonClass('btn btn-default btn-sm');
        $action_onEdit->setLabel("Editar");
        $action_onEdit->setImage('far:edit #478fca');
        $action_onEdit->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onEdit);

        // create the datagrid model
        $this->datagrid->createModel();

        $tr = new TElement('tr');
        $this->datagrid->prependRow($tr);

        if(!$action_onShowDetailList->isHidden())
        {
            $tr->add(TElement::tag('td', ''));
        }
        if(!$action_onEdit->isHidden())
        {
            $tr->add(TElement::tag('td', ''));
        }
        $td_id = TElement::tag('td', $id);
        $tr->add($td_id);
        $td_nome = TElement::tag('td', $nome);
        $tr->add($td_nome);
        $td_empty = TElement::tag('td', "");
        $tr->add($td_empty);
        $td_empty = TElement::tag('td', "");
        $tr->add($td_empty);
        $td_ativo = TElement::tag('td', $ativo);
        $tr->add($td_ativo);

        $this->datagrid_form->addField($id);
        $this->datagrid_form->addField($nome);
        $this->datagrid_form->addField($ativo);

        $this->datagrid_form->setData( TSession::getValue(__CLASS__.'_filter_data') );

        // creates the page navigation
        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
        $this->pageNavigation->setWidth($this->datagrid->getWidth());

        $this->datagrid->disableDefaultClick(); 

        $panel = new TPanelGroup("Listagem de planos");
        $panel->datagrid = 'datagrid-container';
        $this->datagridPanel = $panel;
        $panel->getBody()->class .= ' table-responsive';

        $panel->addFooter($this->pageNavigation);

        $headerActions = new TElement('div');
        $headerActions->class = ' datagrid-header-actions ';

        $head_left_actions = new TElement('div');
        $head_left_actions->class = ' datagrid-header-actions-left-actions ';

        $head_right_actions = new TElement('div');
        $head_right_actions->class = ' datagrid-header-actions-left-actions ';

        $headerActions->add($head_left_actions);
        $headerActions->add($head_right_actions);

        $this->datagrid_form->add($this->datagrid);
        $panel->add($headerActions);
        $panel->add($this->datagrid_form);

        $button_cadastrar = new TButton('button_button_cadastrar');
        $button_cadastrar->setAction(new TAction(['SaasPlanoForm', 'onShow']), "Cadastrar");
        $button_cadastrar->addStyleClass('btn-default');
        $button_cadastrar->setImage('fas:plus #69aa46');

        $this->datagrid_form->addField($button_cadastrar);

        $button_atualizar = new TButton('button_button_atualizar');
        $button_atualizar->setAction(new TAction(['SaasPlanoHeaderList', 'onRefresh']), "Atualizar");
        $button_atualizar->addStyleClass('btn-default');
        $button_atualizar->setImage('fas:sync-alt #03a9f4');

        $this->datagrid_form->addField($button_atualizar);

        $head_left_actions->add($button_cadastrar);
        $head_left_actions->add($button_atualizar);

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["SaaS Admin","Planos"]));
        }

        $container->add($panel);

        parent::add($container);

    }

    public static function onShowDetailList($param = null) 
    {
        try 
        {
            //code here

                        $pageParam = [
                'target_container' => "row_{$param['key']}_SaasPlanoValorSimpleList_itens",
                'bforcedparam_saas_plano_id' => $param['saas_plano_id'],
                'saas_plano_id' => $param['saas_plano_id'],
                'register_state' => 'false'
            ];

            TApplication::loadPage('SaasPlanoValorSimpleList', 'onReload', $pageParam);
            TScript::create(" Builder.toggleDetailRow('SaasPlanoValorSimpleList', 'onShowDetailList', '{$param['key']}', 'SaasPlanoHeaderList_datagrid') ");

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onRefresh($param = null) 
    {
        $this->onReload([]);
    }

    public static function onSaveInline($param)
    {
        $name   = $param['_field_name'];
        $value  = $param['_field_value'];
        $column = $param['column'];
        $parts  = explode('_', $name);
        $id     = $parts[0];

        if(!empty($param['_builder_field_options']))
        {
            $field_options = unserialize(base64_decode($param['_builder_field_options']));
            if(!empty($field_options['component']) && $field_options['component'] == 'TDate' && !empty($value) && $field_options['viewMask'] != $field_options['databaseMask'])
            {
                $value = TDate::convertToMask($value, $field_options['viewMask'], $field_options['databaseMask']);
            }
            elseif(!empty($field_options['component']) && $field_options['component'] == 'TDateTime' && !empty($value) && $field_options['viewMask'] != $field_options['databaseMask'])
            {
                $value = TDateTime::convertToMask($value, $field_options['viewMask'], $field_options['databaseMask']);
            }
            elseif(!empty($field_options['component']) && $field_options['component'] == 'TNumeric' && !empty($value))
            {
                $value = str_replace( $field_options['thousandSeparator'], '', $value);
                $value = str_replace( $field_options['decimalSeparator'], '.', $value);
            }
        }

        try
        {
            // open transaction
            TTransaction::open(self::$database);
            $class = self::$activeRecord;
            $object = $class::find($id);
            if ($object)
            {
                $object->$column = $value;

                $object->store();

            }

            // close transaction
            TTransaction::close();
        }
        catch (Exception $e)
        {
            // show the exception message
            new TMessage('error', $e->getMessage());
        }
    }

    /**
     * Register the filter in the session
     */
    public function onSearch($param = null)
    {
        // get the search form data
        $data = $this->datagrid_form->getData();
        $filters = [];

        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        if (isset($data->id) AND ( (is_scalar($data->id) AND $data->id !== '') OR (is_array($data->id) AND (!empty($data->id)) )) )
        {

            $filters[] = new TFilter('id', '=', $data->id);// create the filter 
        }

        if (isset($data->nome) AND ( (is_scalar($data->nome) AND $data->nome !== '') OR (is_array($data->nome) AND (!empty($data->nome)) )) )
        {

            $filters[] = new TFilter('nome', 'like', "%{$data->nome}%");// create the filter 
        }

        // fill the form with data again
        $this->datagrid_form->setData($data);

        // keep the search data in the session
        TSession::setValue(__CLASS__.'_filter_data', $data);
        TSession::setValue(__CLASS__.'_filters', $filters);

        if (isset($param['static']) && ($param['static'] == '1') )
        {
            $class = get_class($this);
            $onReloadParam = ['offset' => 0, 'first_page' => 1, 'target_container' => $param['target_container'] ?? null];
            AdiantiCoreApplication::loadPage($class, 'onReload', $onReloadParam);
            TScript::create('$(".select2").prev().select2("close");');
        }
        else
        {
            $this->onReload(['offset' => 0, 'first_page' => 1]);
        }
    }

    /**
     * Load the datagrid with data
     */
    public function onReload($param = NULL)
    {
        try
        {
            // open a transaction with database 'minierp'
            TTransaction::open(self::$database);

            // creates a repository for SaasPlano
            $repository = new TRepository(self::$activeRecord);

            $criteria = clone $this->filter_criteria;

            if (empty($param['order']))
            {
                $param['order'] = 'id';    
            }
            if (empty($param['direction']))
            {
                $param['direction'] = 'desc';
            }

            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $this->limit);

            if($filters = TSession::getValue(__CLASS__.'_filters'))
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            $cont = 1;

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            $this->datagrid->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {
                    $rowContainer = new TTableRow();

                    $div = new TElement('div');
                    $div->id = "row_{$object->id}_SaasPlanoValorSimpleList_itens";

                    $container = new BPageContainer();
                    $container->setAction(new TAction(['SaasPlanoValorSimpleList', 'onReload'], ['bforcedparam_saas_plano_id'=> $object->id, 'saas_plano_id'=> $object->id]));
                    $container->setId($div->id);

                    $div->add($container);

                    $row = $this->datagrid->addItem($object);
                    $row->id = "row_{$object->id}";
                    $cell = $rowContainer->addCell($div);

                    $cell->colspan = $this->datagrid->getTotalColumns();
                    $cell->style='padding:10px;';

                    $container->hide();

                    $rowContainer->style = 'display:none';

                    $rowContainerHidden = new TTableRow();
                    $rowContainerHidden->style = 'display:none';
                    $rowContainerHidden->addCell('')->colspan = $this->datagrid->getTotalColumns();
                    $this->datagrid->insert($cont + 1, $rowContainerHidden);
                    $this->datagrid->insert($cont + 1, $rowContainer);

                    $cont+=3;
                }
            }

            // reset the criteria for record count
            $criteria->resetProperties();
            $count= $repository->count($criteria);

            $this->pageNavigation->setCount($count); // count of records
            $this->pageNavigation->setProperties($param); // order, page
            $this->pageNavigation->setLimit($this->limit); // limit

            // close the transaction
            TTransaction::close();
            $this->loaded = true;

            return $objects;
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

    /**
     * method show()
     * Shows the page
     */
    public function show()
    {
        // check if the datagrid is already loaded
        if (!$this->loaded AND (!isset($_GET['method']) OR !(in_array($_GET['method'],  $this->showMethods))) )
        {
            if (func_num_args() > 0)
            {
                $this->onReload( func_get_arg(0) );
            }
            else
            {
                $this->onReload();
            }
        }
        parent::show();
    }

    public static function manageRow($id, $param = [])
    {
        $list = new self($param);

        $openTransaction = TTransaction::getDatabase() != self::$database ? true : false;

        if($openTransaction)
        {
            TTransaction::open(self::$database);    
        }

        $object = new SaasPlano($id);

        $row = $list->datagrid->addItem($object);
        $row->id = "row_{$object->id}";

        if($openTransaction)
        {
            TTransaction::close();    
        }

        TDataGrid::replaceRowById(__CLASS__.'_datagrid', $row->id, $row);
    }

}

