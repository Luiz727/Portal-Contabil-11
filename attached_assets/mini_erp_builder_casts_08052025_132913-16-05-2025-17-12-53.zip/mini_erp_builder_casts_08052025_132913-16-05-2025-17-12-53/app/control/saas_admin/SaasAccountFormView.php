<?php

class SaasAccountFormView extends TPage
{
    protected $form; // form
    private static $database = 'minierp';
    private static $activeRecord = 'Account';
    private static $primaryKey = 'id';
    private static $formName = 'formView_Account';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        TTransaction::open(self::$database);
        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        $this->form->setTagName('div');

        $account = new Account($param['key']);
        // define the form title
        $this->form->setFormTitle("Consulta de account");

        $label1 = new TLabel("Id:", '', '14px', 'B', '100%');
        $text1 = new TTextDisplay($account->id, '', '16px', '');
        $label4 = new TLabel("Nome responsavel:", '', '14px', 'B', '100%');
        $text4 = new TTextDisplay($account->nome_responsavel, '', '16px', '');
        $label5 = new TLabel("Razao social:", '', '14px', 'B', '100%');
        $text5 = new TTextDisplay($account->razao_social, '', '16px', '');
        $label7 = new TLabel("Documento:", '', '14px', 'B', '100%');
        $text7 = new TTextDisplay($account->documento, '', '16px', '');
        $label3 = new TLabel("Usuário principal no sistema:", '', '14px', 'B', '100%');
        $text3 = new TTextDisplay($account->system_user->login, '', '16px', '');
        $label17 = new TLabel("Criado em:", '', '14px', 'B', '100%');
        $text17 = new TTextDisplay(TDateTime::convertToMask($account->created_at, 'yyyy-mm-dd hh:ii', 'dd/mm/yyyy hh:ii'), '', '16px', '');
        $label8 = new TLabel("Email:", '', '14px', 'B', '100%');
        $text8 = new TTextDisplay($account->email, '', '16px', '');
        $label9 = new TLabel("Telefone:", '', '14px', 'B', '100%');
        $text9 = new TTextDisplay($account->telefone, '', '16px', '');
        $label_estado = new TLabel("Estado:", '', '14px', 'B', '100%');
        $textetado = new TTextDisplay($account->cidade->estado->nome, '', '16px', '');
        $label2 = new TLabel("Cidade:", '', '14px', 'B', '100%');
        $text2 = new TTextDisplay($account->cidade->nome, '', '16px', '');
        $label10 = new TLabel("Cep:", '', '14px', 'B', '100%');
        $text10 = new TTextDisplay($account->cep, '', '16px', '');
        $label14 = new TLabel("Bairro:", '', '14px', 'B', '100%');
        $text14 = new TTextDisplay($account->bairro, '', '16px', '');
        $label11 = new TLabel("Rua:", '', '14px', 'B', '100%');
        $text11 = new TTextDisplay($account->rua, '', '16px', '');
        $label12 = new TLabel("Numero:", '', '14px', 'B', '100%');
        $text12 = new TTextDisplay($account->numero, '', '16px', '');
        $label13 = new TLabel("Complemento:", '', '14px', 'B', '100%');
        $text13 = new TTextDisplay($account->complemento, '', '16px', '');

        $row1 = $this->form->addFields([$label1,$text1],[$label4,$text4],[$label5,$text5],[$label7,$text7]);
        $row1->layout = [' col-sm-3',' col-sm-3',' col-sm-3',' col-sm-3'];

        $row2 = $this->form->addFields([$label3,$text3],[$label17,$text17],[],[]);
        $row2->layout = ['col-sm-3','col-sm-3',' col-sm-3',' col-sm-3'];

        $tab_667db25916086 = new BootstrapFormBuilder('tab_667db25916086');
        $this->tab_667db25916086 = $tab_667db25916086;
        $tab_667db25916086->setProperty('style', 'border:none; box-shadow:none;');

        $tab_667db25916086->appendPage("Contato");

        $tab_667db25916086->addFields([new THidden('current_tab_tab_667db25916086')]);
        $tab_667db25916086->setTabFunction("$('[name=current_tab_tab_667db25916086]').val($(this).attr('data-current_page'));");

        $row3 = $tab_667db25916086->addFields([$label8,$text8],[$label9,$text9]);
        $row3->layout = [' col-sm-6',' col-sm-6'];

        $tab_667db25916086->appendPage("Endereço");
        $row4 = $tab_667db25916086->addFields([$label_estado,$textetado],[$label2,$text2],[$label10,$text10],[$label14,$text14]);
        $row4->layout = [' col-sm-3',' col-sm-3',' col-sm-3',' col-sm-3'];

        $row5 = $tab_667db25916086->addFields([$label11,$text11],[$label12,$text12],[$label13,$text13],[]);
        $row5->layout = [' col-sm-3',' col-sm-3',' col-sm-3',' col-sm-3'];

        $row6 = $this->form->addFields([$tab_667db25916086]);
        $row6->layout = [' col-sm-12'];

        $this->saas_pagamento_account_id_list = new TQuickGrid;
        $this->saas_pagamento_account_id_list->style = 'width:100%';
        $this->saas_pagamento_account_id_list->disableDefaultClick();

        $column_saas_contrato_saas_plano_valor_saas_plano_nome = $this->saas_pagamento_account_id_list->addQuickColumn("Plano", 'saas_contrato->saas_plano_valor->saas_plano->nome', 'left');
        $column_saas_forma_pagamento_nome = $this->saas_pagamento_account_id_list->addQuickColumn("Forma pgto.", 'saas_forma_pagamento->nome', 'left');
        $column_saas_gateway_pagamento_nome = $this->saas_pagamento_account_id_list->addQuickColumn("Gateway", 'saas_gateway_pagamento->nome', 'left');
        $column_data_compra_transformed = $this->saas_pagamento_account_id_list->addQuickColumn("Data compra", 'data_compra', 'center');
        $column_data_vencimento_transformed = $this->saas_pagamento_account_id_list->addQuickColumn("Data vencimento", 'data_vencimento', 'center');
        $column_data_pagamento_transformed = $this->saas_pagamento_account_id_list->addQuickColumn("Data pagamento", 'data_pagamento', 'center');
        $column_valor_transformed = $this->saas_pagamento_account_id_list->addQuickColumn("Valor", 'valor', 'right');

        $column_valor_transformed->setTotalFunction( function($values) { 
            return array_sum((array) $values); 
        }); 

        $column_data_compra_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_data_vencimento_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y H:i');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_data_pagamento_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_valor_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });

        $this->saas_pagamento_account_id_list->createModel();

        $criteria_saas_pagamento_account_id = new TCriteria();
        $criteria_saas_pagamento_account_id->add(new TFilter('account_id', '=', $account->id));

        $criteria_saas_pagamento_account_id->setProperty('order', 'id desc');

        $saas_pagamento_account_id_items = SaasPagamento::getObjects($criteria_saas_pagamento_account_id);

        $this->saas_pagamento_account_id_list->addItems($saas_pagamento_account_id_items);

        $icon = new TImage('fas:money-bill-alt #000000');
        $title = new TTextDisplay("{$icon} Pagamentos", '#333', '16px', '{$fontStyle}');

        $panel = new TPanelGroup($title, '#FFFFFF');
        $panel->class = 'panel panel-default formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->saas_pagamento_account_id_list));

        $this->form->addContent([$panel]);

        $this->system_users_account_id_list = new TQuickGrid;
        $this->system_users_account_id_list->style = 'width:100%';
        $this->system_users_account_id_list->disableDefaultClick();

        $column_name = $this->system_users_account_id_list->addQuickColumn("Nome", 'name', 'left');
        $column_login = $this->system_users_account_id_list->addQuickColumn("Login", 'login', 'left');
        $column_email = $this->system_users_account_id_list->addQuickColumn("Email", 'email', 'left');
        $column_active_transformed = $this->system_users_account_id_list->addQuickColumn("Ativo", 'active', 'left');

        $column_active_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if ($value && $value == 'F')
            {
                return "<div class='label' style='background-color:#dd4b39; color: white;' >Não</div>";
            }
            return "<div class='label' style=' background-color: #00a65a; color: white;' >Sim</div>";

        });

        $this->system_users_account_id_list->createModel();

        $criteria_system_users_account_id = new TCriteria();
        $criteria_system_users_account_id->add(new TFilter('account_id', '=', $account->id));

        $criteria_system_users_account_id->setProperty('order', 'id desc');

        $system_users_account_id_items = SystemUsers::getObjects($criteria_system_users_account_id);

        $this->system_users_account_id_list->addItems($system_users_account_id_items);

        $icon = new TImage('fas:users #000000');
        $title = new TTextDisplay("{$icon} Usuários", '#333', '16px', '{$fontStyle}');

        $panel = new TPanelGroup($title, '#FFFFFF');
        $panel->class = 'panel panel-default formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->system_users_account_id_list));

        $this->form->addContent([$panel]);

        $this->system_unit_account_id_list = new TQuickGrid;
        $this->system_unit_account_id_list->style = 'width:100%';
        $this->system_unit_account_id_list->disableDefaultClick();

        $column_name1 = $this->system_unit_account_id_list->addQuickColumn("Nome", 'name', 'left');
        $column_active_transformed1 = $this->system_unit_account_id_list->addQuickColumn("Ativa", 'active', 'left');

        $column_active_transformed1->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            if($value === 'T' || $value === true || $value === 't' || $value === 'S' || $value === 'Y'  || $value === 'y'  )
            {
                return '<span class="label label-success">Sim</span>';
            }
            elseif($value === 'F' || $value === false || $value === 'f' || $value === 'N' || $value === 'n'  )
            {
                return '<span class="label label-danger">Não</span>';
            }

            return '';

        });

        $this->system_unit_account_id_list->createModel();

        $criteria_system_unit_account_id = new TCriteria();
        $criteria_system_unit_account_id->add(new TFilter('account_id', '=', $account->id));

        $criteria_system_unit_account_id->setProperty('order', 'id desc');

        $system_unit_account_id_items = SystemUnit::getObjects($criteria_system_unit_account_id);

        $this->system_unit_account_id_list->addItems($system_unit_account_id_items);

        $icon = new TImage('fas:warehouse #000000');
        $title = new TTextDisplay("{$icon} Unidades", '#333', '16px', '{$fontStyle}');

        $panel = new TPanelGroup($title, '#FFFFFF');
        $panel->class = 'panel panel-default formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->system_unit_account_id_list));

        $this->form->addContent([$panel]);

        if(!empty($param['current_tab']))
        {
            $this->form->setCurrentPage($param['current_tab']);
        }

        if(!empty($param['current_tab_tab_667db25916086']))
        {
            $this->tab_667db25916086->setCurrentPage($param['current_tab_tab_667db25916086']);
        }

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        TTransaction::close();
        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=SaasAccountFormView]');
        $style->width = '70% !important';   
        $style->show(true);

    }

    public function onShow($param = null)
    {     

    }

}

