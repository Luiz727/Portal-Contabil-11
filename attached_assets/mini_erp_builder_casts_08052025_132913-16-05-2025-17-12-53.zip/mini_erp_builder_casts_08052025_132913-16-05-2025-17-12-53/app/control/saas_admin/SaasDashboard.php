<?php

class SaasDashboard extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_SaasDashboard';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Dashboard");

        $criteria_total_vendido_mes = new TCriteria();
        $criteria_total_vendido_ano = new TCriteria();
        $criteria_cadastros_mes = new TCriteria();
        $criteria_faturamento_por_mes = new TCriteria();
        $criteria_venda_gateway = new TCriteria();
        $criteria_planos_vendidos_mes = new TCriteria();
        $criteria_accounts = new TCriteria();
        $criteria_users = new TCriteria();
        $criteria_proximos_vencimentos = new TCriteria();

        $filterVar = SaasContratoStatus::ATIVO;
        $criteria_accounts->add(new TFilter('saas_contrato.saas_contrato_status_id', '=', $filterVar)); 
        $filterVar = "Y";
        $criteria_users->add(new TFilter('system_users.active', '=', $filterVar)); 
        $filterVar = date('Y-m-d', strtotime('-10 days'));
        $criteria_proximos_vencimentos->add(new TFilter('saas_contrato.data_final', '>=', $filterVar)); 
        $filterVar = SaasContratoStatus::ATIVO;
        $criteria_proximos_vencimentos->add(new TFilter('saas_contrato.saas_contrato_status_id', '=', $filterVar)); 

        $ano = new TCombo('ano');
        $mes = new TCombo('mes');
        $button_filtrar = new TButton('button_filtrar');
        $total_vendido_mes = new BIndicator('total_vendido_mes');
        $total_vendido_ano = new BIndicator('total_vendido_ano');
        $cadastros_mes = new BIndicator('cadastros_mes');
        $faturamento_por_mes = new BBarChart('faturamento_por_mes');
        $venda_gateway = new BPieChart('venda_gateway');
        $planos_vendidos_mes = new BPieChart('planos_vendidos_mes');
        $accounts = new BIndicator('accounts');
        $users = new BIndicator('users');
        $proximos_vencimentos = new BTableChart('proximos_vencimentos');


        $button_filtrar->setAction(new TAction(['SaasDashboard', 'onShow']), "Filtrar");
        $button_filtrar->addStyleClass('btn-default');
        $button_filtrar->setImage('fas:filter #000000');
        $ano->setSize('100%');
        $mes->setSize('100%');

        $ano->addItems(SaasTempoService::getAnos());
        $mes->addItems(SaasTempoService::getMeses());

        $ano->setValue($param["ano"] ?? date('Y'));
        $mes->setValue($param["mes "] ?? date('m'));

        $ano->enableSearch();
        $mes->enableSearch();

        $total_vendido_mes->setDatabase('minierp');
        $total_vendido_mes->setFieldValue("saas_pagamento.valor");
        $total_vendido_mes->setModel('SaasPagamento');
        $total_vendido_mes->setTransformerValue(function($value)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $total_vendido_mes->setTotal('sum');
        $total_vendido_mes->setColors('#27ae60', '#ffffff', '#2ecc71', '#ffffff');
        $total_vendido_mes->setTitle("FATURAMENTO NO MÊS", '#ffffff', '20', '');
        $total_vendido_mes->setCriteria($criteria_total_vendido_mes);
        $total_vendido_mes->setValueSize("20");
        $total_vendido_mes->setValueColor("#ffffff", 'B');
        $total_vendido_mes->setSize('100%', 90);
        $total_vendido_mes->setLayout('horizontal', 'left');

        $total_vendido_ano->setDatabase('minierp');
        $total_vendido_ano->setFieldValue("saas_pagamento.valor");
        $total_vendido_ano->setModel('SaasPagamento');
        $total_vendido_ano->setTransformerValue(function($value)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $total_vendido_ano->setTotal('sum');
        $total_vendido_ano->setColors('#1ABC9C', '#FFFFFF', '#16A085', '#FFFFFF');
        $total_vendido_ano->setTitle("FATURAMENTO NO ANO", '#FFFFFF', '20', '');
        $total_vendido_ano->setCriteria($criteria_total_vendido_ano);
        $total_vendido_ano->setValueSize("20");
        $total_vendido_ano->setValueColor("#FFFFFF", 'B');
        $total_vendido_ano->setSize('100%', 90);
        $total_vendido_ano->setLayout('horizontal', 'left');

        $cadastros_mes->setDatabase('minierp');
        $cadastros_mes->setFieldValue("account.id");
        $cadastros_mes->setModel('Account');
        $cadastros_mes->setTotal('count');
        $cadastros_mes->setColors('#D35400', '#FFFFFF', '#E67E22', '#FFFFFF');
        $cadastros_mes->setTitle("CADASTROS NO MÊS", '#FFFFFF', '20', '');
        $cadastros_mes->setCriteria($criteria_cadastros_mes);
        $cadastros_mes->setValueSize("20");
        $cadastros_mes->setValueColor("#FFFFFF", 'B');
        $cadastros_mes->setSize('100%', 90);
        $cadastros_mes->setLayout('horizontal', 'left');

        $faturamento_por_mes->setDatabase('minierp');
        $faturamento_por_mes->setFieldValue("saas_pagamento.valor");
        $faturamento_por_mes->setFieldGroup(["saas_pagamento.mes_ano_pagamento"]);
        $faturamento_por_mes->setModel('SaasPagamento');
        $faturamento_por_mes->setTitle("Faturamento por mês");
        $faturamento_por_mes->setTransformerLegend(function($value, $row, $data)
            {
                if($value)
                {
                    $mes = explode('/', $value);

                    $meses = SaasTempoService::getMesesAbreviados();
                    $mesAbrev = $meses[$mes[0]];

                    return "{$mesAbrev} / {$mes[1]}";    
                }

                return $value;
            });
        $faturamento_por_mes->setTransformerValue(function($value, $row, $data)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $faturamento_por_mes->setLayout('vertical');
        $faturamento_por_mes->setTotal('sum');
        $faturamento_por_mes->showLegend(true);
        $faturamento_por_mes->setCriteria($criteria_faturamento_por_mes);
        $faturamento_por_mes->setLabelValue("Total");
        $faturamento_por_mes->setSize('100%', 280);
        $faturamento_por_mes->disableZoom();

        $venda_gateway->setDatabase('minierp');
        $venda_gateway->setFieldValue("saas_pagamento.valor");
        $venda_gateway->setFieldGroup("saas_gateway_pagamento.nome");
        $venda_gateway->setModel('SaasPagamento');
        $venda_gateway->setTitle("Vendas gateway");
        $venda_gateway->setTransformerValue(function($value, $row, $data)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $venda_gateway->setJoins([
             'saas_gateway_pagamento' => ['saas_pagamento.saas_gateway_pagamento_id', 'saas_gateway_pagamento.id']
        ]);
        $venda_gateway->setTotal('sum');
        $venda_gateway->showLegend(true);
        $venda_gateway->enableOrderByValue('asc');
        $venda_gateway->setCriteria($criteria_venda_gateway);
        $venda_gateway->setSize('100%', 280);
        $venda_gateway->disableZoom();

        $planos_vendidos_mes->setDatabase('minierp');
        $planos_vendidos_mes->setFieldValue("saas_pagamento.valor");
        $planos_vendidos_mes->setFieldGroup("saas_plano.nome");
        $planos_vendidos_mes->setModel('SaasPagamento');
        $planos_vendidos_mes->setTitle("Planos vendidos");
        $planos_vendidos_mes->setTransformerValue(function($value, $row, $data)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });
        $planos_vendidos_mes->setJoins([
             'saas_contrato' => ['saas_pagamento.saas_contrato_id', 'saas_contrato.id'],
             'saas_plano_valor' => ['saas_contrato.saas_plano_valor_id', 'saas_plano_valor.id'],
             'saas_plano' => ['saas_plano_valor.saas_plano_id', 'saas_plano.id']
        ]);
        $planos_vendidos_mes->setTotal('sum');
        $planos_vendidos_mes->showLegend(true);
        $planos_vendidos_mes->setCriteria($criteria_planos_vendidos_mes);
        $planos_vendidos_mes->setSize('100%', 280);
        $planos_vendidos_mes->disableZoom();

        $accounts->setDatabase('minierp');
        $accounts->setFieldValue("saas_contrato.id");
        $accounts->setModel('SaasContrato');
        $accounts->setTotal('count');
        $accounts->setColors('#27ae60', '#ffffff', '#2ecc71', '#ffffff');
        $accounts->setTitle("Contratos", '#ffffff', '20', '');
        $accounts->setCriteria($criteria_accounts);
        $accounts->setIcon(new TImage('fas:file-contract #ffffff'));
        $accounts->setValueSize("35");
        $accounts->setValueColor("#ffffff", 'B');
        $accounts->setSize('100%', 95);
        $accounts->setLayout('horizontal', 'left');

        $users->setDatabase('minierp');
        $users->setFieldValue("system_users.id");
        $users->setModel('SystemUsers');
        $users->setTotal('count');
        $users->setColors('#27ae60', '#ffffff', '#2ecc71', '#ffffff');
        $users->setTitle("Usuários", '#ffffff', '20', '');
        $users->setCriteria($criteria_users);
        $users->setIcon(new TImage('fas:user #ffffff'));
        $users->setValueSize("35");
        $users->setValueColor("#ffffff", 'B');
        $users->setSize('100%', 95);
        $users->setLayout('horizontal', 'left');

        $proximos_vencimentos_column_account_razao_social = new BTableColumnChart('account.razao_social', "Conta", 'left','30%');
        $proximos_vencimentos_column_account_nome_responsavel = new BTableColumnChart('account.nome_responsavel', "Responsável", 'left','30%');
        $proximos_vencimentos_column_saas_plano_nome = new BTableColumnChart('saas_plano.nome', "Plano", 'left','25%');
        $proximos_vencimentos_column_data_final = new BTableColumnChart('data_final', "Vencimento", 'center','15%');

        $proximos_vencimentos->setDatabase('minierp');
        $proximos_vencimentos->setModel('SaasContrato');
        $proximos_vencimentos->setTitle("Contratos à vencer");
        $proximos_vencimentos->setSize('100%', 280);
        $proximos_vencimentos->setColumns([$proximos_vencimentos_column_account_razao_social,$proximos_vencimentos_column_account_nome_responsavel,$proximos_vencimentos_column_saas_plano_nome,$proximos_vencimentos_column_data_final]);
        $proximos_vencimentos->setCriteria($criteria_proximos_vencimentos);
        $proximos_vencimentos->setJoins([
             'account' => ['saas_contrato.account_id', 'account.id'],
             'saas_plano_valor' => ['saas_contrato.saas_plano_valor_id', 'saas_plano_valor.id'],
             'saas_plano' => ['saas_plano_valor.saas_plano_id', 'saas_plano.id']
        ]);

        $proximos_vencimentos->setRowColorOdd('#F9F9F9');
        $proximos_vencimentos->setRowColorEven('#FFFFFF');
        $proximos_vencimentos->setFontRowColorOdd('#333333');
        $proximos_vencimentos->setFontRowColorEven('#333333');
        $proximos_vencimentos->setBorderColor('#DDDDDD');
        $proximos_vencimentos->setTableHeaderColor('#FFFFFF');
        $proximos_vencimentos->setTableHeaderFontColor('#333333');
        $proximos_vencimentos->setTableFooterColor('#FFFFFF');
        $proximos_vencimentos->setTableFooterFontColor('#333333');

        $row1 = $this->form->addFields([new TLabel("Ano:", null, '14px', null, '100%'),$ano],[new TLabel("Mês:", null, '14px', null, '100%'),$mes],[new TLabel(" ", null, '14px', null, '100%'),$button_filtrar]);
        $row1->layout = [' col-sm-3',' col-sm-3',' col-sm-3'];

        $row2 = $this->form->addFields([$total_vendido_mes],[$total_vendido_ano],[$cadastros_mes]);
        $row2->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row3 = $this->form->addFields([$faturamento_por_mes]);
        $row3->layout = [' col-sm-12'];

        $row4 = $this->form->addFields([$venda_gateway],[$planos_vendidos_mes]);
        $row4->layout = [' col-sm-6',' col-sm-6'];

        $row5 = $this->form->addFields([new TFormSeparator(" ", '#333', '15', '#eee')]);
        $row5->layout = [' col-sm-12'];

        $row6 = $this->form->addFields([$accounts],[$users]);
        $row6->layout = [' col-sm-6',' col-sm-6'];

        $row7 = $this->form->addFields([$proximos_vencimentos]);
        $row7->layout = [' col-sm-12'];

        if(!isset($param['ano']) && $ano->getValue())
        {
            $_POST['ano'] = $ano->getValue();
        }
        if(!isset($param['mes']) && $mes->getValue())
        {
            $_POST['mes'] = $mes->getValue();
        }

        $searchData = $this->form->getData();
        $this->form->setData($searchData);

        $filterVar = $searchData->mes;
        if($filterVar)
        {
            $criteria_total_vendido_mes->add(new TFilter('saas_pagamento.mes_pagamento', '=', $filterVar)); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_total_vendido_mes->add(new TFilter('saas_pagamento.ano_pagamento', '=', $filterVar)); 
        }
        $filterVar = $searchData->mes;
        if($filterVar)
        {
            $criteria_total_vendido_ano->add(new TFilter('saas_pagamento.mes_pagamento', '=', $filterVar)); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_total_vendido_ano->add(new TFilter('saas_pagamento.ano_pagamento', '=', $filterVar)); 
        }
        $filterVar = $searchData->mes;
        if($filterVar)
        {
            $criteria_cadastros_mes->add(new TFilter('account.mes_criacao', '=', $filterVar)); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_cadastros_mes->add(new TFilter('account.ano_criacao', '=', $filterVar)); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_faturamento_por_mes->add(new TFilter('saas_pagamento.ano_pagamento', '=', $filterVar)); 
        }
        $filterVar = $searchData->mes;
        if($filterVar)
        {
            $criteria_venda_gateway->add(new TFilter('saas_pagamento.mes_compra', '=', $filterVar)); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_venda_gateway->add(new TFilter('saas_pagamento.ano_compra', '=', $filterVar)); 
        }
        $filterVar = $searchData->ano;
        if($filterVar)
        {
            $criteria_planos_vendidos_mes->add(new TFilter('saas_pagamento.ano_pagamento', '=', $filterVar)); 
        }
        $filterVar = $searchData->mes;
        if($filterVar)
        {
            $criteria_planos_vendidos_mes->add(new TFilter('saas_pagamento.mes_pagamento', '=', $filterVar)); 
        }

        BChart::generate($total_vendido_mes, $total_vendido_ano, $cadastros_mes, $faturamento_por_mes, $venda_gateway, $planos_vendidos_mes, $accounts, $users, $proximos_vencimentos);

        // create the form actions

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["SaaS Admin","Dashboard"]));
        }
        $container->add($this->form);

        parent::add($container);

    }

    public function onShow($param = null)
    {               

    } 

}

