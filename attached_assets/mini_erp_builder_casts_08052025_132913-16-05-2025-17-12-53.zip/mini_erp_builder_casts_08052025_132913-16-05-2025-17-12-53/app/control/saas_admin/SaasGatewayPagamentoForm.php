<?php

class SaasGatewayPagamentoForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'minierp';
    private static $activeRecord = 'SaasGatewayPagamento';
    private static $primaryKey = 'id';
    private static $formName = 'form_SaasGatewayPagamentoForm';

    use Adianti\Base\AdiantiFileSaveTrait;
    use BuilderMasterDetailFieldListTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de Gateway de pagamento");

        $criteria_saas_gateway_forma_pagamento_saas_gateway_pagamento_saas_forma_pagamento_id = new TCriteria();
        $criteria_saas_gateway_pagamento_status_saas_gateway_pagamento_saas_status_pagamento_id = new TCriteria();

        $nome = new TEntry('nome');
        $id = new THidden('id');
        $ativo = new TCheckButton('ativo');
        $fl_homologacao = new TCheckButton('fl_homologacao');
        $access_token = new TEntry('access_token');
        $client_id = new TEntry('client_id');
        $client_secret = new TEntry('client_secret');
        $public_key = new TEntry('public_key');
        $certificado_crt = new TFile('certificado_crt');
        $certificado_key = new TFile('certificado_key');
        $saas_gateway_forma_pagamento_saas_gateway_pagamento_id = new THidden('saas_gateway_forma_pagamento_saas_gateway_pagamento_id[]');
        $saas_gateway_forma_pagamento_saas_gateway_pagamento___row__id = new THidden('saas_gateway_forma_pagamento_saas_gateway_pagamento___row__id[]');
        $saas_gateway_forma_pagamento_saas_gateway_pagamento___row__data = new THidden('saas_gateway_forma_pagamento_saas_gateway_pagamento___row__data[]');
        $saas_gateway_forma_pagamento_saas_gateway_pagamento_saas_forma_pagamento_id = new TDBCombo('saas_gateway_forma_pagamento_saas_gateway_pagamento_saas_forma_pagamento_id[]', 'minierp', 'SaasFormaPagamento', 'id', '{nome}','nome asc' , $criteria_saas_gateway_forma_pagamento_saas_gateway_pagamento_saas_forma_pagamento_id );
        $saas_gateway_forma_pagamento_saas_gateway_pagamento_codigo = new TEntry('saas_gateway_forma_pagamento_saas_gateway_pagamento_codigo[]');
        $this->fieldList_Ffprmas = new TFieldList();
        $saas_gateway_pagamento_status_saas_gateway_pagamento_id = new THidden('saas_gateway_pagamento_status_saas_gateway_pagamento_id[]');
        $saas_gateway_pagamento_status_saas_gateway_pagamento___row__id = new THidden('saas_gateway_pagamento_status_saas_gateway_pagamento___row__id[]');
        $saas_gateway_pagamento_status_saas_gateway_pagamento___row__data = new THidden('saas_gateway_pagamento_status_saas_gateway_pagamento___row__data[]');
        $saas_gateway_pagamento_status_saas_gateway_pagamento_saas_status_pagamento_id = new TDBCombo('saas_gateway_pagamento_status_saas_gateway_pagamento_saas_status_pagamento_id[]', 'minierp', 'SaasStatusPagamento', 'id', '{nome}','nome asc' , $criteria_saas_gateway_pagamento_status_saas_gateway_pagamento_saas_status_pagamento_id );
        $saas_gateway_pagamento_status_saas_gateway_pagamento_codigo = new TEntry('saas_gateway_pagamento_status_saas_gateway_pagamento_codigo[]');
        $this->fieldList_status = new TFieldList();

        $this->fieldList_Ffprmas->addField(null, $saas_gateway_forma_pagamento_saas_gateway_pagamento_id, []);
        $this->fieldList_Ffprmas->addField(null, $saas_gateway_forma_pagamento_saas_gateway_pagamento___row__id, ['uniqid' => true]);
        $this->fieldList_Ffprmas->addField(null, $saas_gateway_forma_pagamento_saas_gateway_pagamento___row__data, []);
        $this->fieldList_Ffprmas->addField(new TLabel("Forma", null, '14px', null), $saas_gateway_forma_pagamento_saas_gateway_pagamento_saas_forma_pagamento_id, ['width' => '50%']);
        $this->fieldList_Ffprmas->addField(new TLabel("Código", null, '14px', null), $saas_gateway_forma_pagamento_saas_gateway_pagamento_codigo, ['width' => '50%']);

        $this->fieldList_Ffprmas->width = '100%';
        $this->fieldList_Ffprmas->setFieldPrefix('saas_gateway_forma_pagamento_saas_gateway_pagamento');
        $this->fieldList_Ffprmas->name = 'fieldList_Ffprmas';

        $this->criteria_fieldList_Ffprmas = new TCriteria();
        $this->default_item_fieldList_Ffprmas = new stdClass();

        $this->form->addField($saas_gateway_forma_pagamento_saas_gateway_pagamento_id);
        $this->form->addField($saas_gateway_forma_pagamento_saas_gateway_pagamento___row__id);
        $this->form->addField($saas_gateway_forma_pagamento_saas_gateway_pagamento___row__data);
        $this->form->addField($saas_gateway_forma_pagamento_saas_gateway_pagamento_saas_forma_pagamento_id);
        $this->form->addField($saas_gateway_forma_pagamento_saas_gateway_pagamento_codigo);

        $this->fieldList_Ffprmas->setRemoveAction(null, 'fas:times #dd5a43', "Excluír");

        $this->fieldList_status->addField(null, $saas_gateway_pagamento_status_saas_gateway_pagamento_id, []);
        $this->fieldList_status->addField(null, $saas_gateway_pagamento_status_saas_gateway_pagamento___row__id, ['uniqid' => true]);
        $this->fieldList_status->addField(null, $saas_gateway_pagamento_status_saas_gateway_pagamento___row__data, []);
        $this->fieldList_status->addField(new TLabel("Status no sistema", null, '14px', null), $saas_gateway_pagamento_status_saas_gateway_pagamento_saas_status_pagamento_id, ['width' => '50%']);
        $this->fieldList_status->addField(new TLabel("Código no Gateway", null, '14px', null), $saas_gateway_pagamento_status_saas_gateway_pagamento_codigo, ['width' => '50%']);

        $this->fieldList_status->width = '100%';
        $this->fieldList_status->setFieldPrefix('saas_gateway_pagamento_status_saas_gateway_pagamento');
        $this->fieldList_status->name = 'fieldList_status';

        $this->criteria_fieldList_status = new TCriteria();
        $this->default_item_fieldList_status = new stdClass();

        $this->form->addField($saas_gateway_pagamento_status_saas_gateway_pagamento_id);
        $this->form->addField($saas_gateway_pagamento_status_saas_gateway_pagamento___row__id);
        $this->form->addField($saas_gateway_pagamento_status_saas_gateway_pagamento___row__data);
        $this->form->addField($saas_gateway_pagamento_status_saas_gateway_pagamento_saas_status_pagamento_id);
        $this->form->addField($saas_gateway_pagamento_status_saas_gateway_pagamento_codigo);

        $this->fieldList_status->setRemoveAction(null, 'fas:times #dd5a43', "Excluír");

        $nome->addValidation("Nome", new TRequiredValidator()); 
        $saas_gateway_pagamento_status_saas_gateway_pagamento_saas_status_pagamento_id->addValidation("Saas status pagamento id", new TRequiredListValidator()); 

        $ativo->setValue('T');
        $fl_homologacao->setValue('T');

        $ativo->setUseSwitch(true, 'blue');
        $fl_homologacao->setUseSwitch(true, 'blue');

        $ativo->setIndexValue("T");
        $fl_homologacao->setIndexValue("F");

        $ativo->setInactiveIndexValue("F");
        $fl_homologacao->setInactiveIndexValue("T");

        $certificado_crt->enableFileHandling();
        $certificado_key->enableFileHandling();

        $certificado_crt->setAllowedExtensions(["crt"]);
        $certificado_key->setAllowedExtensions(["key"]);

        $saas_gateway_forma_pagamento_saas_gateway_pagamento_saas_forma_pagamento_id->enableSearch();
        $saas_gateway_pagamento_status_saas_gateway_pagamento_saas_status_pagamento_id->enableSearch();

        $id->setSize(200);
        $nome->setSize('100%');
        $client_id->setSize('100%');
        $public_key->setSize('100%');
        $access_token->setSize('100%');
        $client_secret->setSize('100%');
        $certificado_crt->setSize('100%');
        $certificado_key->setSize('100%');
        $saas_gateway_forma_pagamento_saas_gateway_pagamento_codigo->setSize('100%');
        $saas_gateway_pagamento_status_saas_gateway_pagamento_codigo->setSize('100%');
        $saas_gateway_forma_pagamento_saas_gateway_pagamento_saas_forma_pagamento_id->setSize('100%');
        $saas_gateway_pagamento_status_saas_gateway_pagamento_saas_status_pagamento_id->setSize('100%');

        $this->form->appendPage("Detalhe");

        $this->form->addFields([new THidden('current_tab')]);
        $this->form->setTabFunction("$('[name=current_tab]').val($(this).attr('data-current_page'));");

        $row1 = $this->form->addFields([new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$nome,$id],[new TLabel("Ativo:", null, '14px', null, '100%'),$ativo]);
        $row1->layout = [' col-sm-9',' col-sm-3'];

        $row2 = $this->form->addFields([new TLabel("Ambiente de Produção habilitado", null, '14px', null, '100%'),$fl_homologacao]);
        $row2->layout = [' col-sm-12'];

        $row3 = $this->form->addFields([new TLabel("Access Token", null, '14px', null),$access_token]);
        $row3->layout = [' col-sm-12'];

        $row4 = $this->form->addFields([new TLabel("Cliente ID:", null, '14px', null),$client_id],[new TLabel("Client Secret", null, '14px', null),$client_secret]);
        $row4->layout = [' col-sm-6',' col-sm-6'];

        $row5 = $this->form->addFields([new TLabel("Public Key:", null, '14px', null, '100%'),$public_key]);
        $row5->layout = [' col-sm-12'];

        $row6 = $this->form->addFields([new TLabel("Certificado:", null, '14px', null),$certificado_crt],[new TLabel("Chave Privada:", null, '14px', null),$certificado_key]);
        $row6->layout = [' col-sm-6',' col-sm-6'];

        $this->form->appendPage("Forma de pagamento");
        $row7 = $this->form->addFields([$this->fieldList_Ffprmas]);
        $row7->layout = [' col-sm-12'];

        $this->form->appendPage("Status");
        $row8 = $this->form->addFields([$this->fieldList_status]);
        $row8->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave'],['static' => 1]), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['SaasGatewayPagamentoHeaderList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new SaasGatewayPagamento(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $certificado_crt_dir = 'arquivos/gateway/certificados';
            $certificado_key_dir = 'arquivos/gateway/chaves';  

            $object->store(); // save the object 

            $this->saveFile($object, $data, 'certificado_crt', $certificado_crt_dir);
            $this->saveFile($object, $data, 'certificado_key', $certificado_key_dir);
            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            $saas_gateway_forma_pagamento_saas_gateway_pagamento_items = $this->storeItems('SaasGatewayFormaPagamento', 'saas_gateway_pagamento_id', $object, $this->fieldList_Ffprmas, function($masterObject, $detailObject){ 

                //code here

            }, $this->criteria_fieldList_Ffprmas); 

            $saas_gateway_pagamento_status_saas_gateway_pagamento_items = $this->storeItems('SaasGatewayPagamentoStatus', 'saas_gateway_pagamento_id', $object, $this->fieldList_status, function($masterObject, $detailObject){ 

                //code here

            }, $this->criteria_fieldList_status); 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('SaasGatewayPagamentoHeaderList', 'onShow', $loadPageParam); 

                        TScript::create("Template.closeRightPanel();");
            TForm::sendData(self::$formName, (object)['id' => $object->id]);

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new SaasGatewayPagamento($key); // instantiates the Active Record 

                $this->fieldList_Ffprmas_items = $this->loadItems('SaasGatewayFormaPagamento', 'saas_gateway_pagamento_id', $object, $this->fieldList_Ffprmas, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }, $this->criteria_fieldList_Ffprmas); 

                $this->fieldList_status_items = $this->loadItems('SaasGatewayPagamentoStatus', 'saas_gateway_pagamento_id', $object, $this->fieldList_status, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }, $this->criteria_fieldList_status); 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        $this->fieldList_Ffprmas->addHeader();
        $this->fieldList_Ffprmas->addDetail($this->default_item_fieldList_Ffprmas);

        $this->fieldList_Ffprmas->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        $this->fieldList_status->addHeader();
        $this->fieldList_status->addDetail($this->default_item_fieldList_status);

        $this->fieldList_status->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

    }

    public function onShow($param = null)
    {
        $this->fieldList_Ffprmas->addHeader();
        $this->fieldList_Ffprmas->addDetail($this->default_item_fieldList_Ffprmas);

        $this->fieldList_Ffprmas->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

        $this->fieldList_status->addHeader();
        $this->fieldList_status->addDetail($this->default_item_fieldList_status);

        $this->fieldList_status->addCloneAction(null, 'fas:plus #69aa46', "Clonar");

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

