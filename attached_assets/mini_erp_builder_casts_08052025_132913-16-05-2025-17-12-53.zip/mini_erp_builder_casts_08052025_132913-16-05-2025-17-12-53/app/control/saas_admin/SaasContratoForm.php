<?php

class SaasContratoForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'minierp';
    private static $activeRecord = 'SaasContrato';
    private static $primaryKey = 'id';
    private static $formName = 'form_SaasContratoForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de contrato");

        $criteria_saas_contrato_status_id = new TCriteria();
        $criteria_account_id = new TCriteria();
        $criteria_saas_plano_valor_id = new TCriteria();
        $criteria_grupos = new TCriteria();

        $filterVar = [1];
        $criteria_grupos->add(new TFilter('id', 'not in', $filterVar)); 

        $id = new TEntry('id');
        $saas_contrato_status_id = new TDBCombo('saas_contrato_status_id', 'minierp', 'SaasContratoStatus', 'id', '{nome}','nome asc' , $criteria_saas_contrato_status_id );
        $account_id = new TDBUniqueSearch('account_id', 'minierp', 'Account', 'id', 'razao_social','id asc' , $criteria_account_id );
        $saas_plano_valor_id = new TDBCombo('saas_plano_valor_id', 'minierp', 'SaasPlanoValor', 'id', '{descricao_html}','nome asc' , $criteria_saas_plano_valor_id );
        $valor_total = new TNumeric('valor_total', '2', ',', '.' );
        $data_inicial = new TDate('data_inicial');
        $data_final = new TDate('data_final');
        $total_usuarios = new TEntry('total_usuarios');
        $total_unidades = new TEntry('total_unidades');
        $grupos = new TCheckList('grupos');

        $saas_contrato_status_id->addValidation("Status", new TRequiredValidator()); 
        $account_id->addValidation("Cliente", new TRequiredValidator()); 
        $valor_total->addValidation("Valor total", new TRequiredValidator()); 
        $data_inicial->addValidation("Data inicial", new TRequiredValidator()); 

        $id->setEditable(false);
        $saas_contrato_status_id->setValue(SaasContratoStatus::AGUARDANDO_PAGAMENTO);
        $account_id->setMinLength(0);
        $account_id->setFilterColumns(["documento","email","razao_social","telefone"]);
        $saas_plano_valor_id->setDefaultOption(false);
        $saas_plano_valor_id->enableSearch();
        $saas_contrato_status_id->enableSearch();

        $data_final->setDatabaseMask('yyyy-mm-dd');
        $data_inicial->setDatabaseMask('yyyy-mm-dd');

        $data_final->setMask('dd/mm/yyyy');
        $data_inicial->setMask('dd/mm/yyyy');
        $account_id->setMask('{razao_social} ( {email} - {documento} - {telefone} )');

        $id->setSize('100%');
        $account_id->setSize('100%');
        $data_final->setSize('100%');
        $valor_total->setSize('100%');
        $data_inicial->setSize('100%');
        $total_usuarios->setSize('100%');
        $total_unidades->setSize('100%');
        $saas_plano_valor_id->setSize('100%');
        $saas_contrato_status_id->setSize('100%');

        $grupos->setIdColumn('id');

        $column_grupos_id = $grupos->addColumn('id', "Id", 'center' , '100px');
        $column_grupos_name = $grupos->addColumn('name', "Name", 'center' , '90%');

        $grupos->setHeight(250);
        $grupos->makeScrollable();

        $grupos->fillWith('minierp', 'SystemGroup', 'id', 'name asc' , $criteria_grupos);

        $row1 = $this->form->addFields([new TLabel("Cód:", null, '14px', null, '100%'),$id],[new TLabel("Status:", '#ff0000', '14px', null, '100%'),$saas_contrato_status_id]);
        $row1->layout = [' col-sm-4',' col-sm-8'];

        $row2 = $this->form->addFields([new TLabel("Cliente:", '#ff0000', '14px', null, '100%'),$account_id]);
        $row2->layout = [' col-sm-12'];

        $tab_67238be2d03e2 = new BootstrapFormBuilder('tab_67238be2d03e2');
        $this->tab_67238be2d03e2 = $tab_67238be2d03e2;
        $tab_67238be2d03e2->setProperty('style', 'border:none; box-shadow:none;');

        $tab_67238be2d03e2->appendPage("Geral");

        $tab_67238be2d03e2->addFields([new THidden('current_tab_tab_67238be2d03e2')]);
        $tab_67238be2d03e2->setTabFunction("$('[name=current_tab_tab_67238be2d03e2]').val($(this).attr('data-current_page'));");

        $row3 = $tab_67238be2d03e2->addContent([new TFormSeparator("Plano & Pagamento", '#333', '18', '#eee')]);
        $row4 = $tab_67238be2d03e2->addFields([new TLabel("Plano:", '#ff0000', '14px', null, '100%'),$saas_plano_valor_id],[new TLabel("Valor total:", '#FF0000', '14px', null, '100%'),$valor_total]);
        $row4->layout = [' col-sm-9',' col-sm-3'];

        $row5 = $tab_67238be2d03e2->addContent([new TFormSeparator("Vigência", '#333', '18', '#eee')]);
        $row6 = $tab_67238be2d03e2->addFields([new TLabel("Data inicial:", '#ff0000', '14px', null, '100%'),$data_inicial],[new TLabel("Data final:", null, '14px', null, '100%'),$data_final]);
        $row6->layout = ['col-sm-3','col-sm-3'];

        $tab_67238be2d03e2->appendPage("Customizações");
        $row7 = $tab_67238be2d03e2->addFields([new TLabel("Quantidade máxima de usuários:", null, '14px', null, '100%'),$total_usuarios],[new TLabel("Quantidade máxima de unidades:", null, '14px', null, '100%'),$total_unidades]);
        $row7->layout = ['col-sm-6',' col-sm-6'];

        $row8 = $tab_67238be2d03e2->addFields([new TLabel("Grupos de permissão:", null, '14px', null, '100%'),$grupos]);
        $row8->layout = [' col-sm-12',' col-sm-6'];

        $row9 = $this->form->addFields([$tab_67238be2d03e2]);
        $row9->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['SaasContratoList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new SaasContrato(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $repository = SaasContratoGrupo::where('saas_contrato_id', '=', $object->id);
            $repository->delete(); 

            if ($data->grupos) 
            {
                foreach ($data->grupos as $grupos_value) 
                {
                    $saas_contrato_grupo = new SaasContratoGrupo;

                    $saas_contrato_grupo->system_group_id = $grupos_value;
                    $saas_contrato_grupo->saas_contrato_id = $object->id;
                    $saas_contrato_grupo->store();
                }
            }

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('SaasContratoList', 'onShow', $loadPageParam); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new SaasContrato($key); // instantiates the Active Record 

                $object->grupos = SaasContratoGrupo::where('saas_contrato_id', '=', $object->id)->getIndexedArray('system_group_id', 'system_group_id');

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

