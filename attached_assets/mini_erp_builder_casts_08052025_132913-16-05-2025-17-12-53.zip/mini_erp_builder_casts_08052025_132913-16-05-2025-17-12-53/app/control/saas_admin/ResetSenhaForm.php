<?php

use \Firebase\JWT\JWT;
use \Firebase\JWT\Key;

class ResetSenhaForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_ResetSenhaForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Resetar a senha");

        if(empty($param["token"]))
        {
            return false;   
        }

        $password1 = new TPassword('password1');
        $password2 = new TPassword('password2');
        $token = new THidden('token');


        $token->setValue($param["token"] ?? "");
        $token->setSize(200);
        $password1->setSize('100%');
        $password2->setSize('100%');


        $row1 = $this->form->addFields([new TLabel("Nova senha:", null, '14px', null, '100%'),$password1]);
        $row1->layout = [' col-sm-12'];

        $row2 = $this->form->addFields([new TLabel("Confirmar nova senha:", null, '14px', null, '100%'),$password2,$token]);
        $row2->layout = [' col-sm-12'];

        // create the form actions
        $btn_onresetsenha = $this->form->addAction("RESETAR A SENHA", new TAction([$this, 'onResetSenha']), 'fas:user-lock #ffffff');
        $this->btn_onresetsenha = $btn_onresetsenha;
        $btn_onresetsenha->addStyleClass('btnnovacontalogin'); 

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        }
        $container->add($this->form);

        parent::add($container);

    }

    public static function onResetSenha($param = null) 
    {
        try
        {
            $ini = AdiantiApplicationConfig::get();

            if (empty($param['password1']))
            {
                throw new Exception('Informe a senha');
            }

            if( $param['password1'] !== $param['password2'] )
            {
                throw new Exception('As senhas informas não conferem');
            }

            if (empty($ini['general']['seed']) OR $ini['general']['seed'] == 's8dkld83kf73kf094')
            {
                throw new Exception(_t('A new seed is required in the application.ini for security reasons'));
            }

            $seed = APPLICATION_NAME . $ini['general']['seed'];

            $token = (array) JWT::decode($param['token'], new Key($seed, 'HS256'));

            $login = $token['user'];
            $expires = $token['expires'];

            if ($expires < strtotime('now'))
            {
                throw new Exception('Permissão negada expirou.');
            }

            TTransaction::open('permission');
            $user  = SystemUsers::newFromLogin($login);

            if ($user instanceof SystemUsers)
            {
                if ($user->active == 'N')
                {
                    throw new Exception("Permissão negada");
                }
                else
                {
                    $user->password = md5($param['password1']);
                    $user->store();

                    new TMessage('info', _t('The password has been changed'));

                    TScript::create("setTimeout(function(){location.href='index.php';}, 1500)");
                }
            }
            TTransaction::close();
        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
        }
    }

    public function onShow($param = null)
    {               

    } 

}

