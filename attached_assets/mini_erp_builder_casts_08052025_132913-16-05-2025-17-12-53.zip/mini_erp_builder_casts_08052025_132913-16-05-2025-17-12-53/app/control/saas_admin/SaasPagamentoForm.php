<?php

class SaasPagamentoForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'minierp';
    private static $activeRecord = 'SaasPagamento';
    private static $primaryKey = 'id';
    private static $formName = 'form_SaasPagamentoForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de Pagamento");

        $criteria_saas_status_pagamento_id = new TCriteria();
        $criteria_saas_gateway_pagamento_id = new TCriteria();
        $criteria_saas_forma_pagamento_id = new TCriteria();

        $id = new TEntry('id');
        $saas_status_pagamento_id = new TDBCombo('saas_status_pagamento_id', 'minierp', 'SaasStatusPagamento', 'id', '{nome}','nome asc' , $criteria_saas_status_pagamento_id );
        $id_gateway = new TEntry('id_gateway');
        $saas_contrato_id = new TSeekButton('saas_contrato_id');
        $contrato_descricao_html_form_pgto = new BElement('div');
        $saas_gateway_pagamento_id = new TDBCombo('saas_gateway_pagamento_id', 'minierp', 'SaasGatewayPagamento', 'id', '{nome}','nome asc' , $criteria_saas_gateway_pagamento_id );
        $saas_forma_pagamento_id = new TDBCombo('saas_forma_pagamento_id', 'minierp', 'SaasFormaPagamento', 'id', '{nome}','nome asc' , $criteria_saas_forma_pagamento_id );
        $valor = new TNumeric('valor', '2', ',', '.' );
        $data_compra = new TDateTime('data_compra');
        $data_vencimento = new TDate('data_vencimento');
        $data_pagamento = new TDate('data_pagamento');

        $saas_contrato_id->setExitAction(new TAction([$this,'onExitContrato']));

        $saas_status_pagamento_id->addValidation("Saas status pagamento id", new TRequiredValidator()); 
        $saas_contrato_id->addValidation("Saas contrato id", new TRequiredValidator()); 
        $saas_forma_pagamento_id->addValidation("Saas forma pagamento id", new TRequiredValidator()); 
        $valor->addValidation("Valor", new TRequiredValidator()); 
        $data_compra->addValidation("Data compra", new TRequiredValidator()); 

        $saas_status_pagamento_id->setValue(SaasStatusPagamento::INICIADO);
        $id->setEditable(false);
        $id_gateway->setEditable(false);

        $saas_forma_pagamento_id->enableSearch();
        $saas_status_pagamento_id->enableSearch();
        $saas_gateway_pagamento_id->enableSearch();

        $data_pagamento->setMask('dd/mm/yyyy');
        $data_vencimento->setMask('dd/mm/yyyy');
        $data_compra->setMask('dd/mm/yyyy hh:ii');

        $data_pagamento->setDatabaseMask('yyyy-mm-dd');
        $data_vencimento->setDatabaseMask('yyyy-mm-dd');
        $data_compra->setDatabaseMask('yyyy-mm-dd hh:ii');

        $id->setSize('100%');
        $valor->setSize('100%');
        $id_gateway->setSize('100%');
        $data_compra->setSize('100%');
        $data_pagamento->setSize('100%');
        $data_vencimento->setSize('100%');
        $saas_contrato_id->setSize('100%');
        $saas_forma_pagamento_id->setSize('100%');
        $saas_status_pagamento_id->setSize('100%');
        $saas_gateway_pagamento_id->setSize('100%');
        $contrato_descricao_html_form_pgto->setSize('100%', 80);

        $contrato_descricao_html_form_pgto->id = 'contrato_descricao_html_form_pgto';

        $this->contrato_descricao_html_form_pgto = $contrato_descricao_html_form_pgto;

        $seed = AdiantiApplicationConfig::get()['general']['seed'];
        $saas_contrato_id_seekAction = new TAction(['SaasContratoSeekWindow', 'onShow']);
        $seekFilters = [];
        $seekFields = base64_encode(serialize([
            ['name'=> 'saas_contrato_id', 'column'=>'{id}'],
            ['name'=> 'saas_contrato_id', 'column'=>'{id}']
        ]));

        $seekFilters = base64_encode(serialize($seekFilters));
        $saas_contrato_id_seekAction->setParameter('_seek_fields', $seekFields);
        $saas_contrato_id_seekAction->setParameter('_seek_filters', $seekFilters);
        $saas_contrato_id_seekAction->setParameter('_seek_hash', md5($seed.$seekFields.$seekFilters));
        $saas_contrato_id->setAction($saas_contrato_id_seekAction);

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null, '100%'),$id],[new TLabel("Status:", '#ff0000', '14px', null, '100%'),$saas_status_pagamento_id]);
        $row1->layout = [' col-sm-4',' col-sm-8'];

        $row2 = $this->form->addFields([new TLabel("ID Gateway:", null, '14px', null, '100%'),$id_gateway]);
        $row2->layout = [' col-sm-5'];

        $row3 = $this->form->addFields([new TLabel("Contrato", '#ff0000', '14px', null, '100%'),$saas_contrato_id],[$contrato_descricao_html_form_pgto]);
        $row3->layout = [' col-sm-4',' col-sm-8'];

        $row4 = $this->form->addContent([new TFormSeparator("", '#333', '18', '#eee')]);
        $row5 = $this->form->addFields([new TLabel("Gateway Pagamento:", '#FF0000', '14px', null, '100%'),$saas_gateway_pagamento_id],[]);
        $row5->layout = ['col-sm-6','col-sm-6'];

        $row6 = $this->form->addFields([new TLabel("Forma do Pagamento:", '#ff0000', '14px', null, '100%'),$saas_forma_pagamento_id],[new TLabel("Valor total:", '#ff0000', '14px', null, '100%'),$valor]);
        $row6->layout = ['col-sm-6','col-sm-6'];

        $row7 = $this->form->addFields([new TLabel("Data da compra:", '#ff0000', '14px', null, '100%'),$data_compra],[new TLabel("Data do vencimento:", null, '14px', null, '100%'),$data_vencimento],[new TLabel("Data do Pagamento:", null, '14px', null, '100%'),$data_pagamento]);
        $row7->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['SaasPagamentoList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

    }

    public static function onExitContrato($param = null) 
    {
        try 
        {

            if(!empty($param['key']))
            {
                TTransaction::open(self::$database);

                $contrato = new SaasContrato($param['key']);

                TScript::create("$('#contrato_descricao_html_form_pgto').html(`{$contrato->descricao_html}`)");

                $data = new stdClass();
                $data->valor = ToolService::toBrl($contrato->valor_total);

                TForm::sendData(self::$formName, $data);

                TTransaction::close();
            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new SaasPagamento(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->account_id = $object->saas_contrato->account_id;

            $object->store(); // save the object 

            $this->fireEvents($object);

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('SaasPagamentoList', 'onShow', $loadPageParam); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {

            $this->fireEvents($this->form->getData());  

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new SaasPagamento($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                $this->fireEvents($object);

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public function fireEvents( $object )
    {
        $obj = new stdClass;
        if(is_object($object) && get_class($object) == 'stdClass')
        {
            if(isset($object->saas_contrato_id))
            {
                $value = $object->saas_contrato_id;

                $obj->saas_contrato_id = $value;
            }
        }
        elseif(is_object($object))
        {
            if(isset($object->saas_contrato_id))
            {
                $value = $object->saas_contrato_id;

                $obj->saas_contrato_id = $value;
            }
        }
        TForm::sendData(self::$formName, $obj);
    }  

    public static function getFormName()
    {
        return self::$formName;
    }

}

