<?php

class SaasNotaFiscalServicoForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'minierp';
    private static $activeRecord = 'SaasNotaFiscalServico';
    private static $primaryKey = 'id';
    private static $formName = 'form_NotaFiscalServicoForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Nota fiscal de serviço");

        $criteria_account_id = new TCriteria();
        $criteria_cidade_tomador_id = new TCriteria();
        $criteria_saas_plano_valor_id = new TCriteria();
        $criteria_saas_servico_id = new TCriteria();

        $id = new THidden('id');
        $numero = new TEntry('numero');
        $numero_rps = new TEntry('numero_rps');
        $codigo_verificacao = new TEntry('codigo_verificacao');
        $data_hora_emissao = new TDateTime('data_hora_emissao');
        $account_id = new TDBUniqueSearch('account_id', 'minierp', 'Account', 'id', 'nome_responsavel','razao_social asc' , $criteria_account_id );
        $tipo_pessoa = new TCombo('tipo_pessoa');
        $nome_tomador = new TEntry('nome_tomador');
        $email_tomador = new TEntry('email_tomador');
        $documento_tomador = new TEntry('documento_tomador');
        $inscricao_municipal_tomador = new TEntry('inscricao_municipal_tomador');
        $telefone_tomador = new TEntry('telefone_tomador');
        $cep_tomador = new TEntry('cep_tomador');
        $endereco_tomador = new TEntry('endereco_tomador');
        $cidade_tomador_id = new TDBCombo('cidade_tomador_id', 'minierp', 'Cidade', 'id', '{nome} ({estado->sigla})','nome asc' , $criteria_cidade_tomador_id );
        $bairro_tomador = new TEntry('bairro_tomador');
        $numero_tomador = new TEntry('numero_tomador');
        $documento_prestador = new TEntry('documento_prestador');
        $nome_prestador = new TEntry('nome_prestador');
        $this->label_regime_tributario_municipal = new TLabel("Regime tributário municipal:", null, '14px', null, '100%');
        $regime_tributario_municipal = new TCombo('regime_tributario_municipal');
        $saas_plano_valor_id = new TDBCombo('saas_plano_valor_id', 'minierp', 'SaasPlanoValor', 'id', '{descricao_html}','nome asc' , $criteria_saas_plano_valor_id );
        $this->label_natureza_operacao = new TLabel("Natureza da operação", null, '14px', null, '100%');
        $natureza_operacao = new TCombo('natureza_operacao');
        $saas_servico_id = new TDBCombo('saas_servico_id', 'minierp', 'SaasServico', 'id', '{descricao}','descricao asc' , $criteria_saas_servico_id );
        $label_discriminacao = new TLabel("Discriminação:", '#ff0000', '14px', null, '100%');
        $discriminacao = new TText('discriminacao');
        $desconto_condicionado = new TNumeric('desconto_condicionado', '2', ',', '.' );
        $desconto_incodicionado = new TNumeric('desconto_incodicionado', '2', ',', '.' );
        $valor_servicos = new TNumeric('valor_servicos', '2', ',', '.' );
        $this->label_valor_liquido = new TLabel("Valor líquido dos serviços:", null, '14px', null, '100%');
        $valor_liquido = new TNumeric('valor_liquido', '2', ',', '.' );
        $iss_retido = new TCombo('iss_retido');
        $btnCalcularImpostos = new TButton('btnCalcularImpostos');
        $base_calculo_iss = new TNumeric('base_calculo_iss', '2', ',', '.' );
        $aliquota_iss = new TNumeric('aliquota_iss', '2', ',', '.' );
        $valor_iss = new TNumeric('valor_iss', '2', ',', '.' );
        $aliquota_pis = new TNumeric('aliquota_pis', '2', ',', '.' );
        $aliquota_cofins = new TNumeric('aliquota_cofins', '2', ',', '.' );
        $aliquota_csll = new TNumeric('aliquota_csll', '2', ',', '.' );
        $aliquota_irrf = new TNumeric('aliquota_irrf', '2', ',', '.' );
        $aliquota_inss = new TNumeric('aliquota_inss', '2', ',', '.' );
        $valor_outras_retencoes = new TNumeric('valor_outras_retencoes', '2', ',', '.' );
        $valor_retencoes = new TNumeric('valor_retencoes', '2', ',', '.' );
        $valor_deducoes = new TNumeric('valor_deducoes', '2', ',', '.' );

        $account_id->setChangeAction(new TAction([$this,'onChangeAccount']));
        $saas_plano_valor_id->setChangeAction(new TAction([$this,'onChangePlano']));

        $desconto_condicionado->setExitAction(new TAction([$this,'onDescontoCondicionado']));
        $desconto_incodicionado->setExitAction(new TAction([$this,'onDescontoIncondicional']));
        $valor_servicos->setExitAction(new TAction([$this,'onValorTotal']));

        $data_hora_emissao->addValidation("Data hora da emissão", new TRequiredValidator()); 
        $nome_tomador->addValidation("Nome", new TRequiredValidator()); 
        $email_tomador->addValidation("E-mail do tomador", new TRequiredValidator()); 
        $documento_tomador->addValidation("Documento", new TRequiredValidator()); 
        $cep_tomador->addValidation("CEP", new TRequiredValidator()); 
        $endereco_tomador->addValidation("Endereço tomador", new TRequiredValidator()); 
        $cidade_tomador_id->addValidation("Cidade", new TRequiredValidator()); 
        $bairro_tomador->addValidation("Bairro", new TRequiredValidator()); 
        $numero_tomador->addValidation("Número", new TRequiredValidator()); 
        $discriminacao->addValidation("Descrição", new TRequiredValidator()); 
        $desconto_incodicionado->addValidation("Descontos incondicionados", new TRequiredValidator()); 
        $valor_servicos->addValidation("Valor dos serviços", new TRequiredValidator()); 
        $aliquota_iss->addValidation("Aliquota", new TRequiredValidator()); 
        $valor_iss->addValidation("Valor ISS", new TRequiredValidator()); 
        $valor_outras_retencoes->addValidation("Retenções", new TRequiredValidator()); 
        $valor_deducoes->addValidation("Deduções", new TRequiredValidator()); 

        $data_hora_emissao->setDatabaseMask('yyyy-mm-dd hh:ii');
        $account_id->setMinLength(2);
        $account_id->setFilterColumns(["email","nome_responsavel","razao_social","telefone"]);
        $btnCalcularImpostos->setAction(new TAction([$this, 'onCalcular']), "Calcular Impostos");
        $btnCalcularImpostos->addStyleClass('btn-success');
        $btnCalcularImpostos->setImage('fas:calculator #FFFFFF');
        $iss_retido->addItems(["T"=>"Sim","F"=>"Não"]);
        $tipo_pessoa->addItems(["J"=>"Jurídica","F"=>"Física"]);
        $natureza_operacao->addItems(["101"=>"Tributação no Município","102"=>"Tributação Fora do Município","103"=>"Isenção","104"=>"Imunidade","105"=>"Exportação de Serviços","106"=>" Não Incidência","107"=>" Exigibilidade Suspensa por Decisão Judicial","108"=>" Exigibilidade Suspensa por Processo Administrativo"]);

        $cep_tomador->setMask('99.999-999');
        $account_id->setMask('{razao_social}');
        $telefone_tomador->setMask('(99) 9999-99999');
        $data_hora_emissao->setMask('dd/mm/yyyy hh:ii');

        $iss_retido->enableSearch();
        $tipo_pessoa->enableSearch();
        $saas_servico_id->enableSearch();
        $cidade_tomador_id->enableSearch();
        $natureza_operacao->enableSearch();
        $saas_plano_valor_id->enableSearch();
        $regime_tributario_municipal->enableSearch();

        $valor_iss->setValue('0,00');
        $aliquota_iss->setValue('0,00');
        $aliquota_pis->setValue('0,00');
        $valor_liquido->setValue('0,00');
        $aliquota_csll->setValue('0,00');
        $aliquota_irrf->setValue('0,00');
        $aliquota_inss->setValue('0,00');
        $valor_servicos->setValue('0,00');
        $valor_deducoes->setValue('0,00');
        $aliquota_cofins->setValue('0,00');
        $valor_retencoes->setValue('0,00');
        $base_calculo_iss->setValue('0,00');
        $desconto_condicionado->setValue('0,00');
        $desconto_incodicionado->setValue('0,00');
        $valor_outras_retencoes->setValue('0,00');
        $data_hora_emissao->setValue(date('d/m/Y H:i'));

        $numero->setEditable(false);
        $numero_rps->setEditable(false);
        $tipo_pessoa->setEditable(false);
        $cep_tomador->setEditable(false);
        $nome_tomador->setEditable(false);
        $email_tomador->setEditable(false);
        $valor_liquido->setEditable(false);
        $bairro_tomador->setEditable(false);
        $numero_tomador->setEditable(false);
        $nome_prestador->setEditable(false);
        $telefone_tomador->setEditable(false);
        $endereco_tomador->setEditable(false);
        $data_hora_emissao->setEditable(false);
        $documento_tomador->setEditable(false);
        $cidade_tomador_id->setEditable(false);
        $codigo_verificacao->setEditable(false);
        $documento_prestador->setEditable(false);
        $inscricao_municipal_tomador->setEditable(false);

        $id->setSize(200);
        $numero->setSize('100%');
        $valor_iss->setSize('100%');
        $numero_rps->setSize('100%');
        $account_id->setSize('100%');
        $iss_retido->setSize('100%');
        $tipo_pessoa->setSize('100%');
        $cep_tomador->setSize('100%');
        $nome_tomador->setSize('100%');
        $aliquota_iss->setSize('100%');
        $aliquota_pis->setSize('100%');
        $email_tomador->setSize('100%');
        $valor_liquido->setSize('100%');
        $aliquota_csll->setSize('100%');
        $aliquota_irrf->setSize('100%');
        $aliquota_inss->setSize('100%');
        $bairro_tomador->setSize('100%');
        $numero_tomador->setSize('100%');
        $nome_prestador->setSize('100%');
        $valor_servicos->setSize('100%');
        $valor_deducoes->setSize('100%');
        $saas_servico_id->setSize('100%');
        $aliquota_cofins->setSize('100%');
        $valor_retencoes->setSize('100%');
        $telefone_tomador->setSize('100%');
        $endereco_tomador->setSize('100%');
        $base_calculo_iss->setSize('100%');
        $data_hora_emissao->setSize('100%');
        $documento_tomador->setSize('100%');
        $cidade_tomador_id->setSize('100%');
        $natureza_operacao->setSize('100%');
        $codigo_verificacao->setSize('100%');
        $discriminacao->setSize('100%', 100);
        $documento_prestador->setSize('100%');
        $saas_plano_valor_id->setSize('100%');
        $desconto_condicionado->setSize('100%');
        $desconto_incodicionado->setSize('100%');
        $valor_outras_retencoes->setSize('100%');
        $inscricao_municipal_tomador->setSize('100%');
        $regime_tributario_municipal->setSize('100%');

        $bcontainer_gerais = new BContainer('bcontainer_gerais');
        $this->bcontainer_gerais = $bcontainer_gerais;

        $bcontainer_gerais->setTitle("Detalhes", '#333', '15px', '', '#fff');
        $bcontainer_gerais->setBorderColor('#c0c0c0');

        $row1 = $bcontainer_gerais->addFields([new TLabel("Número:", null, '14px', null, '100%'),$id,$numero],[new TLabel("Número RPS:", null, '14px', null, '100%'),$numero_rps],[new TLabel("Código de verificação:", null, '14px', null, '100%'),$codigo_verificacao],[new TLabel("Data hora da emissão:", '#ff0000', '14px', null, '100%'),$data_hora_emissao]);
        $row1->layout = [' col-sm-3',' col-sm-3',' col-sm-3',' col-sm-3'];

        $row2 = $this->form->addFields([$bcontainer_gerais]);
        $row2->layout = [' col-sm-12'];

        $bcontainer_tomador = new BContainer('bcontainer_tomador');
        $this->bcontainer_tomador = $bcontainer_tomador;

        $bcontainer_tomador->setTitle("Tomador", '#333', '15px', '', '#fff');
        $bcontainer_tomador->setBorderColor('#c0c0c0');

        $row3 = $bcontainer_tomador->addFields([new TLabel("Cliente:", null, '14px', null, '100%'),$account_id],[new TLabel("Tipo pessoa:", null, '14px', null),$tipo_pessoa]);
        $row3->layout = ['col-sm-8',' col-sm-4'];

        $row4 = $bcontainer_tomador->addFields([new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$nome_tomador],[new TLabel("E-mail:", '#FF0000', '14px', null),$email_tomador]);
        $row4->layout = [' col-sm-8',' col-sm-4'];

        $row5 = $bcontainer_tomador->addFields([new TLabel("Documento:", '#ff0000', '14px', null, '100%'),$documento_tomador],[new TLabel("Inscrição municipal:", null, '14px', null, '100%'),$inscricao_municipal_tomador],[new TLabel("Telefone:", null, '14px', null, '100%'),$telefone_tomador]);
        $row5->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row6 = $bcontainer_tomador->addFields([new TLabel("CEP:", '#ff0000', '14px', null, '100%'),$cep_tomador],[new TLabel("Endereço:", '#FF0000', '14px', null),$endereco_tomador]);
        $row6->layout = [' col-sm-4',' col-sm-8'];

        $row7 = $bcontainer_tomador->addFields([new TLabel("Cidade:", '#ff0000', '14px', null, '100%'),$cidade_tomador_id],[new TLabel("Bairro:", '#ff0000', '14px', null, '100%'),$bairro_tomador],[new TLabel("Número:", '#ff0000', '14px', null, '100%'),$numero_tomador]);
        $row7->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row8 = $this->form->addFields([$bcontainer_tomador]);
        $row8->layout = [' col-sm-12'];

        $bcontainer_65d89a8e1fb3a = new BContainer('bcontainer_65d89a8e1fb3a');
        $this->bcontainer_65d89a8e1fb3a = $bcontainer_65d89a8e1fb3a;

        $bcontainer_65d89a8e1fb3a->setTitle("Prestador", '#333', '18px', '', '#fff');
        $bcontainer_65d89a8e1fb3a->setBorderColor('#c0c0c0');

        $row9 = $bcontainer_65d89a8e1fb3a->addFields([new TLabel("CNPJ:", null, '14px', null, '100%'),$documento_prestador],[new TLabel("Razão social:", null, '14px', null, '100%'),$nome_prestador]);
        $row9->layout = ['col-sm-4','col-sm-4'];

        $row10 = $bcontainer_65d89a8e1fb3a->addFields([$this->label_regime_tributario_municipal,$regime_tributario_municipal],[],[]);
        $row10->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row11 = $this->form->addFields([$bcontainer_65d89a8e1fb3a]);
        $row11->layout = [' col-sm-12'];

        $bcontainer_valores = new BContainer('bcontainer_valores');
        $this->bcontainer_valores = $bcontainer_valores;

        $bcontainer_valores->setTitle("Informações do Serviço", '#333', '15px', '', '#fff');
        $bcontainer_valores->setBorderColor('#c0c0c0');

        $row12 = $bcontainer_valores->addFields([new TLabel("Plano:", null, '14px', null, '100%'),$saas_plano_valor_id],[$this->label_natureza_operacao,$natureza_operacao]);
        $row12->layout = [' col-sm-6',' col-sm-6'];

        $row13 = $bcontainer_valores->addFields([new TLabel("Serviço:", null, '14px', null, '100%'),$saas_servico_id],[]);
        $row13->layout = [' col-sm-6',' col-sm-6'];

        $row14 = $bcontainer_valores->addFields([$label_discriminacao,$discriminacao]);
        $row14->layout = ['col-sm-12'];

        $row15 = $bcontainer_valores->addFields([new TLabel("Desconto condicionado:", '#FF0000', '14px', null),$desconto_condicionado],[new TLabel("Desconto incondicionado:", '#ff0000', '14px', null, '100%'),$desconto_incodicionado],[new TLabel("Valor total dos serviços:", '#ff0000', '14px', null, '100%'),$valor_servicos]);
        $row15->layout = ['col-sm-4','col-sm-4',' col-sm-4'];

        $row16 = $bcontainer_valores->addFields([$this->label_valor_liquido,$valor_liquido]);
        $row16->layout = ['col-sm-4'];

        $bcontainer_65d888783a698 = new BContainer('bcontainer_65d888783a698');
        $this->bcontainer_65d888783a698 = $bcontainer_65d888783a698;

        $bcontainer_65d888783a698->setTitle("Impostos", '#333', '18px', '', '#fff');
        $bcontainer_65d888783a698->setBorderColor('#c0c0c0');

        $row17 = $bcontainer_65d888783a698->addFields([new TLabel("ISS Retido?", null, '14px', null),$iss_retido],[new TLabel("Rótulo:", '#FFFFFF', '14px', null, '100%'),$btnCalcularImpostos]);
        $row17->layout = [' col-sm-4',' col-sm-4'];

        $container_impostos_municipais = new BContainer('container_impostos_municipais');
        $this->container_impostos_municipais = $container_impostos_municipais;

        $container_impostos_municipais->setTitle("Municipal", '#333', '18px', '', '#fff');
        $container_impostos_municipais->setBorderColor('#c0c0c0');

        $row18 = $container_impostos_municipais->addFields([new TLabel("Base de cálculo ISS:", null, '14px', null, '100%'),$base_calculo_iss],[new TLabel("Alíquota ISS:", '#ff0000', '14px', null, '100%'),$aliquota_iss],[new TLabel("Valor ISS:", '#ff0000', '14px', null, '100%'),$valor_iss]);
        $row18->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row19 = $bcontainer_65d888783a698->addFields([$container_impostos_municipais]);
        $row19->layout = [' col-sm-12'];

        $container_impostos_federais = new BContainer('container_impostos_federais');
        $this->container_impostos_federais = $container_impostos_federais;

        $container_impostos_federais->setTitle("Federal", '#333', '18px', '', '#fff');
        $container_impostos_federais->setBorderColor('#c0c0c0');

        $row20 = $container_impostos_federais->addFields([new TLabel("Alíquota PIS:", null, '14px', null, '100%'),$aliquota_pis],[new TLabel("Alíquota COFINS:", null, '14px', null, '100%'),$aliquota_cofins],[new TLabel("Alíquota CSLL:", null, '14px', null, '100%'),$aliquota_csll]);
        $row20->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row21 = $container_impostos_federais->addFields([new TLabel("Alíquota % IRRF:", null, '14px', null, '100%'),$aliquota_irrf],[new TLabel("Alíquota INSS:", null, '14px', null, '100%'),$aliquota_inss],[]);
        $row21->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row22 = $bcontainer_65d888783a698->addFields([$container_impostos_federais]);
        $row22->layout = [' col-sm-12'];

        $row23 = $bcontainer_65d888783a698->addFields([new TLabel("Outras retenções:", null, '14px', null, '100%'),$valor_outras_retencoes],[new TLabel("Retenções:", null, '14px', null, '100%'),$valor_retencoes],[new TLabel("Deduções:", null, '14px', null, '100%'),$valor_deducoes]);
        $row23->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row24 = $bcontainer_valores->addFields([$bcontainer_65d888783a698]);
        $row24->layout = [' col-sm-12'];

        $row25 = $this->form->addFields([$bcontainer_valores]);
        $row25->layout = [' col-sm-12'];

        TTransaction::open(self::$database);
        SaasConfiguracaoService::ajustaCampos($this->form, $this);
        TTransaction::close();

        // create the form actions
        $btnSalvar = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btnSalvar = $btnSalvar;
        $btnSalvar->addStyleClass('btn-primary'); 

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['SaasNotaFiscalServicoList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel > .container-part[page-name=SaasNotaFiscalServicoForm]');
        $style->width = '85% !important';   
        $style->show(true);

    }

    public static function onDescontoCondicionado($param = null) 
    {
        try 
        {
            self::valorLiquidoFinal($param);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onDescontoIncondicional($param = null) 
    {
        try 
        {
            self::valorLiquidoFinal($param);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onValorTotal($param = null) 
    {
        try 
        {
            // $data = new stdClass;
            // $data->valor_liquido = $param['valor_total'];
            // $data->base_calculo_iss = $param['valor_total'];

            // TForm::sendData(self::$formName, $data);

            self::valorLiquidoFinal($param);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onChangeAccount($param = null) 
    {
        try 
        {
            if (isset($param['key']))
            {
                TTransaction::open(self::$database);
                $account = new Account($param['key']);

                $object = new stdClass();
                $object->nome_tomador       = $account->razao_social;
                $object->email_tomador      = $account->email;
                $object->documento_tomador  = $account->documento;
                $object->inscricao_municipal_tomador = $account->inscricao_municipal;
                $object->telefone_tomador   = $account->telefone;
                $object->cep_tomador        = $account->cep;
                $object->endereco_tomador   = $account->rua;
                $object->cidade_tomador_id  = $account->cidade_id;
                $object->bairro_tomador     = $account->bairro;
                $object->numero_tomador     = $account->numero;
                $object->tipo_pessoa        = $account->tipo_pessoa;

                TTransaction::close();
                TForm::sendData(self::$formName, $object);

            }

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onChangePlano($param = null) 
    {
        try 
        {

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onCalcular($param = null) 
    {
        try 
        {

            TTransaction::open(self::$database);

            $notaFiscalServico = new SaasNotaFiscalServico();
            $notaFiscalServico->saas_servico_id = $param['saas_servico_id'];
            $notaFiscalServico->valor_servicos = ToolService::toDouble($param['valor_servicos']);
            $notaFiscalServico->cliente_id = $param['tomador_id'];

            $notaFiscalServico = SaasNotaFiscalServicoService::calculaImpostos($notaFiscalServico);

            TTransaction::close();

            unset($notaFiscalServico->saas_servico_id);
            unset($notaFiscalServico->valor_servicos);
            unset($notaFiscalServico->account_id);

            if ($notaFiscalServico->aliquota_iss)
            {
                $notaFiscalServico->valor_iss = ToolService::toBRL($notaFiscalServico->valor_iss);
                $notaFiscalServico->aliquota_iss = ToolService::toBRL($notaFiscalServico->aliquota_iss);
            }
            if ($notaFiscalServico->aliquota_pis)
            {
                $notaFiscalServico->valor_pis = ToolService::toBRL($notaFiscalServico->valor_pis);
                $notaFiscalServico->aliquota_pis = ToolService::toBRL($notaFiscalServico->aliquota_pis);
            }
            if ($notaFiscalServico->aliquota_inss)
            {
                $notaFiscalServico->valor_inss = ToolService::toBRL($notaFiscalServico->valor_inss);
                $notaFiscalServico->aliquota_inss = ToolService::toBRL($notaFiscalServico->aliquota_inss);
            }
            if ($notaFiscalServico->aliquota_cofins)
            {
                $notaFiscalServico->valor_cofins = ToolService::toBRL($notaFiscalServico->valor_cofins);
                $notaFiscalServico->aliquota_cofins = ToolService::toBRL($notaFiscalServico->aliquota_cofins);
            }
            if ($notaFiscalServico->aliquota_csll)
            {
                $notaFiscalServico->valor_csll = ToolService::toBRL($notaFiscalServico->valor_csll);
                $notaFiscalServico->aliquota_csll = ToolService::toBRL($notaFiscalServico->aliquota_csll);
            }
            if ($notaFiscalServico->aliquota_irrf)
            {
                $notaFiscalServico->valor_irrf = ToolService::toBRL($notaFiscalServico->valor_irrf);
                $notaFiscalServico->aliquota_irrf = ToolService::toBRL($notaFiscalServico->aliquota_irrf);
            }

            if (isset($notaFiscalServico->valor_liquido))
            {
                $notaFiscalServico->valor_liquido = ToolService::toBRL($notaFiscalServico->valor_liquido);
            }

            $notaFiscalServico->base_calculo_iss = ToolService::toBRL($notaFiscalServico->base_calculo_iss);

            TForm::sendData(self::$formName, $notaFiscalServico);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new SaasNotaFiscalServico(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $empresa = SaasConfiguracaoService::getConfiguracoes();

            $object->cidade_prestador_id = $empresa->cidade_id;
            $object->municipio_prestacao_servico_id = $empresa->cidade_id;
            $object->nome_prestador = $empresa->razao_social;
            $object->documento_prestador = $empresa->cnpj;
            $object->endereco_prestador = $empresa->rua;
            $object->email_prestador = $empresa->email;
            $object->numero_prestador = $empresa->numero;
            $object->bairro_prestador = $empresa->bairro;
            $object->cep_prestador = $empresa->cep;

            if (empty($data->id))
            {

                $object->nota_fiscal_status_id = NotaFiscalStatus::PENDENTE;
            }
            else
            {
                $nota = NotaFiscalServico::find($data->id);
                if (in_array($nota->nota_fiscal_status_id, [NotaFiscalStatus::AUTORIZADA, NotaFiscalStatus::ENVIADA]))
                {
                    throw new Exception("Essa nota não pode ser editada");
                }
            }

            $object->cliente_id = $data->tomador_id;

            $object->store(); // save the object 

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            if(!empty($object->id))
            {
                $loadPageParam["id"] = $object->id;
            }

            if(!empty($object->id))
            {
                $loadPageParam["key"] = $object->id;
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            // $loadPageParam['target_container'] = 'adianti_right_panel';

            // TApplication::loadPage('NotaFiscalServicoList', 'onReload', ['target_container' => 'adianti_div_content']);

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('SaasNotaFiscalServicoList', 'onShow', $loadPageParam); 

            TScript::create("Template.closeRightPanel('');");

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new SaasNotaFiscalServico($key); // instantiates the Active Record 

                $object->tomador_id = $object->cliente_id;

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
            TScript::create("Template.closeRightPanel();");
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

        TTransaction::open(self::$database);

        $configuracoes = SaasConfiguracaoService::getConfiguracoes();

        $object = new stdClass();
        $object->documento_prestador = $configuracoes->cnpj;
        $object->nome_prestador = $configuracoes->razao_social;
        $object->numero_rps = $configuracoes->nfse_numero;

        $this->form->setData($object);

        TTransaction::close();

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

    public function onVisualizar($param = null)
    {
        $this->onEdit($param);

        $this->form->setEditable(false);
        $this->btnSalvar->style = 'display:none';
    }

    public static function valorLiquidoFinal($param)
    {
        $desconto_condicionado = (double) str_replace(',', '.', str_replace('.', '', $param['desconto_condicionado']));
        $desconto_incodicionado = (double) str_replace(',', '.', str_replace('.', '', $param['desconto_incodicionado']));
        $valor_servicos = (double) str_replace(',', '.', str_replace('.', '', $param['valor_servicos']));

        $valor_liquido = $valor_servicos - ($desconto_condicionado + $desconto_incodicionado);
        $object = new stdClass();

        $object->valor_liquido = number_format($valor_liquido, 2, ',', '.');
        $object->base_calculo_iss = $object->valor_liquido;

        TForm::sendData(self::$formName, $object);
    }

}

