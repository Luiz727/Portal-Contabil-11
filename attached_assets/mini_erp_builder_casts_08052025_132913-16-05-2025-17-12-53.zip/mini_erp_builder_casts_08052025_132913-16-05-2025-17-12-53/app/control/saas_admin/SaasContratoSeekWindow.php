<?php

class SaasContratoSeekWindow extends TWindow
{
    private $form; // form
    private $datagrid; // listing
    private $pageNavigation;
    private $loaded;
    private $filter_criteria;
    private static $database = 'minierp';
    private static $activeRecord = 'SaasContrato';
    private static $primaryKey = 'id';
    private static $formName = 'form_SaasContratoSeekWindow';
    private $showMethods = ['onReload', 'onSearch'];
    private $limit = 20;

    use BuilderSeekWindowTrait;

    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct($param = null)
    {
        parent::__construct();
        parent::setSize(0.8, null);
        parent::setTitle("Janela de Busca de Contrato");
        parent::setProperty('class', 'window_modal');

        $param['_seek_window_id'] = $this->id;
        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        $this->limit = 20;

        // define the form title
        $this->form->setFormTitle("Janela de Busca de Contrato");

        $criteria_saas_plano_valor_saas_plano_id = new TCriteria();
        $criteria_account_id = new TCriteria();
        $criteria_saas_contrato_status_id = new TCriteria();

        $filterVar = "T";
        $criteria_saas_plano_valor_saas_plano_id->add(new TFilter('ativo', '=', $filterVar)); 

        $id = new TEntry('id');
        $saas_plano_valor_saas_plano_id = new TDBCombo('saas_plano_valor_saas_plano_id', 'minierp', 'SaasPlano', 'id', '{nome}','nome asc' , $criteria_saas_plano_valor_saas_plano_id );
        $account_id = new TDBUniqueSearch('account_id', 'minierp', 'Account', 'id', 'razao_social','id asc' , $criteria_account_id );
        $saas_contrato_status_id = new TDBCombo('saas_contrato_status_id', 'minierp', 'SaasContratoStatus', 'id', '{nome}','nome asc' , $criteria_saas_contrato_status_id );

        $account_id->setMinLength(2);
        $account_id->setMask('{razao_social} ( {email} - {documento} )');
        $account_id->setFilterColumns(["documento","email","razao_social","telefone"]);
        $saas_contrato_status_id->enableSearch();
        $saas_plano_valor_saas_plano_id->enableSearch();

        $id->setSize('100%');
        $account_id->setSize('100%');
        $saas_contrato_status_id->setSize('100%');
        $saas_plano_valor_saas_plano_id->setSize('100%');

        $row1 = $this->form->addFields([new TLabel("Cód:", null, '14px', null, '100%'),$id],[new TLabel("Plano:", null, '14px', null),$saas_plano_valor_saas_plano_id]);
        $row1->layout = ['col-sm-6',' col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Cliente:", null, '14px', null, '100%'),$account_id],[new TLabel("Status:", null, '14px', null, '100%'),$saas_contrato_status_id]);
        $row2->layout = ['col-sm-6','col-sm-6'];

        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );

        $btn_onsearch = $this->form->addAction("Buscar", new TAction([$this, 'onSearch']), 'fas:search #ffffff');
        $this->btn_onsearch = $btn_onsearch;
        $btn_onsearch->addStyleClass('btn-primary'); 

        $this->setSeekParameters($btn_onsearch->getAction(), $param);

        // creates a Datagrid
        $this->datagrid = new TDataGrid;
        $this->datagrid->setId(__CLASS__.'_datagrid');

        $this->datagrid_form = new TForm('datagrid_'.self::$formName);
        $this->datagrid_form->onsubmit = 'return false';

        $this->datagrid = new BootstrapDatagridWrapper($this->datagrid);
        $this->filter_criteria = $this->getSeekFiltersCriteria($param);

        $this->datagrid->style = 'width: 100%';
        $this->datagrid->setHeight(320);

        $column_id = new TDataGridColumn('id', "Cód", 'center' , '70px');
        $column_account_razao_social_account_email = new TDataGridColumn('{account->razao_social} - {account->email}', "Cliente", 'left');
        $column_valor_total_transformed = new TDataGridColumn('valor_total', "Valor total", 'right');
        $column_criado_em_transformed = new TDataGridColumn('criado_em', "Criado em", 'center');
        $column_data_inicial_transformed = new TDataGridColumn('data_inicial', "Data inicial", 'center');
        $column_data_final_transformed = new TDataGridColumn('data_final', "Data final", 'center');
        $column_saas_contrato_status_nome_transformed = new TDataGridColumn('saas_contrato_status->nome', "Status", 'left');

        $column_valor_total_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });

        $column_criado_em_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y H:i');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_data_inicial_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_data_final_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_saas_contrato_status_nome_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            return "<span class = 'label label-default' style='color:#fff; background-color: {$object->saas_contrato_status->cor}'> {$object->saas_contrato_status->nome} </span> ";

        });        

        $order_id = new TAction(array($this, 'onReload'));
        $order_id->setParameter('order', 'id');
        $this->setSeekParameters($order_id, $param);
        $column_id->setAction($order_id);

        $this->datagrid->addColumn($column_id);
        $this->datagrid->addColumn($column_account_razao_social_account_email);
        $this->datagrid->addColumn($column_valor_total_transformed);
        $this->datagrid->addColumn($column_criado_em_transformed);
        $this->datagrid->addColumn($column_data_inicial_transformed);
        $this->datagrid->addColumn($column_data_final_transformed);
        $this->datagrid->addColumn($column_saas_contrato_status_nome_transformed);

        $action_onSelect = new TDataGridAction(array('SaasContratoSeekWindow', 'onSelect'));
        $action_onSelect->setUseButton(true);
        $action_onSelect->setButtonClass('btn btn-default btn-sm');
        $action_onSelect->setLabel("Selecionar");
        $action_onSelect->setImage('far:hand-pointer #44bd32');
        $action_onSelect->setField(self::$primaryKey);
        $this->setSeekParameters($action_onSelect, $param);

        $this->datagrid->addAction($action_onSelect);

        // create the datagrid model
        $this->datagrid->createModel();

        // creates the page navigation
        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $navigationAction = new TAction(array($this, 'onReload'));
        $this->setSeekParameters($navigationAction, $param);
        $this->pageNavigation->setAction($navigationAction);
        $this->pageNavigation->setWidth($this->datagrid->getWidth());

        $panel = new TPanelGroup();
        $panel->datagrid = 'datagrid-container';
        $this->datagridPanel = $panel;
        $this->datagrid_form->add($this->datagrid);
        $panel->add($this->datagrid_form);

        $panel->getBody()->class .= ' table-responsive';

        $panel->addFooter($this->pageNavigation);

        parent::add($this->form);
        parent::add($panel);

    }

    public static function onSelect($param = null) 
    { 
        try 
        {   
            $seekFields = self::getSeekFields($param);
            $formData = new stdClass();

            if(!empty($param['key']))
            {
                TTransaction::open(self::$database);

                $repository = new TRepository(self::$activeRecord);

                $criteria = self::getSeekFiltersCriteria($param);

                $criteria->add(new TFilter(self::$primaryKey, '=', $param['key']));
                $objects = $repository->load($criteria);

                if($objects)
                {
                    $object = reset($objects);
                    if($seekFields)
                    {
                        foreach ($seekFields as $seek_field) 
                        {

                            $formData->{"{$seek_field['name']}"} = $object->render("{$seek_field['column']}");
                        }
                    }
                }
                elseif($seekFields)
                {
                    foreach ($seekFields as $seek_field) 
                    {
                        $formData->{"{$seek_field['name']}"} = '';
                    }   
                }
                TTransaction::close();
            }
            else
            {
                if($seekFields)
                {
                    foreach ($seekFields as $seek_field) 
                    {
                        $formData->{"{$seek_field['name']}"} = '';
                    }   
                }
            }

            TForm::sendData($param['_form_name'], $formData);

            if(!empty($param['_seek_window_id']))
            {
                TWindow::closeWindow($param['_seek_window_id']);
            }
            else
            {
                //TScript::create("Template.closeRightPanel();");
            }
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    /**
     * Register the filter in the session
     */
    public function onSearch($param = null)
    {
        // get the search form data
        $data = $this->form->getData();
        $filters = [];

        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        if (isset($data->id) AND ( (is_scalar($data->id) AND $data->id !== '') OR (is_array($data->id) AND (!empty($data->id)) )) )
        {

            $filters[] = new TFilter('id', '=', $data->id);// create the filter 
        }

        if (isset($data->saas_plano_valor_saas_plano_id) AND ( (is_scalar($data->saas_plano_valor_saas_plano_id) AND $data->saas_plano_valor_saas_plano_id !== '') OR (is_array($data->saas_plano_valor_saas_plano_id) AND (!empty($data->saas_plano_valor_saas_plano_id)) )) )
        {

            $filters[] = new TFilter('saas_plano_valor_id', 'in', "(SELECT id FROM saas_plano_valor WHERE saas_plano_id = '{$data->saas_plano_valor_saas_plano_id}')");// create the filter 
        }

        if (isset($data->account_id) AND ( (is_scalar($data->account_id) AND $data->account_id !== '') OR (is_array($data->account_id) AND (!empty($data->account_id)) )) )
        {

            $filters[] = new TFilter('account_id', '=', $data->account_id);// create the filter 
        }

        if (isset($data->saas_contrato_status_id) AND ( (is_scalar($data->saas_contrato_status_id) AND $data->saas_contrato_status_id !== '') OR (is_array($data->saas_contrato_status_id) AND (!empty($data->saas_contrato_status_id)) )) )
        {

            $filters[] = new TFilter('saas_contrato_status_id', '=', $data->saas_contrato_status_id);// create the filter 
        }

        // fill the form with data again
        $this->form->setData($data);

        // keep the search data in the session
        TSession::setValue(__CLASS__.'_filter_data', $data);
        TSession::setValue(__CLASS__.'_filters', $filters);

        if (isset($param['static']) && ($param['static'] == '1') )
        {
            $class = get_class($this);
            AdiantiCoreApplication::loadPage($class, 'onReload', ['offset' => 0, 'first_page' => 1]);
        }
        else
        {
            $this->onReload(['offset' => 0, 'first_page' => 1]);
        }
    }

    /**
     * Load the datagrid with data
     */
    public function onReload($param = NULL)
    {
        try
        {
            // open a transaction with database 'minierp'
            TTransaction::open(self::$database);

            // creates a repository for SaasContrato
            $repository = new TRepository(self::$activeRecord);

            $criteria = clone $this->filter_criteria;

            if (empty($param['order']))
            {
                $param['order'] = 'id';    
            }
            if (empty($param['direction']))
            {
                $param['direction'] = 'desc';
            }

            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $this->limit);

            if($filters = TSession::getValue(__CLASS__.'_filters'))
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            $this->datagrid->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {
                    // add the object inside the datagrid

                    $this->datagrid->addItem($object);

                }
            }

            // reset the criteria for record count
            $criteria->resetProperties();
            $count= $repository->count($criteria);

            $this->pageNavigation->setCount($count); // count of records
            $this->pageNavigation->setProperties($param); // order, page
            $this->pageNavigation->setLimit($this->limit); // limit

            // close the transaction
            TTransaction::close();
            $this->loaded = true;
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

    /**
     * method show()
     * Shows the page
     */
    public function show()
    {
        // check if the datagrid is already loaded
        if (!$this->loaded AND (!isset($_GET['method']) OR !(in_array($_GET['method'],  $this->showMethods))) )
        {
            if (func_num_args() > 0)
            {
                $this->onReload( func_get_arg(0) );
            }
            else
            {
                $this->onReload();
            }
        }
        parent::show();
    }

}

