<?php

class SaasPlanoView extends TPage
{
    protected $form; // form
    private static $database = 'minierp';
    private static $activeRecord = 'SaasPlano';
    private static $primaryKey = 'id';
    private static $formName = 'formView_SaasPlano';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        TTransaction::open(self::$database);
        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        $this->form->setTagName('div');

        $saas_plano = new SaasPlano($param['key']);
        // define the form title
        $this->form->setFormTitle("Informação do Plano: {$saas_plano->nome}");

        $descricao = new BElement('div');

        $descricao->width = '100%';
        $descricao->height = '80px';

        $this->descricao = $descricao;

        $row1 = $this->form->addFields([$descricao]);
        $row1->layout = ['col-sm-12'];

        $descricao->add($saas_plano->descricao);

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        TTransaction::close();
        parent::add($this->form);

    }

    public function onShow($param = null)
    {     

    }

}

