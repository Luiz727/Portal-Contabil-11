<?php

class SaasMinhaContaDashboard extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_SaasMinhaContaDashboard';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Sistema");


        $html_principal = new BElement('div');


        $html_principal->setSize('100%', 80);

        $this->html_principal = $html_principal;

        $row1 = $this->form->addFields([$html_principal]);
        $row1->layout = [' col-sm-12'];

        // create the form actions

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Minha Conta","Minha conta"]));
        }
        $container->add($this->form);

        parent::add($container);

    }

    public function onShow($param = null)
    {               

        try
        {
            SaasPagamentoService::verificarPagamentosEmAberto();

            TTransaction::open(MAIN_DATABASE);

            $user = SystemUsers::find(TSession::getValue('userid'));

            ApplicationAuthenticationService::loadSessionVars($user, false);

            $config = SaasConfiguracao::first();
            $contrato = SaasContrato::find(TSession::getValue('contrato_id'));
            $proximo_pagamento = $contrato->proximo_pagamento;
            $trialAtivo = false;

            $html = new THtmlRenderer('app/resources/SaasMinhaContaDashboard.html');

            $ultimosPagamentosReplace = [];
            $planosReplace = [];

            $mainReplace = [
                'plano_nome' => $contrato->saas_plano->nome,
                'plano_valor' => $contrato->valor_total_formatado,
                'plano_vencimento' => TDate::date2br($contrato->data_final)
            ];

            $html->enableSection('main', $mainReplace);

            if (!$contrato->isAtivo())
            {
                $html->enableSection('contratoInativo');
            }
            elseif($contrato->dias_vencimento <= 10 && $contrato->saas_plano->id != $config->saas_plano_valor_trial->saas_plano_id)
            {
                if($contrato->saas_plano_valor->recorrencia == 'T')
                {
                    $tempo = '';
                    if($contrato->dias_vencimento == 0)
                    {
                        $tempo = ' hoje';
                    }
                    else
                    {
                        $tempo = " em {$contrato->dias_vencimento} dias";
                    }
                    $html->enableSection('contratoVencendoComRecorrencia', ['tempo'=> $tempo]);
                }
                else
                {
                    $html->enableSection('contratoVencendo', ['dias'=> $contrato->dias_vencimento]);
                }
            }

            if($contrato->saas_plano->id == $config->saas_plano_valor_trial->saas_plano_id)
            {
                $trialAtivo = true;
            }

            $ultimosPagamentos = SaasPagamento::where('saas_contrato_id', 'IN', "(SELECT id FROM saas_contrato WHERE account_id = {$contrato->account_id})")
                                        ->where('data_vencimento', '<=', date('Y-m-d', strtotime("+1 month")))
                                        ->take(4)
                                        ->orderBy('data_compra', 'desc')
                                        ->load();

            if ($ultimosPagamentos)
            {
                foreach ($ultimosPagamentos as $pagamento)
                {
                    $pagamentoReplace = [
                        'valor' => $pagamento->valor_formatado,
                        'data_vencimento' => $pagamento->data_vencimento_formatada,
                        'status' => $pagamento->saas_status_pagamento->nome,
                        'status_cor' => $pagamento->saas_status_pagamento->cor,
                        'plano' => $pagamento->saas_contrato->saas_plano->nome,
                        'valor' => $pagamento->valor_formatado,
                        'vencimento' => '',
                        'vencimento_cor' => '',
                        'vencimento_display' => 'display:none',
                        'botao' => ''
                    ];

                    $button = new TElement('a');
                    $button->class = 'btn btn-default';

                    if (!$pagamento->data_pagamento)
                    {
                        $button->href = $pagamento->link_gateway;
                        $button->target = '_blank';
                        $button->add(TElement::tag('i', '', ['class' => 'fa fa-external-link-alt']));
                        $button->add("Pagar");

                        $pagamentoReplace['botao'] = $button;
                    }
                    elseif($pagamento->saas_nota_fiscal_servico_id && $pagamento->saas_nota_fiscal_servico->nota_fiscal_status_id == NotaFiscalStatus::AUTORIZADA)
                    {
                        $button->add(TElement::tag('i', '', ['class' => 'fa fa-download']));
                        $button->add("NFSe");
                        $button->href = 'index.php?class=SaasAccountPagamentoList&method=onGerarNotaFiscal&static=1&key='.$pagamento->id;
                        $button->generator = 'adianti';

                        $pagamentoReplace['botao'] = $button;
                    }

                    $ultimosPagamentosReplace[] = $pagamentoReplace;
                }

                $html->enableSection('ultimosPagamentos', $ultimosPagamentosReplace, true);
            }

            $planos = SaasPlano::where('ativo', '=', 'T');

            if ($config->saas_plano_valor_trial_id)
            {
                $planos = $planos->where('id', '!=', $config->saas_plano_valor_trial->saas_plano_id);
            }

            $planos = $planos->orderBy("ordem")->load();

            if ($planos)
            {
                foreach($planos as $plano)
                {
                    $planoReplace = [
                        'plano' => $plano->nome,
                        'botao' => '',
                        'plano_id' => $plano->id,
                        'valores' => []
                    ];

                    $botao = '';

                    if ($contrato->saas_plano->id == $plano->id && $contrato->isAtivo() && !$trialAtivo)
                    {
                        $botao = TElement::tag('div', 'Plano atual', ['class' => 'label plano-atual']);
                    }
                    else if ($contrato->saas_plano->id == $plano->id && ! $contrato->isAtivo())
                    {
                        $botao = new TElement('a');
                        $botao->class = 'btn btn-default btn-small label plano-atual';
                        $botao->generator = 'adianti';
                        $botao->href = 'index.php?class=SaasCompraViewEtapa1&method=onShow&saas_plano_id=' . $plano->id;
                        $botao->add(TElement::tag('i', '', ['class' => 'fa fa-edit']));
                        $botao->add('Renovar');
                    }
                    elseif (!$contrato->isAtivo() || $trialAtivo)
                    {
                        $botao = new TElement('a');
                        $botao->class = 'btn btn-default btn-small';
                        $botao->generator = 'adianti';
                        $botao->href = 'index.php?class=SaasCompraViewEtapa1&method=onShow&saas_plano_id=' . $plano->id;
                        $botao->add(TElement::tag('i', '', ['class' => 'fa fa-edit']));
                        $botao->add('assinar');
                    }

                    $planoReplace['botao'] = $botao;

                    $valores = $plano->getSaasPlanoValors();

                    foreach($valores as $valor)
                    {
                        $planoReplace['valores'][] = [
                            'nome' => $valor->nome,
                            'valor' => $valor->valor_formatado,
                        ];
                    }

                    $planosReplace[] = $planoReplace;
                }

                $html->enableSection('planos', $planosReplace, true);
            }

            $this->html_principal->add($html);

            TTransaction::close();
        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage(). $e->getTraceAsString());
            TTransaction::rollback();
        }

    } 

    public static function renovarPlano($param)
    {
        try
        {
            $contrato_id = TSession::getValue('contrato_id');

            if($contrato_id)
            {
                TTransaction::open(MAIN_DATABASE);

                $contrato = new SaasContrato($contrato_id);

                TApplication::loadPage('SaasCompraViewEtapa1', 'onShow', ['saas_plano_id' => $contrato->saas_plano->id, 'renovar'=>1]);

                TTransaction::close();    
            }
            else
            {
                TApplication::loadPage('SaasCompraViewEtapa1', 'onShow');
            }

        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
            TTransaction::rollback();
        }
    }

}

