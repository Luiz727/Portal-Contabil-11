<?php

class SaasCompraViewEtapa2 extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_SaasCompraViewEtapa2';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Escolha o Valor");

        $criteria_saas_plano_valor_id = new TCriteria();

        $filterVar = TSession::getValue('saas_carrinho_compras')->saas_plano_id;
        $criteria_saas_plano_valor_id->add(new TFilter('saas_plano_id', '=', $filterVar)); 

        $data = TSession::getValue('saas_carrinho_compras');

        if(empty($data->saas_plano_id))
        {
            TApplication::loadPage('SaasCompraViewEtapa1', 'onShow');
            new TMessage('info', 'O plano não foi escolhido!');
            return false;
        }

        $Etapas = new TPageStep();
        $saas_plano_valor_id = new TDBRadioGroup('saas_plano_valor_id', 'minierp', 'SaasPlanoValor', 'id', '{option_html}','valor desc' , $criteria_saas_plano_valor_id );


        $saas_plano_valor_id->setSize(250);
        $saas_plano_valor_id->setLayout('horizontal');
        $saas_plano_valor_id->setUseButton();

        $Etapas->addItem("Defina o Plano");
        $Etapas->addItem("Defina o Valor");
        $Etapas->addItem("Informações Fiscais");
        $Etapas->addItem("Pagamento");

        $Etapas->select("Defina o Valor");

        $this->Etapas = $Etapas;

        $row1 = $this->form->addFields([$Etapas]);
        $row1->layout = [' col-sm-12'];

        $row2 = $this->form->addFields([new TFormSeparator("Valor", '#333', '18', '#eee')]);
        $row2->layout = [' col-sm-12'];

        $row3 = $this->form->addFields([$saas_plano_valor_id]);
        $row3->layout = [' col-sm-12  text-center'];

        // create the form actions
        $btn_onshow = $this->form->addAction("Voltar", new TAction(['SaasCompraViewEtapa1', 'onShow']), 'fas:arrow-alt-circle-left #000000');
        $this->btn_onshow = $btn_onshow;

        $avancar = $this->form->addAction("Avançar", new TAction([$this, 'onNext']), 'fas:arrow-alt-circle-right #ffffff');
        $this->avancar = $avancar;
        $avancar->addStyleClass('btn-primary'); 

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        }
        $container->add($this->form);

        parent::add($container);

    }

    public function onNext($param = null) 
    {
        try
        {
            $data = $this->form->getData();

            if (empty($data->saas_plano_valor_id)) 
            {
                throw new Exception("Selecione o valor");
            }

            $dataCarrinho = TSession::getValue('saas_carrinho_compras');
            $dataCarrinho->saas_plano_valor_id = $data->saas_plano_valor_id;

            TSession::setValue('saas_carrinho_compras', $dataCarrinho);

            TApplication::loadPage('SaasCompraViewEtapa3', 'onShow');
        }
        catch (Exception $e)
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());
        }
    }

    public function onShow($param = null)
    {               

        try
        {
            TTransaction::open(MAIN_DATABASE);

            $contrato = SaasContrato::find(TSession::getValue('contrato_id'));
            $data = TSession::getValue('saas_carrinho_compras') ?? new stdClass;

            $data->saas_plano_valor_id = $data->saas_plano_valor_id ?? $contrato->saas_plano_valor_id;

            $this->form->setData($data);

            TTransaction::close();
        }
        catch (Exception $e)
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());
        }
    } 

}

