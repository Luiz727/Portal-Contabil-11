<?php

class SaasAccountPagamentoList extends TPage
{
    private $form; // form
    private $datagrid; // listing
    private $pageNavigation;
    private $loaded;
    private $filter_criteria;
    private static $database = 'minierp';
    private static $activeRecord = 'SaasPagamento';
    private static $primaryKey = 'id';
    private static $formName = 'form_SaasPagamentoList';
    private $showMethods = ['onReload', 'onSearch', 'onRefresh', 'onClearFilters'];
    private $limit = 20;

    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct($param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        // define the form title
        $this->form->setFormTitle("Pagamentos");
        $this->limit = 20;

        $criteria_saas_status_pagamento_id = new TCriteria();

        $data_compra = new TDate('data_compra');
        $data_compra_final = new TDate('data_compra_final');
        $data_pagamento = new TDate('data_pagamento');
        $data_pagamento_final = new TDate('data_pagamento_final');
        $data_vencimento = new TDate('data_vencimento');
        $data_vencimento_final = new TDate('data_vencimento_final');
        $saas_status_pagamento_id = new TDBCombo('saas_status_pagamento_id', 'minierp', 'SaasStatusPagamento', 'id', '{nome}','nome asc' , $criteria_saas_status_pagamento_id );


        $saas_status_pagamento_id->enableSearch();
        $data_compra->setMask('dd/mm/yyyy');
        $data_pagamento->setMask('dd/mm/yyyy');
        $data_vencimento->setMask('dd/mm/yyyy');
        $data_compra_final->setMask('dd/mm/yyyy');
        $data_pagamento_final->setMask('dd/mm/yyyy');
        $data_vencimento_final->setMask('dd/mm/yyyy');

        $data_compra->setDatabaseMask('yyyy-mm-dd');
        $data_pagamento->setDatabaseMask('yyyy-mm-dd');
        $data_vencimento->setDatabaseMask('yyyy-mm-dd');
        $data_compra_final->setDatabaseMask('yyyy-mm-dd');
        $data_pagamento_final->setDatabaseMask('yyyy-mm-dd');
        $data_vencimento_final->setDatabaseMask('yyyy-mm-dd');

        $data_compra->setSize(110);
        $data_pagamento->setSize(110);
        $data_vencimento->setSize(110);
        $data_compra_final->setSize(110);
        $data_pagamento_final->setSize(110);
        $data_vencimento_final->setSize(110);
        $saas_status_pagamento_id->setSize('100%');

        $row1 = $this->form->addFields([new TLabel("Data compra:", null, '14px', null, '100%'),$data_compra,new TLabel("até", null, '14px', null),$data_compra_final],[new TLabel("Data pagamento:", null, '14px', null, '100%'),$data_pagamento,new TLabel("até", null, '14px', null),$data_pagamento_final]);
        $row1->layout = ['col-sm-6',' col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("Data vencimento:", null, '14px', null, '100%'),$data_vencimento,new TLabel("até", null, '14px', null),$data_vencimento_final],[new TLabel("Status:", null, '14px', null, '100%'),$saas_status_pagamento_id]);
        $row2->layout = ['col-sm-6','col-sm-6'];

        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );

        $btn_onsearch = $this->form->addAction("Buscar", new TAction([$this, 'onSearch']), 'fas:search #ffffff');
        $this->btn_onsearch = $btn_onsearch;
        $btn_onsearch->addStyleClass('btn-primary'); 

        // creates a Datagrid
        $this->datagrid = new TDataGrid;
        $this->datagrid->setId(__CLASS__.'_datagrid');

        $this->datagrid_form = new TForm('datagrid_'.self::$formName);
        $this->datagrid_form->onsubmit = 'return false';

        $this->datagrid = new BootstrapDatagridWrapper($this->datagrid);
        $this->filter_criteria = new TCriteria;

        $filterVar = TSession::getValue('account_id');
        $this->filter_criteria->add(new TFilter('account_id', '=', $filterVar));

        $this->datagrid->style = 'width: 100%';
        $this->datagrid->setHeight(250);

        $column_saas_contrato_descricao_html = new TDataGridColumn('saas_contrato->descricao_html', "Contrato", 'left');
        $column_saas_gateway_pagamento_nome = new TDataGridColumn('saas_gateway_pagamento->nome', "Gateway", 'left');
        $column_valor_transformed = new TDataGridColumn('valor', "Valor", 'right' , '150px');
        $column_data_vencimento_transformed = new TDataGridColumn('data_vencimento', "Vencimento", 'center' , '125px');
        $column_saas_status_pagamento_nome_transformed = new TDataGridColumn('saas_status_pagamento->nome', "Status", 'center' , '150px');

        $column_valor_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!$value)
            {
                $value = 0;
            }

            if(is_numeric($value))
            {
                return "R$ " . number_format($value, 2, ",", ".");
            }
            else
            {
                return $value;
            }
        });

        $column_data_vencimento_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {
            if(!empty(trim((string) $value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $column_saas_status_pagamento_nome_transformed->setTransformer(function($value, $object, $row, $cell = null, $last_row = null)
        {

            return "<span class = 'label label-default' style='color:#fff; background-color: {$object->saas_status_pagamento->cor}'> {$object->saas_status_pagamento->nome} <span> ";

        });        

        $column_saas_contrato_descricao_html->disableHtmlConversion();
        $column_saas_status_pagamento_nome_transformed->disableHtmlConversion();

        $this->datagrid->addColumn($column_saas_contrato_descricao_html);
        $this->datagrid->addColumn($column_saas_gateway_pagamento_nome);
        $this->datagrid->addColumn($column_valor_transformed);
        $this->datagrid->addColumn($column_data_vencimento_transformed);
        $this->datagrid->addColumn($column_saas_status_pagamento_nome_transformed);

        $action_onGerarNotaFiscal = new TDataGridAction(array('SaasAccountPagamentoList', 'onGerarNotaFiscal'));
        $action_onGerarNotaFiscal->setUseButton(true);
        $action_onGerarNotaFiscal->setButtonClass('btn btn-default btn-sm');
        $action_onGerarNotaFiscal->setLabel("NFS-e");
        $action_onGerarNotaFiscal->setImage('fas:file-alt #8BC34A');
        $action_onGerarNotaFiscal->setField(self::$primaryKey);
        $action_onGerarNotaFiscal->setDisplayCondition('SaasAccountPagamentoList::podeExibirNf');

        $this->datagrid->addAction($action_onGerarNotaFiscal);

        // create the datagrid model
        $this->datagrid->createModel();

        // creates the page navigation
        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
        $this->pageNavigation->setWidth($this->datagrid->getWidth());

        $panel = new TPanelGroup("Pagamentos");
        $panel->datagrid = 'datagrid-container';
        $this->datagridPanel = $panel;
        $this->datagrid_form->add($this->datagrid);
        $panel->add($this->datagrid_form);

        $panel->getBody()->class .= ' table-responsive';

        $panel->addFooter($this->pageNavigation);

        $headerActions = new TElement('div');
        $headerActions->class = ' datagrid-header-actions ';
        $headerActions->style = 'justify-content: space-between;';

        $head_left_actions = new TElement('div');
        $head_left_actions->class = ' datagrid-header-actions-left-actions ';

        $head_right_actions = new TElement('div');
        $head_right_actions->class = ' datagrid-header-actions-left-actions ';

        $headerActions->add($head_left_actions);
        $headerActions->add($head_right_actions);

        $panel->getBody()->insert(0, $headerActions);

        $btnShowCurtainFilters = new TButton('button_btnShowCurtainFilters');
        $btnShowCurtainFilters->setAction(new TAction(['SaasAccountPagamentoList', 'onShowCurtainFilters']), "Filtros");
        $btnShowCurtainFilters->addStyleClass('btn-default');
        $btnShowCurtainFilters->setImage('fas:filter #000000');

        $this->datagrid_form->addField($btnShowCurtainFilters);

        $button_limpar_filtros = new TButton('button_button_limpar_filtros');
        $button_limpar_filtros->setAction(new TAction(['SaasAccountPagamentoList', 'onClearFilters']), "Limpar filtros");
        $button_limpar_filtros->addStyleClass('btn-default');
        $button_limpar_filtros->setImage('fas:eraser #f44336');

        $this->datagrid_form->addField($button_limpar_filtros);

        $button_atualizar = new TButton('button_button_atualizar');
        $button_atualizar->setAction(new TAction(['SaasAccountPagamentoList', 'onRefresh']), "Atualizar");
        $button_atualizar->addStyleClass('btn-default');
        $button_atualizar->setImage('fas:sync-alt #03a9f4');

        $this->datagrid_form->addField($button_atualizar);

        $head_left_actions->add($btnShowCurtainFilters);
        $head_left_actions->add($button_limpar_filtros);
        $head_left_actions->add($button_atualizar);

        $this->btnShowCurtainFilters = $btnShowCurtainFilters;

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Minha Conta","Meus Pagamentos"]));
        }

        $container->add($panel);

        parent::add($container);

    }

    public static function onGerarNotaFiscal($param = null) 
    {
        try 
        {
            if(!empty($param['key']))
            {
                TTransaction::open(self::$database);

                $pagamento = new SaasPagamento($param['key']);

                if($pagamento->account_id != PermissaoService::getAccountId())
                {
                    throw new Exception('Permissão negada');
                }

                if($pagamento->saas_nota_fiscal_servico_id && $pagamento->saas_nota_fiscal_servico->nota_fiscal_status_id == NotaFiscalStatus::AUTORIZADA)
                {
                    $notaFiscal = $pagamento->saas_nota_fiscal_servico;

                    $dados = json_decode($notaFiscal->dados_gateway_externo ?? '');

                    if (!empty($dados->documento))
                    {
                        $window = TWindow::create('PDF', 0.8, 0.8);

                        $object = new TElement('iframe');
                        $object->src  = 'data:application/pdf;base64,'. base64_encode(file_get_contents($dados->documento));
                        $object->type  = 'application/pdf';
                        $object->style = "width: 100%; height:calc(100% - 10px)";

                        $window->add($object);
                        $window->show();

                        // TScript::create("window.open('$dados->documento');");
                    }
                }
                else
                {
                    new TMessage('info', 'A nota fiscal ainda não foi emitida');
                }

                TTransaction::close();
            }
            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function podeExibirNf($object)
    {
        try 
        {
            if($object->saas_nota_fiscal_servico_id && $object->saas_nota_fiscal_servico->nota_fiscal_status_id == NotaFiscalStatus::AUTORIZADA)
            {
                return true;
            }

            return false;
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public static function onShowCurtainFilters($param = null) 
    {
        try 
        {
            //code here

                        $filter = new self([]);

            $btnClose = new TButton('closeCurtain');
            $btnClose->class = 'btn btn-sm btn-default';
            $btnClose->style = 'margin-right:10px;';
            $btnClose->onClick = "Template.closeRightPanel();";
            $btnClose->setLabel("Fechar");
            $btnClose->setImage('fas:times');

            $filter->form->addHeaderWidget($btnClose);

            $page = new TPage();
            $page->setTargetContainer('adianti_right_panel');
            $page->setProperty('page-name', 'SaasAccountPagamentoListSearch');
            $page->setProperty('page_name', 'SaasAccountPagamentoListSearch');
            $page->adianti_target_container = 'adianti_right_panel';
            $page->target_container = 'adianti_right_panel';
            $page->add($filter->form);
            $page->setIsWrapped(true);
            $page->show();

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onClearFilters($param = null) 
    {
        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }
    public function onRefresh($param = null) 
    {
        $this->onReload([]);
    }

    /**
     * Register the filter in the session
     */
    public function onSearch($param = null)
    {
        $data = $this->form->getData();
        $filters = [];

        $dataClone = clone $data;

        if (isset($data->data_compra_final) AND ( (is_scalar($data->data_compra_final) AND $data->data_compra_final !== '') OR (is_array($data->data_compra_final) AND (!empty($data->data_compra_final)) )) )
        {
            $data->data_compra_final = $data->data_compra_final . ' 23:59:59';
        }

        if (isset($data->data_compra) AND ( (is_scalar($data->data_compra) AND $data->data_compra !== '') OR (is_array($data->data_compra) AND (!empty($data->data_compra)) )) )
        {
            $data->data_compra = $data->data_compra . ' 00:00:00';
        }

        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        if (isset($data->data_compra) AND ( (is_scalar($data->data_compra) AND $data->data_compra !== '') OR (is_array($data->data_compra) AND (!empty($data->data_compra)) )) )
        {

            $filters[] = new TFilter('data_compra', '>=', $data->data_compra);// create the filter 
        }

        if (isset($data->data_compra_final) AND ( (is_scalar($data->data_compra_final) AND $data->data_compra_final !== '') OR (is_array($data->data_compra_final) AND (!empty($data->data_compra_final)) )) )
        {

            $filters[] = new TFilter('data_compra', '<=', $data->data_compra_final);// create the filter 
        }

        if (isset($data->data_pagamento) AND ( (is_scalar($data->data_pagamento) AND $data->data_pagamento !== '') OR (is_array($data->data_pagamento) AND (!empty($data->data_pagamento)) )) )
        {

            $filters[] = new TFilter('data_pagamento', '>=', $data->data_pagamento);// create the filter 
        }

        if (isset($data->data_pagamento_final) AND ( (is_scalar($data->data_pagamento_final) AND $data->data_pagamento_final !== '') OR (is_array($data->data_pagamento_final) AND (!empty($data->data_pagamento_final)) )) )
        {

            $filters[] = new TFilter('data_pagamento', '<=', $data->data_pagamento_final);// create the filter 
        }

        if (isset($data->data_vencimento) AND ( (is_scalar($data->data_vencimento) AND $data->data_vencimento !== '') OR (is_array($data->data_vencimento) AND (!empty($data->data_vencimento)) )) )
        {

            $filters[] = new TFilter('data_vencimento', '>=', $data->data_vencimento);// create the filter 
        }

        if (isset($data->data_vencimento_final) AND ( (is_scalar($data->data_vencimento_final) AND $data->data_vencimento_final !== '') OR (is_array($data->data_vencimento_final) AND (!empty($data->data_vencimento_final)) )) )
        {

            $filters[] = new TFilter('data_vencimento', '<=', $data->data_vencimento_final);// create the filter 
        }

        if (isset($data->saas_status_pagamento_id) AND ( (is_scalar($data->saas_status_pagamento_id) AND $data->saas_status_pagamento_id !== '') OR (is_array($data->saas_status_pagamento_id) AND (!empty($data->saas_status_pagamento_id)) )) )
        {

            $filters[] = new TFilter('saas_status_pagamento_id', '=', $data->saas_status_pagamento_id);// create the filter 
        }

        $data = $dataClone;

        // fill the form with data again
        $this->form->setData($data);

        // keep the search data in the session
        TSession::setValue(__CLASS__.'_filter_data', $data);
        TSession::setValue(__CLASS__.'_filters', $filters);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }

    /**
     * Load the datagrid with data
     */
    public function onReload($param = NULL)
    {
        try
        {
            // open a transaction with database 'minierp'
            TTransaction::open(self::$database);

            // creates a repository for SaasPagamento
            $repository = new TRepository(self::$activeRecord);

            $criteria = clone $this->filter_criteria;

            if (empty($param['order']))
            {
                $param['order'] = 'id';    
            }

            if (empty($param['direction']))
            {
                $param['direction'] = 'desc';
            }

            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $this->limit);

            if($filters = TSession::getValue(__CLASS__.'_filters'))
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            //</blockLine><btnShowCurtainFiltersAutoCode>
            if(!empty($this->btnShowCurtainFilters) && empty($this->btnShowCurtainFiltersAdjusted))
            {
                $this->btnShowCurtainFiltersAdjusted = true;
                $this->btnShowCurtainFilters->style = 'position: relative';
                $countFilters = count($filters ?? []);
                $this->btnShowCurtainFilters->setLabel($this->btnShowCurtainFilters->getLabel(). "<span class='badge badge-success' style='position: absolute'>{$countFilters}<span>");
            }
            //</blockLine></btnShowCurtainFiltersAutoCode>

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            $this->datagrid->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {

                    $row = $this->datagrid->addItem($object);
                    $row->id = "row_{$object->id}";

                }
            }

            // reset the criteria for record count
            $criteria->resetProperties();
            $count= $repository->count($criteria);

            $this->pageNavigation->setCount($count); // count of records
            $this->pageNavigation->setProperties($param); // order, page
            $this->pageNavigation->setLimit($this->limit); // limit

            // close the transaction
            TTransaction::close();
            $this->loaded = true;

            return $objects;
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

    /**
     * method show()
     * Shows the page
     */
    public function show()
    {
        // check if the datagrid is already loaded
        if (!$this->loaded AND (!isset($_GET['method']) OR !(in_array($_GET['method'],  $this->showMethods))) )
        {
            if (func_num_args() > 0)
            {
                $this->onReload( func_get_arg(0) );
            }
            else
            {
                $this->onReload();
            }
        }
        parent::show();
    }

    public static function manageRow($id, $param = [])
    {
        $list = new self($param);

        $openTransaction = TTransaction::getDatabase() != self::$database ? true : false;

        if($openTransaction)
        {
            TTransaction::open(self::$database);    
        }

        $object = new SaasPagamento($id);

        $row = $list->datagrid->addItem($object);
        $row->id = "row_{$object->id}";

        if($openTransaction)
        {
            TTransaction::close();    
        }

        TDataGrid::replaceRowById(__CLASS__.'_datagrid', $row->id, $row);
    }

}

