<?php

class SaasCompraViewEtapa1 extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = '';
    private static $activeRecord = '';
    private static $primaryKey = '';
    private static $formName = 'form_SaasCompraViewEtapa1';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Escolha o seu Plano");

        $criteria_saas_plano_id = new TCriteria();

        $filterVar = "T";
        $criteria_saas_plano_id->add(new TFilter('ativo', '=', $filterVar)); 
        $filterVar = SaasConfiguracaoService::getPlanoTrialId();
        $criteria_saas_plano_id->add(new TFilter('id', '!=', $filterVar)); 

        $etapas = new TPageStep();
        $saas_plano_id = new TDBRadioGroup('saas_plano_id', 'minierp', 'SaasPlano', 'id', '{option_html}','ordem asc' , $criteria_saas_plano_id );
        $renovar = new THidden('renovar');


        $saas_plano_id->setLayout('horizontal');
        $saas_plano_id->setUseButton();
        $renovar->setSize(200);
        $saas_plano_id->setSize('100%');

        $renovar->setValue($param['renovar'] ?? null);
        $saas_plano_id->setValue($param['saas_plano_id'] ?? '');

        $etapas->addItem("Defina o Plano");
        $etapas->addItem("Defina o Valor");
        $etapas->addItem("Informações Fiscais");
        $etapas->addItem("Pagamento");

        $etapas->select("Defina o Plano");

        $this->etapas = $etapas;

        $row1 = $this->form->addFields([$etapas]);
        $row1->layout = [' col-sm-12'];

        $row2 = $this->form->addFields([new TFormSeparator("Plano", '#333', '16', '#eee')]);
        $row2->layout = [' col-sm-12'];

        $row3 = $this->form->addFields([$saas_plano_id]);
        $row3->layout = [' col-sm-12'];

        $row4 = $this->form->addFields([$renovar]);
        $row4->layout = [' col-sm-12'];

        // create the form actions
        $avancar = $this->form->addAction("Avançar", new TAction([$this, 'onNext'],['static' => 1]), 'fas:arrow-alt-circle-right #ffffff');
        $this->avancar = $avancar;
        $avancar->addStyleClass('btn-primary'); 

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        }
        $container->add($this->form);

        parent::add($container);

    }

    public function onNext($param = null) 
    {
        try
        {
            $data = $this->form->getData();

            if (empty($data->saas_plano_id))
            {
                throw new Exception("Selecione o plano");
            }

            TSession::setValue('saas_carrinho_compras', $data);

            TApplication::loadPage('SaasCompraViewEtapa2', 'onShow');
        }
        catch (Exception $e)
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());
        }
    }

    public function onShow($param = null)
    {               

        try
        {
            TTransaction::open(MAIN_DATABASE);

            $contrato = SaasContrato::find(TSession::getValue('contrato_id'));

            $data = TSession::getValue('saas_carrinho_compras') ?? new stdClass;
            $data->saas_plano_id = $param['saas_plano_id'] ?? $data->saas_plano_id ?? $contrato->saas_plano->id;

            if(!empty($param['renovar']))
            {
                $data->renovar = $param['renovar'];
            }

            $this->form->setData($data);

            TTransaction::close();
        }
        catch (Exception $e)
        {
            TTransaction::rollback();
            new TMessage('error', $e->getMessage());
        }
    } 

}

