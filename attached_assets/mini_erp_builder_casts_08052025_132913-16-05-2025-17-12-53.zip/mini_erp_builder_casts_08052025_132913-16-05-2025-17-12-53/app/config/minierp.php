<?php 
return[
    'host' => "",
    'name' => "app/database/minierp.db",
    'user' => "",
    'pass' => "",
    'type' => "sqlite",
    'prep' => "1",
    'slog' => "SystemSqlLogService"
];