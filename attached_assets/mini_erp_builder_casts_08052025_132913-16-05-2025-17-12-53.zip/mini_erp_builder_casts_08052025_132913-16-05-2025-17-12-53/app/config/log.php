<?php 
return[
    'host' => "",
    'name' => "app/database/minierp_log.db",
    'user' => "",
    'pass' => "",
    'type' => "sqlite",
    'prep' => "1",
    'slog' => "SystemSqlLogService"
];