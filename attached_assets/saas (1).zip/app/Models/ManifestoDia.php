<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ManifestoDia extends Model
{
    protected $fillable = [
		'empresa_id'
	];
}
