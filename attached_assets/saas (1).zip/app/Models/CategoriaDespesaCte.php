<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CategoriaDespesaCte extends Model
{
    protected $fillable = [
		'nome', 'empresa_id'
	];
}
