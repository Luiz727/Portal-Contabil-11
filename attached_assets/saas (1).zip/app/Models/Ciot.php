<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ciot extends Model
{
    protected $fillable = [
		'mdfe_id', 'cpf_cnpj', 'codigo'
	];
}
