<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LacreTransporte extends Model
{
    protected $fillable = [
		'info_id', 'numero'
	];
}
