<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CategoriaDestaqueMasterDelivery extends Model
{
	protected $fillable = [ 'nome' ];
}
