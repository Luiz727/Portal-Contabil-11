<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Percurso extends Model
{
    protected $fillable = [
		'mdfe_id', 'uf'
	];
}
