<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ControleComandaController extends Controller
{
    public function index()
    {
        
    }
}
