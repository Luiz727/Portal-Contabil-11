<?php

class ClienteForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'banco';
    private static $activeRecord = 'Cliente';
    private static $primaryKey = 'cliente_id';
    private static $formName = 'form_Cliente';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de cliente");


        $cliente_id = new TEntry('cliente_id');
        $nome = new TEntry('nome');
        $cpf_cnpj = new TEntry('cpf_cnpj');
        $inscricao_estadual = new TEntry('inscricao_estadual');
        $cep = new TEntry('cep');
        $logradouro = new TEntry('logradouro');
        $numero = new TEntry('numero');
        $complemento = new TEntry('complemento');
        $bairro = new TEntry('bairro');
        $nome_municipio = new TEntry('nome_municipio');
        $codigo_municipio = new TEntry('codigo_municipio');
        $indicador_ie = new TEntry('indicador_ie');


        $cliente_id->setEditable(false);
        $cep->setMaxLength(9);
        $nome->setMaxLength(50);
        $numero->setMaxLength(10);
        $bairro->setMaxLength(50);
        $logradouro->setMaxLength(50);
        $complemento->setMaxLength(20);
        $nome_municipio->setMaxLength(50);
        $codigo_municipio->setMaxLength(10);
        $inscricao_estadual->setMaxLength(15);

        $cep->setSize('100%');
        $nome->setSize('100%');
        $numero->setSize('100%');
        $bairro->setSize('100%');
        $cliente_id->setSize(100);
        $cpf_cnpj->setSize('100%');
        $logradouro->setSize('100%');
        $complemento->setSize('100%');
        $indicador_ie->setSize('100%');
        $nome_municipio->setSize('100%');
        $codigo_municipio->setSize('100%');
        $inscricao_estadual->setSize('100%');

        $row1 = $this->form->addFields([new TLabel("Cliente id:", null, '14px', null, '100%'),$cliente_id],[new TLabel("Nome:", null, '14px', null, '100%'),$nome]);
        $row1->layout = ['col-sm-6','col-sm-6'];

        $row2 = $this->form->addFields([new TLabel("CPF / CNPJ:", null, '14px', null, '100%'),$cpf_cnpj],[new TLabel("Inscrição Estadual:", null, '14px', null, '100%'),$inscricao_estadual]);
        $row2->layout = ['col-sm-6','col-sm-6'];

        $row3 = $this->form->addFields([new TLabel("CEP:", null, '14px', null, '100%'),$cep],[new TLabel("Rua:", null, '14px', null, '100%'),$logradouro]);
        $row3->layout = ['col-sm-6','col-sm-6'];

        $row4 = $this->form->addFields([new TLabel("Número:", null, '14px', null, '100%'),$numero],[new TLabel("Complemento:", null, '14px', null, '100%'),$complemento]);
        $row4->layout = ['col-sm-6','col-sm-6'];

        $row5 = $this->form->addFields([new TLabel("Bairro:", null, '14px', null, '100%'),$bairro],[new TLabel("Nome municipio:", null, '14px', null, '100%'),$nome_municipio]);
        $row5->layout = ['col-sm-6','col-sm-6'];

        $row6 = $this->form->addFields([new TLabel("Codigo municipio:", null, '14px', null, '100%'),$codigo_municipio],[new TLabel("Indicador ie:", null, '14px', null, '100%'),$indicador_ie]);
        $row6->layout = ['col-sm-6','col-sm-6'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['ClienteList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Cadastros","Cadastro de cliente"]));
        }
        $container->add($this->form);

        parent::add($container);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Cliente(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            // get the generated {PRIMARY_KEY}
            $data->cliente_id = $object->cliente_id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('ClienteList', 'onShow', $loadPageParam); 

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Cliente($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

