<?php

use CloudDfe\SdkPHP\Nfe;

class VendasList extends TPage
{
    private $form; // form
    private $datagrid; // listing
    private $pageNavigation;
    private $loaded;
    private $filter_criteria;
    private static $database = 'banco';
    private static $activeRecord = 'Venda';
    private static $primaryKey = 'venda_id';
    private static $formName = 'formList_Venda';
    private $showMethods = ['onReload', 'onSearch', 'onRefresh', 'onClearFilters'];
    private $limit = 20;

    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct($param = null)
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        // define the form title
        $this->form->setFormTitle("VENDAS");
        $this->limit = 20;

        $data_venda = new TDateTime('data_venda');


        $data_venda->setSize(150);
        $data_venda->setMask('dd/mm/yyyy hh:ii');
        $data_venda->setDatabaseMask('yyyy-mm-dd hh:ii');

        $row1 = $this->form->addFields([new TLabel("Data venda:", null, '14px', null)],[$data_venda]);

        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );

        $btn_onshow = $this->form->addAction("NOVA VENDA", new TAction(['VendaForm', 'onShow']), 'fas:plus #000000');
        $this->btn_onshow = $btn_onshow;

        // creates a Datagrid
        $this->datagrid = new TDataGrid;
        $this->datagrid->setId(__CLASS__.'_datagrid');

        $this->datagrid_form = new TForm('datagrid_'.self::$formName);
        $this->datagrid_form->onsubmit = 'return false';

        $this->datagrid = new BootstrapDatagridWrapper($this->datagrid);
        $this->filter_criteria = new TCriteria;

        $this->datagrid->style = 'width: 100%';
        $this->datagrid->setHeight(250);

        $column_venda_id = new TDataGridColumn('venda_id', "N° VENDA", 'center' , '120px');
        $column_data_venda = new TDataGridColumn('data_venda', "DATA VENDA", 'center' , '200px');
        $column_cliente_nome = new TDataGridColumn('cliente->nome', "CLIENTE", 'left');

        $order_venda_id = new TAction(array($this, 'onReload'));
        $order_venda_id->setParameter('order', 'venda_id');
        $column_venda_id->setAction($order_venda_id);

        $this->datagrid->addColumn($column_venda_id);
        $this->datagrid->addColumn($column_data_venda);
        $this->datagrid->addColumn($column_cliente_nome);

        $action_onENVIAR = new TDataGridAction(array('VendasList', 'onENVIAR'));
        $action_onENVIAR->setUseButton(false);
        $action_onENVIAR->setButtonClass('btn btn-default btn-sm');
        $action_onENVIAR->setLabel("NFe");
        $action_onENVIAR->setImage('far:file-alt #000000');
        $action_onENVIAR->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onENVIAR);

        $action_onNFCe = new TDataGridAction(array('VendasList', 'onNFCe'));
        $action_onNFCe->setUseButton(false);
        $action_onNFCe->setButtonClass('btn btn-default btn-sm');
        $action_onNFCe->setLabel("NFCe");
        $action_onNFCe->setImage('fab:dochub #000000');
        $action_onNFCe->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onNFCe);

        $action_onCANCELAR = new TDataGridAction(array('VendasList', 'onCANCELAR'));
        $action_onCANCELAR->setUseButton(false);
        $action_onCANCELAR->setButtonClass('btn btn-default btn-sm');
        $action_onCANCELAR->setLabel("CANCELAR");
        $action_onCANCELAR->setImage('fas:arrow-left #000000');
        $action_onCANCELAR->setField(self::$primaryKey);

        $this->datagrid->addAction($action_onCANCELAR);

        // create the datagrid model
        $this->datagrid->createModel();

        // creates the page navigation
        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
        $this->pageNavigation->setWidth($this->datagrid->getWidth());

        $panel = new TPanelGroup();
        $panel->datagrid = 'datagrid-container';
        $this->datagridPanel = $panel;
        $this->datagrid_form->add($this->datagrid);
        $panel->add($this->datagrid_form);

        $panel->addFooter($this->pageNavigation);

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Movimentação","VENDAS"]));
        }
        $container->add($this->form);
        $container->add($panel);

        parent::add($container);

    }

    public function onENVIAR($param = null) 
    {
        try 
        {
            TTransaction::open('banco');

            $venda = Venda::find($param['key']);

            if ($venda) 
            {
                $cliente = Cliente::find($venda->cliente_id);
                if ($cliente) {
                   $nome = $cliente->nome;
                   $cpf_cnpj = $cliente->cpf_cnpj;
                   $inscricao = $cliente->inscricao;
                   $cep = $cliente->cep;
                   $logradouro = $cliente->logradouro;
                   $numero = $cliente->numero;
                   $complemento = $cliente->complemento;
                   $bairro = $cliente->bairro;
                   $nome_municipio = $cliente->nome_municipio;
                   $codigo_municipio = $cliente->codigo_municipio;
                   $indicador_ie  = $cliente->indicador_ie;
                   $telefone = $cliente->telefone;
                   $uf = $cliente->uf;
                }

                $data = [
                    "natureza_operacao" => "VENDA DENTRO DO ESTADO",
                    "serie" => "1",
                    "numero" => "102101",
                    "data_emissao" =>  date("Y-m-d\TH:i:sP", strtotime($venda->data_venda)),
                    "data_entrada_saida" => date("Y-m-d\TH:i:sP", strtotime($venda->data_venda)),
                    "tipo_operacao" => "1",
                    "finalidade_emissao" => "1",
                    "consumidor_final" => "1",
                    "presenca_comprador" => "1",
                    "intermediario" => [
                        "indicador" => "0"
                    ],
                    "destinatario" => [
                        "cpf" => "{$cpf_cnpj}",
                        "nome" => "{$nome}",
                        "indicador_inscricao_estadual" => "{$indicador_ie}",
                        "inscricao_estadual" => "{$inscricao}",
                        "endereco" => [
                            "logradouro" => "{$logradouro}",
                            "numero" => "{$numero}",
                            "bairro" => "{$bairro}",
                            "codigo_municipio" => "4108403",
                            "nome_municipio" => "Mossoro",
                            "uf" => "{$uf}",
                            "cep" => "{$cep}",
                            "codigo_pais" => "1058",
                            "nome_pais" => "BRASIL",
                            "telefone" => "{$telefone}"
                        ]
                    ],
                    "itens" => [],
                    "frete" => [
                        "modalidade_frete" => "0"
                    ],
                    "cobranca" => [
                        "fatura" => [
                            "numero" => $venda->venda_id,
                            "valor_original" => $venda->total_venda,
                            "valor_desconto" => "0.00",
                            "valor_liquido" => $venda->total_venda
                        ]
                    ],
                    "pagamento" => [
                        "formas_pagamento" => [
                            [
                                "meio_pagamento" => $venda->meio_pagamento,
                                "valor" => $venda->total_venda
                            ]
                        ]
                    ]
                ];

                $venda_itens = VendaItem::where('venda_id',  '=', $venda->venda_id)->orderBy('venda_item_id')->load();

                foreach ($venda_itens as $key => $venda_item) 
                {
                    $produto = Produto::find($venda_item->produto_id);

                    if ($produto) 
                    {
                        $item = [
                            "numero_item" => strval($key + 1),
                            "codigo_produto" => $produto->produto_id,
                            "descricao" => $produto->descricao,
                            "codigo_ncm" => $produto->ncm,
                            "cfop" => "5102",
                            "unidade_comercial" => $produto->unidade,
                            "quantidade_comercial" => $venda_item->quant,
                            "valor_unitario_comercial" => $venda_item->preco,
                            "valor_bruto" => $venda_item->total,
                            "unidade_tributavel" => $produto->unidade,
                            "quantidade_tributavel" => $venda_item->quant,
                            "valor_unitario_tributavel" => $venda_item->preco,
                            "origem" => $produto->origem,
                            "inclui_no_total" => "1",
                            "imposto" => [
                                "valor_aproximado_tributos" => 0,
                                "icms" => [
                                    "situacao_tributaria" => "102"
                                ],
                                "pis" => [
                                    "situacao_tributaria" => "49",
                                    "valor_base_calculo" => 0,
                                    "aliquota" => 0,
                                    "valor" => 0
                                ],
                                "cofins" => [
                                    "situacao_tributaria" => "49",
                                    "valor_base_calculo" => 0,
                                    "aliquota" => 0,
                                    "valor" => 0
                                ]
                            ],
                            "valor_desconto" => 0,
                            "valor_frete" => 0,
                            "valor_seguro" => 0,
                            "valor_outras_despesas" => 0,
                            "informacoes_adicionais_item" => "Valor aproximado tributos R$: 9,43 (4,20%) Fonte: IBPT"
                        ];
                        $data['itens'][] = $item;
                    }
                }

                $token = "eyJ0eXAiOiJKV1iOjQ1LCJ1c3IiOjE5LCJ0cCI6MiwiaWF0IjoxNTkyODI1MDkwfQ.SmZhXytS1jgYab4BoCOHglFutn-VobYd9693c4pE2Yk"; // pegar no gestão dentro do cadastro do emitente
                $ambiente = 2; // 1 - Produção; 2 - Homologação

                $response = $this->enviaAPI($ambiente, "nfe", "POST", $token, $data);

                if ($response->sucesso) 
                {
                    $pdf = base64_decode($response->pdf);

                    $file = "app/output/{$response->chave}.pdf";
                    file_put_contents($file, $pdf);

                    $chave = $response->chave;

                    $window = TWindow::create('PDF', 0.8, 0.8);
                    $object = new TElement('object');
                    $object->data  = $file;
                    $object->type  = 'application/pdf';
                    $object->style = "width: 100%; height:calc(100% - 10px)";

                    $window->add($object);
                    $window->show();

                } else if (in_array($response->codigo, [5001, 5002])) {
                    foreach ($response->erros as $erro) {
                        // ..
                    }
                } else if ($response->codigo == 5023) {
                    // lote em processamento
                    // implementar esta rota https://doc.cloud-dfe.com.br/v1/nfe/#!/1-3
                } else {
                    new TMessage('error', "HOUVE UM ERRO NA GERAÇÃO DA NFe :( $response->codigo - $response->mensagem");
                }

            }

            TTransaction::close();

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onNFCe($param = null) 
    {
        try 
        {

            TTransaction::open('banco');

            $venda = Venda::find($param['key']);

            if ($venda) {

                $cliente = Cliente::find($venda->cliente_id);
                if ($cliente) {
                   $nome = $cliente->nome;
                   $cpf_cnpj = $cliente->cpf_cnpj;
                   $inscricao = $cliente->inscricao;
                   $cep = $cliente->cep;
                   $logradouro = $cliente->logradouro;
                   $numero = $cliente->numero;
                   $complemento = $cliente->complemento;
                   $bairro = $cliente->bairro;
                   $nome_municipio = $cliente->nome_municipio;
                   $codigo_municipio = $cliente->codigo_municipio;
                   $indicador_ie  = $cliente->indicador_ie;
                   $telefone = $cliente->telefone;
                   $uf = $cliente->uf;
                }

                $data = [
                    "natureza_operacao" => "VENDA DENTRO DO ESTADO",
                    "serie" => "1",
                    "numero" => "102100",
                    "data_emissao" =>  date("Y-m-d\TH:i:sP"),
                    "tipo_operacao" => "1",
                    //"local_destino" => "1", 
                    "finalidade_emissao" => "1",
                    "consumidor_final" => "1",
                    "presenca_comprador" => "1",
                    "intermediario" => [
                        "indicador" => "0"
                    ],
                    "itens" => [],
                    "frete" => [
                        "modalidade_frete" => "9"
                    ],
                    "cobranca" => [
                        "fatura" => [
                            "numero" => $venda->venda_id,
                            "valor_original" => $venda->total_venda,
                            "valor_desconto" => "0.00",
                            "valor_liquido" => $venda->total_venda
                        ]
                    ],
                    "pagamento" => [
                        "formas_pagamento" => [
                            [
                                "meio_pagamento" => $venda->meio_pagamento,
                                "valor" => $venda->total_venda
                            ]
                        ]
                    ]
                ];

                $venda_itens = VendaItem::where('venda_id',  '=', $venda->venda_id)->orderBy('venda_item_id')->load();

                foreach ($venda_itens as $key => $venda_item) 
                {
                    $produto = Produto::find($venda_item->produto_id);
                    if ($produto) {

                        $item = [
                            "numero_item" => strval($key + 1),
                            "codigo_produto" => $produto->produto_id,
                            "descricao" => $produto->descricao,
                            "codigo_ncm" => $produto->ncm,
                            "cfop" => "5102",
                            "unidade_comercial" => $produto->unidade,
                            "quantidade_comercial" => $venda_item->quant,
                            "valor_unitario_comercial" => $venda_item->preco,
                            "valor_bruto" => $venda_item->total,
                            "unidade_tributavel" => $produto->unidade,
                            "quantidade_tributavel" => $venda_item->quant,
                            "valor_unitario_tributavel" => $venda_item->preco,
                            "origem" => $produto->origem,
                            "inclui_no_total" => "1",
                            "imposto" => [
                                "valor_aproximado_tributos" => 0,
                                "icms" => [
                                    "situacao_tributaria" => "102"
                                ],
                                "pis" => [
                                    "situacao_tributaria" => "49",
                                    "valor_base_calculo" => 0,
                                    "aliquota" => 0,
                                    "valor" => 0
                                ],
                                "cofins" => [
                                    "situacao_tributaria" => "49",
                                    "valor_base_calculo" => 0,
                                    "aliquota" => 0,
                                    "valor" => 0
                                ]
                            ],
                            "valor_desconto" => 0,
                            "valor_frete" => 0,
                            "valor_seguro" => 0,
                            "valor_outras_despesas" => 0,
                            "informacoes_adicionais_item" => "Valor aproximado tributos R$: 9,43 (4,20%) Fonte: IBPT"
                        ];
                        $data['itens'][] = $item;
                    }
                }

                $token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbXAiOjQ1LCJ1c3IiOjE5LCJ0cCI6MiwiaWF0IjoxNTkyODI1MDkwfQ.SmZhXytS1jgYab4BoCOHglFutn-VobYd9693c4pE2Yk"; // pegar no gestão dentro do cadastro do emitente
                $ambiente = 2; // 1 - Produção; 2 - Homologação

                $response = $this->enviaAPI($ambiente, "nfce", "POST", $token, $data);

                if ($response->sucesso) {

                    $pdf = base64_decode($response->pdf);

                    $file = "app/output/{$response->chave}.pdf";
                    file_put_contents($file, $pdf);

                    $window = TWindow::create('PDF', 0.8, 0.8);
                    $object = new TElement('object');
                    $object->data  = $file;
                    $object->type  = 'application/pdf';
                    $object->style = "width: 100%; height:calc(100% - 10px)";

                    $window->add($object);
                    $window->show();

                } else if (in_array($response->codigo, [5001, 5002])) {
                    foreach ($response->erros as $erro) {
                        // ..
                    }
                } else {
                    new TMessage('error', "HOUVE UM ERRO NA GERAÇÃO DA NFCe :( $response->codigo - $response->mensagem");
                }

            }

            TTransaction::close();

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }
    public function onCANCELAR($param = null) 
    {
        try 
        {
            $token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NQ1LCJ1c3IiOjE5LCJ0cCI6MiwiaWF0IjoxNTkyODI1MDkwfQ.SmZhXytS1jgYab4BoCOHglFutn-VobYd9693c4pE2Yk"; // pegar no gestão dentro do cadastro do emitente
            $ambiente = 2; // 1 - Produção; 2 - Homologação

            $data = [
                "chave" => "41210422545265000108550010001021011093346032",
                "justificativa" => "Teste de cancelamento de nfe"  
            ];

            $response = $this->enviaAPI($ambiente, "nfe/cancela", "POST", $token, $data);

            if ($response->sucesso) {

                $pdf = base64_decode($response->pdf);

                $file = "app/output/{$response->chave}.pdf";
                file_put_contents($file, $pdf);

                $window = TWindow::create('PDF', 0.8, 0.8);
                $object = new TElement('object');
                $object->data  = $file;
                $object->type  = 'application/pdf';
                $object->style = "width: 100%; height:calc(100% - 10px)";

                $window->add($object);
                $window->show();

            } else if (in_array($response->codigo, [5001, 5002])) {
                foreach ($response->erros as $erro) {
                    // ..
                }
            } else {
                new TMessage('error', "HOUVE UM ERRO NA GERAÇÃO DA NFe :( $response->codigo - $response->mensagem");
            }

            //</autoCode>
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    /**
     * Register the filter in the session
     */
    public function onSearch($param = null)
    {
        $data = $this->form->getData();
        $filters = [];

        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        if (isset($data->data_venda) AND ( (is_scalar($data->data_venda) AND $data->data_venda !== '') OR (is_array($data->data_venda) AND (!empty($data->data_venda)) )) )
        {

            $filters[] = new TFilter('data_venda', '=', $data->data_venda);// create the filter 
        }

        // fill the form with data again
        $this->form->setData($data);

        // keep the search data in the session
        TSession::setValue(__CLASS__.'_filter_data', $data);
        TSession::setValue(__CLASS__.'_filters', $filters);

        $this->onReload(['offset' => 0, 'first_page' => 1]);
    }

    /**
     * Load the datagrid with data
     */
    public function onReload($param = NULL)
    {
        try
        {
            // open a transaction with database 'banco'
            TTransaction::open(self::$database);

            // creates a repository for Venda
            $repository = new TRepository(self::$activeRecord);

            $criteria = clone $this->filter_criteria;

            if (empty($param['order']))
            {
                $param['order'] = 'venda_id';    
            }

            if (empty($param['direction']))
            {
                $param['direction'] = 'desc';
            }

            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $this->limit);

            if($filters = TSession::getValue(__CLASS__.'_filters'))
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            $this->datagrid->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {

                    $row = $this->datagrid->addItem($object);
                    $row->id = "row_{$object->venda_id}";

                }
            }

            // reset the criteria for record count
            $criteria->resetProperties();
            $count= $repository->count($criteria);

            $this->pageNavigation->setCount($count); // count of records
            $this->pageNavigation->setProperties($param); // order, page
            $this->pageNavigation->setLimit($this->limit); // limit

            // close the transaction
            TTransaction::close();
            $this->loaded = true;

            return $objects;
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

    /**
     * method show()
     * Shows the page
     */
    public function show()
    {
        // check if the datagrid is already loaded
        if (!$this->loaded AND (!isset($_GET['method']) OR !(in_array($_GET['method'],  $this->showMethods))) )
        {
            if (func_num_args() > 0)
            {
                $this->onReload( func_get_arg(0) );
            }
            else
            {
                $this->onReload();
            }
        }
        parent::show();
    }

    public static function manageRow($id, $param = [])
    {
        $list = new self($param);

        $openTransaction = TTransaction::getDatabase() != self::$database ? true : false;

        if($openTransaction)
        {
            TTransaction::open(self::$database);    
        }

        $object = new Venda($id);

        $row = $list->datagrid->addItem($object);
        $row->id = "row_{$object->venda_id}";

        if($openTransaction)
        {
            TTransaction::close();    
        }

        TDataGrid::replaceRowById(__CLASS__.'_datagrid', $row->id, $row);
    }

    private function enviaAPI($ambiente, $endpoint, $method, $token, $data)
    {
        $url = "https://hom.api.cloud-dfe.com.br/v1";
        if ($ambiente == 1) {
            $url = "https://api.cloud-dfe.com.br/v1";
        }

        $ch = curl_init("{$url}/{$endpoint}");
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_PORT, 443);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: {$token}",
            "Content-Type: application/json"
        ]);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $resp = curl_exec($ch);
        return json_decode($resp);
    }

    # COMPOSER: cloud-dfe/sdk-php
    # https://github.com/cloud-dfe/sdk-php

    public static function GerarNFCe($param = null)
    {
        $params = [
            'token' => 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI2x8qcu4Rtp2XNTOINqR-3c5V8iyI',
            'ambiente' => Nfce::AMBIENTE_HOMOLOGACAO,
            'options' => [
                'debug' => false,
                'timeout' => 60,
                'port' => 443,
                'http_version' => CURL_HTTP_VERSION_NONE
            ]
        ];

        $nfce = new Nfce($params);

        $payload = [
            "natureza_operacao" => "VENDA DENTRO DO ESTADO",
            "serie" => "1",
            "numero" => "101008",
            "data_emissao" => "2021-06-26T15:20:00-03:00",
            "tipo_operacao" => "1",
            "presenca_comprador" => "1",
            "itens" => [
                [
                    "numero_item" => "1",
                    "codigo_produto" => "000297",
                    "descricao" => "SAL GROSSO 50KGS",
                    "codigo_ncm" => "84159020",
                    "cfop" => "5102",
                    "unidade_comercial" => "SC",
                    "quantidade_comercial" => 10,
                    "valor_unitario_comercial" => "22.45",
                    "valor_bruto" => "224.50",
                    "unidade_tributavel" => "SC",
                    "quantidade_tributavel" => "10.00",
                    "valor_unitario_tributavel" => "22.45",
                    "origem" => "0",
                    "inclui_no_total" => "1",
                    "imposto" => [
                        "valor_total_tributos" => 9.43,
                        "icms" => [
                            "situacao_tributaria" => "102",
                            "aliquota_credito_simples" => "0",
                            "valor_credito_simples" => "0",
                            "modalidade_base_calculo" => "3",
                            "valor_base_calculo" => "0.00",
                            "modalidade_base_calculo_st" => "4",
                            "aliquota_reducao_base_calculo" => "0.00",
                            "aliquota" => "0.00",
                            "aliquota_final" => "0.00",
                            "valor" => "0.00",
                            "aliquota_margem_valor_adicionado_st" => "0.00",
                            "aliquota_reducao_base_calculo_st" => "0.00",
                            "valor_base_calculo_st" => "0.00",
                            "aliquota_st" => "0.00",
                            "valor_st" => "0.00"
                        ],
                        "fcp" => [
                            "aliquota" => "1.65"
                        ],
                        "pis" => [
                            "situacao_tributaria" => "01",
                            "valor_base_calculo" => 224.5,
                            "aliquota" => "1.65",
                            "valor" => "3.70"
                        ],
                        "cofins" => [
                            "situacao_tributaria" => "01",
                            "valor_base_calculo" => 224.5,
                            "aliquota" => "7.60",
                            "valor" => "17.06"
                        ]
                    ],
                    "valor_desconto" => 0,
                    "valor_frete" => 0,
                    "valor_seguro" => 0,
                    "valor_outras_despesas" => 0,
                    "informacoes_adicionais_item" => ""
                ]
            ],
            "frete" => [
                "modalidade_frete" => "9"
            ],
            "pagamento" => [
                "formas_pagamento" => [
                    [
                        "meio_pagamento" => "01",
                        "valor" => "224.50"
                    ]
                ]
            ],
            "informacoes_adicionais_contribuinte" => "",
            "pessoas_autorizadas" => [
                [
                    "cnpj" => "96256273000170"
                ], [
                    "cnpj" => "80681257000195"
                ]
            ]
        ];

        $resp = $nfce->cria($payload);

        var_dump($resp);
    }

    public static function GerarNFe($param = null) 
     {
         try 
         {
             TTransaction::open(self::$database);

             $RazaoSocial        = $param['razaosocial'];
             $cpf_cnpj           = $param['documento'];
             $inscricao          = $param['inscricao_estadual'];
             $dest_cep           = $param['dest_cep'];
             $logradouro         = $param['logradouro'];
             $numero             = $param['numero'];
             $complemento        = $param['complemento'];
             $bairro             = $param['bairro'];
             $municipio          = $param['municipio'];
             $dest_cod_municipio = $param['dest_cod_municipio'];
             $uf                 = $param['uf'];
             $telefone           = $param['telefone_dest'];
             $email              = $param['email_dest'];
             $natureza           = $param['natureza_operacao'];
             $nnota              = $param['nnota'];
             $nserie             = $param['nserie'];
             $data_emissao       = $param['data_emissao'];
             $valor_total        = $param['valor_total'];

             # CALCULA TOTAL 
             $totalconstante       = $valor_total;
             $valor_base_stcalculo = $totalconstante;
             $valor_st_total       = ($valor_total) + ($valor_base_stcalculo);

             $total_definitivo   = $valor_st_total;

             $params = [
                'token' => 'SEU TOKEN',
                'ambiente' => Nfe::AMBIENTE_HOMOLOGACAO,
                'options' => [
                    'debug' => false,
                    'timeout' => 60,
                    'port' => 443,
                    'http_version' => CURL_HTTP_VERSION_NONE,
                    'contingencia' => false
                 ]
              ];

              $nfe = new Nfe($params);
              $payload = [
              "natureza_operacao" => "{$natureza}",
              "serie" => "{$nserie}",
              "numero" => "{$nnota}",
              "data_emissao" =>  date("Y-m-d\TH:i:sP", strtotime($data_emissao)),
              "data_entrada_saida" => date("Y-m-d\TH:i:sP", strtotime($data_emissao)),
              "tipo_operacao" => "1",
              "finalidade_emissao" => "1",
              "consumidor_final" => "0",
              "presenca_comprador" => "0",
              "intermediario" => [
                  "indicador" => "0"
              ],
              "destinatario" => [
                  "cnpj" => "{$cpf_cnpj}",
                  "nome" => "{$RazaoSocial}",
                  "indicador_inscricao_estadual" => "1",
                  "inscricao_estadual" => "{$inscricao}",
                  "email" => "{$email}",
                  "endereco" => [
                      "logradouro" => "{$logradouro}",
                      "numero" => "{$numero}",
                      "bairro" => "{$bairro}",
                      "codigo_municipio" => "{$dest_cod_municipio}",
                      "nome_municipio" => "{$municipio}",
                      "uf" => "{$uf}",
                      "cep" => "{$dest_cep}",
                      "codigo_pais" => "1058",
                      "nome_pais" => "BRASIL",
                      "telefone" => "{$telefone}"
                  ]
              ],

              "itens" => [],
              "frete" => [
                  "modalidade_frete" => "1"
              ],
              "cobranca" => [
                  "fatura" => [
                      "numero" => "0",
                      "valor_original" =>$total_definitivo,
                      "valor_desconto" => "0.00",
                      "valor_liquido" => $total_definitivo
                  ]
              ],
              "pagamento" => [
                  "formas_pagamento" => [
                      [
                          "meio_pagamento" => "90",
                          "valor" => "0"
                      ]
                  ]
              ]
             ];

             if(!empty($param['item_nota_fiscal_list___row__data']))
             {
                 $rowId = $param['nota_fiscal_item_nota_fiscal__row__id'];

                 $linhas = 1;

                 foreach($param['item_nota_fiscal_list___row__data'] as $rowDataCoded)
                 {
                     $rowDataDecoded = unserialize(base64_decode($rowDataCoded));    

                     $produto_id = (int) $rowDataDecoded->produto_id;

                     $produto = Produto::find($produto_id);

                     if ($produto)
                     {
                         $codigo_produto = $produto->id;
                         $descricao      = $produto->nome;
                         $codigo_ncm     = $produto->ncm;
                         $codigo_cfop    = $produto->cfop;
                         $situacao_icms  = $produto->situacao_icms_id;
                         $situacao_pis   = $produto->situacao_pis_id;
                         $situacao_cofins  = $produto->situacao_cofins_id;
                         $origem         = $produto->origem_id;
                         $Informacao_Adicional = $produto->info_adicional;
                         $unidade        = UnidadeMedida::find($produto->unidade_medida_id)->sigla;
                         $quantidade_comercial = $rowDataDecoded->quantidade;
                         $valor_unitario_comercial = $rowDataDecoded->valor;
                         $desconto_produto = $rowDataDecoded->desconto;
                         $rowDataDecoded->valor_total;
                         $Valor_Total =  $rowDataDecoded->valor_total;

                         # ICMS
                         $situacao_icms       = $produto->situacao_icms_id;
                         $base_icms              = $Valor_Total;
                         $aliquota_icms       = $produto->aicms;
                         $calculo_valor_icms  =  ($base_icms) * ($aliquota_icms);
                         $valor_icms      =  $calculo_valor_icms / 100;

                         # PIS
                         $situacao_pis       = $produto->situacao_pis_id;
                         $base_pis              = $Valor_Total;
                         $aliquota_pis       = $produto->apis;
                         $calculo_valor_pis  = ($base_pis) * ($aliquota_pis);
                         $valor_pis      = $calculo_valor_pis / 100;

                         # COFINS
                         $situacao_cofins       = $produto->situacao_cofins_id;
                         $base_cofins              = $Valor_Total;
                         $aliquota_cofins       = $produto->acofins;
                         $calculo_valor_cofins   = ($base_cofins) * ($aliquota_cofins);
                         $valor_cofins      = $calculo_valor_cofins / 100;

                         # ICMS ST
                         $aliquota_st             = "18";
                         $margemmva               = ($Valor_Total * 0.7178);
                         $valor_base_calculo_st   = $Valor_Total + $margemmva;
                         $valor_st                = ($margemmva * $aliquota_st ) / 100;

                         # FCP
                         $base_fcp             = $Valor_Total;
                         $base_fcp_st            = $valor_base_calculo_st;
                         $aliquota_fcp       = "2";
                         $calculo_valor_fcp   = ($base_fcp) * ($aliquota_fcp);
                         $calculo_valor_fcp_st = ($base_fcp_st) * ($aliquota_fcp);
                         $valor_fcp      = $calculo_valor_fcp / 100;
                         $valor_fcp_st   =  ($margemmva * $aliquota_fcp) / 100;

                         $item = [
                             "numero_item" => "{$linhas}",
                             "codigo_produto" => $codigo_produto,
                             "descricao" => $descricao,
                             "codigo_ncm" => $codigo_ncm,
                             "cfop" => "5403",
                             "unidade_comercial" => $unidade,
                             "quantidade_comercial" => $quantidade_comercial,
                             "valor_unitario_comercial" => $valor_unitario_comercial,
                             "valor_bruto" => ($valor_unitario_comercial) * ($quantidade_comercial),
                             "origem" => $origem,
                             "inclui_no_total" => "1",
                             "imposto" => [
                                 "valor_aproximado_tributos" => 0,
                                 "icms" => [
                                         "situacao_tributaria" => "10",
                                         "aliquota_credito_simples" => 0,
                                         "valor_credito_simples" => 0,
                                         "modalidade_base_calculo" => "3",
                                         "valor_base_calculo" => $base_icms,
                                         "modalidade_base_calculo_st" => "4",
                                         "aliquota_reducao_base_calculo" => 0,
                                         "aliquota" => $aliquota_icms,
                                         "aliquota_final" => 0,
                                         "valor" => number_format($valor_icms, "2",".", ","),
                                         "aliquota_margem_valor_adicionado_st" => 0,
                                         "aliquota_reducao_base_calculo_st" => 0,
                                         "valor_base_calculo_st" => $valor_base_calculo_st,
                                         "aliquota_st" => $aliquota_st,
                                         "valor_st" => number_format($valor_st, "2",".", ",")
                                     ],
                                     "fcp" => [
                                         "valor_base_calculo" => $base_fcp,
                                         "aliquota" => $aliquota_fcp,
                                         "valor" => number_format($valor_fcp, "2",".", ","),
                                         "valor_base_calculo_st" => $base_fcp_st,
                                         "aliquota_st" => $aliquota_fcp,
                                         "valor_st" => number_format($valor_fcp_st, "2",".", ",")
                                     ],
                                     "pis" => [
                                         "situacao_tributaria" => "01",
                                         "valor_base_calculo" => $base_pis,
                                         "aliquota" => $aliquota_pis,
                                         "valor" => $valor_pis
                                     ],
                                     "cofins" => [
                                         "situacao_tributaria" => "01",
                                         "valor_base_calculo" => $base_cofins,
                                         "aliquota" => $aliquota_cofins,
                                         "valor" => $valor_cofins
                                 ]
                             ],
                             "valor_desconto" => $desconto_produto,
                             "valor_frete" => "0",
                             "valor_seguro" => 0,
                             "valor_outras_despesas" => 0,
                             "informacoes_adicionais_item" => $Informacao_Adicional
                         ];

                         $payload['itens'][] = $item;
                     }
                     $linhas++;
                 }

             }
                 $resp = $nfe->cria($payload);

                 if ($resp->sucesso) {

                     $object = new stdClass();
                     $object->chave = $resp->chave;

                     TForm::sendData(self::$formName, $object);

                     $pdf = base64_decode($resp->pdf);

                     $file = "app/output/nfe_{$resp->chave}.pdf";
                     file_put_contents($file, $pdf);

                     $window = TWindow::create('PDF', 0.8, 0.8);
                     $object = new TElement('object');
                     $object->data  = $file;
                     $object->type  = 'application/pdf';
                     $object->style = "width: 100%; height:calc(100% - 10px)";

                     $window->add($object);
                     $window->show();

                     if ($resp->codigo == 5023) 
                     {
                         sleep(5);
                         $tentativa = 1;
                         while ($tentativa <= 5) {
                             $payload = [
                                 'chave' => $chave
                             ];
                             $resp = $nfe->consulta($payload);
                             if ($resp->codigo != 5023) {
                                 if ($resp->sucesso) {
                                     var_dump($resp);
                                     break;
                                 } else {
                                     var_dump($resp);
                                     break;
                                 }
                             }
                             sleep(5);
                             $tentativa++;
                         }
                     }

                 } else if (in_array($resp->codigo, [5001, 5002])) {

                 } else if ($resp->codigo == 5008 or $resp->codigo >= 7000) {
                     $chave = $resp->chave;

                     var_dump($resp);
                     $payload = [
                         'chave' => $chave
                     ];
                     $resp = $nfe->consulta($payload);
                     if ($resp->sucesso) {

                     $pdf = base64_decode($resp->pdf);

                     $file = "app/output/nota_{$resp->chave}.pdf";
                     file_put_contents($file, $pdf);

                     $window = TWindow::create('PDF', 0.8, 0.8);
                     $object = new TElement('object');
                     $object->data  = $file;
                     $object->type  = 'application/pdf';
                     $object->style = "width: 100%; height:calc(100% - 10px)";

                     $window->add($object);
                     $window->show();
                     } 
                 } 

             TTransaction::close();
        } 

                catch (Exception $e) // in case of exception
        {

        }
    }

}

