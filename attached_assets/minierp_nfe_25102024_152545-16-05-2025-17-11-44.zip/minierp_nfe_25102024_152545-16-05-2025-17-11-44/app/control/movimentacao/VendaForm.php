<?php

class VendaForm extends TPage
{
    protected BootstrapFormBuilder $form;
    private $formFields = [];
    private static $database = 'banco';
    private static $activeRecord = 'Venda';
    private static $primaryKey = 'venda_id';
    private static $formName = 'form_Venda';

    use BuilderMasterDetailTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("LANÇAMENTO | VENDA");

        $criteria_cliente_id = new TCriteria();
        $criteria_venda_item_venda_produto_id = new TCriteria();

        $venda_id = new TEntry('venda_id');
        $data_venda = new TDateTime('data_venda');
        $cliente_id = new TDBCombo('cliente_id', 'banco', 'Cliente', 'cliente_id', '{nome}','nome asc' , $criteria_cliente_id );
        $meio_pagamento = new TCombo('meio_pagamento');
        $venda_item_venda_produto_id = new TDBCombo('venda_item_venda_produto_id', 'banco', 'Produto', 'produto_id', '{descricao}','descricao asc' , $criteria_venda_item_venda_produto_id );
        $venda_item_venda_venda_item_id = new THidden('venda_item_venda_venda_item_id');
        $venda_item_venda_preco = new TNumeric('venda_item_venda_preco', '2', ',', '.' );
        $venda_item_venda_quant = new TEntry('venda_item_venda_quant');
        $venda_item_venda_total = new TNumeric('venda_item_venda_total', '2', ',', '.' );
        $button_adicionar_item_venda_item_venda = new TButton('button_adicionar_item_venda_item_venda');

        $venda_item_venda_produto_id->setChangeAction(new TAction([$this,'onSAIR']));

        $cliente_id->addValidation("Cliente id", new TRequiredValidator()); 

        $venda_id->setEditable(false);
        $data_venda->setMask('dd/mm/yyyy hh:ii');
        $data_venda->setValue(date('d/m/Y H:i:s'));
        $data_venda->setDatabaseMask('yyyy-mm-dd hh:ii');
        $meio_pagamento->addItems(["01"=>"DINHEIRO","02"=>"CHEQUE","03"=>"CARTÃO DE CRÉDITO","04"=>"CARTÃO DE DÉBITO"]);
        $button_adicionar_item_venda_item_venda->setAction(new TAction([$this, 'onAddDetailVendaItemVenda'],['static' => 1]), "ADICIONAR ITEM");
        $button_adicionar_item_venda_item_venda->addStyleClass('btn-default');
        $button_adicionar_item_venda_item_venda->setImage('fas:plus #000000');
        $venda_id->setSize('100%');
        $data_venda->setSize('100%');
        $cliente_id->setSize('100%');
        $meio_pagamento->setSize('100%');
        $venda_item_venda_preco->setSize('100%');
        $venda_item_venda_quant->setSize('100%');
        $venda_item_venda_total->setSize('100%');
        $venda_item_venda_produto_id->setSize('100%');
        $venda_item_venda_venda_item_id->setSize(200);

        $button_adicionar_item_venda_item_venda->id = '607ad6dd684b9';

        $row1 = $this->form->addFields([new TLabel("N° VENDA", null, '14px', null, '100%'),$venda_id],[new TLabel("DATA", null, '14px', null, '100%'),$data_venda],[new TLabel("CLIENTE", '#000000', '14px', null, '100%'),$cliente_id],[new TLabel("FORMA DE PAGAMENTO", null, '14px', null, '100%'),$meio_pagamento]);
        $row1->layout = [' col-sm-1','col-sm-2',' col-sm-5',' col-sm-4'];

        $row2 = $this->form->addFields([new TLabel("ITEM DA VENDA", null, '14px', 'B')]);
        $row2->layout = ['col-sm-6'];

        $this->detailFormVendaItemVenda = new BootstrapFormBuilder('detailFormVendaItemVenda');
        $this->detailFormVendaItemVenda->setProperty('style', 'border:none; box-shadow:none; width:100%;');

        $this->detailFormVendaItemVenda->setProperty('class', 'form-horizontal builder-detail-form');

        $row3 = $this->detailFormVendaItemVenda->addFields([new TLabel("PRODUTO:", '#000000', '14px', null, '100%'),$venda_item_venda_produto_id,$venda_item_venda_venda_item_id],[new TLabel("PREÇO R$", null, '14px', null, '100%'),$venda_item_venda_preco],[new TLabel("QUANT", null, '14px', null, '100%'),$venda_item_venda_quant],[new TLabel("TOTAL R$", null, '14px', null, '100%'),$venda_item_venda_total]);
        $row3->layout = [' col-sm-7',' col-sm-2',' col-sm-1','col-sm-2'];

        $row4 = $this->detailFormVendaItemVenda->addFields([$button_adicionar_item_venda_item_venda]);
        $row4->layout = [' col-sm-12'];

        $row5 = $this->detailFormVendaItemVenda->addFields([new THidden('venda_item_venda__row__id')]);
        $this->venda_item_venda_criteria = new TCriteria();

        $this->venda_item_venda_list = new BootstrapDatagridWrapper(new TDataGrid);
        $this->venda_item_venda_list->generateHiddenFields();
        $this->venda_item_venda_list->setId('venda_item_venda_list');

        $this->venda_item_venda_list->style = 'width:100%';
        $this->venda_item_venda_list->class .= ' table-bordered';

        $column_venda_item_venda_produto_descricao = new TDataGridColumn('produto->descricao', "PRODUTO", 'left' , '350px');
        $column_venda_item_venda_preco = new TDataGridColumn('preco', "PREÇO R$", 'left' , '90px');
        $column_venda_item_venda_quant = new TDataGridColumn('quant', "QUANT", 'left' , '960px');
        $column_calculated_1 = new TDataGridColumn('=( {preco} * {quant}  )', "TOTAL R$", 'left' , '970px');

        $column_venda_item_venda__row__data = new TDataGridColumn('__row__data', '', 'center');
        $column_venda_item_venda__row__data->setVisibility(false);

        $action_onEditDetailVendaItem = new TDataGridAction(array('VendaForm', 'onEditDetailVendaItem'));
        $action_onEditDetailVendaItem->setUseButton(false);
        $action_onEditDetailVendaItem->setButtonClass('btn btn-default btn-sm');
        $action_onEditDetailVendaItem->setLabel("Editar");
        $action_onEditDetailVendaItem->setImage('far:edit #000000');
        $action_onEditDetailVendaItem->setFields(['__row__id', '__row__data']);

        $this->venda_item_venda_list->addAction($action_onEditDetailVendaItem);
        $action_onDeleteDetailVendaItem = new TDataGridAction(array('VendaForm', 'onDeleteDetailVendaItem'));
        $action_onDeleteDetailVendaItem->setUseButton(false);
        $action_onDeleteDetailVendaItem->setButtonClass('btn btn-default btn-sm');
        $action_onDeleteDetailVendaItem->setLabel("Excluir");
        $action_onDeleteDetailVendaItem->setImage('fas:trash-alt #dd5a43');
        $action_onDeleteDetailVendaItem->setFields(['__row__id', '__row__data']);

        $this->venda_item_venda_list->addAction($action_onDeleteDetailVendaItem);

        $this->venda_item_venda_list->addColumn($column_venda_item_venda_produto_descricao);
        $this->venda_item_venda_list->addColumn($column_venda_item_venda_preco);
        $this->venda_item_venda_list->addColumn($column_venda_item_venda_quant);
        $this->venda_item_venda_list->addColumn($column_calculated_1);

        $this->venda_item_venda_list->addColumn($column_venda_item_venda__row__data);

        $this->venda_item_venda_list->createModel();
        $this->detailFormVendaItemVenda->addContent([$this->venda_item_venda_list]);
        $row6 = $this->form->addFields([$this->detailFormVendaItemVenda]);
        $row6->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("FINALIZA VENDA", new TAction([$this, 'onSave'],['static' => 1]), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-danger'); 

        $btn_onshow = $this->form->addAction("VOLTAR", new TAction(['VendasList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        if(empty($param['target_container']))
        {
            $container->add(TBreadCrumb::create(["Movimentação","Cadastro de venda"]));
        }
        $container->add($this->form);

        parent::add($container);

    }

    public static function onSAIR($param = null) 
    {
        try 
        {

            TTransaction::open(self::$database);

            $produto = Produto::find($param['key']);
            if ($produto) {
                $object = new stdClass();
                $object->venda_item_venda_preco = $produto->valor_venda;
                $object->venda_item_venda_quant = 1; 
                $object->venda_item_venda_total = $produto->valor_venda;

                TForm::sendData(self::$formName, $object);

            }

            TTransaction::close();

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public  function onAddDetailVendaItemVenda($param = null) 
    {
        try
        {
            $data = $this->form->getData();

            $errors = [];
            $requiredFields = [];
            $requiredFields[] = ['label'=>"Produto id", 'name'=>"venda_item_venda_produto_id", 'class'=>'TRequiredValidator', 'value'=>[]];
            foreach($requiredFields as $requiredField)
            {
                try
                {
                    (new $requiredField['class'])->validate($requiredField['label'], $data->{$requiredField['name']}, $requiredField['value']);
                }
                catch(Exception $e)
                {
                    $errors[] = $e->getMessage() . '.';
                }
             }
             if(count($errors) > 0)
             {
                 throw new Exception(implode('<br>', $errors));
             }

            $__row__id = !empty($data->venda_item_venda__row__id) ? $data->venda_item_venda__row__id : 'b'.uniqid();

            TTransaction::open(self::$database);

            $grid_data = new VendaItem();
            $grid_data->__row__id = $__row__id;
            $grid_data->produto_id = $data->venda_item_venda_produto_id;
            $grid_data->venda_item_id = $data->venda_item_venda_venda_item_id;
            $grid_data->preco = $data->venda_item_venda_preco;
            $grid_data->quant = $data->venda_item_venda_quant;
            $grid_data->total = $data->venda_item_venda_total;

            $__row__data = array_merge($grid_data->toArray(), (array)$grid_data->getVirtualData());
            $__row__data['__row__id'] = $__row__id;
            $__row__data['__display__']['produto_id'] =  $param['venda_item_venda_produto_id'] ?? null;
            $__row__data['__display__']['venda_item_id'] =  $param['venda_item_venda_venda_item_id'] ?? null;
            $__row__data['__display__']['preco'] =  $param['venda_item_venda_preco'] ?? null;
            $__row__data['__display__']['quant'] =  $param['venda_item_venda_quant'] ?? null;
            $__row__data['__display__']['total'] =  $param['venda_item_venda_total'] ?? null;

            $grid_data->__row__data = base64_encode(serialize((object)$__row__data));
            $row = $this->venda_item_venda_list->addItem($grid_data);
            $row->id = $grid_data->__row__id;

            TDataGrid::replaceRowById('venda_item_venda_list', $grid_data->__row__id, $row);

            TTransaction::close();

            $data = new stdClass;
            $data->venda_item_venda_produto_id = '';
            $data->venda_item_venda_venda_item_id = '';
            $data->venda_item_venda_preco = '';
            $data->venda_item_venda_quant = '';
            $data->venda_item_venda_total = '';
            $data->venda_item_venda__row__id = '';

            TForm::sendData(self::$formName, $data);
            TScript::create("
               var element = $('#607ad6dd684b9');
               if(typeof element.attr('add') != 'undefined')
               {
                   element.html(base64_decode(element.attr('add')));
               }
            ");

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }

    public static function onEditDetailVendaItem($param = null) 
    {
        try
        {

            $__row__data = unserialize(base64_decode($param['__row__data']));
            $__row__data->__display__ = is_array($__row__data->__display__) ? (object) $__row__data->__display__ : $__row__data->__display__;
            $fireEvents = true;
            $aggregate = false;

            $data = new stdClass;
            $data->venda_item_venda_produto_id = $__row__data->__display__->produto_id ?? null;
            $data->venda_item_venda_venda_item_id = $__row__data->__display__->venda_item_id ?? null;
            $data->venda_item_venda_preco = $__row__data->__display__->preco ?? null;
            $data->venda_item_venda_quant = $__row__data->__display__->quant ?? null;
            $data->venda_item_venda_total = $__row__data->__display__->total ?? null;
            $data->venda_item_venda__row__id = $__row__data->__row__id;

            TForm::sendData(self::$formName, $data, $aggregate, $fireEvents);
            TScript::create("
               var element = $('#607ad6dd684b9');
               if(!element.attr('add')){
                   element.attr('add', base64_encode(element.html()));
               }
               element.html(\"<span><i class='far fa-edit' style='color:#478fca;padding-right:4px;'></i>Editar</span>\");
               if(!element.attr('edit')){
                   element.attr('edit', base64_encode(element.html()));
               }
            ");

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }
    public static function onDeleteDetailVendaItem($param = null) 
    {
        try
        {

            $__row__data = unserialize(base64_decode($param['__row__data']));

            $data = new stdClass;
            $data->venda_item_venda_produto_id = '';
            $data->venda_item_venda_venda_item_id = '';
            $data->venda_item_venda_preco = '';
            $data->venda_item_venda_quant = '';
            $data->venda_item_venda_total = '';
            $data->venda_item_venda__row__id = '';

            TForm::sendData(self::$formName, $data);

            TDataGrid::removeRowById('venda_item_venda_list', $__row__data->__row__id);
            TScript::create("
               var element = $('#607ad6dd684b9');
               if(typeof element.attr('add') != 'undefined')
               {
                   element.html(base64_decode(element.attr('add')));
               }
            ");

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
        }
    }
    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Venda(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            TForm::sendData(self::$formName, (object)['venda_id' => $object->venda_id]);

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            $venda_item_venda_items = $this->storeMasterDetailItems('VendaItem', 'venda_id', 'venda_item_venda', $object, $param['venda_item_venda_list___row__data'] ?? [], $this->form, $this->venda_item_venda_list, function($masterObject, $detailObject){ 

                //code here

            }, $this->venda_item_venda_criteria); 

            // get the generated {PRIMARY_KEY}
            $data->venda_id = $object->venda_id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "VENDA REALIZADA COM SUCESSO", 'topRight', 'far:check-circle');
            TApplication::loadPage('VendasList', 'onShow', $loadPageParam); 

        }
        catch (Exception $e) // in case of exception
        {

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Venda($key); // instantiates the Active Record 

                $venda_item_venda_items = $this->loadMasterDetailItems('VendaItem', 'venda_id', 'venda_item_venda', $object, $this->form, $this->venda_item_venda_list, $this->venda_item_venda_criteria, function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }); 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public static function getFormName()
    {
        return self::$formName;
    }

}

