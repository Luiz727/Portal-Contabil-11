CREATE TABLE cliente( 
      cliente_id  INT IDENTITY    NOT NULL  , 
      nome varchar  (50)   , 
      cpf_cnpj varchar  (14)   , 
      inscricao_estadual varchar  (15)   , 
      cep varchar  (9)   , 
      logradouro varchar  (50)   , 
      numero varchar  (10)   , 
      complemento varchar  (20)   , 
      bairro varchar  (50)   , 
      nome_municipio varchar  (50)   , 
      codigo_municipio varchar  (10)   , 
      indicador_ie int   , 
      telefone varchar  (15)   , 
      uf char  (2)   , 
 PRIMARY KEY (cliente_id)) ; 

CREATE TABLE produto( 
      produto_id  INT IDENTITY    NOT NULL  , 
      descricao varchar  (100)   , 
      valor_venda float   , 
      unidade varchar  (6)   , 
      ncm varchar  (10)   , 
      origem int   , 
      cest varchar  (8)   , 
 PRIMARY KEY (produto_id)) ; 

CREATE TABLE venda( 
      venda_id  INT IDENTITY    NOT NULL  , 
      cliente_id int   NOT NULL  , 
      data_venda datetime2   , 
      meio_pagamento char  (2)   , 
      total_venda float   , 
 PRIMARY KEY (venda_id)) ; 

CREATE TABLE venda_item( 
      venda_item_id  INT IDENTITY    NOT NULL  , 
      produto_id int   NOT NULL  , 
      preco float   , 
      quant int   , 
      total float   , 
      venda_id int   NOT NULL  , 
 PRIMARY KEY (venda_item_id)) ; 

 
  
 ALTER TABLE venda ADD CONSTRAINT fk_venda_1 FOREIGN KEY (cliente_id) references cliente(cliente_id); 
ALTER TABLE venda_item ADD CONSTRAINT fk_venda_item_1 FOREIGN KEY (produto_id) references produto(produto_id); 
ALTER TABLE venda_item ADD CONSTRAINT fk_venda_item_2 FOREIGN KEY (venda_id) references venda(venda_id); 
