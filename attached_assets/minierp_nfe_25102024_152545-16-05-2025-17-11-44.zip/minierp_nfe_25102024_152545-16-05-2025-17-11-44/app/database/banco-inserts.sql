INSERT INTO cliente (cliente_id,nome,cpf_cnpj,inscricao_estadual,cep,logradouro,numero,complemento,bairro,nome_municipio,codigo_municipio,indicador_ie,telefone,uf) VALUES (1,'TESTE','01234567890','','85602400','TESTE','1','TESTE','TESTE','TESTE','4108403',9,'','PR'); 

INSERT INTO produto (produto_id,descricao,valor_venda,unidade,ncm,origem,cest) VALUES (1,'TESTE',10,'un','84159020',0,''); 

INSERT INTO venda (venda_id,cliente_id,data_venda,meio_pagamento,total_venda) VALUES (1,1,'2021-04-17 11:30:00','01',20); 

INSERT INTO venda_item (venda_item_id,produto_id,preco,quant,total,venda_id) VALUES (1,1,10,1,10,1); 

INSERT INTO venda_item (venda_item_id,produto_id,preco,quant,total,venda_id) VALUES (2,1,10,1,10,1); 
