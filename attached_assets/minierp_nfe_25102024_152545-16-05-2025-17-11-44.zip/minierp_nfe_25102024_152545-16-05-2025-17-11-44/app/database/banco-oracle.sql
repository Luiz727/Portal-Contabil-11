CREATE TABLE cliente( 
      cliente_id number(10)    NOT NULL , 
      nome varchar  (50)   , 
      cpf_cnpj varchar  (14)   , 
      inscricao_estadual varchar  (15)   , 
      cep varchar  (9)   , 
      logradouro varchar  (50)   , 
      numero varchar  (10)   , 
      complemento varchar  (20)   , 
      bairro varchar  (50)   , 
      nome_municipio varchar  (50)   , 
      codigo_municipio varchar  (10)   , 
      indicador_ie number(10)   , 
      telefone varchar  (15)   , 
      uf char  (2)   , 
 PRIMARY KEY (cliente_id)) ; 

CREATE TABLE produto( 
      produto_id number(10)    NOT NULL , 
      descricao varchar  (100)   , 
      valor_venda binary_double   , 
      unidade varchar  (6)   , 
      ncm varchar  (10)   , 
      origem number(10)   , 
      cest varchar  (8)   , 
 PRIMARY KEY (produto_id)) ; 

CREATE TABLE venda( 
      venda_id number(10)    NOT NULL , 
      cliente_id number(10)    NOT NULL , 
      data_venda timestamp(0)   , 
      meio_pagamento char  (2)   , 
      total_venda binary_double   , 
 PRIMARY KEY (venda_id)) ; 

CREATE TABLE venda_item( 
      venda_item_id number(10)    NOT NULL , 
      produto_id number(10)    NOT NULL , 
      preco binary_double   , 
      quant number(10)   , 
      total binary_double   , 
      venda_id number(10)    NOT NULL , 
 PRIMARY KEY (venda_item_id)) ; 

 
  
 ALTER TABLE venda ADD CONSTRAINT fk_venda_1 FOREIGN KEY (cliente_id) references cliente(cliente_id); 
ALTER TABLE venda_item ADD CONSTRAINT fk_venda_item_1 FOREIGN KEY (produto_id) references produto(produto_id); 
ALTER TABLE venda_item ADD CONSTRAINT fk_venda_item_2 FOREIGN KEY (venda_id) references venda(venda_id); 
 CREATE SEQUENCE cliente_cliente_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER cliente_cliente_id_seq_tr 

BEFORE INSERT ON cliente FOR EACH ROW 

    WHEN 

        (NEW.cliente_id IS NULL) 

    BEGIN 

        SELECT cliente_cliente_id_seq.NEXTVAL INTO :NEW.cliente_id FROM DUAL; 

END;
CREATE SEQUENCE produto_produto_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER produto_produto_id_seq_tr 

BEFORE INSERT ON produto FOR EACH ROW 

    WHEN 

        (NEW.produto_id IS NULL) 

    BEGIN 

        SELECT produto_produto_id_seq.NEXTVAL INTO :NEW.produto_id FROM DUAL; 

END;
CREATE SEQUENCE venda_venda_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER venda_venda_id_seq_tr 

BEFORE INSERT ON venda FOR EACH ROW 

    WHEN 

        (NEW.venda_id IS NULL) 

    BEGIN 

        SELECT venda_venda_id_seq.NEXTVAL INTO :NEW.venda_id FROM DUAL; 

END;
CREATE SEQUENCE venda_item_venda_item_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER venda_item_venda_item_id_seq_tr 

BEFORE INSERT ON venda_item FOR EACH ROW 

    WHEN 

        (NEW.venda_item_id IS NULL) 

    BEGIN 

        SELECT venda_item_venda_item_id_seq.NEXTVAL INTO :NEW.venda_item_id FROM DUAL; 

END;
 