SELECT setval('cliente_cliente_id_seq', coalesce(max(cliente_id),0) + 1, false) FROM cliente;
SELECT setval('produto_produto_id_seq', coalesce(max(produto_id),0) + 1, false) FROM produto;
SELECT setval('venda_venda_id_seq', coalesce(max(venda_id),0) + 1, false) FROM venda;
SELECT setval('venda_item_venda_item_id_seq', coalesce(max(venda_item_id),0) + 1, false) FROM venda_item;