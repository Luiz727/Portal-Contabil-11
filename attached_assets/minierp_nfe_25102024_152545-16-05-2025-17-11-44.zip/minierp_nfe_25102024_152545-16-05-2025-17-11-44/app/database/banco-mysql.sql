CREATE TABLE cliente( 
      `cliente_id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `nome` varchar  (50)   , 
      `cpf_cnpj` varchar  (14)   , 
      `inscricao_estadual` varchar  (15)   , 
      `cep` varchar  (9)   , 
      `logradouro` varchar  (50)   , 
      `numero` varchar  (10)   , 
      `complemento` varchar  (20)   , 
      `bairro` varchar  (50)   , 
      `nome_municipio` varchar  (50)   , 
      `codigo_municipio` varchar  (10)   , 
      `indicador_ie` int   , 
      `telefone` varchar  (15)   , 
      `uf` char  (2)   , 
 PRIMARY KEY (cliente_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE produto( 
      `produto_id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `descricao` varchar  (100)   , 
      `valor_venda` double   , 
      `unidade` varchar  (6)   , 
      `ncm` varchar  (10)   , 
      `origem` int   , 
      `cest` varchar  (8)   , 
 PRIMARY KEY (produto_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE venda( 
      `venda_id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `cliente_id` int   NOT NULL  , 
      `data_venda` datetime   , 
      `meio_pagamento` char  (2)   , 
      `total_venda` double   , 
 PRIMARY KEY (venda_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

CREATE TABLE venda_item( 
      `venda_item_id`  INT  AUTO_INCREMENT    NOT NULL  , 
      `produto_id` int   NOT NULL  , 
      `preco` double   , 
      `quant` int   , 
      `total` double   , 
      `venda_id` int   NOT NULL  , 
 PRIMARY KEY (venda_item_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

 
  
 ALTER TABLE venda ADD CONSTRAINT fk_venda_1 FOREIGN KEY (cliente_id) references cliente(cliente_id); 
ALTER TABLE venda_item ADD CONSTRAINT fk_venda_item_1 FOREIGN KEY (produto_id) references produto(produto_id); 
ALTER TABLE venda_item ADD CONSTRAINT fk_venda_item_2 FOREIGN KEY (venda_id) references venda(venda_id); 
