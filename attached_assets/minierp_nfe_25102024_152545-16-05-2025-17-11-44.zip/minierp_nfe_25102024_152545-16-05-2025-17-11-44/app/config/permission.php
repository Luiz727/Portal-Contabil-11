<?php 
return[
    'host' => "",
    'name' => "app/database/banco_permission.db",
    'user' => "",
    'pass' => "",
    'type' => "sqlite",
    'prep' => "1",
    'slog' => "SystemSqlLogService"
];