<?php 
return[
    'host' => "",
    'name' => "app/database/banco_communication.db",
    'user' => "",
    'pass' => "",
    'type' => "sqlite",
    'prep' => "1",
    'slog' => "SystemSqlLogService"
];